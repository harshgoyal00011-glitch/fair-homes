/* ==========================================================================
   Fair Homes OS — Service Worker (App Shell Caching)
   Caches every HTML/CSS/JS/icon file so the app's UI loads instantly and
   works fully offline (even before any Firestore data syncs). Business
   data itself stays live/cloud-synced via Firebase (see js/cloud.js) —
   this worker is only responsible for the app's own code and assets.
   Bump CACHE_NAME whenever files change, so returning users get updates
   instead of a stale cached version.
   ========================================================================== */

const CACHE_NAME = 'fair-homes-os-v58';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './css/theme.css', './css/style.css', './css/owners.css', './css/properties.css',
  './css/rooms.css', './css/tenants.css', './css/finance.css', './css/maintenance.css',
  './css/reports.css', './css/notifications.css', './css/settings.css',
  './js/cloud.js', './js/access.js', './js/shared.js', './js/theme.js', './js/nav.js',
  './js/owners.js', './js/dashboard.js', './js/properties.js', './js/rooms.js', './js/bookings.js', './js/brokerageflats.js', './js/tenants.js', './js/socialmedia.js',
  './js/finance.js', './js/maintenance.js', './js/reports.js', './js/notifications.js',
  './js/settings.js', './js/trash.js', './js/search.js', './js/app.js',
  './icons/icon-192.png', './icons/icon-512.png', './icons/icon-maskable-512.png', './icons/apple-touch-icon.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
    // Note: no longer calls self.skipWaiting() automatically here — the
    // new version waits until the user taps "Update Now" (see app.js),
    // so an open session never gets its code swapped out unexpectedly.
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) => Promise.all(
      names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n))
    )).then(() => self.clients.claim())
  );
});

// App-shell files: cache-first (instant load, works offline).
// Everything else (e.g. Firebase/CDN calls): network-first, since that
// traffic needs to stay live for real-time sync.
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  const isAppShellFile = url.origin === self.location.origin;

  if (!isAppShellFile) return; // let Firebase/CDN requests go straight to network

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).catch(() => caches.match('./index.html'));
    })
  );
});
