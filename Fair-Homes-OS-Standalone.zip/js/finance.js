/* ==========================================================================
   Fair Homes OS — Finance Module (Phase 6)
   Rent Collection, Security Deposits, Brokerage, Management Fees, Expenses,
   Dashboard, and Tenant Payment History integration.
   Fully integrated with Owners / Properties / Rooms & Beds / Tenants.
   ========================================================================== */

const FinanceController = (() => {
  const KEYS = {
    rent: 'fh_rent_entries', deposit: 'fh_deposits', brokerage: 'fh_brokerage',
    fee: 'fh_management_fees', expense: 'fh_expenses', margin: 'fh_margin_income',
    advance: 'fh_owner_advances', bizExpense: 'fh_business_expenses', payout: 'fh_owner_payouts',
  };
  const SEQ = {
    rent: 'fh_rent_seq', deposit: 'fh_deposit_seq', brokerage: 'fh_brokerage_seq',
    fee: 'fh_fee_seq', expense: 'fh_expense_seq', margin: 'fh_margin_seq',
    advance: 'fh_advance_seq', bizExpense: 'fh_bizexpense_seq', payout: 'fh_payout_seq',
  };

  let rentEntries = [], deposits = [], brokerageEntries = [], managementFees = [], expenses = [], marginIncome = [];
  let ownerAdvances = [], businessExpenses = [], ownerPayouts = [];
  let editingRentId = null, editingDepositId = null, editingBrokerageId = null, editingFeeId = null, editingExpenseId = null;
  let editingAdvanceId = null, editingBizExpenseId = null;
  let refundContext = null; // { depositId, mode: 'refund' | 'forfeit' }

  const EXPENSE_CATEGORIES = ['Cleaning', 'Painting', 'Electrician', 'Plumber', 'Furniture', 'Appliances', 'Marketing', 'Maintenance', 'Miscellaneous'];
  const BIZ_EXPENSE_CATEGORIES = ['Advertisement', 'Board / Signage', 'Stationery', 'Food', 'Miscellaneous'];

  // ---------------- Storage ----------------
  function load() {
    try { rentEntries = JSON.parse(localStorage.getItem(KEYS.rent)) || []; } catch (e) { rentEntries = []; }
    try { deposits = JSON.parse(localStorage.getItem(KEYS.deposit)) || []; } catch (e) { deposits = []; }
    try { brokerageEntries = JSON.parse(localStorage.getItem(KEYS.brokerage)) || []; } catch (e) { brokerageEntries = []; }
    try { managementFees = JSON.parse(localStorage.getItem(KEYS.fee)) || []; } catch (e) { managementFees = []; }
    try { expenses = JSON.parse(localStorage.getItem(KEYS.expense)) || []; } catch (e) { expenses = []; }
    try { marginIncome = JSON.parse(localStorage.getItem(KEYS.margin)) || []; } catch (e) { marginIncome = []; }
    try { ownerAdvances = JSON.parse(localStorage.getItem(KEYS.advance)) || []; } catch (e) { ownerAdvances = []; }
    try { businessExpenses = JSON.parse(localStorage.getItem(KEYS.bizExpense)) || []; } catch (e) { businessExpenses = []; }
    try { ownerPayouts = JSON.parse(localStorage.getItem(KEYS.payout)) || []; } catch (e) { ownerPayouts = []; }

    CloudSync.watch('rentEntries', (arr) => { rentEntries = arr; localStorage.setItem(KEYS.rent, JSON.stringify(arr)); refreshActiveFinanceTab(); });
    CloudSync.watch('deposits', (arr) => { deposits = arr; localStorage.setItem(KEYS.deposit, JSON.stringify(arr)); refreshActiveFinanceTab(); });
    CloudSync.watch('brokerageEntries', (arr) => { brokerageEntries = arr; localStorage.setItem(KEYS.brokerage, JSON.stringify(arr)); refreshActiveFinanceTab(); });
    CloudSync.watch('managementFees', (arr) => { managementFees = arr; localStorage.setItem(KEYS.fee, JSON.stringify(arr)); refreshActiveFinanceTab(); });
    CloudSync.watch('expenses', (arr) => { expenses = arr; localStorage.setItem(KEYS.expense, JSON.stringify(arr)); refreshActiveFinanceTab(); });
    CloudSync.watch('marginIncome', (arr) => { marginIncome = arr; localStorage.setItem(KEYS.margin, JSON.stringify(arr)); refreshActiveFinanceTab(); });
    CloudSync.watch('ownerAdvances', (arr) => { ownerAdvances = arr; localStorage.setItem(KEYS.advance, JSON.stringify(arr)); refreshActiveFinanceTab(); });
    CloudSync.watch('businessExpenses', (arr) => { businessExpenses = arr; localStorage.setItem(KEYS.bizExpense, JSON.stringify(arr)); refreshActiveFinanceTab(); });
    CloudSync.watch('ownerPayouts', (arr) => { ownerPayouts = arr; localStorage.setItem(KEYS.payout, JSON.stringify(arr)); refreshActiveFinanceTab(); });
  }

  const CLOUD_COLLECTION = { rent: 'rentEntries', deposit: 'deposits', brokerage: 'brokerageEntries', fee: 'managementFees', expense: 'expenses', margin: 'marginIncome', advance: 'ownerAdvances', bizExpense: 'businessExpenses', payout: 'ownerPayouts' };
  function persist(type) {
    const map = { rent: rentEntries, deposit: deposits, brokerage: brokerageEntries, fee: managementFees, expense: expenses, margin: marginIncome, advance: ownerAdvances, bizExpense: businessExpenses, payout: ownerPayouts };
    localStorage.setItem(KEYS[type], JSON.stringify(map[type]));
    CloudSync.sync(CLOUD_COLLECTION[type], map[type]);
  }

  /** Re-renders whichever Finance sub-tab is currently visible — used
   *  whenever a cloud update arrives (from this device's own writes, or
   *  another device's), since we don't know which tab the user is on. */
  function refreshActiveFinanceTab() {
    const activeTab = document.querySelector('#financeSubnav .fs-tab.active');
    if (activeTab) switchSubTab(activeTab.dataset.sub);
  }

  function generateId() {
    return (crypto.randomUUID ? crypto.randomUUID() : 'id_' + Date.now() + '_' + Math.random().toString(16).slice(2));
  }
  function nextCode(type, prefix) {
    let seq = parseInt(localStorage.getItem(SEQ[type]) || '0', 10) + 1;
    localStorage.setItem(SEQ[type], String(seq));
    return prefix + '-' + String(seq).padStart(4, '0');
  }

  // ---------------- Shared Helpers ----------------
  function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function fmtDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (isNaN(d)) return iso;
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  }
  function fmtMonth(ym) {
    if (!ym) return '—';
    const [y, m] = ym.split('-');
    const d = new Date(Number(y), Number(m) - 1, 1);
    return d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
  }
  function todayIso() { return new Date().toISOString().slice(0, 10); }
  function currentMonthStr() { return new Date().toISOString().slice(0, 7); }

  function tenantLocationText(tenantId) {
    const tenant = TenantsController.getById(tenantId);
    if (!tenant || !tenant.currentAllocation) return 'Tenant has no active room allocation';
    const a = tenant.currentAllocation;
    const property = PropertiesController.getAll().find((p) => p.id === a.propertyId);
    const room = RoomsController.getRoomById(a.roomId);
    return `📍 ${property ? property.name : '—'} · Room ${room ? room.roomNumber : '—'}`;
  }

  function clearErrors(formId) { document.querySelectorAll('#' + formId + ' .form-error').forEach((el) => (el.textContent = '')); }
  function showErrors(errors) { Object.entries(errors).forEach(([id, msg]) => { const el = document.getElementById('err-' + id); if (el) el.textContent = msg; }); }

  function populatePropertySelect(selId, includeAll) {
    const sel = document.getElementById(selId);
    const current = sel.value;
    const properties = PropertiesController.getAll();
    sel.innerHTML = (includeAll ? '<option value="all">All Properties</option>' : '<option value="">Select Property</option>') +
      properties.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
    sel.value = current || (includeAll ? 'all' : '');
  }

  function populateTenantSelect(selId) {
    const sel = document.getElementById(selId);
    const current = sel.value;
    const tenants = TenantsController.getAll().filter((t) => t.currentAllocation); // only allocated tenants can generate finance entries
    sel.innerHTML = '<option value="">Select Tenant</option>' +
      tenants.map((t) => `<option value="${t.id}">${esc(t.fullName)} (${esc(t.tenantCode)})</option>`).join('');
    sel.value = current;
  }

  // ======================================================================
  // RENT COLLECTION
  // ======================================================================
  function computeRentTotals(f) {
    const totalPayable = f.monthlyRent + f.maintCharges + f.electricity + f.water + f.other + f.lateFee - f.discount;
    const remainingBalance = Math.max(0, totalPayable - f.amountPaid);
    return { totalPayable, remainingBalance };
  }

  function computeRentStatus(totalPayable, amountPaid, dueDate) {
    if (amountPaid >= totalPayable && totalPayable > 0) return 'Paid';
    if (amountPaid > 0) return 'Partial';
    if (dueDate && new Date(dueDate) < new Date(todayIso())) return 'Overdue';
    return 'Pending';
  }

  function suggestLateFee(dueDate, paymentDate) {
    if (!dueDate || !paymentDate) return 0;
    const due = new Date(dueDate), paid = new Date(paymentDate);
    const daysLate = Math.floor((paid - due) / (1000 * 60 * 60 * 24));
    if (daysLate <= 0) return 0;
    // Reads the configurable rate from Settings (Phase 10) if set, else ₹20/day default.
    let rate = 20;
    try {
      const bs = JSON.parse(localStorage.getItem('fh_business_settings'));
      if (bs && bs.lateFeeRate !== undefined && bs.lateFeeRate !== '') rate = Number(bs.lateFeeRate);
    } catch (e) { /* keep default */ }
    return daysLate * rate;
  }

  /**
   * Checks whether the tenant's property has an annual brokerage renewal
   * due (via PropertiesController — Property module owns that logic).
   * Purely informational + a confirm checkbox here; the actual Brokerage
   * entry + cycle advance only happens on Save, and only if checked.
   */
  function checkBrokerageDue(tenantId) {
    const box = document.getElementById('rentBrokerageDueBox');
    if (!tenantId || typeof PropertiesController === 'undefined') { box.classList.add('hidden'); return; }
    const tenant = TenantsController.getById(tenantId);
    const propertyId = tenant?.currentAllocation?.propertyId;
    if (!propertyId) { box.classList.add('hidden'); return; }
    const info = PropertiesController.getBrokerageDueInfo(propertyId);
    if (info.due) {
      document.getElementById('rentBrokerageDueText').textContent =
        `₹${info.amount} brokerage renewal for ${info.propertyName} was due on ${info.dueDate} (1-year cycle).`;
      document.getElementById('rentRecordBrokerage').checked = true;
      box.classList.remove('hidden');
    } else {
      box.classList.add('hidden');
    }
    checkOwnerDeductions(propertyId);
    checkTenantPendingBalance(tenantId);
    checkRoutineDue(propertyId);
    checkMaintenanceDue(tenantId);
    checkElectricityDue(tenantId);
  }

  /** Shows this tenant's own share of the property's electricity bill
   *  for the currently-selected rent month, if one has been entered
   *  and not yet collected — reads the month live so it re-checks
   *  whichever the manager picks, tenant or month, in either order. */
  function checkElectricityDue(tenantId) {
    const box = document.getElementById('rentElectricityDueBox');
    const month = document.getElementById('rentMonth').value;
    if (!tenantId || !month || typeof PropertiesController === 'undefined' || !PropertiesController.getTenantElectricityDue) { box.classList.add('hidden'); return; }
    const due = PropertiesController.getTenantElectricityDue(tenantId, month);
    if (due) {
      document.getElementById('rentElectricityDueText').textContent = `${due.days} din ke liए ₹${due.amount} — room-day ke hisaab se automatically calculate hua.`;
      box.dataset.billId = due.billId;
      box.dataset.amount = due.amount;
      box.classList.remove('hidden');
    } else {
      box.classList.add('hidden');
    }
  }

  /** Shows any Done Routine Checklist tasks (RO/AC/Inverter/Maid) whose
   *  billed cost hasn't yet been collected from the tenant — since this
   *  is meant to always ride along with rent, per the agreed flow. */
  function checkRoutineDue(propertyId) {
    const box = document.getElementById('rentRoutineDueBox');
    if (!propertyId || typeof MaintenanceController === 'undefined') { box.classList.add('hidden'); return; }
    const pendingTasks = MaintenanceController.getRoutinePendingBilling(propertyId);
    if (pendingTasks.length) {
      const total = pendingTasks.reduce((s, t) => s + t.billedCost, 0);
      const lines = pendingTasks.map((t) => `${t.category} (₹${t.billedCost})`).join(' + ');
      document.getElementById('rentRoutineDueText').textContent = `${lines} = ₹${total}`;
      box.dataset.taskIds = JSON.stringify(pendingTasks.map((t) => t.id));
      box.dataset.amount = total;
      box.classList.remove('hidden');
    } else {
      box.classList.add('hidden');
    }
  }

  /** Shows any Closed, tenant-approved maintenance tickets whose charge
   *  hasn't yet ridden along with a rent bill — same reasoning as
   *  Routine Due: this is meant to always come with the next rent. */
  function checkMaintenanceDue(tenantId) {
    const box = document.getElementById('rentMaintenanceDueBox');
    if (!tenantId || typeof MaintenanceController === 'undefined') { box.classList.add('hidden'); return; }
    const pendingTickets = MaintenanceController.getTenantPendingMaintenanceBilling(tenantId);
    if (pendingTickets.length) {
      const total = pendingTickets.reduce((s, t) => s + t.closingDetails.totalBilled, 0);
      const lines = pendingTickets.map((t) => `${t.category} (₹${t.closingDetails.totalBilled})`).join(' + ');
      document.getElementById('rentMaintenanceDueText').textContent = `${lines} = ₹${total}`;
      box.dataset.ticketIds = JSON.stringify(pendingTickets.map((t) => t.id));
      box.dataset.amount = total;
      box.classList.remove('hidden');
    } else {
      box.classList.add('hidden');
    }
  }

  /** Shows any unpaid/partial balance from this tenant's PREVIOUS rent
   *  entries, so the manager doesn't forget to carry it into this bill. */
  function checkTenantPendingBalance(tenantId) {
    const box = document.getElementById('rentTenantPendingBox');
    if (!tenantId) { box.classList.add('hidden'); return; }
    const pending = getTenantPendingBalance(tenantId);
    if (pending > 0) {
      document.getElementById('rentTenantPendingText').textContent = `₹${pending} pending from previous month(s)' rent.`;
      box.classList.remove('hidden');
    } else {
      box.classList.add('hidden');
    }
  }

  /** Sums remainingBalance across this tenant's past unpaid/partial rent
   *  entries — excludes whichever entry is currently being edited, so
   *  editing an existing partial entry doesn't count itself as "pending". */
  function getTenantPendingBalance(tenantId) {
    return rentEntries
      .filter((r) => r.tenantId === tenantId && r.id !== editingRentId && r.paymentStatus !== 'Paid')
      .reduce((s, r) => s + r.remainingBalance, 0);
  }

  /** Shows any unsettled Owner-borne maintenance costs for this tenant's
   *  property, so the manager can mark them settled while collecting rent. */
  function checkOwnerDeductions(propertyId) {
    const box = document.getElementById('rentOwnerDeductionBox');
    if (!propertyId || typeof PropertiesController === 'undefined') { box.classList.add('hidden'); return; }
    const total = getTotalOutstandingForProperty(propertyId);
    if (total > 0) {
      const active = getActiveAdvancesForProperty(propertyId);
      const lines = active.map((a) => `${a.reason || 'Advance'} — ₹${a.outstandingBalance} outstanding`).join(', ');
      document.getElementById('rentOwnerDeductionText').textContent = `₹${total} total outstanding (${lines}).`;
      document.getElementById('rentAdvanceAdjustAmount').value = total;
      box.dataset.propertyId = propertyId;
      box.classList.remove('hidden');
    } else {
      box.classList.add('hidden');
    }
  }

  function updateRentCalcBox() {
    const monthlyRent = Number(document.getElementById('rentMonthlyRent').value) || 0;
    const maintCharges = Number(document.getElementById('rentMaintCharges').value) || 0;
    const electricity = Number(document.getElementById('rentElectricity').value) || 0;
    const water = Number(document.getElementById('rentWater').value) || 0;
    const other = Number(document.getElementById('rentOther').value) || 0;
    const discount = Number(document.getElementById('rentDiscount').value) || 0;
    const lateFee = Number(document.getElementById('rentLateFee').value) || 0;
    const amountPaid = Number(document.getElementById('rentAmountPaid').value) || 0;

    const { totalPayable, remainingBalance } = computeRentTotals({ monthlyRent, maintCharges, electricity, water, other, discount, lateFee, amountPaid });

    document.getElementById('rentCalcBox').innerHTML = `
      <div class="calc-row"><span>Total Amount</span><span>₹${monthlyRent + maintCharges + electricity + water + other}</span></div>
      <div class="calc-row"><span>+ Late Fee</span><span>₹${lateFee}</span></div>
      <div class="calc-row"><span>− Discount</span><span>₹${discount}</span></div>
      <div class="calc-row total"><span>Total Payable</span><span>₹${totalPayable}</span></div>
      <div class="calc-row balance ${remainingBalance > 0 ? 'due' : 'clear'}"><span>Remaining Balance</span><span>₹${remainingBalance}</span></div>
    `;
    document.getElementById('rentExpectedDateGroup').classList.toggle('hidden', remainingBalance <= 0);
  }

  function openAddRentModal() {
    editingRentId = null;
    document.getElementById('rentModalTitle').textContent = 'Collect Rent';
    document.getElementById('rentForm').reset();
    document.getElementById('rentId').value = '';
    document.getElementById('rentLocationDisplay').textContent = '';
    document.getElementById('rentBrokerageDueBox').classList.add('hidden');
    document.getElementById('rentOwnerDeductionBox').classList.add('hidden');
    document.getElementById('rentTenantPendingBox').classList.add('hidden');
    document.getElementById('rentRoutineDueBox').classList.add('hidden');
    delete document.getElementById('rentRoutineDueBox').dataset.added;
    document.getElementById('rentMaintenanceDueBox').classList.add('hidden');
    delete document.getElementById('rentMaintenanceDueBox').dataset.added;
    document.getElementById('rentElectricityDueBox').classList.add('hidden');
    delete document.getElementById('rentElectricityDueBox').dataset.added;
    populateTenantSelect('rentTenant');
    document.getElementById('rentDueDate').value = todayIso();
    document.getElementById('rentExpectedPaymentDate').value = '';
    document.getElementById('rentExpectedDateGroup').classList.add('hidden');
    document.getElementById('rentPaymentMethod').value = 'Cash';
    clearErrors('rentForm');
    updateRentCalcBox();
    document.getElementById('rentModalOverlay').classList.add('open');
  }

  function openEditRentModal(id) {
    const r = rentEntries.find((x) => x.id === id);
    if (!r) return;
    editingRentId = id;
    document.getElementById('rentModalTitle').textContent = 'Edit Rent Entry';
    populateTenantSelect('rentTenant');
    document.getElementById('rentId').value = r.id;
    document.getElementById('rentTenant').value = r.tenantId;
    document.getElementById('rentLocationDisplay').textContent = tenantLocationText(r.tenantId);
    document.getElementById('rentBrokerageDueBox').classList.add('hidden');
    document.getElementById('rentOwnerDeductionBox').classList.add('hidden');
    document.getElementById('rentTenantPendingBox').classList.add('hidden');
    document.getElementById('rentRoutineDueBox').classList.add('hidden');
    delete document.getElementById('rentRoutineDueBox').dataset.added;
    document.getElementById('rentMaintenanceDueBox').classList.add('hidden');
    delete document.getElementById('rentMaintenanceDueBox').dataset.added;
    document.getElementById('rentElectricityDueBox').classList.add('hidden');
    delete document.getElementById('rentElectricityDueBox').dataset.added;
    document.getElementById('rentMonth').value = r.rentMonth;
    document.getElementById('rentDueDate').value = r.dueDate;
    document.getElementById('rentPaymentDate').value = r.paymentDate || '';
    document.getElementById('rentMonthlyRent').value = r.monthlyRent;
    document.getElementById('rentMaintCharges').value = r.maintCharges;
    document.getElementById('rentElectricity').value = r.electricity;
    document.getElementById('rentWater').value = r.water;
    document.getElementById('rentOther').value = r.other;
    document.getElementById('rentDiscount').value = r.discount;
    document.getElementById('rentLateFee').value = r.lateFee;
    document.getElementById('rentAmountPaid').value = r.amountPaid;
    document.getElementById('rentPaymentMethod').value = r.paymentMethod;
    document.getElementById('rentTxnRef').value = r.transactionRef || '';
    document.getElementById('rentExpectedPaymentDate').value = r.expectedPaymentDate || '';
    document.getElementById('rentNotes').value = r.notes || '';
    clearErrors('rentForm');
    updateRentCalcBox();
    document.getElementById('rentModalOverlay').classList.add('open');
  }

  function closeRentModal() { document.getElementById('rentModalOverlay').classList.remove('open'); editingRentId = null; }

  function handleSaveRent() {
    const tenantId = document.getElementById('rentTenant').value;
    const rentMonth = document.getElementById('rentMonth').value;
    const dueDate = document.getElementById('rentDueDate').value;
    const paymentDate = document.getElementById('rentPaymentDate').value;
    const monthlyRent = document.getElementById('rentMonthlyRent').value;
    const maintCharges = document.getElementById('rentMaintCharges').value || 0;
    const electricity = document.getElementById('rentElectricity').value || 0;
    const water = document.getElementById('rentWater').value || 0;
    const other = document.getElementById('rentOther').value || 0;
    const discount = document.getElementById('rentDiscount').value || 0;
    const lateFee = document.getElementById('rentLateFee').value || 0;
    const amountPaid = document.getElementById('rentAmountPaid').value;
    const paymentMethod = document.getElementById('rentPaymentMethod').value;
    const transactionRef = document.getElementById('rentTxnRef').value.trim();
    const expectedPaymentDate = document.getElementById('rentExpectedPaymentDate').value || null;
    const notes = document.getElementById('rentNotes').value.trim();

    const errors = {};
    if (!tenantId) errors.rentTenant = 'Select a tenant';
    if (!rentMonth) errors.rentMonth = 'Select the rent month';
    else {
      const dup = rentEntries.some((r) => r.tenantId === tenantId && r.rentMonth === rentMonth && r.id !== editingRentId);
      if (dup) errors.rentMonth = 'Rent has already been collected for this tenant for this month';
    }
    if (!dueDate) errors.rentDueDate = 'Due date is required';
    if (monthlyRent === '' || Number(monthlyRent) < 0) errors.rentMonthlyRent = 'Enter the monthly rent';
    if (amountPaid === '' || Number(amountPaid) < 0) errors.rentAmountPaid = 'Enter the amount paid (0 if unpaid)';

    clearErrors('rentForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const f = {
      monthlyRent: Number(monthlyRent), maintCharges: Number(maintCharges), electricity: Number(electricity),
      water: Number(water), other: Number(other), discount: Number(discount), lateFee: Number(lateFee), amountPaid: Number(amountPaid),
    };
    const { totalPayable, remainingBalance } = computeRentTotals(f);
    const paymentStatus = computeRentStatus(totalPayable, f.amountPaid, dueDate);

    const tenant = TenantsController.getById(tenantId);
    const a = tenant?.currentAllocation;
    const now = new Date().toISOString();
    const rentData = {
      tenantId, propertyId: a?.propertyId || null, roomId: a?.roomId || null,
      rentMonth, dueDate, paymentDate: paymentDate || null,
      ...f, totalPayable, remainingBalance, paymentStatus,
      paymentMethod, transactionRef, expectedPaymentDate, notes, updatedAt: now,
    };

    if (editingRentId) {
      const idx = rentEntries.findIndex((r) => r.id === editingRentId);
      if (idx !== -1) rentEntries[idx] = { ...rentEntries[idx], ...rentData };
    } else {
      rentEntries.unshift({ id: generateId(), rentCode: nextCode('rent', 'RENT'), createdAt: now, ...rentData });

      // Auto-record annual brokerage renewal, only when collecting a NEW
      // rent entry (not while editing an existing one), only if due, and
      // only if the manager left the confirmation checkbox checked.
      if (rentData.propertyId && typeof PropertiesController !== 'undefined') {
        const brokerageInfo = PropertiesController.getBrokerageDueInfo(rentData.propertyId);
        const recordChecked = document.getElementById('rentRecordBrokerage').checked;
        if (brokerageInfo.due && recordChecked) {
          brokerageEntries.unshift({
            id: generateId(), brokerageCode: nextCode('brokerage', 'BRK'), type: 'Owner',
            tenantId, propertyId: rentData.propertyId, amount: brokerageInfo.amount,
            brokerName: '', status: 'Paid', paymentDate: todayIso(),
            notes: 'Auto-recorded 1-year brokerage renewal', createdAt: now, updatedAt: now,
          });
          persist('brokerage');
          PropertiesController.advanceBrokerageCycle(rentData.propertyId);
        }
      }

      // Apply the manager-confirmed advance adjustment (can be a partial
      // amount — whatever's left over automatically carries forward to
      // the next rent cycle for this property).
      const deductionBox = document.getElementById('rentOwnerDeductionBox');
      if (!deductionBox.classList.contains('hidden')) {
        const adjustAmount = Number(document.getElementById('rentAdvanceAdjustAmount').value) || 0;
        if (adjustAmount > 0 && deductionBox.dataset.propertyId) {
          adjustAdvances(deductionBox.dataset.propertyId, adjustAmount, editingRentId || null);
        }
      }

      // Mark Routine Checklist tasks as collected-from-tenant, but only
      // if the manager explicitly clicked "Add to Bill" — never silently,
      // since that would misrepresent money that wasn't actually included.
      const routineBox = document.getElementById('rentRoutineDueBox');
      if (routineBox.dataset.added === 'true' && typeof MaintenanceController !== 'undefined') {
        try {
          const taskIds = JSON.parse(routineBox.dataset.taskIds || '[]');
          if (taskIds.length) MaintenanceController.markRoutineTasksCollected(taskIds);
        } catch (e) { /* nothing to settle */ }
      }
      const maintenanceBox = document.getElementById('rentMaintenanceDueBox');
      if (maintenanceBox.dataset.added === 'true' && typeof MaintenanceController !== 'undefined') {
        try {
          const ticketIds = JSON.parse(maintenanceBox.dataset.ticketIds || '[]');
          if (ticketIds.length) MaintenanceController.markMaintenanceTicketsCollected(ticketIds);
        } catch (e) { /* nothing to settle */ }
      }
      const electricityBox = document.getElementById('rentElectricityDueBox');
      if (electricityBox.dataset.added === 'true' && typeof PropertiesController !== 'undefined' && PropertiesController.markElectricityShareCollected) {
        PropertiesController.markElectricityShareCollected(electricityBox.dataset.billId, tenantId);
      }
    }
    persist('rent');
    closeRentModal();
    populateRentFilters();
    renderRentList();
    renderDashboard();
  }

  function handleDeleteRent(id) {
    const r = rentEntries.find((x) => x.id === id);
    if (!r) return;
    ConfirmModal.show('Delete this rent entry? You can restore it later from Settings → Trash.', () => {
      TrashController.moveToTrash('rentEntry', r, r.rentCode);
      rentEntries = rentEntries.filter((x) => x.id !== id);
      persist('rent');
      renderRentList();
      renderDashboard();
    });
  }

  function populateRentFilters() {
    populatePropertySelect('rentPropertyFilter', true);
    const months = [...new Set(rentEntries.map((r) => r.rentMonth))].sort().reverse();
    const sel = document.getElementById('rentMonthFilter');
    const current = sel.value;
    sel.innerHTML = '<option value="all">All Months</option>' + months.map((m) => `<option value="${m}">${fmtMonth(m)}</option>`).join('');
    sel.value = current || 'all';

    const years = [...new Set(rentEntries.map((r) => r.rentMonth.split('-')[0]))].sort().reverse();
    const yearSel = document.getElementById('rentYearFilter');
    const currentYear = yearSel.value;
    yearSel.innerHTML = '<option value="all">All Years</option>' + years.map((y) => `<option value="${y}">${y}</option>`).join('');
    yearSel.value = currentYear || 'all';
  }

  function renderRentList() {
    const query = (document.getElementById('rentSearchInput')?.value || '').toLowerCase().trim();
    const propFilter = document.getElementById('rentPropertyFilter')?.value || 'all';
    const monthFilter = document.getElementById('rentMonthFilter')?.value || 'all';
    const yearFilter = document.getElementById('rentYearFilter')?.value || 'all';
    const statusFilter = document.getElementById('rentStatusFilter')?.value || 'all';
    const methodFilter = document.getElementById('rentMethodFilter')?.value || 'all';

    const list = rentEntries.filter((r) => {
      const tenant = TenantsController.getById(r.tenantId);
      const tenantName = tenant ? tenant.fullName.toLowerCase() : '';
      return tenantName.includes(query) &&
        (propFilter === 'all' || r.propertyId === propFilter) &&
        (monthFilter === 'all' || r.rentMonth === monthFilter) &&
        (yearFilter === 'all' || r.rentMonth.startsWith(yearFilter)) &&
        (statusFilter === 'all' || r.paymentStatus === statusFilter) &&
        (methodFilter === 'all' || r.paymentMethod === methodFilter);
    });

    const el = document.getElementById('rentList');
    if (!list.length) {
      el.innerHTML = `<div class="empty-state"><div class="ico">💰</div><div class="title">${rentEntries.length === 0 ? 'No rent entries yet' : 'No matching entries'}</div><div class="desc">${rentEntries.length === 0 ? 'Collect your first rent payment above.' : 'Try a different search or filter.'}</div></div>`;
      return;
    }

    const statusClassMap = { Paid: 'pay-paid', Partial: 'pay-partial', Pending: 'pay-pending', Overdue: 'pay-overdue' };

    el.innerHTML = list.map((r) => {
      const tenant = TenantsController.getById(r.tenantId);
      const property = PropertiesController.getAll().find((p) => p.id === r.propertyId);
      const room = r.roomId ? RoomsController.getRoomById(r.roomId) : null;
      const locationBit = property ? `${esc(property.name)}${room ? ' · Room ' + esc(room.roomNumber) : ''}` : '—';
      return `
        <div class="finance-list-row" data-id="${r.id}">
          <div class="fr-main">
            <div class="fr-title">${esc(tenant ? tenant.fullName : 'Unknown Tenant')} · ${fmtMonth(r.rentMonth)}</div>
            <div class="fr-sub">${esc(r.rentCode)} · ${locationBit} · Due ${fmtDate(r.dueDate)} · ${esc(r.paymentMethod)}</div>
          </div>
          <div class="fr-amount">
            <div class="amt income">₹${r.amountPaid} / ₹${r.totalPayable}</div>
            <span class="badge ${statusClassMap[r.paymentStatus]}">${r.paymentStatus}</span>
            <div class="fr-actions">
              <button class="btn small secondary rent-edit-btn" data-id="${r.id}">Edit</button>
              ${tenant && tenant.mobile ? `<button class="btn small secondary rent-receipt-btn" data-id="${r.id}">Share Receipt</button>` : ''}
              <button class="btn small secondary rent-receipt-pdf-btn" data-id="${r.id}">Download Receipt (PDF)</button>
              <button class="btn small rent-delete-btn" data-id="${r.id}" style="background:var(--error);">Delete</button>
            </div>
          </div>
        </div>`;
    }).join('');

    el.querySelectorAll('.rent-edit-btn').forEach((btn) => btn.addEventListener('click', () => openEditRentModal(btn.dataset.id)));
    el.querySelectorAll('.rent-receipt-btn').forEach((btn) => btn.addEventListener('click', () => shareRentReceipt(btn.dataset.id)));
    el.querySelectorAll('.rent-receipt-pdf-btn').forEach((btn) => btn.addEventListener('click', () => generateTenantReceiptPdf(btn.dataset.id)));
    el.querySelectorAll('.rent-delete-btn').forEach((btn) => btn.addEventListener('click', () => handleDeleteRent(btn.dataset.id)));
  }

  /** Sends a WhatsApp message to the tenant with a plain-text rent
   *  receipt — company name, amount, month, balance if any. Uses the
   *  wa.me click-to-chat link (text only; a PDF attachment would need
   *  the Web Share API, which isn't reliably available everywhere). */
  function shareRentReceipt(rentId) {
    const r = rentEntries.find((x) => x.id === rentId);
    if (!r) return;
    const tenant = TenantsController.getById(r.tenantId);
    if (!tenant || !tenant.mobile) { alert('No mobile number on file for this tenant.'); return; }
    let companyName = 'Fair Homes';
    try { const c = JSON.parse(localStorage.getItem('fh_company_profile')); if (c && c.companyName) companyName = c.companyName; } catch (e) { /* use default */ }
    const balanceLine = r.remainingBalance > 0 ? `\nBalance Due: ₹${r.remainingBalance}` : '\nStatus: Fully Paid ✅';
    const text = `${companyName} — Rent Receipt\n\nReceipt No: ${r.rentCode}\nTenant: ${tenant.fullName}\nMonth: ${fmtMonth(r.rentMonth)}\nAmount Paid: ₹${r.amountPaid}\nDate: ${fmtDate(r.paymentDate || r.dueDate)}\nPayment Mode: ${r.paymentMethod}${balanceLine}\n\nThank you!`;
    shareViaWhatsApp(tenant.mobile, text);
  }

  /** Generates a properly laid-out Tenant Receipt PDF — Fair Homes
   *  header, tenant/property/room identity, full charge breakdown,
   *  payment details, and remaining balance. Opens in a new tab first
   *  (browser's own PDF viewer has Download/Share/Print built in),
   *  falling back to a direct download if popups are blocked. */
  function generateTenantReceiptPdf(rentId) {
    const r = rentEntries.find((x) => x.id === rentId);
    if (!r) return;
    if (typeof window.jspdf === 'undefined' || typeof window.jspdf.jsPDF !== 'function') {
      alert('PDF library (jsPDF) failed to load from the CDN — check your internet connection.');
      return;
    }
    const tenant = TenantsController.getById(r.tenantId);
    const property = PropertiesController.getAll().find((p) => p.id === r.propertyId);
    const room = r.roomId ? RoomsController.getRoomById(r.roomId) : null;
    let companyName = 'Fair Homes';
    try { const c = JSON.parse(localStorage.getItem('fh_company_profile')); if (c && c.companyName) companyName = c.companyName; } catch (e) { /* use default */ }

    const jsPDFCtor = window.jspdf.jsPDF;
    const doc = new jsPDFCtor();
    let y = 18;

    doc.setFontSize(18); doc.setFont(undefined, 'bold');
    doc.text(companyName, 14, y);
    doc.setFontSize(11); doc.setFont(undefined, 'normal');
    doc.text('Rent Receipt', 14, y + 7);
    doc.setFontSize(9);
    doc.text('Receipt No: ' + r.rentCode, 196, y, { align: 'right' });
    doc.text('Date: ' + fmtDate(r.paymentDate || r.dueDate), 196, y + 5, { align: 'right' });
    y += 16;
    doc.setLineWidth(0.3); doc.line(14, y, 196, y); y += 8;

    doc.setFontSize(10); doc.setFont(undefined, 'bold');
    doc.text('Tenant Details', 14, y); y += 6;
    doc.setFont(undefined, 'normal');
    doc.text('Name: ' + (tenant ? tenant.fullName : '—'), 14, y);
    doc.text('Mobile: ' + (tenant ? tenant.mobile : '—'), 110, y); y += 6;
    doc.text('Property: ' + (property ? property.name : '—'), 14, y); y += 6;
    doc.text('Room: ' + (room ? room.roomNumber : '—') + '   Month: ' + fmtMonth(r.rentMonth), 14, y); y += 10;

    doc.setFont(undefined, 'bold'); doc.text('Charges', 14, y); y += 7;
    doc.setFont(undefined, 'normal');
    const chargeRows = [
      ['Monthly Rent', r.monthlyRent],
      ['Maintenance / Work Charges', r.maintCharges || 0],
      ['Electricity', r.electricity || 0],
      ['Water', r.water || 0],
      ['Other Charges', r.other || 0],
      ['Late Fee', r.lateFee || 0],
      ['Discount', -(r.discount || 0)],
    ].filter((row) => row[1] !== 0);
    chargeRows.forEach(([label, amt]) => {
      doc.text(label, 20, y);
      doc.text((amt < 0 ? '-₹' + Math.abs(amt) : '₹' + amt), 196, y, { align: 'right' });
      y += 6;
    });
    doc.setLineWidth(0.2); doc.line(14, y, 196, y); y += 6;
    doc.setFont(undefined, 'bold');
    doc.text('Total Amount', 14, y); doc.text('₹' + r.totalPayable, 196, y, { align: 'right' }); y += 10;

    doc.setFillColor(245, 245, 245);
    doc.rect(14, y - 5, 182, r.remainingBalance > 0 ? 26 : 20, 'F');
    doc.text('Amount Received', 20, y); doc.text('₹' + r.amountPaid, 190, y, { align: 'right' }); y += 6;
    doc.setFont(undefined, 'normal');
    doc.text('Payment Date: ' + fmtDate(r.paymentDate || '—'), 20, y);
    doc.text('Payment Method: ' + (r.paymentMethod || '—'), 110, y); y += 6;
    if (r.remainingBalance > 0) {
      doc.setFont(undefined, 'bold'); doc.setTextColor(200, 0, 0);
      doc.text('Remaining / Pending Amount: ₹' + r.remainingBalance, 20, y);
      doc.setTextColor(0, 0, 0);
      y += 6;
    } else {
      doc.setFont(undefined, 'bold'); doc.setTextColor(0, 130, 0);
      doc.text('Status: Fully Paid', 20, y);
      doc.setTextColor(0, 0, 0);
      y += 6;
    }

    y += 10;
    doc.setFontSize(8); doc.setFont(undefined, 'italic');
    doc.text('This is a system-generated receipt from ' + companyName + '.', 14, y);

    const blob = doc.output('blob');
    const url = URL.createObjectURL(blob);
    let opened = null;
    try { opened = window.open(url, '_blank'); } catch (e) { opened = null; }
    if (!opened) {
      const a = document.createElement('a');
      a.href = url; a.download = 'Receipt_' + r.rentCode + '.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  // ======================================================================
  // SECURITY DEPOSITS
  // ======================================================================
  function openAddDepositModal() {
    editingDepositId = null;
    document.getElementById('depositModalTitle').textContent = 'Receive Deposit';
    document.getElementById('depositForm').reset();
    document.getElementById('depositId').value = '';
    document.getElementById('depositLocationDisplay').textContent = '';
    populateTenantSelect('depositTenant');
    document.getElementById('depositDate').value = todayIso();
    clearErrors('depositForm');
    document.getElementById('depositModalOverlay').classList.add('open');
  }

  function openEditDepositModal(id) {
    const d = deposits.find((x) => x.id === id);
    if (!d) return;
    if (d.status !== 'Held') { alert('Only deposits still fully "Held" can be edited. Use Refund/Forfeit actions instead.'); return; }
    editingDepositId = id;
    document.getElementById('depositModalTitle').textContent = 'Edit Deposit';
    populateTenantSelect('depositTenant');
    document.getElementById('depositId').value = d.id;
    document.getElementById('depositTenant').value = d.tenantId;
    document.getElementById('depositLocationDisplay').textContent = tenantLocationText(d.tenantId);
    document.getElementById('depositAmount').value = d.amount;
    document.getElementById('depositDate').value = d.depositDate;
    clearErrors('depositForm');
    document.getElementById('depositModalOverlay').classList.add('open');
  }

  function closeDepositModal() { document.getElementById('depositModalOverlay').classList.remove('open'); editingDepositId = null; }

  function handleSaveDeposit() {
    const tenantId = document.getElementById('depositTenant').value;
    const amount = document.getElementById('depositAmount').value;
    const depositDate = document.getElementById('depositDate').value;

    const errors = {};
    if (!tenantId) errors.depositTenant = 'Select a tenant';
    if (amount === '' || Number(amount) <= 0) errors.depositAmount = 'Enter a valid deposit amount';
    if (!depositDate) errors.depositDate = 'Deposit date is required';

    clearErrors('depositForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const tenant = TenantsController.getById(tenantId);
    const propertyId = tenant?.currentAllocation?.propertyId || null;
    const now = new Date().toISOString();

    if (editingDepositId) {
      const idx = deposits.findIndex((d) => d.id === editingDepositId);
      if (idx !== -1) deposits[idx] = { ...deposits[idx], tenantId, propertyId, amount: Number(amount), depositDate, updatedAt: now };
    } else {
      deposits.unshift({
        id: generateId(), depositCode: nextCode('deposit', 'DEP'), tenantId, propertyId,
        amount: Number(amount), depositDate, refundDate: null, status: 'Held', refundedAmount: 0,
        refundNotes: '', createdAt: now, updatedAt: now,
      });
    }
    persist('deposit');
    closeDepositModal();
    populateDepositFilters();
    renderDepositsList();
    renderDashboard();
  }

  function handleDeleteDeposit(id) {
    const d = deposits.find((x) => x.id === id);
    if (!d) return;
    ConfirmModal.show('Delete this deposit record? You can restore it later from Settings → Trash.', () => {
      TrashController.moveToTrash('deposit', d, d.depositCode || 'Deposit');
      deposits = deposits.filter((x) => x.id !== id);
      persist('deposit');
      renderDepositsList();
      renderDashboard();
    });
  }

  function openRefundModal(depositId, mode, prefillAmount) {
    const d = deposits.find((x) => x.id === depositId);
    if (!d) return;
    refundContext = { depositId, mode };
    const remaining = d.amount - d.refundedAmount;
    const tenant = TenantsController.getById(d.tenantId);

    document.getElementById('refundModalTitle').textContent = mode === 'forfeit' ? 'Forfeit Deposit' : 'Refund Deposit';
    document.getElementById('refundDepositInfo').innerHTML = `
      <div class="detail-item"><div class="di-label">Tenant</div><div class="di-value">${esc(tenant ? tenant.fullName : '—')}</div></div>
      <div class="detail-item"><div class="di-label">Total Deposit</div><div class="di-value">₹${d.amount}</div></div>
      <div class="detail-item"><div class="di-label">Already Refunded</div><div class="di-value">₹${d.refundedAmount}</div></div>
      <div class="detail-item"><div class="di-label">Remaining Held</div><div class="di-value">₹${remaining}</div></div>
    `;

    document.getElementById('refundForm').reset();
    document.getElementById('refundDate').value = todayIso();
    clearErrors('refundForm');

    if (mode === 'forfeit') {
      document.getElementById('refundAmountGroup').style.display = 'none';
    } else {
      document.getElementById('refundAmountGroup').style.display = 'block';
      document.getElementById('refundAmount').value = (prefillAmount !== undefined && prefillAmount !== null) ? Math.min(prefillAmount, remaining) : remaining;
      document.getElementById('refundSaveBtn').textContent = 'Confirm Refund';
    }
    document.getElementById('refundModalOverlay').classList.add('open');
  }

  function closeRefundModal() { document.getElementById('refundModalOverlay').classList.remove('open'); refundContext = null; }

  function handleSaveRefund() {
    if (!refundContext) return;
    const d = deposits.find((x) => x.id === refundContext.depositId);
    if (!d) return;
    const refundDate = document.getElementById('refundDate').value;
    const notes = document.getElementById('refundNotes').value.trim();
    const errors = {};
    if (!refundDate) errors.refundDate = 'Date is required';

    if (refundContext.mode === 'forfeit') {
      clearErrors('refundForm');
      if (Object.keys(errors).length) { showErrors(errors); return; }
      d.status = 'Forfeited';
      d.refundDate = refundDate;
      d.refundNotes = notes;
    } else {
      const refundAmount = document.getElementById('refundAmount').value;
      const remaining = d.amount - d.refundedAmount;
      if (refundAmount === '' || Number(refundAmount) <= 0) errors.refundAmount = 'Enter a valid refund amount';
      else if (Number(refundAmount) > remaining) errors.refundAmount = `Cannot exceed remaining held amount (₹${remaining})`;

      clearErrors('refundForm');
      if (Object.keys(errors).length) { showErrors(errors); return; }

      d.refundedAmount += Number(refundAmount);
      d.refundDate = refundDate;
      d.refundNotes = notes;
      d.status = d.refundedAmount >= d.amount ? 'Refunded' : 'Partially Refunded';
    }
    d.updatedAt = new Date().toISOString();
    persist('deposit');
    closeRefundModal();
    renderDepositsList();
    renderDashboard();
  }

  function populateDepositFilters() { populatePropertySelect('depositPropertyFilter', true); }

  function renderDepositsList() {
    const query = (document.getElementById('depositSearchInput')?.value || '').toLowerCase().trim();
    const propFilter = document.getElementById('depositPropertyFilter')?.value || 'all';
    const statusFilter = document.getElementById('depositStatusFilter')?.value || 'all';

    const statusClassMap = { Held: 'dep-held', Refunded: 'dep-refunded', 'Partially Refunded': 'dep-partial', Forfeited: 'dep-forfeited' };

    const list = deposits.filter((d) => {
      const tenant = TenantsController.getById(d.tenantId);
      const name = tenant ? tenant.fullName.toLowerCase() : '';
      return name.includes(query) && (propFilter === 'all' || d.propertyId === propFilter) && (statusFilter === 'all' || d.status === statusFilter);
    });

    const el = document.getElementById('depositsList');
    if (!list.length) {
      el.innerHTML = `<div class="empty-state"><div class="ico">🔒</div><div class="title">${deposits.length === 0 ? 'No deposits yet' : 'No matching deposits'}</div><div class="desc">${deposits.length === 0 ? 'Record your first security deposit above.' : 'Try a different search or filter.'}</div></div>`;
      return;
    }

    el.innerHTML = list.map((d) => {
      const tenant = TenantsController.getById(d.tenantId);
      const property = PropertiesController.getAll().find((p) => p.id === d.propertyId);
      return `
        <div class="finance-list-row">
          <div class="fr-main">
            <div class="fr-title">${esc(tenant ? tenant.fullName : 'Unknown Tenant')}</div>
            <div class="fr-sub">${esc(d.depositCode)} · ${esc(property ? property.name : '—')} · Deposited ${fmtDate(d.depositDate)}${d.refundedAmount ? ' · Refunded ₹' + d.refundedAmount : ''}</div>
          </div>
          <div class="fr-amount">
            <div class="amt income">₹${d.amount}</div>
            <span class="badge ${statusClassMap[d.status]}">${d.status}</span>
            <div class="fr-actions">
              ${d.status === 'Held' ? `<button class="btn small secondary dep-edit-btn" data-id="${d.id}">Edit</button>` : ''}
              ${d.status === 'Held' || d.status === 'Partially Refunded' ? `<button class="btn small dep-refund-btn" data-id="${d.id}">Refund</button><button class="btn small dep-forfeit-btn" data-id="${d.id}" style="background:var(--error);">Forfeit</button>` : ''}
              <button class="btn small dep-delete-btn" data-id="${d.id}" style="background:var(--error);">Delete</button>
            </div>
          </div>
        </div>`;
    }).join('');

    el.querySelectorAll('.dep-edit-btn').forEach((b) => b.addEventListener('click', () => openEditDepositModal(b.dataset.id)));
    el.querySelectorAll('.dep-refund-btn').forEach((b) => b.addEventListener('click', () => openRefundModal(b.dataset.id, 'refund')));
    el.querySelectorAll('.dep-forfeit-btn').forEach((b) => b.addEventListener('click', () => openRefundModal(b.dataset.id, 'forfeit')));
    el.querySelectorAll('.dep-delete-btn').forEach((b) => b.addEventListener('click', () => handleDeleteDeposit(b.dataset.id)));
  }

  // ======================================================================
  // BROKERAGE
  // ======================================================================
  function toggleBrokerageTypeFields() {
    const type = document.getElementById('brokerageType').value;
    document.getElementById('brokerageTenantGroup').classList.toggle('hidden', type !== 'Tenant');
    document.getElementById('brokeragePropertyGroup').classList.toggle('hidden', type !== 'Owner');
  }

  function openAddBrokerageModal() {
    editingBrokerageId = null;
    document.getElementById('brokerageModalTitle').textContent = 'Add Brokerage';
    document.getElementById('brokerageForm').reset();
    document.getElementById('brokerageId').value = '';
    document.getElementById('brokerageLocationDisplay').textContent = '';
    document.getElementById('brokerageType').value = 'Tenant';
    toggleBrokerageTypeFields();
    populateTenantSelect('brokerageTenant');
    populatePropertySelect('brokeragePropertySelect', false);
    document.getElementById('brokerageStatus').value = 'Pending';
    clearErrors('brokerageForm');
    document.getElementById('brokerageModalOverlay').classList.add('open');
  }

  function openEditBrokerageModal(id) {
    const b = brokerageEntries.find((x) => x.id === id);
    if (!b) return;
    editingBrokerageId = id;
    document.getElementById('brokerageModalTitle').textContent = 'Edit Brokerage';
    populateTenantSelect('brokerageTenant');
    populatePropertySelect('brokeragePropertySelect', false);
    document.getElementById('brokerageId').value = b.id;
    document.getElementById('brokerageType').value = b.type || 'Tenant';
    toggleBrokerageTypeFields();
    document.getElementById('brokerageTenant').value = b.tenantId || '';
    document.getElementById('brokeragePropertySelect').value = b.propertyId || '';
    document.getElementById('brokerageLocationDisplay').textContent = b.tenantId ? tenantLocationText(b.tenantId) : '';
    document.getElementById('brokerageAmount').value = b.amount;
    document.getElementById('brokerName').value = b.brokerName || '';
    document.getElementById('brokerageStatus').value = b.status;
    document.getElementById('brokeragePaymentDate').value = b.paymentDate || '';
    clearErrors('brokerageForm');
    document.getElementById('brokerageModalOverlay').classList.add('open');
  }

  function closeBrokerageModal() { document.getElementById('brokerageModalOverlay').classList.remove('open'); editingBrokerageId = null; }

  function handleSaveBrokerage() {
    const type = document.getElementById('brokerageType').value;
    const tenantId = type === 'Tenant' ? document.getElementById('brokerageTenant').value : '';
    const propertySelectVal = document.getElementById('brokeragePropertySelect').value;
    const amount = document.getElementById('brokerageAmount').value;
    const brokerName = document.getElementById('brokerName').value.trim();
    const status = document.getElementById('brokerageStatus').value;
    const paymentDate = document.getElementById('brokeragePaymentDate').value;

    const errors = {};
    if (type === 'Tenant' && !tenantId) errors.brokerageTenant = 'Select a tenant';
    if (type === 'Owner' && !propertySelectVal) errors.brokeragePropertySelect = 'Select a property';
    if (amount === '' || Number(amount) < 0) errors.brokerageAmount = 'Enter a valid amount';

    clearErrors('brokerageForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const tenant = type === 'Tenant' ? TenantsController.getById(tenantId) : null;
    const propertyId = type === 'Tenant' ? (tenant?.currentAllocation?.propertyId || null) : propertySelectVal;
    const now = new Date().toISOString();

    if (editingBrokerageId) {
      const idx = brokerageEntries.findIndex((b) => b.id === editingBrokerageId);
      if (idx !== -1) brokerageEntries[idx] = { ...brokerageEntries[idx], type, tenantId: tenantId || null, propertyId, amount: Number(amount), brokerName, status, paymentDate: paymentDate || null, updatedAt: now };
    } else {
      brokerageEntries.unshift({ id: generateId(), brokerageCode: nextCode('brokerage', 'BRK'), type, tenantId: tenantId || null, propertyId, amount: Number(amount), brokerName, status, paymentDate: paymentDate || null, createdAt: now, updatedAt: now });
    }
    persist('brokerage');
    closeBrokerageModal();
    populatePropertySelect('brokeragePropertyFilter', true);
    renderBrokerageList();
    renderDashboard();
  }

  function handleDeleteBrokerage(id) {
    const b = brokerageEntries.find((x) => x.id === id);
    if (!b) return;
    ConfirmModal.show('Delete this brokerage entry? You can restore it later from Settings → Trash.', () => {
      TrashController.moveToTrash('brokerage', b, b.brokerageCode || 'Brokerage');
      brokerageEntries = brokerageEntries.filter((x) => x.id !== id);
      persist('brokerage');
      renderBrokerageList();
      renderDashboard();
    });
  }

  /**
   * Reference list of each property's configured Owner Brokerage % —
   * this is what makes the % visible in Finance even before it's ever
   * been collected/triggered as an actual transaction below.
   */
  function renderOwnerBrokerageConfig() {
    const box = document.getElementById('ownerBrokerageConfigList');
    if (!box || typeof PropertiesController === 'undefined') return;
    const properties = PropertiesController.getAll().filter((p) => p.brokeragePercent > 0);

    if (!properties.length) {
      box.innerHTML = '<div class="empty-state"><div class="desc">No property has an Owner Brokerage % set yet — add it from that property\'s Edit form.</div></div>';
      return;
    }

    box.innerHTML = properties.map((p) => {
      const info = PropertiesController.getBrokerageDueInfo(p.id);
      return `
        <div class="danger-row">
          <div>
            <div class="dr-label">${esc(p.society || p.name)}</div>
            <div class="dr-desc">${p.brokeragePercent}% of ₹${p.rent} rent = ₹${p.brokerage}${info.dueDate ? ' · Next due ' + fmtDate(info.dueDate) : ''}</div>
          </div>
          ${info.due ? '<span class="badge pay-overdue">Due Now</span>' : '<span class="badge pay-paid">On Track</span>'}
        </div>`;
    }).join('');
  }

  function renderBrokerageList() {
    const query = (document.getElementById('brokerageSearchInput')?.value || '').toLowerCase().trim();
    const propFilter = document.getElementById('brokeragePropertyFilter')?.value || 'all';
    const statusFilter = document.getElementById('brokerageStatusFilter')?.value || 'all';

    const list = brokerageEntries.filter((b) => {
      const tenant = TenantsController.getById(b.tenantId);
      const text = ((tenant ? tenant.fullName : '') + ' ' + (b.brokerName || '')).toLowerCase();
      return text.includes(query) && (propFilter === 'all' || b.propertyId === propFilter) && (statusFilter === 'all' || b.status === statusFilter);
    });

    const el = document.getElementById('brokerageList');
    if (!list.length) {
      el.innerHTML = `<div class="empty-state"><div class="ico">🤝</div><div class="title">${brokerageEntries.length === 0 ? 'No brokerage entries yet' : 'No matching entries'}</div><div class="desc">${brokerageEntries.length === 0 ? 'Add your first brokerage entry above.' : 'Try a different search or filter.'}</div></div>`;
      return;
    }

    el.innerHTML = list.map((b) => {
      const tenant = TenantsController.getById(b.tenantId);
      const property = PropertiesController.getAll().find((p) => p.id === b.propertyId);
      const propertyLabel = property ? (property.society || property.name) : '—';
      const isOwnerType = b.type === 'Owner';
      const title = isOwnerType ? propertyLabel + ' (Owner)' : (tenant ? tenant.fullName : 'Unknown Tenant');
      const typeBadgeClass = isOwnerType ? 'cat-settlement' : 'cat-reminder';
      return `
        <div class="finance-list-row">
          <div class="fr-main">
            <div class="fr-title">${esc(title)} <span class="badge ${typeBadgeClass}" style="margin-left:6px;">${isOwnerType ? 'Owner Brokerage' : 'Tenant Brokerage'}</span>${b.brokerName ? ' · Broker: ' + esc(b.brokerName) : ''}</div>
            <div class="fr-sub">${esc(b.brokerageCode)}${!isOwnerType ? ' · ' + esc(propertyLabel) : ''}${b.paymentDate ? ' · Paid ' + fmtDate(b.paymentDate) : ''}</div>
          </div>
          <div class="fr-amount">
            <div class="amt outgo">₹${b.amount}</div>
            <span class="badge ${b.status === 'Paid' ? 'pay-paid' : 'pay-pending'}">${b.status}</span>
            <div class="fr-actions">
              <button class="btn small secondary brk-edit-btn" data-id="${b.id}">Edit</button>
              <button class="btn small brk-delete-btn" data-id="${b.id}" style="background:var(--error);">Delete</button>
            </div>
          </div>
        </div>`;
    }).join('');

    el.querySelectorAll('.brk-edit-btn').forEach((btn) => btn.addEventListener('click', () => openEditBrokerageModal(btn.dataset.id)));
    el.querySelectorAll('.brk-delete-btn').forEach((btn) => btn.addEventListener('click', () => handleDeleteBrokerage(btn.dataset.id)));
  }

  // ======================================================================
  // MANAGEMENT FEES
  // ======================================================================
  function updateFeeAutoCalc() {
    const propertyId = document.getElementById('feeProperty').value;
    const month = document.getElementById('feeMonth').value;
    const box = document.getElementById('feeCalcBreakdownBox');
    if (!propertyId || !month || typeof PropertiesController === 'undefined' || !PropertiesController.computeManagementFeeForMonth) {
      box.classList.add('hidden');
      return;
    }
    const result = PropertiesController.computeManagementFeeForMonth(propertyId, month);
    document.getElementById('feeAmount').value = result.total;
    box.classList.remove('hidden');
    box.innerHTML = `
      ${result.isTrialRate ? '<div class="form-hint" style="margin-bottom:6px;">Trial rate applied this month.</div>' : ''}
      ${result.breakdown.map((b) => `<div class="calc-row"><span>Room ${esc(b.roomNumber)} (${b.occupiedDays}/${b.daysInMonth} days)</span><span>₹${b.fee}</span></div>`).join('')}
      <div class="calc-row total"><span>Total (₹${result.rateUsed}/room)</span><span>₹${result.total}</span></div>
    `;
  }

  function openAddFeeModal() {
    editingFeeId = null;
    document.getElementById('feeModalTitle').textContent = 'Add Management Fee';
    document.getElementById('feeForm').reset();
    document.getElementById('feeId').value = '';
    document.getElementById('feeOwnerDisplay').textContent = '';
    document.getElementById('feeCalcBreakdownBox').classList.add('hidden');
    populatePropertySelect('feeProperty', false);
    document.getElementById('feeStatus').value = 'Pending';
    clearErrors('feeForm');
    document.getElementById('feeModalOverlay').classList.add('open');
  }

  function openEditFeeModal(id) {
    const f = managementFees.find((x) => x.id === id);
    if (!f) return;
    editingFeeId = id;
    document.getElementById('feeModalTitle').textContent = 'Edit Management Fee';
    populatePropertySelect('feeProperty', false);
    document.getElementById('feeId').value = f.id;
    document.getElementById('feeProperty').value = f.propertyId;
    updateFeeOwnerDisplay();
    document.getElementById('feeAmount').value = f.amount;
    document.getElementById('feeMonth').value = f.month;
    document.getElementById('feeStatus').value = f.status;
    clearErrors('feeForm');
    document.getElementById('feeModalOverlay').classList.add('open');
  }

  function closeFeeModal() { document.getElementById('feeModalOverlay').classList.remove('open'); editingFeeId = null; }

  function updateFeeOwnerDisplay() {
    const propertyId = document.getElementById('feeProperty').value;
    const property = PropertiesController.getAll().find((p) => p.id === propertyId);
    const owner = property ? OwnersController.getAll().find((o) => o.id === property.ownerId) : null;
    document.getElementById('feeOwnerDisplay').textContent = owner ? '👤 Owner: ' + owner.fullName : '';
  }

  function handleSaveFee() {
    const propertyId = document.getElementById('feeProperty').value;
    const amount = document.getElementById('feeAmount').value;
    const month = document.getElementById('feeMonth').value;
    const status = document.getElementById('feeStatus').value;

    const errors = {};
    if (!propertyId) errors.feeProperty = 'Select a property';
    if (amount === '' || Number(amount) < 0) errors.feeAmount = 'Enter a valid fee amount';
    if (!month) errors.feeMonth = 'Select the month';
    else {
      const dup = managementFees.some((f) => f.propertyId === propertyId && f.month === month && f.id !== editingFeeId);
      if (dup) errors.feeMonth = 'A management fee for this property and month already exists';
    }

    clearErrors('feeForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const property = PropertiesController.getAll().find((p) => p.id === propertyId);
    const now = new Date().toISOString();

    if (editingFeeId) {
      const idx = managementFees.findIndex((f) => f.id === editingFeeId);
      if (idx !== -1) managementFees[idx] = { ...managementFees[idx], propertyId, ownerId: property?.ownerId || null, amount: Number(amount), month, status, updatedAt: now };
    } else {
      managementFees.unshift({ id: generateId(), feeCode: nextCode('fee', 'MGT'), propertyId, ownerId: property?.ownerId || null, amount: Number(amount), month, status, createdAt: now, updatedAt: now });
    }
    persist('fee');
    closeFeeModal();
    populatePropertySelect('feePropertyFilter', true);
    renderFeesList();
    renderDashboard();
  }

  function handleDeleteFee(id) {
    const fee = managementFees.find((x) => x.id === id);
    if (!fee) return;
    ConfirmModal.show('Delete this management fee entry? You can restore it later from Settings → Trash.', () => {
      TrashController.moveToTrash('managementFee', fee, fee.feeCode || 'Management Fee');
      managementFees = managementFees.filter((x) => x.id !== id);
      persist('fee');
      renderFeesList();
      renderDashboard();
    });
  }

  function renderFeesList() {
    const query = (document.getElementById('feeSearchInput')?.value || '').toLowerCase().trim();
    const propFilter = document.getElementById('feePropertyFilter')?.value || 'all';
    const statusFilter = document.getElementById('feeStatusFilter')?.value || 'all';

    const list = managementFees.filter((f) => {
      const property = PropertiesController.getAll().find((p) => p.id === f.propertyId);
      const name = property ? property.name.toLowerCase() : '';
      return name.includes(query) && (propFilter === 'all' || f.propertyId === propFilter) && (statusFilter === 'all' || f.status === statusFilter);
    });

    const el = document.getElementById('managementFeesList');
    if (!list.length) {
      el.innerHTML = `<div class="empty-state"><div class="ico">🏦</div><div class="title">${managementFees.length === 0 ? 'No management fees yet' : 'No matching entries'}</div><div class="desc">${managementFees.length === 0 ? 'Add the first management fee above.' : 'Try a different search or filter.'}</div></div>`;
      return;
    }

    el.innerHTML = list.map((f) => {
      const property = PropertiesController.getAll().find((p) => p.id === f.propertyId);
      const owner = OwnersController.getAll().find((o) => o.id === f.ownerId);
      return `
        <div class="finance-list-row">
          <div class="fr-main">
            <div class="fr-title">${esc(property ? property.name : 'Unknown Property')} · ${fmtMonth(f.month)}</div>
            <div class="fr-sub">${esc(f.feeCode)}${owner ? ' · Owner: ' + esc(owner.fullName) : ''}</div>
          </div>
          <div class="fr-amount">
            <div class="amt income">₹${f.amount}</div>
            <span class="badge ${f.status === 'Paid' ? 'pay-paid' : 'pay-pending'}">${f.status}</span>
            <div class="fr-actions">
              <button class="btn small secondary fee-edit-btn" data-id="${f.id}">Edit</button>
              <button class="btn small fee-delete-btn" data-id="${f.id}" style="background:var(--error);">Delete</button>
            </div>
          </div>
        </div>`;
    }).join('');

    el.querySelectorAll('.fee-edit-btn').forEach((btn) => btn.addEventListener('click', () => openEditFeeModal(btn.dataset.id)));
    el.querySelectorAll('.fee-delete-btn').forEach((btn) => btn.addEventListener('click', () => handleDeleteFee(btn.dataset.id)));
  }

  // ======================================================================
  // EXPENSES
  // ======================================================================
  function openAddExpenseModal() {
    editingExpenseId = null;
    document.getElementById('expenseModalTitle').textContent = 'Add Expense';
    document.getElementById('expenseForm').reset();
    document.getElementById('expenseId').value = '';
    populatePropertySelect('expenseProperty', false);
    document.getElementById('expenseDate').value = todayIso();
    document.getElementById('expenseCostBearer').value = 'Owner';
    clearErrors('expenseForm');
    document.getElementById('expenseModalOverlay').classList.add('open');
  }

  function openEditExpenseModal(id) {
    const e = expenses.find((x) => x.id === id);
    if (!e) return;
    editingExpenseId = id;
    document.getElementById('expenseModalTitle').textContent = 'Edit Expense';
    populatePropertySelect('expenseProperty', false);
    document.getElementById('expenseId').value = e.id;
    document.getElementById('expenseProperty').value = e.propertyId;
    document.getElementById('expenseCategory').value = e.category;
    document.getElementById('expenseAmount').value = e.amount;
    document.getElementById('expenseDate').value = e.date;
    document.getElementById('expenseVendor').value = e.vendor || '';
    document.getElementById('expenseInvoice').value = e.invoiceNumber || '';
    document.getElementById('expenseCostBearer').value = e.costBearer || 'Owner';
    document.getElementById('expenseNotes').value = e.notes || '';
    clearErrors('expenseForm');
    document.getElementById('expenseModalOverlay').classList.add('open');
  }

  function closeExpenseModal() { document.getElementById('expenseModalOverlay').classList.remove('open'); editingExpenseId = null; }

  function handleSaveExpense() {
    const propertyId = document.getElementById('expenseProperty').value;
    const category = document.getElementById('expenseCategory').value;
    const amount = document.getElementById('expenseAmount').value;
    const date = document.getElementById('expenseDate').value;
    const vendor = document.getElementById('expenseVendor').value.trim();
    const invoiceNumber = document.getElementById('expenseInvoice').value.trim();
    const costBearer = document.getElementById('expenseCostBearer').value;
    const notes = document.getElementById('expenseNotes').value.trim();

    const errors = {};
    if (!propertyId) errors.expenseProperty = 'Select a property';
    if (!category) errors.expenseCategory = 'Select a category';
    if (amount === '' || Number(amount) <= 0) errors.expenseAmount = 'Enter a valid amount';
    if (!date) errors.expenseDate = 'Expense date is required';

    clearErrors('expenseForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const now = new Date().toISOString();
    if (editingExpenseId) {
      const idx = expenses.findIndex((e) => e.id === editingExpenseId);
      if (idx !== -1) expenses[idx] = { ...expenses[idx], propertyId, category, amount: Number(amount), date, vendor, invoiceNumber, costBearer, notes, updatedAt: now };
    } else {
      const newExpenseId = generateId();
      expenses.unshift({ id: newExpenseId, expenseCode: nextCode('expense', 'EXP'), propertyId, category, amount: Number(amount), date, vendor, invoiceNumber, costBearer, notes, createdAt: now, updatedAt: now });
      if (costBearer === 'Owner') {
        createOwnerAdvance({ propertyId, amount: Number(amount), reason: category, sourceType: 'expense', sourceId: newExpenseId });
      }
    }
    persist('expense');
    closeExpenseModal();
    populatePropertySelect('expensePropertyFilter', true);
    renderExpensesList();
    renderDashboard();
  }

  function handleDeleteExpense(id) {
    const e = expenses.find((x) => x.id === id);
    if (!e) return;
    ConfirmModal.show('Delete this expense? You can restore it later from Settings → Trash.', () => {
      TrashController.moveToTrash('expense', e, e.expenseCode || e.category || 'Expense');
      expenses = expenses.filter((x) => x.id !== id);
      persist('expense');
      renderExpensesList();
      renderDashboard();
    });
  }

  /** Removes an expense without confirmation/trash — used only for
   *  automated system corrections (e.g. Maintenance's Routine Checklist
   *  undoing a "Mark Done" that had already synced an expense), never
   *  from a direct user delete action. */
  function removeExpenseSilently(id) {
    expenses = expenses.filter((x) => x.id !== id);
    persist('expense');
  }

  /**
   * "Fair Homes Income" — the business's real profit: Management Fees
   * collected + Owner Brokerage + Tenant Brokerage + Maintenance Margin
   * (the actual-vs-billed gap on every job). Distinct from "Revenue −
   * Expenses" shown elsewhere, which reflects total business cash flow.
   */
  // ======================================================================
  // OWNER PAYOUTS — records the ACTUAL amount paid to an owner, using
  // the same "Rent − Management Fee − Expenses − Brokerage" formula the
  // Owner Report already calculates live, but turns it into a
  // persistent, dated record instead of just a recalculated display
  // figure. Covers both routine monthly payouts and the special
  // first-time onboarding settlement (setup/renovation costs come
  // through as that month's Expenses automatically).
  // ======================================================================
  let lastPayoutBreakdown = null;

  function populatePayoutOwnerSelect() {
    const sel = document.getElementById('payoutOwnerSelect');
    if (typeof OwnersController === 'undefined') return;
    const current = sel.value;
    sel.innerHTML = '<option value="">Select Owner</option>' + OwnersController.getAll().map((o) => `<option value="${o.id}">${esc(o.fullName)}</option>`).join('');
    sel.value = current;
    if (!document.getElementById('payoutMonth').value) document.getElementById('payoutMonth').value = currentMonthStr();
  }

  /** Same formula as the Owner Report's Net Income column — computed
   *  here so it can also be used to pre-fill and validate an actual
   *  payout record, not just displayed. */
  function computeOwnerPayoutBreakdown(ownerId, month) {
    const ownerProperties = PropertiesController.getAll().filter((p) => p.ownerId === ownerId);
    const propertyIds = ownerProperties.map((p) => p.id);
    const grossRent = rentEntries.filter((r) => propertyIds.includes(r.propertyId) && r.paymentDate && r.paymentDate.startsWith(month)).reduce((s, r) => s + r.amountPaid, 0);
    const electricity = rentEntries.filter((r) => propertyIds.includes(r.propertyId) && r.paymentDate && r.paymentDate.startsWith(month)).reduce((s, r) => s + (r.electricity || 0), 0);
    const mgmtFee = managementFees.filter((mf) => propertyIds.includes(mf.propertyId) && mf.month === month).reduce((s, mf) => s + mf.amount, 0);
    const expensesDeducted = getAdvanceAdjustmentsInMonth(propertyIds, month);
    const brokerageDeducted = brokerageEntries.filter((b) => propertyIds.includes(b.propertyId) && b.status === 'Paid' && b.paymentDate && b.paymentDate.startsWith(month)).reduce((s, b) => s + b.amount, 0);
    const netAmount = grossRent + electricity - mgmtFee - expensesDeducted - brokerageDeducted;
    return { propertyIds, grossRent, electricity, mgmtFee, expensesDeducted, brokerageDeducted, netAmount };
  }

  function handleCalculatePayout() {
    const ownerId = document.getElementById('payoutOwnerSelect').value;
    const month = document.getElementById('payoutMonth').value;
    if (!ownerId || !month) { alert('Select an Owner and Month first.'); return; }
    const b = computeOwnerPayoutBreakdown(ownerId, month);
    const otherAdjustments = Number(document.getElementById('payoutOtherAdjustments').value) || 0;
    const otherAdjustmentsNote = document.getElementById('payoutOtherAdjustmentsNote').value.trim();
    const finalNet = b.netAmount + otherAdjustments;
    lastPayoutBreakdown = { ...b, ownerId, month, otherAdjustments, otherAdjustmentsNote, netAmount: finalNet };
    document.getElementById('payoutCalcBox').innerHTML = `
      <div class="calc-row"><span>Rent Collected</span><span>₹${b.grossRent}</span></div>
      <div class="calc-row"><span>+ Electricity</span><span>₹${b.electricity}</span></div>
      <div class="calc-row"><span>− Management Fee</span><span>₹${b.mgmtFee}</span></div>
      <div class="calc-row"><span>− Expenses (incl. renovation/setup this month)</span><span>₹${b.expensesDeducted}</span></div>
      <div class="calc-row"><span>− Brokerage</span><span>₹${b.brokerageDeducted}</span></div>
      ${otherAdjustments !== 0 ? `<div class="calc-row"><span>${otherAdjustments > 0 ? '+' : '−'} Other Adjustment${otherAdjustmentsNote ? ' (' + esc(otherAdjustmentsNote) + ')' : ''}</span><span>₹${Math.abs(otherAdjustments)}</span></div>` : ''}
      <div class="calc-row total"><span>Net Amount to Pay Owner</span><span>₹${finalNet}</span></div>
    `;
    document.getElementById('payoutAmount').value = finalNet;
    document.getElementById('payoutDate').value = todayIso();
    clearErrors('payoutRecordForm');
    document.getElementById('payoutRecordForm').classList.remove('hidden');
  }

  function handleRecordPayout() {
    if (!lastPayoutBreakdown) return;
    const amount = document.getElementById('payoutAmount').value;
    const date = document.getElementById('payoutDate').value;
    const method = document.getElementById('payoutMethod').value;
    const notes = document.getElementById('payoutNotes').value.trim();

    clearErrors('payoutRecordForm');
    if (!amount || Number(amount) < 0) { showErrors({ payoutAmount: 'Enter a valid amount' }); return; }
    if (!date) { showErrors({ payoutAmount: 'Select a payment date' }); return; }

    const owner = OwnersController.getAll().find((o) => o.id === lastPayoutBreakdown.ownerId);
    const now = new Date().toISOString();
    ownerPayouts.unshift({
      id: generateId(), payoutCode: nextCode('payout', 'PAY'),
      ownerId: lastPayoutBreakdown.ownerId, ownerName: owner ? owner.fullName : '', month: lastPayoutBreakdown.month,
      grossRent: lastPayoutBreakdown.grossRent, electricity: lastPayoutBreakdown.electricity, mgmtFee: lastPayoutBreakdown.mgmtFee,
      expensesDeducted: lastPayoutBreakdown.expensesDeducted, brokerageDeducted: lastPayoutBreakdown.brokerageDeducted,
      otherAdjustments: lastPayoutBreakdown.otherAdjustments || 0, otherAdjustmentsNote: lastPayoutBreakdown.otherAdjustmentsNote || '',
      calculatedNet: lastPayoutBreakdown.netAmount, amountPaid: Number(amount),
      paymentDate: date, paymentMethod: method, notes, createdAt: now,
    });
    persist('payout');
    document.getElementById('payoutRecordForm').classList.add('hidden');
    document.getElementById('payoutNotes').value = '';
    document.getElementById('payoutOtherAdjustments').value = '';
    document.getElementById('payoutOtherAdjustmentsNote').value = '';
    lastPayoutBreakdown = null;
    renderPayoutHistory();
    alert('Payout recorded.');
  }

  function renderPayoutHistory() {
    const box = document.getElementById('payoutHistoryList');
    if (!box) return;
    if (!ownerPayouts.length) { box.innerHTML = '<div class="empty-state"><div class="desc">No payouts recorded yet.</div></div>'; return; }
    box.innerHTML = ownerPayouts.map((p) => `
      <div class="danger-row">
        <div>
          <div class="dr-label">${esc(p.ownerName)} — ${fmtMonth(p.month)}</div>
          <div class="dr-desc">${esc(p.payoutCode)} · ${fmtDate(p.paymentDate)} · ${esc(p.paymentMethod)}${p.notes ? ' · ' + esc(p.notes) : ''}${p.otherAdjustmentsNote ? ' · Adjustment: ' + esc(p.otherAdjustmentsNote) + ' (₹' + p.otherAdjustments + ')' : ''}</div>
        </div>
        <div style="font-weight:700;">₹${p.amountPaid}</div>
      </div>`).join('');
  }

  function renderFairHomesIncome() {
    const thisMonth = todayIso().slice(0, 7);

    const mgmtFeesTotal = managementFees.filter((f) => f.status === 'Paid' && f.month === thisMonth).reduce((s, f) => s + f.amount, 0);
    const ownerBrokerageTotal = brokerageEntries.filter((b) => b.status === 'Paid' && b.type === 'Owner' && b.paymentDate && b.paymentDate.startsWith(thisMonth)).reduce((s, b) => s + b.amount, 0);
    const tenantBrokerageTotal = brokerageEntries.filter((b) => b.status === 'Paid' && b.type === 'Tenant' && b.paymentDate && b.paymentDate.startsWith(thisMonth)).reduce((s, b) => s + b.amount, 0);
    const thisMonthMargin = marginIncome.filter((m) => m.date.startsWith(thisMonth));
    const maintenanceMarginEntries = thisMonthMargin.filter((m) => m.source !== 'brokerageOnlyDeal');
    const brokerageOnlyEntries = thisMonthMargin.filter((m) => m.source === 'brokerageOnlyDeal');
    const maintenanceMarginTotal = maintenanceMarginEntries.reduce((s, m) => s + m.amount, 0);
    const brokerageOnlyTotal = brokerageOnlyEntries.reduce((s, m) => s + m.amount, 0);
    const marginTotal = maintenanceMarginTotal + brokerageOnlyTotal;
    const bizExpenseTotal = businessExpenses.filter((b) => b.type === 'Expense' && b.date.startsWith(thisMonth)).reduce((s, b) => s + b.amount, 0);
    const withdrawalTotal = businessExpenses.filter((b) => b.type === 'Withdrawal' && b.date.startsWith(thisMonth)).reduce((s, b) => s + b.amount, 0);
    const grossIncome = mgmtFeesTotal + ownerBrokerageTotal + tenantBrokerageTotal + marginTotal;
    // Withdrawal is NOT a business expense — it's the owner taking out
    // their own already-earned profit, so it's deducted AFTER Net
    // Profit, not folded into it.
    const netProfit = grossIncome - bizExpenseTotal;
    const remainingAfterWithdrawal = netProfit - withdrawalTotal;

    document.getElementById('fhIncomeSummaryGrid').innerHTML = `
      <div class="stat-card"><div class="label">Management Fees</div><div class="value success">₹${mgmtFeesTotal}</div></div>
      <div class="stat-card"><div class="label">Owner Brokerage</div><div class="value success">₹${ownerBrokerageTotal}</div></div>
      <div class="stat-card"><div class="label">Tenant Brokerage</div><div class="value success">₹${tenantBrokerageTotal}</div></div>
      <div class="stat-card"><div class="label">Maintenance Margin</div><div class="value success">₹${maintenanceMarginTotal}</div></div>
      <div class="stat-card"><div class="label">Brokerage-Only Deals</div><div class="value success">₹${brokerageOnlyTotal}</div></div>
      <div class="stat-card"><div class="label">Business Expenses</div><div class="value error">₹${bizExpenseTotal}</div></div>
      <div class="stat-card"><div class="label">Net Profit This Month</div><div class="value success" style="font-size:20px;">₹${netProfit}</div></div>
      <div class="stat-card"><div class="label">Withdrawals</div><div class="value warning">₹${withdrawalTotal}</div></div>
      <div class="stat-card"><div class="label">Remaining After Withdrawal</div><div class="value ${remainingAfterWithdrawal >= 0 ? 'success' : 'error'}" style="font-size:22px;">₹${remainingAfterWithdrawal}</div></div>
    `;

    document.getElementById('fhIncomeBreakdown').innerHTML = `
      <div class="danger-row"><div class="dr-label">Management Fees Collected</div><div style="font-weight:700;">₹${mgmtFeesTotal}</div></div>
      <div class="danger-row"><div class="dr-label">Owner Brokerage Collected</div><div style="font-weight:700;">₹${ownerBrokerageTotal}</div></div>
      <div class="danger-row"><div class="dr-label">Tenant Brokerage Collected</div><div style="font-weight:700;">₹${tenantBrokerageTotal}</div></div>
      <div class="danger-row"><div class="dr-label">Maintenance Margin Earned</div><div style="font-weight:700;">₹${maintenanceMarginTotal}</div></div>
      <div class="danger-row"><div class="dr-label">Brokerage-Only Deals Earned</div><div style="font-weight:700;">₹${brokerageOnlyTotal}</div></div>
      <div class="danger-row"><div class="dr-label">Gross Income</div><div style="font-weight:700;">₹${grossIncome}</div></div>
      <div class="danger-row"><div class="dr-label">Less: Business Expenses</div><div style="font-weight:700; color:var(--error);">−₹${bizExpenseTotal}</div></div>
      <div class="danger-row" style="border-top:2px solid var(--border); margin-top:4px; padding-top:10px;">
        <div class="dr-label" style="font-size:14px;">Net Profit This Month</div>
        <div style="font-weight:800; font-size:16px; color:var(--success);">₹${netProfit}</div>
      </div>
      <div class="danger-row"><div class="dr-label">Less: Withdrawal</div><div style="font-weight:700; color:var(--warning);">−₹${withdrawalTotal}</div></div>
      <div class="danger-row" style="border-top:2px solid var(--border); margin-top:4px; padding-top:10px;">
        <div class="dr-label" style="font-size:14px;">Remaining Balance / Profit After Withdrawal</div>
        <div style="font-weight:800; font-size:16px; color:${remainingAfterWithdrawal >= 0 ? 'var(--success)' : 'var(--error)'};">₹${remainingAfterWithdrawal}</div>
      </div>
    `;

    // ---- 5 separately-labeled history sections — each shows ONLY its
    // own income type, never mixed with another category. ----
    renderMgmtFeeHistory();
    renderOwnerBrokerageHistory();
    renderTenantBrokerageHistory();
    renderMaintenanceMarginHistory();
    renderBrokerageOnlyHistory();

    renderBizExpenseList();
    if (!document.getElementById('bizExpenseDate').value) document.getElementById('bizExpenseDate').value = todayIso();
    populateAdvancePropertySelect();
    renderOwnerAdvanceList();
  }

  function renderMgmtFeeHistory() {
    const box = document.getElementById('fhMgmtFeeHistory');
    const recent = managementFees.filter((f) => f.status === 'Paid').sort((a, b) => (b.paidDate || b.month).localeCompare(a.paidDate || a.month)).slice(0, 20);
    box.innerHTML = recent.length
      ? recent.map((f) => {
          const property = PropertiesController.getAll().find((p) => p.id === f.propertyId);
          return `<div class="history-item"><div class="hi-title">${property ? esc(property.society || property.name) : 'Management Fee'}</div><div class="hi-row">${fmtMonth(f.month)} · ₹${f.amount}</div></div>`;
        }).join('')
      : '<div class="empty-state"><div class="desc">No management fees collected yet.</div></div>';
  }

  function renderOwnerBrokerageHistory() {
    const box = document.getElementById('fhOwnerBrokerageHistory');
    const recent = brokerageEntries.filter((b) => b.status === 'Paid' && b.type === 'Owner').sort((a, b) => (b.paymentDate || '').localeCompare(a.paymentDate || '')).slice(0, 20);
    box.innerHTML = recent.length
      ? recent.map((b) => {
          const property = PropertiesController.getAll().find((p) => p.id === b.propertyId);
          return `<div class="history-item"><div class="hi-title">${property ? esc(property.society || property.name) : 'Owner Brokerage'}</div><div class="hi-row">${fmtDate(b.paymentDate)} · ₹${b.amount}</div></div>`;
        }).join('')
      : '<div class="empty-state"><div class="desc">No owner brokerage collected yet.</div></div>';
  }

  function renderTenantBrokerageHistory() {
    const box = document.getElementById('fhTenantBrokerageHistory');
    const recent = brokerageEntries.filter((b) => b.status === 'Paid' && b.type === 'Tenant').sort((a, b) => (b.paymentDate || '').localeCompare(a.paymentDate || '')).slice(0, 20);
    box.innerHTML = recent.length
      ? recent.map((b) => {
          const property = PropertiesController.getAll().find((p) => p.id === b.propertyId);
          return `<div class="history-item"><div class="hi-title">${property ? esc(property.society || property.name) : 'Tenant Brokerage'}</div><div class="hi-row">${fmtDate(b.paymentDate)} · ₹${b.amount}</div></div>`;
        }).join('')
      : '<div class="empty-state"><div class="desc">No tenant brokerage collected yet.</div></div>';
  }

  /** Only source !== 'brokerageOnlyDeal' — actual maintenance/routine
   *  margin, never mixed with Brokerage-Only Deal income. Delete-only
   *  (no edit): these are meant to be corrected at the source
   *  (Maintenance ticket/routine task), not hand-edited here — this is
   *  purely for removing a mistaken/test entry. */
  function renderMaintenanceMarginHistory() {
    const box = document.getElementById('fhMaintenanceMarginHistory');
    const recent = marginIncome.filter((m) => m.source !== 'brokerageOnlyDeal').sort((a, b) => b.date.localeCompare(a.date)).slice(0, 20);
    box.innerHTML = recent.length
      ? recent.map((m) => {
          const property = PropertiesController.getAll().find((p) => p.id === m.propertyId);
          return `<div class="history-item"><div class="hi-title">${esc(m.label)}</div><div class="hi-row">${property ? esc(property.society || property.name) + ' · ' : ''}${fmtDate(m.date)} · ₹${m.amount} <button class="btn small secondary margin-delete-btn" data-id="${m.id}" style="margin-left:8px; padding:2px 8px; background:var(--error); color:#fff;">Delete</button></div></div>`;
        }).join('')
      : '<div class="empty-state"><div class="desc">No maintenance margin recorded yet.</div></div>';
    box.querySelectorAll('.margin-delete-btn').forEach((btn) => btn.addEventListener('click', () => {
      ConfirmModal.show('Delete this entry? Gross Income and Net Profit will recalculate automatically.', () => {
        deleteMarginIncome(btn.dataset.id);
        renderFairHomesIncome();
      });
    }));
  }

  /** Only source === 'brokerageOnlyDeal'. Same delete-only pattern —
   *  the underlying Deal itself is edited from the Brokerage-Only
   *  Flats page, not here; this is just for removing a
   *  mistaken/duplicate income record. */
  let expandedBrkFlatId = null;

  /** Groups Brokerage-Only income entries by flat — one collapsed
   *  summary line per flat as requested, expandable to the full
   *  per-deal breakdown (booking-time amount, shifting-time amount,
   *  discount given, extra received) pulled from the actual Deal
   *  records in BrokerageFlatsController, not just the income总额. */
  function renderBrokerageOnlyHistory() {
    const box = document.getElementById('fhBrokerageOnlyHistory');
    const entries = marginIncome.filter((m) => m.source === 'brokerageOnlyDeal');
    if (!entries.length) { box.innerHTML = '<div class="empty-state"><div class="desc">No brokerage-only deals recorded yet.</div></div>'; return; }

    const allFlats = typeof BrokerageFlatsController !== 'undefined' ? BrokerageFlatsController.getAll() : [];
    const groups = {};
    entries.forEach((m) => {
      const key = m.flatId || 'unlinked';
      if (!groups[key]) groups[key] = [];
      groups[key].push(m);
    });

    const groupKeys = Object.keys(groups).sort((a, b) => {
      const latestA = Math.max(...groups[a].map((m) => new Date(m.date).getTime()));
      const latestB = Math.max(...groups[b].map((m) => new Date(m.date).getTime()));
      return latestB - latestA;
    });

    box.innerHTML = groupKeys.map((flatId) => {
      const groupEntries = groups[flatId].sort((a, b) => b.date.localeCompare(a.date));
      const flat = allFlats.find((f) => f.id === flatId);
      const flatLabel = flat ? `Brokerage-Only Deal — ${esc(flat.society)}, Flat ${esc(flat.flatNo)}` : 'Brokerage-Only Deal — Flat Details Not Found';
      const total = groupEntries.reduce((s, m) => s + m.amount, 0);
      const isExpanded = expandedBrkFlatId === flatId;

      const detailRows = groupEntries.map((m) => {
        const deal = flat ? (flat.deals || []).find((d) => d.marginIncomeId === m.id) : null;
        const stageLabel = deal ? (deal.dealStage === 'Booking Conversion' ? 'At Booking Time' : deal.dealStage === 'Shifting Settlement' ? 'At Shifting Time' : 'Standalone Deal') : '';
        return `
          <div class="history-item" style="margin-left:14px; border-left:2px solid var(--border); padding-left:10px;">
            <div class="hi-title">${fmtDate(m.date)} — ₹${m.amount} ${stageLabel ? `<span class="badge cat-system" style="margin-left:6px;">${stageLabel}</span>` : ''}
              <button class="btn small secondary margin-delete-btn" data-id="${m.id}" style="margin-left:8px; padding:2px 8px; background:var(--error); color:#fff;">Delete</button>
            </div>
            ${deal ? `<div class="hi-row">From Tenant: ₹${deal.fromTenant} · From Owner: ₹${deal.fromOwner}${deal.discountGiven > 0 ? ' · Discount Given: ₹' + deal.discountGiven : ''}${deal.extraReceived > 0 ? ' · Extra Received (Documentation/Extra Work): ₹' + deal.extraReceived : ''}</div>` : ''}
          </div>`;
      }).join('');

      return `
        <div class="settings-card brk-flat-group" data-flat-id="${flatId}" style="cursor:pointer; padding:12px;">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <div class="hi-title">${flatLabel}</div>
            <div style="font-weight:700; color:var(--success);">₹${total} ${isExpanded ? '▲' : '▼'}</div>
          </div>
          ${isExpanded ? `<div style="margin-top:8px;">${detailRows}</div>` : ''}
        </div>`;
    }).join('');

    box.querySelectorAll('.brk-flat-group').forEach((card) => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('.margin-delete-btn')) return;
        const flatId = card.dataset.flatId;
        expandedBrkFlatId = expandedBrkFlatId === flatId ? null : flatId;
        renderBrokerageOnlyHistory();
      });
    });
    box.querySelectorAll('.margin-delete-btn').forEach((btn) => btn.addEventListener('click', (e) => {
      e.stopPropagation();
      ConfirmModal.show('Delete this entry? Gross Income and Net Profit will recalculate automatically.', () => {
        deleteMarginIncome(btn.dataset.id);
        renderFairHomesIncome();
      });
    }));
  }

  function renderBizExpenseList() {
    const box = document.getElementById('bizExpenseList');
    const recent = [...businessExpenses].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 30);
    box.innerHTML = recent.length
      ? recent.map((b) => `
          <div class="finance-list-row">
            <div class="fr-main">
              <div class="fr-title">${esc(b.category)} <span class="badge ${b.type === 'Withdrawal' ? 'pay-pending' : 'cat-system'}" style="margin-left:6px;">${b.type}</span></div>
              <div class="fr-sub">${esc(b.code)} · ${fmtDate(b.date)}${b.notes ? ' · ' + esc(b.notes) : ''}</div>
            </div>
            <div class="fr-amount">
              <div class="amt outgo">₹${b.amount}</div>
              <div class="fr-actions"><button class="btn small biz-delete-btn" data-id="${b.id}" style="background:var(--error);">Delete</button></div>
            </div>
          </div>`).join('')
      : '<div class="empty-state"><div class="desc">No business expenses or withdrawals recorded yet.</div></div>';
    box.querySelectorAll('.biz-delete-btn').forEach((btn) => btn.addEventListener('click', () => {
      ConfirmModal.show('Delete this entry?', () => { deleteBusinessExpense(btn.dataset.id); renderFairHomesIncome(); });
    }));
  }

  function handleAddBizExpense() {
    const type = document.getElementById('bizExpenseType').value;
    const category = document.getElementById('bizExpenseCategory').value;
    const amount = document.getElementById('bizExpenseAmount').value;
    const date = document.getElementById('bizExpenseDate').value || todayIso();
    const notes = document.getElementById('bizExpenseNotes').value.trim();
    if (!amount || Number(amount) <= 0) { alert('Enter a valid amount.'); return; }
    recordBusinessExpense({ type, category, amount, date, notes });
    document.getElementById('bizExpenseAmount').value = '';
    document.getElementById('bizExpenseNotes').value = '';
    renderFairHomesIncome();
  }

  function populateAdvancePropertySelect() {
    const sel = document.getElementById('advanceProperty');
    if (!sel || typeof PropertiesController === 'undefined') return;
    const current = sel.value;
    sel.innerHTML = '<option value="">Select Property</option>' + PropertiesController.getAll().map((p) => `<option value="${p.id}">${esc(p.society || p.name)}</option>`).join('');
    sel.value = current;
  }

  function renderOwnerAdvanceList() {
    const box = document.getElementById('ownerAdvanceList');
    if (!box || typeof PropertiesController === 'undefined') return;
    const sorted = [...ownerAdvances].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    box.innerHTML = sorted.length
      ? sorted.map((a) => {
          const property = PropertiesController.getAll().find((p) => p.id === a.propertyId);
          const historyLines = a.history.map((h) => `${fmtDate(h.date)}: ₹${h.amountAdjusted} adjusted`).join(' · ');
          return `
            <div class="danger-row" style="align-items:flex-start;">
              <div>
                <div class="dr-label">${esc(a.reason || 'Advance')} — ${property ? esc(property.society || property.name) : '—'}</div>
                <div class="dr-desc">Original ₹${a.amount} · Outstanding ₹${a.outstandingBalance}${historyLines ? ' · ' + esc(historyLines) : ''}</div>
              </div>
              <span class="badge ${a.status === 'Settled' ? 'pay-paid' : 'pay-overdue'}">${a.status}</span>
            </div>`;
        }).join('')
      : '<div class="empty-state"><div class="desc">No owner advances yet.</div></div>';
  }

  function handleAddAdvance() {
    const propertyId = document.getElementById('advanceProperty').value;
    const amount = document.getElementById('advanceAmount').value;
    const reason = document.getElementById('advanceReason').value.trim();
    if (!propertyId) { alert('Select a property.'); return; }
    if (!amount || Number(amount) <= 0) { alert('Enter a valid amount.'); return; }
    createOwnerAdvance({ propertyId, amount, reason: reason || 'Manual advance', sourceType: 'manual' });
    document.getElementById('advanceAmount').value = '';
    document.getElementById('advanceReason').value = '';
    renderFairHomesIncome();
  }


  function renderExpensesList() {
    const query = (document.getElementById('expenseSearchInput')?.value || '').toLowerCase().trim();
    const propFilter = document.getElementById('expensePropertyFilter')?.value || 'all';
    const catFilter = document.getElementById('expenseCategoryFilter')?.value || 'all';

    const list = expenses.filter((e) => {
      const text = ((e.vendor || '') + ' ' + (e.notes || '')).toLowerCase();
      return text.includes(query) && (propFilter === 'all' || e.propertyId === propFilter) && (catFilter === 'all' || e.category === catFilter);
    });

    const el = document.getElementById('expensesList');
    if (!list.length) {
      el.innerHTML = `<div class="empty-state"><div class="ico">🧾</div><div class="title">${expenses.length === 0 ? 'No expenses yet' : 'No matching expenses'}</div><div class="desc">${expenses.length === 0 ? 'Add your first expense above.' : 'Try a different search or filter.'}</div></div>`;
      return;
    }

    el.innerHTML = list.map((e) => {
      const property = PropertiesController.getAll().find((p) => p.id === e.propertyId);
      const isOwnerType = e.costBearer !== 'Tenant'; // undefined/missing (old records) defaults to Owner
      const typeBadgeClass = isOwnerType ? 'cat-settlement' : 'cat-reminder';
      return `
        <div class="finance-list-row">
          <div class="fr-main">
            <div class="fr-title">${esc(e.category)}${e.vendor ? ' · ' + esc(e.vendor) : ''} <span class="badge ${typeBadgeClass}" style="margin-left:6px;">${isOwnerType ? 'Owner' : 'Tenant'}</span></div>
            <div class="fr-sub">${esc(e.expenseCode)} · ${esc(property ? (property.society || property.name) : '—')} · ${fmtDate(e.date)}${e.invoiceNumber ? ' · Inv# ' + esc(e.invoiceNumber) : ''}</div>
          </div>
          <div class="fr-amount">
            <div class="amt outgo">₹${e.amount}</div>
            <div class="fr-actions">
              <button class="btn small secondary exp-edit-btn" data-id="${e.id}">Edit</button>
              <button class="btn small exp-delete-btn" data-id="${e.id}" style="background:var(--error);">Delete</button>
            </div>
          </div>
        </div>`;
    }).join('');

    el.querySelectorAll('.exp-edit-btn').forEach((btn) => btn.addEventListener('click', () => openEditExpenseModal(btn.dataset.id)));
    el.querySelectorAll('.exp-delete-btn').forEach((btn) => btn.addEventListener('click', () => handleDeleteExpense(btn.dataset.id)));
  }

  // ======================================================================
  // DASHBOARD
  // ======================================================================
  function renderDashboard() {
    const today = todayIso();
    const thisMonth = currentMonthStr();

    const todaysCollection = rentEntries.filter((r) => r.paymentDate === today).reduce((s, r) => s + r.amountPaid, 0);
    const thisMonthCollection = rentEntries.filter((r) => r.paymentDate && r.paymentDate.startsWith(thisMonth)).reduce((s, r) => s + r.amountPaid, 0);
    const pendingRent = rentEntries.filter((r) => r.paymentStatus === 'Pending').reduce((s, r) => s + r.remainingBalance, 0);
    const overdueRent = rentEntries.filter((r) => r.paymentStatus === 'Overdue').reduce((s, r) => s + r.remainingBalance, 0);
    const depositsHeld = deposits.filter((d) => d.status === 'Held' || d.status === 'Partially Refunded').reduce((s, d) => s + (d.amount - d.refundedAmount), 0);
    const thisMonthExpenses = expenses.filter((e) => e.date.startsWith(thisMonth)).reduce((s, e) => s + e.amount, 0);

    const monthlyRentIncome = rentEntries.filter((r) => r.paymentDate && r.paymentDate.startsWith(thisMonth)).reduce((s, r) => s + r.amountPaid, 0);
    const monthlyBrokerageIncome = brokerageEntries.filter((b) => b.paymentDate && b.paymentDate.startsWith(thisMonth) && b.status === 'Paid').reduce((s, b) => s + b.amount, 0);
    const monthlyFeeIncome = managementFees.filter((f) => f.month === thisMonth && f.status === 'Paid').reduce((s, f) => s + f.amount, 0);
    const monthlyIncome = monthlyRentIncome + monthlyBrokerageIncome + monthlyFeeIncome;
    const monthlyProfit = monthlyIncome - thisMonthExpenses;

    const thisMonthDue = rentEntries.filter((r) => r.rentMonth === thisMonth).reduce((s, r) => s + r.totalPayable, 0);
    const thisMonthPaid = rentEntries.filter((r) => r.rentMonth === thisMonth).reduce((s, r) => s + r.amountPaid, 0);
    const collectionPct = thisMonthDue > 0 ? Math.round((thisMonthPaid / thisMonthDue) * 100) : 0;

    document.getElementById('financeStatGrid').innerHTML = `
      <div class="stat-card"><div class="label">Today's Collection</div><div class="value success">₹${todaysCollection}</div></div>
      <div class="stat-card"><div class="label">This Month Collection</div><div class="value success">₹${thisMonthCollection}</div></div>
      <div class="stat-card"><div class="label">Pending Rent</div><div class="value warning">₹${pendingRent}</div></div>
      <div class="stat-card"><div class="label">Overdue Rent</div><div class="value error">₹${overdueRent}</div></div>
      <div class="stat-card"><div class="label">Security Deposits Held</div><div class="value">₹${depositsHeld}</div></div>
      <div class="stat-card"><div class="label">Expenses (This Month)</div><div class="value error">₹${thisMonthExpenses}</div></div>
      <div class="stat-card"><div class="label">Profit (This Month)</div><div class="value ${monthlyProfit >= 0 ? 'success' : 'error'}">₹${monthlyProfit}</div></div>
      <div class="stat-card"><div class="label">Loss (This Month)</div><div class="value error">₹${monthlyProfit < 0 ? Math.abs(monthlyProfit) : 0}</div></div>
      <div class="stat-card"><div class="label">Collection %</div><div class="value">${collectionPct}%</div></div>
    `;

    const outstandingRent = rentEntries.filter((r) => r.paymentStatus !== 'Paid').reduce((s, r) => s + r.remainingBalance, 0);
    const collectedRentAllTime = rentEntries.reduce((s, r) => s + r.amountPaid, 0);
    const pendingRentAllTime = rentEntries.filter((r) => r.paymentStatus === 'Pending' || r.paymentStatus === 'Overdue').reduce((s, r) => s + r.remainingBalance, 0);
    const brokerageCollected = brokerageEntries.filter((b) => b.status === 'Paid').reduce((s, b) => s + b.amount, 0);
    const feesCollected = managementFees.filter((f) => f.status === 'Paid').reduce((s, f) => s + f.amount, 0);

    document.getElementById('financeAutoCalcGrid').innerHTML = `
      <div class="stat-card"><div class="label">Monthly Income</div><div class="value success">₹${monthlyIncome}</div></div>
      <div class="stat-card"><div class="label">Monthly Expenses</div><div class="value error">₹${thisMonthExpenses}</div></div>
      <div class="stat-card"><div class="label">Monthly Profit</div><div class="value ${monthlyProfit >= 0 ? 'success' : 'error'}">₹${monthlyProfit}</div></div>
      <div class="stat-card"><div class="label">Outstanding Rent</div><div class="value warning">₹${outstandingRent}</div></div>
      <div class="stat-card"><div class="label">Collected Rent (All-Time)</div><div class="value success">₹${collectedRentAllTime}</div></div>
      <div class="stat-card"><div class="label">Pending Rent (All-Time)</div><div class="value warning">₹${pendingRentAllTime}</div></div>
      <div class="stat-card"><div class="label">Security Deposits Held</div><div class="value">₹${depositsHeld}</div></div>
      <div class="stat-card"><div class="label">Brokerage Collected</div><div class="value success">₹${brokerageCollected}</div></div>
      <div class="stat-card"><div class="label">Management Fees Collected</div><div class="value success">₹${feesCollected}</div></div>
    `;

    renderTimeline();
  }

  function renderTimeline() {
    const items = [
      ...rentEntries.filter((r) => r.paymentDate).map((r) => ({ date: r.paymentDate, icon: '💰', text: `Rent collected — ₹${r.amountPaid}`, ts: r.updatedAt || r.createdAt })),
      ...deposits.map((d) => ({ date: d.depositDate, icon: '🔒', text: `Deposit received — ₹${d.amount}`, ts: d.updatedAt || d.createdAt })),
      ...expenses.map((e) => ({ date: e.date, icon: '🧾', text: `${e.category} expense — ₹${e.amount}`, ts: e.updatedAt || e.createdAt })),
    ].sort((a, b) => (b.ts || '').localeCompare(a.ts || '')).slice(0, 10);

    const box = document.getElementById('financeTimelineBox');
    box.innerHTML = items.length
      ? items.map((i) => `<div class="timeline-item"><div class="ti-icon">${i.icon}</div><div><div class="ti-text">${esc(i.text)}</div><div class="ti-date">${fmtDate(i.date)}</div></div></div>`).join('')
      : '<div class="empty-state"><div class="desc">No transactions recorded yet.</div></div>';
  }

  // ======================================================================
  // TENANT PAYMENT HISTORY (consumed by TenantsController profile view)
  // ======================================================================
  function getTenantFinanceSummary(tenantId) {
    const rents = rentEntries.filter((r) => r.tenantId === tenantId).sort((a, b) => (b.rentMonth || '').localeCompare(a.rentMonth || ''));
    const tenantDeposits = deposits.filter((d) => d.tenantId === tenantId);
    const totalPaid = rents.reduce((s, r) => s + r.amountPaid, 0);
    const outstandingBalance = rents.reduce((s, r) => s + r.remainingBalance, 0);
    const latePayments = rents.filter((r) => r.paymentDate && r.dueDate && r.paymentDate > r.dueDate).length;
    const pendingPayments = rents.filter((r) => r.paymentStatus === 'Pending' || r.paymentStatus === 'Overdue').length;
    return { rents, deposits: tenantDeposits, totalPaid, outstandingBalance, latePayments, pendingPayments };
  }

  // ======================================================================
  // Sub-navigation + Init
  // ======================================================================
  function switchSubTab(subId) {
    document.querySelectorAll('#financeSubnav .fs-tab').forEach((t) => t.classList.toggle('active', t.dataset.sub === subId));
    document.querySelectorAll('#page-finance .finance-subview').forEach((v) => v.classList.toggle('active', v.id === 'sub-' + subId));
    if (subId === 'financeDashboard') renderDashboard();
    if (subId === 'rentCollection') { populateRentFilters(); renderRentList(); }
    if (subId === 'deposits') { populateDepositFilters(); renderDepositsList(); }
    if (subId === 'brokerage') { populatePropertySelect('brokeragePropertyFilter', true); renderOwnerBrokerageConfig(); renderBrokerageList(); }
    if (subId === 'managementFees') { populatePropertySelect('feePropertyFilter', true); renderFeesList(); }
    if (subId === 'expenses') { populatePropertySelect('expensePropertyFilter', true); renderExpensesList(); }
    if (subId === 'ownerPayouts') { populatePayoutOwnerSelect(); renderPayoutHistory(); }
    if (subId === 'fairHomesIncome') renderFairHomesIncome();
  }

  function bindEvents() {
    document.querySelectorAll('#financeSubnav .fs-tab').forEach((tab) => tab.addEventListener('click', () => switchSubTab(tab.dataset.sub)));

    document.getElementById('payoutCalcBtn').addEventListener('click', handleCalculatePayout);
    document.getElementById('payoutRecordBtn').addEventListener('click', handleRecordPayout);

    // Rent
    document.getElementById('addRentBtn').addEventListener('click', openAddRentModal);
    document.getElementById('rentModalCloseBtn').addEventListener('click', closeRentModal);
    document.getElementById('rentCancelBtn').addEventListener('click', closeRentModal);
    document.getElementById('rentSaveBtn').addEventListener('click', handleSaveRent);
    document.getElementById('rentModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'rentModalOverlay') closeRentModal(); });
    document.getElementById('rentTenant').addEventListener('change', (e) => {
      document.getElementById('rentLocationDisplay').textContent = e.target.value ? tenantLocationText(e.target.value) : '';
      checkBrokerageDue(e.target.value);
    });
    document.getElementById('rentAddPendingToBillBtn').addEventListener('click', () => {
      const tenantId = document.getElementById('rentTenant').value;
      const pending = getTenantPendingBalance(tenantId);
      const otherField = document.getElementById('rentOther');
      otherField.value = (Number(otherField.value) || 0) + pending;
      updateRentCalcBox();
      document.getElementById('rentTenantPendingBox').classList.add('hidden');
    });
    document.getElementById('rentAddRoutineToBillBtn').addEventListener('click', () => {
      const box = document.getElementById('rentRoutineDueBox');
      const amount = Number(box.dataset.amount) || 0;
      const otherField = document.getElementById('rentOther');
      otherField.value = (Number(otherField.value) || 0) + amount;
      updateRentCalcBox();
      box.classList.add('hidden');
      box.dataset.added = 'true';
    });
    document.getElementById('rentAddMaintenanceToBillBtn').addEventListener('click', () => {
      const box = document.getElementById('rentMaintenanceDueBox');
      const amount = Number(box.dataset.amount) || 0;
      const maintField = document.getElementById('rentMaintCharges');
      maintField.value = (Number(maintField.value) || 0) + amount;
      updateRentCalcBox();
      box.classList.add('hidden');
      box.dataset.added = 'true';
    });
    document.getElementById('rentAddElectricityToBillBtn').addEventListener('click', () => {
      const box = document.getElementById('rentElectricityDueBox');
      const amount = Number(box.dataset.amount) || 0;
      const elecField = document.getElementById('rentElectricity');
      elecField.value = (Number(elecField.value) || 0) + amount;
      updateRentCalcBox();
      box.classList.add('hidden');
      box.dataset.added = 'true';
    });
    document.getElementById('rentMonth').addEventListener('change', () => {
      checkElectricityDue(document.getElementById('rentTenant').value);
    });
    ['rentMonthlyRent','rentMaintCharges','rentElectricity','rentWater','rentOther','rentDiscount','rentLateFee','rentAmountPaid'].forEach((id) => {
      document.getElementById(id).addEventListener('input', updateRentCalcBox);
    });
    document.getElementById('rentPaymentDate').addEventListener('change', () => {
      const due = document.getElementById('rentDueDate').value;
      const paid = document.getElementById('rentPaymentDate').value;
      const suggested = suggestLateFee(due, paid);
      if (suggested > 0) document.getElementById('rentLateFee').value = suggested;
      updateRentCalcBox();
    });
    document.getElementById('rentSearchInput').addEventListener('input', renderRentList);
    document.getElementById('rentPropertyFilter').addEventListener('change', renderRentList);
    document.getElementById('rentMonthFilter').addEventListener('change', renderRentList);
    document.getElementById('rentYearFilter').addEventListener('change', renderRentList);
    document.getElementById('rentStatusFilter').addEventListener('change', renderRentList);
    document.getElementById('rentMethodFilter').addEventListener('change', renderRentList);

    // Deposits
    document.getElementById('addDepositBtn').addEventListener('click', openAddDepositModal);
    document.getElementById('depositModalCloseBtn').addEventListener('click', closeDepositModal);
    document.getElementById('depositCancelBtn').addEventListener('click', closeDepositModal);
    document.getElementById('depositSaveBtn').addEventListener('click', handleSaveDeposit);
    document.getElementById('depositModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'depositModalOverlay') closeDepositModal(); });
    document.getElementById('depositTenant').addEventListener('change', (e) => { document.getElementById('depositLocationDisplay').textContent = e.target.value ? tenantLocationText(e.target.value) : ''; });
    document.getElementById('depositSearchInput').addEventListener('input', renderDepositsList);
    document.getElementById('depositPropertyFilter').addEventListener('change', renderDepositsList);
    document.getElementById('depositStatusFilter').addEventListener('change', renderDepositsList);

    document.getElementById('refundModalCloseBtn').addEventListener('click', closeRefundModal);
    document.getElementById('refundCancelBtn').addEventListener('click', closeRefundModal);
    document.getElementById('refundSaveBtn').addEventListener('click', handleSaveRefund);
    document.getElementById('refundModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'refundModalOverlay') closeRefundModal(); });

    // Brokerage
    document.getElementById('addBrokerageBtn').addEventListener('click', openAddBrokerageModal);
    document.getElementById('brokerageModalCloseBtn').addEventListener('click', closeBrokerageModal);
    document.getElementById('brokerageType').addEventListener('change', toggleBrokerageTypeFields);
    document.getElementById('brokerageCancelBtn').addEventListener('click', closeBrokerageModal);
    document.getElementById('brokerageSaveBtn').addEventListener('click', handleSaveBrokerage);
    document.getElementById('brokerageModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'brokerageModalOverlay') closeBrokerageModal(); });
    document.getElementById('brokerageTenant').addEventListener('change', (e) => { document.getElementById('brokerageLocationDisplay').textContent = e.target.value ? tenantLocationText(e.target.value) : ''; });
    document.getElementById('brokerageSearchInput').addEventListener('input', renderBrokerageList);
    document.getElementById('brokeragePropertyFilter').addEventListener('change', renderBrokerageList);
    document.getElementById('brokerageStatusFilter').addEventListener('change', renderBrokerageList);

    // Management Fees
    document.getElementById('addFeeBtn').addEventListener('click', openAddFeeModal);
    document.getElementById('feeModalCloseBtn').addEventListener('click', closeFeeModal);
    document.getElementById('feeCancelBtn').addEventListener('click', closeFeeModal);
    document.getElementById('feeSaveBtn').addEventListener('click', handleSaveFee);
    document.getElementById('feeModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'feeModalOverlay') closeFeeModal(); });
    document.getElementById('feeProperty').addEventListener('change', () => { updateFeeOwnerDisplay(); updateFeeAutoCalc(); });
    document.getElementById('feeMonth').addEventListener('change', updateFeeAutoCalc);
    document.getElementById('feeSearchInput').addEventListener('input', renderFeesList);
    document.getElementById('feePropertyFilter').addEventListener('change', renderFeesList);
    document.getElementById('feeStatusFilter').addEventListener('change', renderFeesList);

    // Expenses
    document.getElementById('addExpenseBtn').addEventListener('click', openAddExpenseModal);
    document.getElementById('addBizExpenseBtn').addEventListener('click', handleAddBizExpense);
    document.getElementById('addAdvanceBtn').addEventListener('click', handleAddAdvance);
    document.getElementById('expenseModalCloseBtn').addEventListener('click', closeExpenseModal);
    document.getElementById('expenseCancelBtn').addEventListener('click', closeExpenseModal);
    document.getElementById('expenseSaveBtn').addEventListener('click', handleSaveExpense);
    document.getElementById('expenseModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'expenseModalOverlay') closeExpenseModal(); });
    document.getElementById('expenseSearchInput').addEventListener('input', renderExpensesList);
    document.getElementById('expensePropertyFilter').addEventListener('change', renderExpensesList);
    document.getElementById('expenseCategoryFilter').addEventListener('change', renderExpensesList);
  }

  function onPageShow() {
    const activeTab = document.querySelector('.fs-tab.active');
    switchSubTab(activeTab ? activeTab.dataset.sub : 'financeDashboard');
  }

  function init() {
    load();
    bindEvents();
    renderDashboard();
  }

  /**
   * Programmatic expense creation — used by the Maintenance module (Phase 7)
   * to automatically log an Expense when a ticket is closed with costs.
   * Goes through the same persist()/render pipeline as manually-added
   * expenses, so it behaves identically everywhere in Finance.
   */
  function createExpenseFromMaintenance({ propertyId, category, amount, date, vendor, invoiceNumber, notes, costBearer, sourceLabel }) {
    const now = new Date().toISOString();
    const expenseRecord = {
      id: generateId(), expenseCode: nextCode('expense', 'EXP'),
      propertyId, category, amount: Number(amount) || 0, date, vendor: vendor || '', invoiceNumber: invoiceNumber || '',
      notes: notes || '', createdAt: now, updatedAt: now,
      // costBearer: who this cost is ultimately recovered from — Fair
      // Homes never absorbs it itself. 'Owner' means it goes into the
      // Owner Advance ledger, recovered gradually (possibly across
      // several rent cycles) from that property's future rent. 'Tenant'
      // means the tenant already covered it directly — nothing to
      // recover, but it's still tracked so Owner Reports can show the
      // value Fair Homes delivered.
      costBearer: costBearer || 'Owner', sourceLabel: sourceLabel || category,
    };
    expenses.unshift(expenseRecord);
    persist('expense');
    if (expenseRecord.costBearer === 'Owner' && expenseRecord.amount > 0) {
      createOwnerAdvance({ propertyId, amount: expenseRecord.amount, reason: sourceLabel || category, sourceType: 'maintenance', sourceId: expenseRecord.id });
    }
    return expenseRecord.id;
  }

  /** Unsettled Owner-borne maintenance costs for a property, awaiting
   *  deduction from that property's next rent collection. */
  /**
   * Records Fair Homes' own profit on a maintenance job — the gap
   * between what the vendor/material actually cost and what was billed
   * to the Owner/Tenant. This is Fair Homes' income, separate from the
   * Expense entry (which reflects the Owner/Tenant-facing billed cost).
   */
  function recordMarginIncome({ source, propertyId, amount, label, date, flatId }) {
    const now = new Date().toISOString();
    const id = generateId();
    marginIncome.unshift({
      id, marginCode: nextCode('margin', 'MGN'),
      source: source || 'maintenance', propertyId, flatId: flatId || null, amount: Number(amount) || 0,
      label: label || 'Maintenance Margin', date: date || new Date().toISOString().slice(0, 10),
      createdAt: now,
    });
    persist('margin');
    return { id };
  }
  /** Updates an existing margin income entry — used when the source
   *  record it came from (e.g. a Brokerage-Only Deal) gets edited, so
   *  the Finance figure stays in sync instead of going stale. */
  function updateMarginIncome(id, { amount, label, date }) {
    const idx = marginIncome.findIndex((m) => m.id === id);
    if (idx === -1) return false;
    if (amount !== undefined) marginIncome[idx].amount = Number(amount) || 0;
    if (label !== undefined) marginIncome[idx].label = label;
    if (date !== undefined) marginIncome[idx].date = date;
    persist('margin');
    return true;
  }
  /** Removes a margin income entry entirely — since Gross Income and
   *  Net Profit are always computed live from marginIncome (never
   *  cached), this alone is what makes every downstream total
   *  recalculate correctly the moment the list re-renders. */
  function deleteMarginIncome(id) {
    marginIncome = marginIncome.filter((m) => m.id !== id);
    persist('margin');
  }
  function getAllMarginIncome() { return [...marginIncome]; }

  // ======================================================================
  // OWNER ADVANCE LEDGER — replaces the old one-shot "deduct in full"
  // system. Fair Homes can front money for a property (Owner-borne
  // maintenance/expense, or a manual advance like a renovation shortfall),
  // and recovery happens gradually — whatever a given rent cycle can
  // cover, with the remainder automatically carrying forward to the next
  // cycle until fully settled. Each advance keeps its own outstanding
  // balance and a history of every partial adjustment made against it.
  // ======================================================================
  function createOwnerAdvance({ propertyId, amount, reason, sourceType, sourceId }) {
    const now = new Date().toISOString();
    const advance = {
      id: generateId(), advanceCode: nextCode('advance', 'ADV'),
      propertyId, amount: Number(amount) || 0, outstandingBalance: Number(amount) || 0,
      reason: reason || '', sourceType: sourceType || 'manual', sourceId: sourceId || null,
      status: 'Active', history: [], createdAt: now, updatedAt: now,
    };
    ownerAdvances.unshift(advance);
    persist('advance');
    return advance.id;
  }

  function getActiveAdvancesForProperty(propertyId) {
    return ownerAdvances.filter((a) => a.propertyId === propertyId && a.status === 'Active' && a.outstandingBalance > 0);
  }

  function getTotalOutstandingForProperty(propertyId) {
    return getActiveAdvancesForProperty(propertyId).reduce((s, a) => s + a.outstandingBalance, 0);
  }

  /**
   * Applies `amountToAdjust` against a property's oldest active advances
   * first (FIFO), reducing each one's outstanding balance in turn and
   * marking any that reach ₹0 as Settled. Never adjusts more than what's
   * actually outstanding. Returns the amount actually applied.
   */
  function adjustAdvances(propertyId, amountToAdjust, rentEntryId) {
    let remaining = Number(amountToAdjust) || 0;
    if (remaining <= 0) return 0;
    const now = new Date().toISOString();
    const active = getActiveAdvancesForProperty(propertyId).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    let totalApplied = 0;
    for (const advance of active) {
      if (remaining <= 0) break;
      const applyAmount = Math.min(advance.outstandingBalance, remaining);
      advance.outstandingBalance -= applyAmount;
      advance.history.push({ date: now.slice(0, 10), rentEntryId: rentEntryId || null, amountAdjusted: applyAmount });
      if (advance.outstandingBalance <= 0) advance.status = 'Settled';
      advance.updatedAt = now;
      remaining -= applyAmount;
      totalApplied += applyAmount;
    }
    if (totalApplied > 0) persist('advance');
    return totalApplied;
  }

  function getAllOwnerAdvances() { return [...ownerAdvances]; }

  /** Sums actual advance-recovery amounts adjusted (via Rent Collection)
   *  in a given month, across the given properties — this is what
   *  genuinely reduced the owner's payout that month, unlike the full
   *  original expense amount which may be recovered over several months. */
  function getAdvanceAdjustmentsInMonth(propertyIds, month) {
    let total = 0;
    ownerAdvances.filter((a) => propertyIds.includes(a.propertyId)).forEach((a) => {
      a.history.forEach((h) => { if (h.date.startsWith(month)) total += h.amountAdjusted; });
    });
    return total;
  }

  /**
   * Fair Homes' own business spending (ads, board, stationery, food) and
   * withdrawals — never tied to any property, never billed to any
   * Owner/Tenant. Reduces the "Total Fair Homes Profit" figure directly.
   */
  function recordBusinessExpense({ type, category, amount, date, notes }) {
    const now = new Date().toISOString();
    const rec = {
      id: generateId(), code: nextCode('bizExpense', 'BIZ'),
      type: type || 'Expense', // 'Expense' | 'Withdrawal'
      category: category || 'Miscellaneous', amount: Number(amount) || 0,
      date: date || now.slice(0, 10), notes: notes || '', createdAt: now,
    };
    businessExpenses.unshift(rec);
    persist('bizExpense');
    return rec.id;
  }
  function getAllBusinessExpenses() { return [...businessExpenses]; }
  function deleteBusinessExpense(id) {
    businessExpenses = businessExpenses.filter((b) => b.id !== id);
    persist('bizExpense');
  }

  function getAllRentEntries() { return [...rentEntries]; }
  function getAllDeposits() { return [...deposits]; }
  function getAllBrokerage() { return [...brokerageEntries]; }
  function getAllManagementFees() { return [...managementFees]; }
  function getAllExpenses() { return [...expenses]; }

  function reload() { load(); renderDashboard(); }

  function bulkImportRent(records) {
    const now = new Date().toISOString();
    records.forEach((r) => {
      const tenant = TenantsController.getAll().find((t) => t.fullName.toLowerCase() === (r.tenantName || '').toLowerCase());
      const rent = Number(r.monthlyRent) || 0;
      rentEntries.unshift({
        id: (crypto.randomUUID ? crypto.randomUUID() : 'rent_' + Date.now() + '_' + Math.random().toString(16).slice(2)),
        rentCode: nextCode('rent', 'RENT'),
        tenantId: tenant ? tenant.id : null, propertyId: tenant?.currentAllocation?.propertyId || null,
        roomId: tenant?.currentAllocation?.roomId || null,
        rentMonth: r.rentMonth || '', dueDate: r.dueDate || '', paymentDate: null,
        monthlyRent: rent, maintCharges: 0, electricity: 0, water: 0, other: 0, discount: 0, lateFee: 0,
        totalPayable: rent, remainingBalance: rent, amountPaid: 0, paymentStatus: 'Pending',
        paymentMethod: 'Cash', transactionRef: '', notes: 'Imported', createdAt: now, updatedAt: now,
      });
    });
    persist('rent');
  }

  /** Creates the first month's Rent entry for a tenant who just converted
   *  from a Booking, applying whatever token was collected as the
   *  amountPaid (up to the monthly rent — any excess is left for the
   *  manager to apply toward Deposit/Brokerage themselves, since those
   *  don't support partial amounts as cleanly). Returns how much of the
   *  token got applied here vs how much rent is still outstanding, so
   *  the caller can show an accurate summary. */
  function createInitialRentFromBooking({ tenantId, monthlyRent, tokenCollected, moveInDate }) {
    const rentApplied = Math.min(Number(tokenCollected) || 0, Number(monthlyRent) || 0);
    const rentRemaining = Math.max((Number(monthlyRent) || 0) - rentApplied, 0);
    const rentMonth = (moveInDate || todayIso()).slice(0, 7);

    const dup = rentEntries.some((r) => r.tenantId === tenantId && r.rentMonth === rentMonth);
    if (dup) return { rentApplied: 0, rentRemaining: Number(monthlyRent) || 0 }; // safety: never double-create

    const f = { monthlyRent: Number(monthlyRent) || 0, maintCharges: 0, electricity: 0, water: 0, other: 0, discount: 0, lateFee: 0, amountPaid: rentApplied };
    const { totalPayable, remainingBalance } = computeRentTotals(f);
    const dueDate = moveInDate || todayIso();
    const paymentStatus = computeRentStatus(totalPayable, rentApplied, dueDate);

    const tenant = TenantsController.getById(tenantId);
    const a = tenant?.currentAllocation;
    const now = new Date().toISOString();
    rentEntries.unshift({
      id: generateId(), rentCode: nextCode('rent', 'RENT'), createdAt: now, updatedAt: now,
      tenantId, propertyId: a?.propertyId || null, roomId: a?.roomId || null,
      rentMonth, dueDate, paymentDate: rentApplied > 0 ? (moveInDate || todayIso()) : null,
      ...f, totalPayable, remainingBalance, paymentStatus,
      paymentMethod: 'Cash', transactionRef: '', notes: 'Auto-created from Booking token on conversion.',
    });
    persist('rent');
    renderDashboard();
    return { rentApplied, rentRemaining };
  }

  return {
    init, onPageShow, getTenantFinanceSummary, createExpenseFromMaintenance,
    getAllRentEntries, getAllDeposits, getAllBrokerage, getAllManagementFees, getAllExpenses,
    reload, bulkImportRent,
    recordMarginIncome, getAllMarginIncome, updateMarginIncome, deleteMarginIncome,
    createOwnerAdvance, getActiveAdvancesForProperty, getTotalOutstandingForProperty, adjustAdvances, getAllOwnerAdvances, getAdvanceAdjustmentsInMonth,
    recordBusinessExpense, getAllBusinessExpenses, deleteBusinessExpense, removeExpenseSilently,
    openRefundModal, createInitialRentFromBooking, getTenantPendingBalance,
  };
})();
