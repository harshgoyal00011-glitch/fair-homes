/* ==========================================================================
   Fair Homes OS — Social Media Tasks
   A daily work log for the social-media/admin-support role — WhatsApp
   groups, rent agreements, signing, Google Forms, police verification,
   reviews, SEO, and social handles/content. Full CRUD for whoever's
   assigned this role; Super Admin can review it too. Everything else in
   the app is hidden from this role via the existing Permission Matrix —
   this module doesn't need to know that; it just needs to exist.
   ========================================================================== */

const SocialMediaController = (() => {
  const STORAGE_KEY = 'fh_social_media_tasks';
  const SEQ_KEY = 'fh_smt_seq';
  let tasks = [];
  let editingTaskId = null;

  function esc(str) { if (str === null || str === undefined) return ''; return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
  function generateId() { return (crypto.randomUUID ? crypto.randomUUID() : 'smt_' + Date.now() + '_' + Math.random().toString(16).slice(2)); }
  function todayIso() { return new Date().toISOString().slice(0, 10); }
  function fmtDate(iso) { if (!iso) return '—'; const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }); }
  function nextCode() {
    let n = Number(localStorage.getItem(SEQ_KEY)) || 0;
    n += 1;
    localStorage.setItem(SEQ_KEY, String(n));
    return 'SMT-' + String(n).padStart(4, '0');
  }
  function clearErrors(formId) { document.querySelectorAll('#' + formId + ' .form-error').forEach((el) => (el.textContent = '')); }
  function showErrors(errors) { Object.entries(errors).forEach(([id, msg]) => { const el = document.getElementById('err-' + id); if (el) el.textContent = msg; }); }

  // ---------------- Storage ----------------
  function load() {
    try { tasks = JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; } catch (e) { tasks = []; }
    CloudSync.watch('socialMediaTasks', (arr) => {
      tasks = arr;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
      renderList();
    });
  }
  function persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    CloudSync.sync('socialMediaTasks', tasks);
  }

  // ---------------- List ----------------
  function renderList() {
    const categoryFilter = document.getElementById('smtCategoryFilter').value || 'all';
    const statusFilter = document.getElementById('smtStatusFilter').value || 'all';
    const dateFilter = document.getElementById('smtDateFilter').value || '';
    let list = [...tasks].sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt));
    if (categoryFilter !== 'all') list = list.filter((t) => t.category === categoryFilter);
    if (statusFilter !== 'all') list = list.filter((t) => t.status === statusFilter);
    if (dateFilter) list = list.filter((t) => t.date === dateFilter);

    const box = document.getElementById('smtList');
    if (!list.length) { box.innerHTML = '<div class="empty-state"><div class="ico">📱</div><div class="title">No entries yet</div><div class="desc">Log today\'s work with "+ Add Task Entry".</div></div>'; return; }

    box.innerHTML = list.map((t) => `
      <div class="finance-list-row">
        <div class="fr-main">
          <div class="fr-title">${esc(t.category)} <span class="badge ${t.status === 'Done' ? 'pay-paid' : 'pay-pending'}" style="margin-left:6px;">${t.status}</span></div>
          <div class="fr-sub">${esc(t.code)} · ${fmtDate(t.date)}${t.createdByEmail ? ' · ' + esc(t.createdByEmail) : ''}</div>
          <div class="sc-desc" style="margin-top:4px;">${esc(t.description)}</div>
        </div>
        <div class="fr-actions">
          <button class="btn small secondary smt-edit-btn" data-id="${t.id}">Edit</button>
          <button class="btn small smt-del-btn" data-id="${t.id}" style="background:var(--error); color:#fff;">Delete</button>
        </div>
      </div>`).join('');

    box.querySelectorAll('.smt-edit-btn').forEach((b) => b.addEventListener('click', () => openEditModal(b.dataset.id)));
    box.querySelectorAll('.smt-del-btn').forEach((b) => b.addEventListener('click', () => handleDelete(b.dataset.id)));
  }

  // ---------------- Add/Edit ----------------
  function openAddModal() {
    editingTaskId = null;
    document.getElementById('smtModalTitle').textContent = 'Add Task Entry';
    document.getElementById('smtForm').reset();
    document.getElementById('smtId').value = '';
    document.getElementById('smtDate').value = todayIso();
    document.getElementById('smtStatus').value = 'Done';
    clearErrors('smtForm');
    document.getElementById('smtModalOverlay').classList.add('open');
  }
  function openEditModal(id) {
    const t = tasks.find((x) => x.id === id);
    if (!t) return;
    editingTaskId = id;
    document.getElementById('smtModalTitle').textContent = 'Edit Task Entry';
    document.getElementById('smtId').value = t.id;
    document.getElementById('smtCategory').value = t.category;
    document.getElementById('smtDescription').value = t.description;
    document.getElementById('smtDate').value = t.date;
    document.getElementById('smtStatus').value = t.status;
    clearErrors('smtForm');
    document.getElementById('smtModalOverlay').classList.add('open');
  }
  function closeModal() { document.getElementById('smtModalOverlay').classList.remove('open'); editingTaskId = null; }

  function handleSave() {
    const category = document.getElementById('smtCategory').value;
    const description = document.getElementById('smtDescription').value.trim();
    const date = document.getElementById('smtDate').value;
    const status = document.getElementById('smtStatus').value;

    const errors = {};
    if (!description) errors.smtDescription = 'Describe what was done';
    if (!date) errors.smtDescription = errors.smtDescription || 'Select a date';
    clearErrors('smtForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const now = new Date().toISOString();
    const authUser = (typeof CloudSync !== 'undefined') ? CloudSync.getCurrentUser() : null;
    if (editingTaskId) {
      const idx = tasks.findIndex((t) => t.id === editingTaskId);
      if (idx !== -1) tasks[idx] = { ...tasks[idx], category, description, date, status, updatedAt: now };
    } else {
      tasks.unshift({
        id: generateId(), code: nextCode(), category, description, date, status,
        createdByEmail: authUser ? authUser.email : '', createdAt: now, updatedAt: now,
      });
    }
    persist();
    closeModal();
    renderList();
  }

  function handleDelete(id) {
    const t = tasks.find((x) => x.id === id);
    if (!t) return;
    ConfirmModal.show(`Delete this ${t.category} entry? You can restore it later from Settings → Trash.`, () => {
      TrashController.moveToTrash('socialMediaTask', t, `${t.category} — ${t.date}`);
      tasks = tasks.filter((x) => x.id !== id);
      persist();
      renderList();
    });
  }

  // ---------------- Init ----------------
  function bindEvents() {
    document.getElementById('addSmtBtn').addEventListener('click', openAddModal);
    document.getElementById('smtModalCloseBtn').addEventListener('click', closeModal);
    document.getElementById('smtCancelBtn').addEventListener('click', closeModal);
    document.getElementById('smtModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'smtModalOverlay') closeModal(); });
    document.getElementById('smtSaveBtn').addEventListener('click', handleSave);

    document.getElementById('smtCategoryFilter').addEventListener('change', renderList);
    document.getElementById('smtStatusFilter').addEventListener('change', renderList);
    document.getElementById('smtDateFilter').addEventListener('change', renderList);
  }

  function onPageShow() { renderList(); }
  function init() { load(); bindEvents(); }
  function reload() { load(); renderList(); }

  const ONBOARDING_CHECKLIST_ITEMS = ['Google Form', 'Agreement', 'Police Verification', 'Review Collection'];

  /** Auto-generates the 4 standard onboarding checklist entries for a
   *  newly created Tenant, tagged with tenantId so they show up
   *  together and Tenant Detail can pull a live "X/4 done" summary.
   *  Skips any item that already exists for this tenant, so calling
   *  this again (e.g. after an edit) never duplicates entries. */
  function createOnboardingChecklist(tenantId, tenantName) {
    const now = new Date().toISOString();
    const authUser = (typeof CloudSync !== 'undefined') ? CloudSync.getCurrentUser() : null;
    let added = false;
    ONBOARDING_CHECKLIST_ITEMS.forEach((item) => {
      const exists = tasks.some((t) => t.tenantId === tenantId && t.checklistItem === item);
      if (exists) return;
      tasks.unshift({
        id: generateId(), code: nextCode(), category: item === 'Agreement' ? 'Agreement Signing' : item,
        description: `${item} — ${tenantName}`, date: now.slice(0, 10), status: 'Pending',
        tenantId, tenantName, checklistItem: item,
        createdByEmail: authUser ? authUser.email : '', createdAt: now, updatedAt: now,
      });
      added = true;
    });
    if (added) persist();
  }

  /** Used by Tenant Detail to show a live onboarding progress summary
   *  without needing to navigate into Social Media Tasks separately. */
  function getOnboardingChecklistForTenant(tenantId) {
    return tasks.filter((t) => t.tenantId === tenantId && t.checklistItem);
  }

  return { init, onPageShow, reload, getAll: () => [...tasks], createOnboardingChecklist, getOnboardingChecklistForTenant };
})();
