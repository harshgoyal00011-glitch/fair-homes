/* ==========================================================================
   Fair Homes OS — Notifications, Reminders & Automation Engine (Phase 9)
   Pure "scan and reconcile" automation: every time this page is opened,
   it scans real data from every other module (Tenants, Finance,
   Maintenance, Properties, Owners) against fixed thresholds and creates
   notifications idempotently (never duplicates the same event).
   No WhatsApp/Email API integration — only message generation (Section 15).
   ========================================================================== */

const NotificationsController = (() => {
  const KEYS = { notif: 'fh_notifications', task: 'fh_task_reminders', log: 'fh_automation_logs', tmpl: 'fh_message_templates' };
  let notifications = [], tasks = [], automationLogs = [], templates = [];
  let editingTaskId = null, editingTemplateId = null;
  let calendarDate = new Date();
  let previewContext = null; // { phone, email, text, subject }

  const CATEGORY_META = {
    'Rent Due': { icon: '⏳', cls: 'cat-rentdue' }, 'Rent Received': { icon: '💰', cls: 'cat-rentreceived' },
    'Security Deposit': { icon: '🔒', cls: 'cat-deposit' }, 'Maintenance': { icon: '🔧', cls: 'cat-maintenance' },
    'Move In': { icon: '🏠', cls: 'cat-movein' }, 'Move Out': { icon: '🚪', cls: 'cat-moveout' },
    'Owner Settlement': { icon: '🤝', cls: 'cat-settlement' }, 'Lease Expiry': { icon: '📄', cls: 'cat-lease' },
    'Reminder': { icon: '🔔', cls: 'cat-reminder' }, 'System Alert': { icon: '⚙️', cls: 'cat-system' },
  };

  const TEMPLATE_CATEGORIES = ['Rent Reminder', 'Payment Received', 'Move In Welcome', 'Move Out Thank You', 'Maintenance Update', 'Owner Settlement', 'General Notice'];
  const TEMPLATE_VARS = ['{{TenantName}}', '{{OwnerName}}', '{{PropertyName}}', '{{Room}}', '{{Rent}}', '{{DueDate}}'];

  const DEFAULT_BODIES = {
    'Rent Reminder': 'Hi {{TenantName}}, a reminder that your rent of ₹{{Rent}} for {{PropertyName}} (Room {{Room}}, Bed {{Bed}}) is due on {{DueDate}}. Please arrange payment at your earliest convenience. Thank you!',
    'Payment Received': 'Hi {{TenantName}}, we have received your rent payment of ₹{{Rent}} for {{PropertyName}}. Thank you for your prompt payment!',
    'Move In Welcome': 'Welcome {{TenantName}}! We are happy to have you at {{PropertyName}}, Room {{Room}}, Bed {{Bed}}. Reach out anytime if you need assistance.',
    'Move Out Thank You': 'Dear {{TenantName}}, thank you for staying with us at {{PropertyName}}. We wish you all the best ahead!',
    'Maintenance Update': 'Hi {{TenantName}}, your maintenance request for {{PropertyName}} (Room {{Room}}) has an update. We will keep you posted on progress.',
    'Owner Settlement': 'Hi {{OwnerName}}, your monthly settlement for {{PropertyName}} has been processed. Please check your account for details.',
    'General Notice': 'Dear {{TenantName}}, this is a notice regarding {{PropertyName}}. Please contact the property manager for more details.',
  };
  const DEFAULT_SUBJECTS = {
    'Rent Reminder': 'Rent Payment Reminder — {{PropertyName}}', 'Payment Received': 'Rent Payment Received — {{PropertyName}}',
    'Move In Welcome': 'Welcome to {{PropertyName}}', 'Move Out Thank You': 'Thank You — {{PropertyName}}',
    'Maintenance Update': 'Maintenance Update — {{PropertyName}}', 'Owner Settlement': 'Monthly Settlement — {{PropertyName}}',
    'General Notice': 'Notice — {{PropertyName}}',
  };

  // ---------------- Storage ----------------
  function load() {
    try { notifications = JSON.parse(localStorage.getItem(KEYS.notif)) || []; } catch (e) { notifications = []; }
    try { tasks = JSON.parse(localStorage.getItem(KEYS.task)) || []; } catch (e) { tasks = []; }
    try { automationLogs = JSON.parse(localStorage.getItem(KEYS.log)) || []; } catch (e) { automationLogs = []; }
    try { templates = JSON.parse(localStorage.getItem(KEYS.tmpl)) || []; } catch (e) { templates = []; }
    if (!templates.length) seedDefaultTemplates();

    CloudSync.watch('notifications', (arr) => { notifications = arr; localStorage.setItem(KEYS.notif, JSON.stringify(arr)); refreshActiveNotifTab(); });
    CloudSync.watch('taskReminders', (arr) => { tasks = arr; localStorage.setItem(KEYS.task, JSON.stringify(arr)); refreshActiveNotifTab(); });
    CloudSync.watch('automationLogs', (arr) => { automationLogs = arr; localStorage.setItem(KEYS.log, JSON.stringify(arr)); refreshActiveNotifTab(); });
    CloudSync.watch('messageTemplates', (arr) => { if (arr.length) { templates = arr; localStorage.setItem(KEYS.tmpl, JSON.stringify(arr)); refreshActiveNotifTab(); } });
  }
  const CLOUD_COLLECTION = { notif: 'notifications', task: 'taskReminders', log: 'automationLogs', tmpl: 'messageTemplates' };
  function persist(type) {
    const map = { notif: notifications, task: tasks, log: automationLogs, tmpl: templates };
    localStorage.setItem(KEYS[type], JSON.stringify(map[type]));
    CloudSync.sync(CLOUD_COLLECTION[type], map[type]);
  }
  function refreshActiveNotifTab() {
    const activeTab = document.querySelector('#notifSubnav .rs-tab.active');
    if (activeTab) switchSubTab(activeTab.dataset.nsub);
  }
  function generateId() { return (crypto.randomUUID ? crypto.randomUUID() : 'id_' + Date.now() + '_' + Math.random().toString(16).slice(2)); }

  function seedDefaultTemplates() {
    // Seeds starter TEMPLATE TEXT only (configuration, not business/demo data) —
    // fully editable afterward, per "Create editable templates for..." requirement.
    TEMPLATE_CATEGORIES.forEach((cat) => {
      templates.push({ id: generateId(), type: 'whatsapp', category: cat, subject: '', body: DEFAULT_BODIES[cat], updatedAt: new Date().toISOString() });
      templates.push({ id: generateId(), type: 'email', category: cat, subject: DEFAULT_SUBJECTS[cat], body: DEFAULT_BODIES[cat], updatedAt: new Date().toISOString() });
    });
    persist('tmpl');
  }

  // ---------------- Helpers ----------------
  function esc(str) { if (str === null || str === undefined) return ''; return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
  function todayIso() { return new Date().toISOString().slice(0, 10); }
  function fmtDate(iso) { if (!iso) return '—'; const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }); }
  function fmtDateTime(iso) { if (!iso) return '—'; const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); }
  function daysBetween(a, b) { return Math.round((new Date(a) - new Date(b)) / 86400000); }
  function clearErrors(formId) { document.querySelectorAll('#' + formId + ' .form-error').forEach((el) => (el.textContent = '')); }
  function showErrors(errors) { Object.entries(errors).forEach(([id, msg]) => { const el = document.getElementById('err-' + id); if (el) el.textContent = msg; }); }

  function notificationExists(sourceType, sourceId, window) {
    return notifications.some((n) => n.sourceType === sourceType && n.sourceId === sourceId && n.window === window);
  }

  function createNotification({ category, title, message, priority, propertyId, ownerId, tenantId, sourceType, sourceId, window }) {
    const n = {
      id: generateId(), category, title, message, priority: priority || 'Low', status: 'Unread',
      propertyId: propertyId || null, ownerId: ownerId || null, tenantId: tenantId || null,
      sourceType: sourceType || null, sourceId: sourceId || null, window: window || null,
      createdAt: new Date().toISOString(), readAt: null, archivedAt: null,
    };
    notifications.unshift(n);
    return n;
  }

  function logAutomation(ruleName, details, notificationId) {
    automationLogs.unshift({ id: generateId(), ruleName, details, notificationId: notificationId || null, triggeredAt: new Date().toISOString() });
  }

  // ======================================================================
  // AUTOMATION ENGINE — SCAN FUNCTIONS (Section 8, rule-based)
  // ======================================================================
  function scanRentReminders() {
    const windows = { '-7': '7 Days Before Due Date', '-3': '3 Days Before Due Date', '0': 'Due Today', '1': '1 Day Overdue', '3': '3 Days Overdue', '7': '7 Days Overdue' };
    FinanceController.getAllRentEntries().filter((r) => r.paymentStatus !== 'Paid').forEach((r) => {
      const diff = daysBetween(todayIso(), r.dueDate) * -1; // positive = overdue, negative = before due
      const key = String(diff);
      if (!windows[key]) return;
      if (notificationExists('rent_reminder', r.id, key)) return;
      const tenant = TenantsController.getById(r.tenantId);
      const n = createNotification({
        category: 'Rent Due',
        title: `Rent ${windows[key]} — ${tenant ? tenant.fullName : 'Tenant'}`,
        message: `₹${r.remainingBalance} due for ${r.rentCode} (${windows[key]}).`,
        priority: diff >= 1 ? 'High' : diff === 0 ? 'Medium' : 'Low',
        propertyId: r.propertyId, tenantId: r.tenantId, sourceType: 'rent_reminder', sourceId: r.id, window: key,
      });
      logAutomation('Rent Reminder — ' + windows[key], `IF Rent Due (${windows[key]}) → Notification created for ${tenant?.fullName || 'tenant'} → WhatsApp message ready`, n.id);
    });
  }

  /** Every property needs its Management Fee recorded each month, but
   *  nothing used to prompt for it — unlike Rent or Lease Expiry, it
   *  was easy to just forget for a property. This surfaces it the same
   *  way, once per property per month, until it's recorded. */
  function scanManagementFeeReminders() {
    if (typeof PropertiesController === 'undefined' || typeof FinanceController === 'undefined') return;
    const thisMonth = todayIso().slice(0, 7);
    const allFees = FinanceController.getAllManagementFees();
    PropertiesController.getAll().forEach((p) => {
      if (p.underMaintenance) return; // not actively managed right now — nothing to bill for
      const recorded = allFees.some((f) => f.propertyId === p.id && f.month === thisMonth);
      if (recorded) return;
      if (notificationExists('mgmt_fee_reminder', p.id, thisMonth)) return;
      const n = createNotification({
        category: 'Reminder', title: `Record Management Fee — ${p.society || p.name}`,
        message: `${thisMonth} ka Management Fee abhi tak record nahi hua is property ke liye.`,
        priority: 'Medium', propertyId: p.id,
        sourceType: 'mgmt_fee_reminder', sourceId: p.id, window: thisMonth,
      });
      logAutomation('Management Fee Reminder', `${p.name} — ${thisMonth} fee not yet recorded`, n.id);
    });
  }

  function scanLeaseExpiry() {
    const windows = [30, 15, 7, 1];
    TenantsController.getAll().filter((t) => t.currentAllocation?.agreementEnd).forEach((t) => {
      const diff = daysBetween(t.currentAllocation.agreementEnd, todayIso());
      if (!windows.includes(diff)) return;
      const key = String(diff);
      if (notificationExists('lease_expiry', t.id, key)) return;
      const property = PropertiesController.getAll().find((p) => p.id === t.currentAllocation.propertyId);
      const n = createNotification({
        category: 'Lease Expiry',
        title: `Lease expiring in ${diff} day(s) — ${t.fullName}`,
        message: `Agreement for ${property ? property.name : 'property'} ends on ${fmtDate(t.currentAllocation.agreementEnd)}.`,
        priority: diff <= 7 ? 'High' : 'Medium',
        propertyId: t.currentAllocation.propertyId, tenantId: t.id, sourceType: 'lease_expiry', sourceId: t.id, window: key,
      });
      logAutomation('Lease Expiry — ' + diff + ' days', `IF Lease Expiring (${diff}d) → Notify Manager → Notify Tenant`, n.id);
    });
  }

  function scanOwnerSettlement() {
    const thisMonth = todayIso().slice(0, 7);
    OwnersController.getAll().forEach((o) => {
      const ownerProperties = PropertiesController.getAll().filter((p) => p.ownerId === o.id);
      if (!ownerProperties.length) return;
      const fees = FinanceController.getAllManagementFees().filter((f) => ownerProperties.some((p) => p.id === f.propertyId) && f.month === thisMonth);
      if (!fees.length) return;
      const allPaid = fees.every((f) => f.status === 'Paid');
      const key = thisMonth + (allPaid ? '_completed' : '_pending');
      if (notificationExists('owner_settlement', o.id, key)) return;
      const n = createNotification({
        category: 'Owner Settlement',
        title: allPaid ? `Settlement completed — ${o.fullName}` : `Settlement pending — ${o.fullName}`,
        message: allPaid ? `Monthly management fee settlement for ${fmtDate(todayIso())} is complete.` : `Monthly management fee settlement is still pending.`,
        priority: allPaid ? 'Low' : 'Medium',
        ownerId: o.id, sourceType: 'owner_settlement', sourceId: o.id, window: key,
      });
      logAutomation('Owner Settlement — ' + (allPaid ? 'Completed' : 'Pending'), `Checked management fees for ${o.fullName} (${thisMonth})`, n.id);
    });
  }

  function scanMaintenanceReminders() {
    MaintenanceController.getAllTickets().forEach((t) => {
      // New Complaint Created
      if (!notificationExists('maintenance_reminder', t.id, 'created')) {
        const n = createNotification({ category: 'Maintenance', title: `New Complaint — ${t.ticketId}`, message: `${t.category} issue reported.`, priority: t.priority === 'Emergency' ? 'High' : 'Low', propertyId: t.propertyId, tenantId: t.tenantId, sourceType: 'maintenance_reminder', sourceId: t.id, window: 'created' });
        logAutomation('Maintenance — New Complaint', `IF Maintenance Created → Notify Manager (${t.ticketId})`, n.id);
      }
      // Ticket Assigned
      if (t.assignment && !notificationExists('maintenance_reminder', t.id, 'assigned')) {
        const n = createNotification({ category: 'Maintenance', title: `Ticket Assigned — ${t.ticketId}`, message: `Assigned to ${t.assignment.staffName || t.assignment.vendorName || 'vendor'}.`, priority: 'Low', propertyId: t.propertyId, tenantId: t.tenantId, sourceType: 'maintenance_reminder', sourceId: t.id, window: 'assigned' });
        logAutomation('Maintenance — Assigned', `Ticket ${t.ticketId} assigned`, n.id);
      }
      // Ticket Pending (still Open 2+ days)
      if (t.status === 'Open' && daysBetween(todayIso(), t.dateTime.slice(0, 10)) >= 2 && !notificationExists('maintenance_reminder', t.id, 'pending')) {
        const n = createNotification({ category: 'Maintenance', title: `Ticket Pending — ${t.ticketId}`, message: `Still unassigned after 2+ days.`, priority: 'Medium', propertyId: t.propertyId, tenantId: t.tenantId, sourceType: 'maintenance_reminder', sourceId: t.id, window: 'pending' });
        logAutomation('Maintenance — Pending', `Ticket ${t.ticketId} pending action`, n.id);
      }
      // Ticket Overdue (past expected completion date)
      if (t.assignment?.expectedCompletionDate && !['Completed', 'Closed', 'Cancelled'].includes(t.status) && t.assignment.expectedCompletionDate < todayIso() && !notificationExists('maintenance_reminder', t.id, 'overdue')) {
        const n = createNotification({ category: 'Maintenance', title: `Ticket Overdue — ${t.ticketId}`, message: `Past expected completion date (${fmtDate(t.assignment.expectedCompletionDate)}).`, priority: 'High', propertyId: t.propertyId, tenantId: t.tenantId, sourceType: 'maintenance_reminder', sourceId: t.id, window: 'overdue' });
        logAutomation('Maintenance — Overdue', `Ticket ${t.ticketId} overdue`, n.id);
      }
      // Ticket Closed
      if (t.status === 'Closed' && !notificationExists('maintenance_reminder', t.id, 'closed')) {
        const n = createNotification({ category: 'Maintenance', title: `Ticket Closed — ${t.ticketId}`, message: `Resolved and closed.`, priority: 'Low', propertyId: t.propertyId, tenantId: t.tenantId, sourceType: 'maintenance_reminder', sourceId: t.id, window: 'closed' });
        logAutomation('Maintenance — Closed', `Ticket ${t.ticketId} closed`, n.id);
      }
    });
  }

  function runAutomation() {
    scanRentReminders();
    scanLeaseExpiry();
    scanOwnerSettlement();
    scanManagementFeeReminders();
    scanMaintenanceReminders();
    scanStaleBookings();
    scanVacantRooms();
    scanExpectedPaymentDates();
    scanRoomOccupancyChanges();
    persist('notif');
    persist('log');
  }

  /** Detects when a room's occupant count changes (a roommate joined or
   *  left, or the last tenant moved out/in) — rent is often meant to be
   *  split differently once occupancy changes, but nothing recalculates
   *  it automatically, so this at least surfaces "go check if rent
   *  needs updating" instead of it being silently forgotten. */
  function scanRoomOccupancyChanges() {
    if (typeof RoomsController === 'undefined') return;
    RoomsController.getAllRooms().forEach((room) => {
      const occupiedCount = RoomsController.activeTenantsInRoom(room.id).length;
      const lastKnown = room.lastKnownOccupancy;
      if (lastKnown === undefined || lastKnown === null) {
        RoomsController.updateLastKnownOccupancy(room.id, occupiedCount); // first time seeing this room — just record baseline
        return;
      }
      if (occupiedCount === lastKnown) return;
      const windowKey = occupiedCount + '@' + todayIso();
      if (!notificationExists('room_occupancy_change', room.id, windowKey)) {
        const property = PropertiesController.getAll().find((p) => p.id === room.propertyId);
        const n = createNotification({
          category: 'Reminder', title: `Room Occupancy Changed — ${property ? (property.society || property.name) : 'Property'}`,
          message: `Room ${room.roomNumber} now has ${occupiedCount} occupant(s), was ${lastKnown} — check if rent needs updating for the remaining tenant(s).`,
          priority: 'Medium', propertyId: room.propertyId,
          sourceType: 'room_occupancy_change', sourceId: room.id, window: windowKey,
        });
        logAutomation('Room Occupancy Changed', `Room ${room.roomNumber}: ${lastKnown} -> ${occupiedCount}`, n.id);
      }
      RoomsController.updateLastKnownOccupancy(room.id, occupiedCount);
    });
  }

  /** Reminds when a tenant's committed "I'll pay the rest on X date" has
   *  arrived (or passed) and the balance is still outstanding — so a
   *  promised date doesn't just get forgotten once it's typed in. */
  function scanExpectedPaymentDates() {
    if (typeof FinanceController === 'undefined') return;
    FinanceController.getAllRentEntries().forEach((r) => {
      if (!r.expectedPaymentDate || r.remainingBalance <= 0) return;
      if (new Date(r.expectedPaymentDate) > new Date(todayIso())) return; // date hasn't arrived yet
      if (notificationExists('expected_payment', r.id, r.expectedPaymentDate)) return;
      const tenant = typeof TenantsController !== 'undefined' ? TenantsController.getById(r.tenantId) : null;
      const n = createNotification({
        category: 'Rent Due', title: `Promised Payment Due — ${tenant ? tenant.fullName : 'Tenant'}`,
        message: `Said they'd pay the remaining ₹${r.remainingBalance} by ${fmtDate(r.expectedPaymentDate)}. Follow up.`,
        priority: 'High', propertyId: r.propertyId, tenantId: r.tenantId,
        sourceType: 'expected_payment', sourceId: r.id, window: r.expectedPaymentDate,
      });
      logAutomation('Promised Payment Date Reached', `${tenant ? tenant.fullName : 'Tenant'} — ₹${r.remainingBalance} still pending`, n.id);
    });
  }

  /** Flags rooms that have sat Available for 7/14/30+ days — every empty
   *  day is lost rent, so this surfaces it instead of it going unnoticed
   *  until someone happens to check occupancy manually. Escalates at
   *  each threshold, and correctly re-alerts if a room is later
   *  reoccupied and then falls vacant again (the window key is tied to
   *  THIS specific vacancy period's start time, not just the room id). */
  function scanVacantRooms() {
    if (typeof RoomsController === 'undefined') return;
    const thresholds = [7, 14, 30];
    RoomsController.getAllRooms().forEach((room) => {
      if (RoomsController.computeRoomStatus(room.id) !== 'Available' || !room.vacantSince) return;
      const daysVacant = daysBetween(todayIso(), room.vacantSince.slice(0, 10));
      thresholds.forEach((threshold) => {
        if (daysVacant < threshold) return;
        const windowKey = room.vacantSince + ':' + threshold;
        if (notificationExists('vacant_room', room.id, windowKey)) return;
        const property = PropertiesController.getAll().find((p) => p.id === room.propertyId);
        const n = createNotification({
          category: 'Reminder', title: `Room Vacant ${daysVacant} Days — ${property ? (property.society || property.name) : 'Property'}`,
          message: `Room ${room.roomNumber} has been empty for ${daysVacant} days.`,
          priority: threshold >= 30 ? 'High' : 'Medium', propertyId: property ? property.id : null,
          sourceType: 'vacant_room', sourceId: room.id, window: windowKey,
        });
        logAutomation(`Vacant Room — ${threshold}+ Days`, `Room ${room.roomNumber} vacant ${daysVacant} days`, n.id);
      });
    });
  }

  /** Flags Bookings still 'Active' (token collected, not yet converted to
   *  a Tenant or cancelled) after 7+ days — a booking sitting that long
   *  usually means it needs a follow-up call, not that it's fine to
   *  ignore indefinitely. */
  function scanStaleBookings() {
    if (typeof BookingsController === 'undefined') return;
    BookingsController.getAll().forEach((b) => {
      if (b.status !== 'Active') return;
      const daysSinceCreated = daysBetween(todayIso(), b.createdAt.slice(0, 10));
      if (daysSinceCreated >= 7 && !notificationExists('booking_reminder', b.id, 'stale')) {
        const n = createNotification({
          category: 'Reminder', title: `Booking Pending — ${b.clientName}`,
          message: `Token collected ${daysSinceCreated} days ago, still not converted to Tenant or cancelled.`,
          priority: 'Medium', propertyId: b.propertyId, sourceType: 'booking_reminder', sourceId: b.id, window: 'stale',
        });
        logAutomation('Booking — Stale', `Booking for ${b.clientName} pending ${daysSinceCreated}+ days`, n.id);
      }
    });
  }

  // ======================================================================
  // 1. NOTIFICATION CENTER
  // ======================================================================
  function markRead(id) { const n = notifications.find((x) => x.id === id); if (n && n.status === 'Unread') { n.status = 'Read'; n.readAt = new Date().toISOString(); persist('notif'); renderCenter(); renderDashboard(); } }
  function archiveNotif(id) { const n = notifications.find((x) => x.id === id); if (n) { n.status = 'Archived'; n.archivedAt = new Date().toISOString(); persist('notif'); renderCenter(); renderDashboard(); } }
  function markAllRead() { notifications.forEach((n) => { if (n.status === 'Unread') { n.status = 'Read'; n.readAt = new Date().toISOString(); } }); persist('notif'); renderCenter(); renderDashboard(); }

  function populateNotifFilters() {
    const catSel = document.getElementById('notifCategoryFilter');
    const current = catSel.value;
    catSel.innerHTML = '<option value="all">All Categories</option>' + Object.keys(CATEGORY_META).map((c) => `<option value="${c}">${c}</option>`).join('');
    catSel.value = current || 'all';
    const propSel = document.getElementById('notifPropertyFilter');
    const currentP = propSel.value;
    propSel.innerHTML = '<option value="all">All Properties</option>' + PropertiesController.getAll().map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
    propSel.value = currentP || 'all';
    const ownerSel = document.getElementById('notifOwnerFilter');
    const currentO = ownerSel.value;
    ownerSel.innerHTML = '<option value="all">All Owners</option>' + OwnersController.getAll().map((o) => `<option value="${o.id}">${esc(o.fullName)}</option>`).join('');
    ownerSel.value = currentO || 'all';
    const tenantSel = document.getElementById('notifTenantFilter');
    const currentT = tenantSel.value;
    tenantSel.innerHTML = '<option value="all">All Tenants</option>' + TenantsController.getAll().map((t) => `<option value="${t.id}">${esc(t.fullName)}</option>`).join('');
    tenantSel.value = currentT || 'all';
  }

  function renderCenter() {
    const query = (document.getElementById('notifSearchInput')?.value || '').toLowerCase().trim();
    const catFilter = document.getElementById('notifCategoryFilter')?.value || 'all';
    const propFilter = document.getElementById('notifPropertyFilter')?.value || 'all';
    const ownerFilter = document.getElementById('notifOwnerFilter')?.value || 'all';
    const tenantFilter = document.getElementById('notifTenantFilter')?.value || 'all';
    const priorityFilter = document.getElementById('notifPriorityFilter')?.value || 'all';
    const dateFilter = document.getElementById('notifDateFilter')?.value || '';
    const statusFilter = document.getElementById('notifStatusTab')?.value || 'all';

    const list = notifications.filter((n) =>
      (n.title.toLowerCase().includes(query) || n.message.toLowerCase().includes(query)) &&
      (catFilter === 'all' || n.category === catFilter) &&
      (propFilter === 'all' || n.propertyId === propFilter) &&
      (ownerFilter === 'all' || n.ownerId === ownerFilter) &&
      (tenantFilter === 'all' || n.tenantId === tenantFilter) &&
      (priorityFilter === 'all' || n.priority === priorityFilter) &&
      (!dateFilter || n.createdAt.startsWith(dateFilter)) &&
      (statusFilter === 'all' || n.status === statusFilter)
    );

    const box = document.getElementById('notifCenterList');
    if (!list.length) { box.innerHTML = '<div class="empty-state"><div class="ico">🔔</div><div class="title">No notifications</div><div class="desc">Automation will generate notifications here as real events occur.</div></div>'; return; }

    box.innerHTML = list.map((n) => {
      const meta = CATEGORY_META[n.category] || CATEGORY_META['System Alert'];
      return `
        <div class="notif-card ${n.status === 'Unread' ? 'unread' : ''} priority-${n.priority.toLowerCase()}" data-id="${n.id}">
          <div>
            <div class="nc-title"><span class="nc-icon">${meta.icon}</span>${esc(n.title)} <span class="badge ${meta.cls}" style="margin-left:6px;">${n.category}</span></div>
            <div class="nc-message">${esc(n.message)}</div>
            <div class="nc-meta">${fmtDateTime(n.createdAt)} · ${n.status}</div>
          </div>
          <div class="nc-actions">
            ${n.status === 'Unread' ? `<button class="btn small secondary nf-read-btn" data-id="${n.id}">Mark Read</button>` : ''}
            ${n.status !== 'Archived' ? `<button class="btn small secondary nf-archive-btn" data-id="${n.id}">Archive</button>` : ''}
            ${n.tenantId || n.ownerId ? `<button class="btn small nf-prepare-btn" data-id="${n.id}">Prepare Message</button>` : ''}
          </div>
        </div>`;
    }).join('');

    box.querySelectorAll('.nf-read-btn').forEach((b) => b.addEventListener('click', () => markRead(b.dataset.id)));
    box.querySelectorAll('.nf-archive-btn').forEach((b) => b.addEventListener('click', () => archiveNotif(b.dataset.id)));
    box.querySelectorAll('.nf-prepare-btn').forEach((b) => b.addEventListener('click', () => prepareFromNotification(b.dataset.id)));
  }

  // ======================================================================
  // REMINDER HISTORY (Sections 2–5 — filtered views of notifications)
  // ======================================================================
  function renderReminderHistory() {
    renderHistoryBox('rentReminderHistory', notifications.filter((n) => n.sourceType === 'rent_reminder'));
    renderHistoryBox('leaseReminderHistory', notifications.filter((n) => n.sourceType === 'lease_expiry'));
    renderHistoryBox('settlementReminderHistory', notifications.filter((n) => n.sourceType === 'owner_settlement'));
    renderHistoryBox('maintReminderHistory', notifications.filter((n) => n.sourceType === 'maintenance_reminder'));
  }
  function renderHistoryBox(elId, list) {
    const box = document.getElementById(elId);
    box.innerHTML = list.length
      ? list.slice(0, 20).map((n) => `<div class="history-item"><div class="hi-title">${esc(n.title)}</div><div class="hi-row">${fmtDateTime(n.createdAt)} · ${esc(n.message)}</div></div>`).join('')
      : '<div class="empty-state"><div class="desc">No reminders generated yet.</div></div>';
  }

  // ======================================================================
  // 9. TASK REMINDERS
  // ======================================================================
  function populateTaskSelects() {
    setOpts('taskProperty', PropertiesController.getAll().map((p) => ({ id: p.id, name: p.name })), 'None');
    setOpts('taskOwner', OwnersController.getAll().map((o) => ({ id: o.id, name: o.fullName })), 'None');
    setOpts('taskTenant', TenantsController.getAll().map((t) => ({ id: t.id, name: t.fullName })), 'None');
  }
  function setOpts(selId, items, placeholder) {
    const sel = document.getElementById(selId);
    const current = sel.value;
    sel.innerHTML = `<option value="">${placeholder}</option>` + items.map((i) => `<option value="${i.id}">${esc(i.name)}</option>`).join('');
    sel.value = current;
  }

  function openAddTaskModal() {
    editingTaskId = null;
    document.getElementById('taskModalTitle').textContent = 'New Task Reminder';
    document.getElementById('taskForm').reset();
    document.getElementById('taskId').value = '';
    populateTaskSelects();
    clearErrors('taskForm');
    document.getElementById('taskModalOverlay').classList.add('open');
  }
  function openEditTaskModal(id) {
    const t = tasks.find((x) => x.id === id);
    if (!t) return;
    editingTaskId = id;
    document.getElementById('taskModalTitle').textContent = 'Edit Task Reminder';
    populateTaskSelects();
    document.getElementById('taskId').value = t.id;
    document.getElementById('taskType').value = t.type;
    document.getElementById('taskTitle').value = t.title;
    document.getElementById('taskProperty').value = t.propertyId || '';
    document.getElementById('taskOwner').value = t.ownerId || '';
    document.getElementById('taskTenant').value = t.tenantId || '';
    document.getElementById('taskDueDate').value = t.dueDate;
    document.getElementById('taskNotes').value = t.notes || '';
    clearErrors('taskForm');
    document.getElementById('taskModalOverlay').classList.add('open');
  }
  function closeTaskModal() { document.getElementById('taskModalOverlay').classList.remove('open'); editingTaskId = null; }

  function handleSaveTask() {
    const type = document.getElementById('taskType').value;
    const title = document.getElementById('taskTitle').value.trim();
    const propertyId = document.getElementById('taskProperty').value || null;
    const ownerId = document.getElementById('taskOwner').value || null;
    const tenantId = document.getElementById('taskTenant').value || null;
    const dueDate = document.getElementById('taskDueDate').value;
    const notes = document.getElementById('taskNotes').value.trim();

    const errors = {};
    if (!title) errors.taskTitle = 'Title is required';
    if (!dueDate) errors.taskDueDate = 'Due date is required';
    clearErrors('taskForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const now = new Date().toISOString();
    if (editingTaskId) {
      const idx = tasks.findIndex((t) => t.id === editingTaskId);
      if (idx !== -1) tasks[idx] = { ...tasks[idx], type, title, propertyId, ownerId, tenantId, dueDate, notes, updatedAt: now };
    } else {
      tasks.unshift({ id: generateId(), type, title, propertyId, ownerId, tenantId, dueDate, notes, status: 'Pending', createdAt: now, updatedAt: now });
    }
    persist('task');
    closeTaskModal();
    renderTasks();
  }

  function toggleTaskStatus(id) { const t = tasks.find((x) => x.id === id); if (t) { t.status = t.status === 'Pending' ? 'Completed' : 'Pending'; persist('task'); renderTasks(); } }
  function deleteTask(id) {
    const t = tasks.find((x) => x.id === id);
    if (!t) return;
    ConfirmModal.show('Delete this task reminder? You can restore it later from Settings → Trash.', () => {
      TrashController.moveToTrash('task', t, t.title);
      tasks = tasks.filter((x) => x.id !== id);
      persist('task');
      renderTasks();
    });
  }

  function renderTasks() {
    const box = document.getElementById('taskRemindersList');
    if (!tasks.length) { box.innerHTML = '<div class="empty-state" style="grid-column:1/-1;"><div class="ico">📝</div><div class="title">No task reminders yet</div><div class="desc">Add follow-ups, calls, visits, or inspections above.</div></div>'; return; }
    box.innerHTML = [...tasks].sort((a, b) => a.dueDate.localeCompare(b.dueDate)).map((t) => {
      const property = t.propertyId ? PropertiesController.getAll().find((p) => p.id === t.propertyId) : null;
      const overdue = t.status === 'Pending' && t.dueDate < todayIso();
      return `
        <div class="info-card">
          <div class="title">${esc(t.title)}</div>
          <div class="sub">${esc(t.type)} · Due ${fmtDate(t.dueDate)}${property ? ' · ' + esc(property.name) : ''}</div>
          <span class="badge ${t.status === 'Completed' ? 'pay-paid' : overdue ? 'pay-overdue' : 'pay-pending'}">${overdue ? 'Overdue' : t.status}</span>
          <div class="row-actions">
            <button class="btn small secondary tk-toggle-btn" data-id="${t.id}">${t.status === 'Pending' ? 'Mark Done' : 'Reopen'}</button>
            <button class="btn small secondary tk-edit-btn" data-id="${t.id}">Edit</button>
            <button class="btn small danger tk-del-btn" data-id="${t.id}" style="background:var(--error); color:#fff;">Delete</button>
          </div>
        </div>`;
    }).join('');
    box.querySelectorAll('.tk-toggle-btn').forEach((b) => b.addEventListener('click', () => toggleTaskStatus(b.dataset.id)));
    box.querySelectorAll('.tk-edit-btn').forEach((b) => b.addEventListener('click', () => openEditTaskModal(b.dataset.id)));
    box.querySelectorAll('.tk-del-btn').forEach((b) => b.addEventListener('click', () => deleteTask(b.dataset.id)));
  }

  // ======================================================================
  // 6 & 7. MESSAGE TEMPLATES (WhatsApp + Email)
  // ======================================================================
  function renderTemplates() {
    const type = document.getElementById('templateTypeFilter').value;
    const box = document.getElementById('templatesList');
    const list = templates.filter((t) => t.type === type);
    box.innerHTML = list.map((t) => `
      <div class="template-card">
        <div class="tc-header">
          <div class="tc-title">${esc(t.category)}</div>
          <div>
            <button class="btn small secondary tp-edit-btn" data-id="${t.id}">Edit</button>
            <button class="btn small tp-preview-btn" data-id="${t.id}">Prepare &amp; Preview</button>
          </div>
        </div>
        ${t.subject ? `<div class="sub" style="margin-bottom:6px;"><strong>Subject:</strong> ${esc(t.subject)}</div>` : ''}
        <div class="tc-body">${esc(t.body)}</div>
      </div>
    `).join('');
    box.querySelectorAll('.tp-edit-btn').forEach((b) => b.addEventListener('click', () => openTemplateModal(b.dataset.id)));
    box.querySelectorAll('.tp-preview-btn').forEach((b) => b.addEventListener('click', () => promptAndPreviewTemplate(b.dataset.id)));
  }

  function openTemplateModal(id) {
    const t = templates.find((x) => x.id === id);
    if (!t) return;
    editingTemplateId = id;
    document.getElementById('templateModalTitle').textContent = 'Edit ' + t.category + ' (' + (t.type === 'whatsapp' ? 'WhatsApp' : 'Email') + ')';
    document.getElementById('templateSubjectGroup').style.display = t.type === 'email' ? 'block' : 'none';
    document.getElementById('templateSubject').value = t.subject || '';
    document.getElementById('templateBody').value = t.body;
    document.getElementById('templateVarChips').innerHTML = TEMPLATE_VARS.map((v) => `<span class="var-chip" data-var="${v}">${v}</span>`).join('');
    document.querySelectorAll('.var-chip').forEach((chip) => chip.addEventListener('click', () => {
      const ta = document.getElementById('templateBody');
      ta.value += (ta.value.endsWith(' ') || ta.value === '' ? '' : ' ') + chip.dataset.var;
    }));
    clearErrors('templateForm');
    document.getElementById('templateModalOverlay').classList.add('open');
  }
  function closeTemplateModal() { document.getElementById('templateModalOverlay').classList.remove('open'); editingTemplateId = null; }

  function handleSaveTemplate() {
    const body = document.getElementById('templateBody').value.trim();
    const subject = document.getElementById('templateSubject').value.trim();
    if (!body) { showErrors({ templateBody: 'Message body is required' }); return; }
    clearErrors('templateForm');
    const t = templates.find((x) => x.id === editingTemplateId);
    if (t) { t.body = body; t.subject = subject; t.updatedAt = new Date().toISOString(); }
    persist('tmpl');
    closeTemplateModal();
    renderTemplates();
  }

  // ---------------- Variable substitution + Preview ----------------
  function fillTemplate(body, vars) {
    let out = body;
    Object.entries(vars).forEach(([key, val]) => { out = out.split('{{' + key + '}}').join(val || ''); });
    return out;
  }

  function promptAndPreviewTemplate(templateId) {
    const t = templates.find((x) => x.id === templateId);
    if (!t) return;
    const isOwnerTemplate = t.category === 'Owner Settlement';
    let personId;
    if (isOwnerTemplate) {
      const owners = OwnersController.getAll();
      if (!owners.length) { alert('No owners exist yet.'); return; }
      const name = prompt('Owner name (type part of the name):\n' + owners.map((o) => o.fullName).join(', '));
      const owner = owners.find((o) => o.fullName.toLowerCase().includes((name || '').toLowerCase()));
      if (!owner) { alert('Owner not found.'); return; }
      personId = owner.id;
      showPreview(buildMessageForOwner(t, owner));
    } else {
      const tenants = TenantsController.getAll();
      if (!tenants.length) { alert('No tenants exist yet.'); return; }
      const name = prompt('Tenant name (type part of the name):\n' + tenants.map((x) => x.fullName).join(', '));
      const tenant = tenants.find((x) => x.fullName.toLowerCase().includes((name || '').toLowerCase()));
      if (!tenant) { alert('Tenant not found.'); return; }
      showPreview(buildMessageForTenant(t, tenant));
    }
  }

  function buildMessageForTenant(template, tenant) {
    const a = tenant.currentAllocation;
    const property = a ? PropertiesController.getAll().find((p) => p.id === a.propertyId) : null;
    const room = a ? RoomsController.getRoomById(a.roomId) : null;
    const vars = { TenantName: tenant.fullName, OwnerName: '', PropertyName: property?.name || '', Room: room?.roomNumber || '', Rent: a ? String(a.rent) : '', DueDate: '' };
    return { subject: fillTemplate(template.subject, vars), text: fillTemplate(template.body, vars), phone: tenant.mobile, email: tenant.email, type: template.type };
  }

  function buildMessageForOwner(template, owner) {
    const property = PropertiesController.getAll().find((p) => p.ownerId === owner.id);
    const vars = { TenantName: '', OwnerName: owner.fullName, PropertyName: property?.name || '', Room: '', Bed: '', Rent: '', DueDate: '' };
    return { subject: fillTemplate(template.subject, vars), text: fillTemplate(template.body, vars), phone: owner.phone, email: owner.email, type: template.type };
  }

  function prepareFromNotification(notifId) {
    const n = notifications.find((x) => x.id === notifId);
    if (!n) return;
    const catMap = { 'Rent Due': 'Rent Reminder', 'Rent Received': 'Payment Received', 'Move In': 'Move In Welcome', 'Move Out': 'Move Out Thank You', 'Maintenance': 'Maintenance Update', 'Owner Settlement': 'Owner Settlement', 'Lease Expiry': 'General Notice' };
    const tmplCategory = catMap[n.category] || 'General Notice';
    const type = 'whatsapp';
    const template = templates.find((t) => t.category === tmplCategory && t.type === type);
    if (!template) { alert('No matching template found.'); return; }
    if (n.tenantId) {
      const tenant = TenantsController.getById(n.tenantId);
      if (tenant) { showPreview(buildMessageForTenant(template, tenant)); return; }
    }
    if (n.ownerId) {
      const owner = OwnersController.getAll().find((o) => o.id === n.ownerId);
      if (owner) { showPreview(buildMessageForOwner(template, owner)); return; }
    }
    alert('No linked tenant or owner to prepare a message for.');
  }

  function showPreview(ctx) {
    previewContext = ctx;
    document.getElementById('previewModalTitle').textContent = ctx.type === 'email' ? 'Email Preview' : 'WhatsApp Message Preview';
    document.getElementById('previewBox').textContent = (ctx.subject ? 'Subject: ' + ctx.subject + '\n\n' : '') + ctx.text;
    document.getElementById('previewModalOverlay').classList.add('open');
  }
  function closePreviewModal() { document.getElementById('previewModalOverlay').classList.remove('open'); previewContext = null; }

  function copyPreview() {
    const text = document.getElementById('previewBox').textContent;
    navigator.clipboard?.writeText(text).then(() => alert('Copied to clipboard.')).catch(() => alert('Could not copy — please select and copy manually.'));
  }

  function sendPreview() {
    if (!previewContext) return;
    // NOT a WhatsApp/Email API integration — these are standard OS-level
    // deep links (wa.me / mailto:) that simply open the user's own
    // WhatsApp or mail app with the message pre-filled. Sending itself is
    // always a manual, user-initiated tap, per Section 15's constraint.
    if (previewContext.type === 'whatsapp') {
      const phone = (previewContext.phone || '').replace(/\D/g, '');
      if (!phone) { alert('No phone number on file for this person.'); return; }
      window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(previewContext.text)}`, '_blank');
    } else {
      const email = previewContext.email || '';
      if (!email) { alert('No email on file for this person.'); return; }
      window.open(`mailto:${email}?subject=${encodeURIComponent(previewContext.subject || '')}&body=${encodeURIComponent(previewContext.text)}`, '_blank');
    }
  }

  // ======================================================================
  // AUTOMATION LOG VIEW
  // ======================================================================
  function renderAutomationLog() {
    const box = document.getElementById('automationLogList');
    box.innerHTML = automationLogs.length
      ? automationLogs.slice(0, 50).map((l) => `<div class="auto-log-item"><span class="al-arrow">⚙️</span><div><strong>${esc(l.ruleName)}</strong><div class="hi-row">${fmtDateTime(l.triggeredAt)} · ${esc(l.details)}</div></div></div>`).join('')
      : '<div class="empty-state"><div class="desc">No automation rules have fired yet.</div></div>';
  }

  // ======================================================================
  // 10. CALENDAR
  // ======================================================================
  function collectCalendarEvents() {
    const events = {}; // date (YYYY-MM-DD) -> [{label, color}]
    function add(date, label, color) { if (!date) return; (events[date] = events[date] || []).push({ label, color }); }

    FinanceController.getAllRentEntries().filter((r) => r.paymentStatus !== 'Paid').forEach((r) => add(r.dueDate, 'Rent Due: ' + (TenantsController.getById(r.tenantId)?.fullName || ''), '#D97706'));
    TenantsController.getAll().forEach((t) => {
      if (t.currentAllocation?.moveInDate) add(t.currentAllocation.moveInDate, 'Move In: ' + t.fullName, '#16A34A');
      if (t.currentAllocation?.agreementEnd) add(t.currentAllocation.agreementEnd, 'Lease Expiry: ' + t.fullName, '#D97706');
      (t.moveOutHistory || []).forEach((h) => add(h.moveOutDate, 'Move Out: ' + t.fullName, '#64748B'));
    });
    MaintenanceController.getAllTickets().forEach((tk) => { if (tk.assignment?.expectedCompletionDate) add(tk.assignment.expectedCompletionDate, 'Maintenance: ' + tk.ticketId, '#2563EB'); });
    tasks.forEach((tk) => add(tk.dueDate, tk.type + ': ' + tk.title, '#9333EA'));

    return events;
  }

  function renderCalendar() {
    const events = collectCalendarEvents();
    const year = calendarDate.getFullYear(), month = calendarDate.getMonth();
    document.getElementById('calMonthLabel').textContent = calendarDate.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });

    const firstDay = new Date(year, month, 1);
    const startOffset = firstDay.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = todayIso();

    let html = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => `<div class="cal-dow">${d}</div>`).join('');
    for (let i = 0; i < startOffset; i++) html += `<div class="cal-day other-month"></div>`;
    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const dayEvents = events[dateStr] || [];
      const dots = dayEvents.slice(0, 4).map((e) => `<span class="cd-dot" style="background:${e.color}"></span>`).join('');
      html += `<div class="cal-day ${dateStr === today ? 'today' : ''}" data-date="${dateStr}"><div class="cd-num">${d}</div><div>${dots}</div></div>`;
    }
    document.getElementById('calendarGrid').innerHTML = html;
    document.querySelectorAll('.cal-day[data-date]').forEach((el) => el.addEventListener('click', () => showDayEvents(el.dataset.date, events[el.dataset.date] || [])));

    const list = document.getElementById('calEventList');
    list.innerHTML = '<div class="sub">Tap a day to see its events.</div>';
  }

  function showDayEvents(date, dayEvents) {
    const list = document.getElementById('calEventList');
    list.innerHTML = `<div style="font-weight:700; margin-bottom:6px;">${fmtDate(date)}</div>` + (dayEvents.length
      ? dayEvents.map((e) => `<div class="cal-event-item"><span class="cd-dot" style="background:${e.color}"></span>${esc(e.label)}</div>`).join('')
      : '<div class="sub">No events on this day.</div>');
  }

  // ======================================================================
  // 12. DASHBOARD WIDGETS
  // ======================================================================
  function renderDashboard() {
    const today = todayIso();
    const todaysReminders = notifications.filter((n) => n.createdAt.startsWith(today)).length;
    const pendingNotifs = notifications.filter((n) => n.status === 'Unread').length;
    const upcomingLeaseExpiry = TenantsController.getAll().filter((t) => t.currentAllocation?.agreementEnd && daysBetween(t.currentAllocation.agreementEnd, today) >= 0 && daysBetween(t.currentAllocation.agreementEnd, today) <= 30).length;
    const pendingRent = FinanceController.getAllRentEntries().filter((r) => r.paymentStatus !== 'Paid').reduce((s, r) => s + r.remainingBalance, 0);
    const upcomingMoveIn = TenantsController.getAll().filter((t) => t.currentAllocation?.moveInDate && t.currentAllocation.moveInDate >= today && daysBetween(t.currentAllocation.moveInDate, today) <= 30).length;
    const upcomingMoveOut = TenantsController.getAll().filter((t) => t.status === 'Notice Period').length;

    document.getElementById('notifDashGrid').innerHTML = `
      <div class="stat-card"><div class="label">Today's Reminders</div><div class="value">${todaysReminders}</div></div>
      <div class="stat-card"><div class="label">Pending Notifications</div><div class="value warning">${pendingNotifs}</div></div>
      <div class="stat-card"><div class="label">Upcoming Lease Expiry (30d)</div><div class="value">${upcomingLeaseExpiry}</div></div>
      <div class="stat-card"><div class="label">Pending Rent</div><div class="value warning">₹${pendingRent}</div></div>
      <div class="stat-card"><div class="label">Upcoming Move In (30d)</div><div class="value success">${upcomingMoveIn}</div></div>
      <div class="stat-card"><div class="label">Upcoming Move Out</div><div class="value">${upcomingMoveOut}</div></div>
    `;
  }

  // ======================================================================
  // Sub-nav + Init
  // ======================================================================
  function switchSubTab(subId) {
    document.querySelectorAll('#notifSubnav .rs-tab').forEach((t) => t.classList.toggle('active', t.dataset.nsub === subId));
    document.querySelectorAll('#page-notifications .report-subview').forEach((v) => v.classList.toggle('active', v.id === 'nsub-' + subId));
    if (subId === 'notifDashboard') renderDashboard();
    if (subId === 'notifCenter') { populateNotifFilters(); renderCenter(); }
    if (subId === 'notifReminders') renderReminderHistory();
    if (subId === 'notifTasks') renderTasks();
    if (subId === 'notifTemplates') renderTemplates();
    if (subId === 'notifAutoLog') renderAutomationLog();
    if (subId === 'notifCalendar') renderCalendar();
  }

  function bindEvents() {
    document.querySelectorAll('#notifSubnav .rs-tab').forEach((tab) => tab.addEventListener('click', () => switchSubTab(tab.dataset.nsub)));

    document.getElementById('notifSearchInput').addEventListener('input', renderCenter);
    document.getElementById('notifCategoryFilter').addEventListener('change', renderCenter);
    document.getElementById('notifPropertyFilter').addEventListener('change', renderCenter);
    document.getElementById('notifOwnerFilter').addEventListener('change', renderCenter);
    document.getElementById('notifTenantFilter').addEventListener('change', renderCenter);
    document.getElementById('notifPriorityFilter').addEventListener('change', renderCenter);
    document.getElementById('notifDateFilter').addEventListener('change', renderCenter);
    document.getElementById('notifStatusTab').addEventListener('change', renderCenter);
    document.getElementById('notifMarkAllReadBtn').addEventListener('click', markAllRead);
    document.getElementById('notifRunAutomationBtn').addEventListener('click', () => { runAutomation(); renderCenter(); renderDashboard(); alert('Automation scan complete.'); });

    document.getElementById('addTaskBtn').addEventListener('click', openAddTaskModal);
    document.getElementById('taskModalCloseBtn').addEventListener('click', closeTaskModal);
    document.getElementById('taskCancelBtn').addEventListener('click', closeTaskModal);
    document.getElementById('taskSaveBtn').addEventListener('click', handleSaveTask);
    document.getElementById('taskModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'taskModalOverlay') closeTaskModal(); });

    document.getElementById('templateTypeFilter').addEventListener('change', renderTemplates);
    document.getElementById('templateModalCloseBtn').addEventListener('click', closeTemplateModal);
    document.getElementById('templateCancelBtn').addEventListener('click', closeTemplateModal);
    document.getElementById('templateSaveBtn').addEventListener('click', handleSaveTemplate);
    document.getElementById('templateModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'templateModalOverlay') closeTemplateModal(); });

    document.getElementById('previewModalCloseBtn').addEventListener('click', closePreviewModal);
    document.getElementById('previewCloseBtn').addEventListener('click', closePreviewModal);
    document.getElementById('previewCopyBtn').addEventListener('click', copyPreview);
    document.getElementById('previewSendBtn').addEventListener('click', sendPreview);
    document.getElementById('previewModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'previewModalOverlay') closePreviewModal(); });

    document.getElementById('calPrevBtn').addEventListener('click', () => { calendarDate.setMonth(calendarDate.getMonth() - 1); renderCalendar(); });
    document.getElementById('calNextBtn').addEventListener('click', () => { calendarDate.setMonth(calendarDate.getMonth() + 1); renderCalendar(); });
  }

  function onPageShow() {
    runAutomation(); // re-scan every time the page is opened, so it stays current
    const activeTab = document.querySelector('#notifSubnav .rs-tab.active');
    switchSubTab(activeTab ? activeTab.dataset.nsub : 'notifDashboard');
  }

  function init() {
    load();
    bindEvents();
    runAutomation();
  }

  function clearAllNotifications() {
    notifications = [];
    persist('notif');
  }

  function archiveOldNotifications(daysThreshold) {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - daysThreshold);
    let count = 0;
    notifications.forEach((n) => {
      if (n.status !== 'Archived' && new Date(n.createdAt) < cutoff) {
        n.status = 'Archived'; n.archivedAt = new Date().toISOString(); count++;
      }
    });
    persist('notif');
    return count;
  }

  return { init, onPageShow, clearAllNotifications, archiveOldNotifications, reload: () => { load(); onPageShow(); } };
})();
