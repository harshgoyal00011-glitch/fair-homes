/* ==========================================================================
   Fair Homes OS — Universal Global Search (Dashboard)
   Searches Owners, Properties (incl. flat no / society), and Tenants by
   name/mobile/code — plus a curated list of "Quick Actions" that jump
   straight to the right Add-form for common day-to-day entries (food,
   stationery, rent, tickets, etc.), all in one box on the first screen.
   ========================================================================== */

const SearchController = (() => {
  // Each quick action: keywords matched against the query, then an
  // `action()` that navigates to the right page/tab and opens/pre-fills
  // the relevant Add form — reuses each module's own existing "+Add"
  // buttons and forms rather than duplicating any logic.
  const QUICK_ACTIONS = [
    { icon: '🍽️', title: 'Add Food Expense', sub: 'Fair Homes Business Expense', keywords: ['food', 'khana', 'khaya', 'piya'],
      action: () => goToFinanceSubTabAndPrefill('fairHomesIncome', 'bizExpenseCategory', 'Food', 'bizExpenseType', 'Expense') },
    { icon: '✏️', title: 'Add Stationery Expense', sub: 'Fair Homes Business Expense', keywords: ['stationery', 'stationary'],
      action: () => goToFinanceSubTabAndPrefill('fairHomesIncome', 'bizExpenseCategory', 'Stationery', 'bizExpenseType', 'Expense') },
    { icon: '📢', title: 'Add Advertisement Expense', sub: 'Fair Homes Business Expense', keywords: ['advertisement', 'ad', 'ads', 'marketing'],
      action: () => goToFinanceSubTabAndPrefill('fairHomesIncome', 'bizExpenseCategory', 'Advertisement', 'bizExpenseType', 'Expense') },
    { icon: '🪧', title: 'Add Board / Signage Expense', sub: 'Fair Homes Business Expense', keywords: ['board', 'signage', 'banner'],
      action: () => goToFinanceSubTabAndPrefill('fairHomesIncome', 'bizExpenseCategory', 'Board / Signage', 'bizExpenseType', 'Expense') },
    { icon: '💸', title: 'Record a Withdrawal', sub: 'Fair Homes Income', keywords: ['withdrawal', 'withdraw', 'nikalna'],
      action: () => goToFinanceSubTabAndPrefill('fairHomesIncome', 'bizExpenseType', 'Withdrawal') },
    { icon: '🏦', title: 'Add Owner Advance', sub: 'Fair Homes Income', keywords: ['advance', 'owner advance', 'udhaar'],
      action: () => goToFinanceSubTabAndFocus('fairHomesIncome', 'advanceProperty') },
    { icon: '💰', title: 'Collect Rent', sub: 'Finance → Rent Collection', keywords: ['rent', 'collect rent', 'kiraya'],
      action: () => goToFinanceSubTabAndClick('rentCollection', 'addRentBtn') },
    { icon: '🔒', title: 'Receive Security Deposit', sub: 'Finance → Security Deposits', keywords: ['deposit', 'security'],
      action: () => goToFinanceSubTabAndClick('deposits', 'addDepositBtn') },
    { icon: '🤝', title: 'Add Brokerage', sub: 'Finance → Brokerage', keywords: ['brokerage', 'broker'],
      action: () => goToFinanceSubTabAndClick('brokerage', 'addBrokerageBtn') },
    { icon: '🧾', title: 'Add Management Fee', sub: 'Finance → Management Fees', keywords: ['management fee', 'mgmt fee'],
      action: () => goToFinanceSubTabAndClick('managementFees', 'addFeeBtn') },
    { icon: '🧾', title: 'Add Expense', sub: 'Finance → Expenses', keywords: ['expense', 'kharcha', 'purchase', 'bought'],
      action: () => goToFinanceSubTabAndClick('expenses', 'addExpenseBtn') },
    { icon: '🔖', title: 'Add Booking', sub: 'Bookings', keywords: ['booking', 'token', 'advance', 'add booking'],
      action: () => goToPageAndClick('bookings', 'addBookingBtn') },
    { icon: '🤝', title: 'Add Brokerage-Only Flat', sub: 'Brokerage-Only Flats', keywords: ['brokerage only', 'brokerage flat', 'add flat'],
      action: () => goToPageAndClick('brokerageFlats', 'addBrokerageFlatBtn') },
    { icon: '📱', title: 'Add Social Media Task', sub: 'Social Media Tasks', keywords: ['social media', 'task', 'whatsapp group', 'instagram', 'agreement'],
      action: () => goToPageAndClick('socialMediaTasks', 'addSmtBtn') },
    { icon: '🧑‍🤝‍🧑', title: 'Add Tenant', sub: 'Tenants', keywords: ['tenant', 'add tenant', 'new tenant'],
      action: () => goToPageAndClick('tenants', 'addTenantBtn') },
    { icon: '👤', title: 'Add Owner', sub: 'Owners', keywords: ['owner', 'add owner', 'new owner'],
      action: () => goToPageAndClick('owners', 'addOwnerBtn') },
    { icon: '🏢', title: 'Add Property', sub: 'Properties', keywords: ['property', 'add property', 'new flat', 'add flat'],
      action: () => goToPageAndClick('properties', 'addPropertyBtn') },
    { icon: '🔧', title: 'New Maintenance Ticket', sub: 'Maintenance', keywords: ['maintenance', 'ticket', 'complaint', 'repair'],
      action: () => goToMaintenanceAndClick('maintTickets', 'addTicketBtn') },
    { icon: '📝', title: 'New Task Reminder', sub: 'Notifications', keywords: ['task', 'reminder', 'follow up', 'yaad'],
      action: () => goToNotificationsAndClick('notifTasks', 'addTaskBtn') },
  ];

  function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // ---------------- Navigation helpers (reuse each module's own forms) ----------------
  function goToPageAndClick(pageId, btnId) {
    NavController.goToPage(pageId);
    document.getElementById(btnId)?.click();
  }
  function goToFinanceSubTabAndClick(subTab, btnId) {
    NavController.goToPage('finance');
    document.querySelector(`#financeSubnav .fs-tab[data-sub="${subTab}"]`)?.click();
    document.getElementById(btnId)?.click();
  }
  function goToFinanceSubTabAndPrefill(subTab, ...fieldValuePairs) {
    NavController.goToPage('finance');
    document.querySelector(`#financeSubnav .fs-tab[data-sub="${subTab}"]`)?.click();
    for (let i = 0; i < fieldValuePairs.length; i += 2) {
      const el = document.getElementById(fieldValuePairs[i]);
      if (el) el.value = fieldValuePairs[i + 1];
    }
    document.getElementById('bizExpenseAmount')?.focus();
  }
  function goToFinanceSubTabAndFocus(subTab, fieldId) {
    NavController.goToPage('finance');
    document.querySelector(`#financeSubnav .fs-tab[data-sub="${subTab}"]`)?.click();
    document.getElementById(fieldId)?.focus();
  }
  function goToMaintenanceAndClick(subTab, btnId) {
    NavController.goToPage('maintenance');
    document.querySelector(`#maintSubnav .fs-tab[data-sub="${subTab}"]`)?.click();
    document.getElementById(btnId)?.click();
  }
  function goToNotificationsAndClick(subTab, btnId) {
    NavController.goToPage('notifications');
    document.querySelector(`#notifSubnav .rs-tab[data-nsub="${subTab}"]`)?.click();
    document.getElementById(btnId)?.click();
  }

  // ---------------- Search ----------------
  function runSearch(query) {
    const q = query.toLowerCase().trim();
    if (!q) return null;

    const quickActions = QUICK_ACTIONS.filter((qa) => qa.keywords.some((k) => k.includes(q) || q.includes(k)));

    const properties = (typeof PropertiesController !== 'undefined' ? PropertiesController.getAll() : []).filter((p) =>
      (p.society || '').toLowerCase().includes(q) || (p.flatNo || '').toLowerCase().includes(q) ||
      p.propertyCode.toLowerCase().includes(q) || (p.name || '').toLowerCase().includes(q)
    );

    const directOwners = (typeof OwnersController !== 'undefined' ? OwnersController.getAll() : []).filter((o) =>
      o.fullName.toLowerCase().includes(q) || (o.mobile || '').includes(q) || (o.email || '').toLowerCase().includes(q)
    );
    const directTenants = (typeof TenantsController !== 'undefined' ? TenantsController.getAll() : []).filter((t) =>
      t.fullName.toLowerCase().includes(q) || (t.mobile || '').includes(q)
    );

    // When a Society/Flat search matches properties, also surface their
    // Owners and current Tenants even though those people's own names
    // don't contain the query — e.g. searching a society name should
    // show every flat there, plus who owns and who lives in each one.
    const relatedOwnerIds = new Set();
    const relatedTenantIds = new Set();
    properties.forEach((p) => {
      if (p.ownerId) relatedOwnerIds.add(p.ownerId);
      (typeof TenantsController !== 'undefined' ? TenantsController.getAll() : []).forEach((t) => {
        if (t.currentAllocation?.propertyId === p.id) relatedTenantIds.add(t.id);
      });
    });

    const allOwners = [...directOwners];
    if (typeof OwnersController !== 'undefined') {
      OwnersController.getAll().forEach((o) => {
        if (relatedOwnerIds.has(o.id) && !allOwners.find((x) => x.id === o.id)) allOwners.push(o);
      });
    }
    const allTenants = [...directTenants];
    if (typeof TenantsController !== 'undefined') {
      TenantsController.getAll().forEach((t) => {
        if (relatedTenantIds.has(t.id) && !allTenants.find((x) => x.id === t.id)) allTenants.push(t);
      });
    }

    const bookings = (typeof BookingsController !== 'undefined' ? BookingsController.getAll() : []).filter((b) =>
      b.clientName.toLowerCase().includes(q) || (b.clientMobile || '').includes(q)
    );
    const brkFlats = (typeof BrokerageFlatsController !== 'undefined' ? BrokerageFlatsController.getAll() : []).filter((f) =>
      (f.society || '').toLowerCase().includes(q) || (f.flatNo || '').toLowerCase().includes(q)
    );

    return { quickActions, properties, owners: allOwners, tenants: allTenants, bookings, brkFlats };
  }

  function propertySubtitle(p) {
    return [p.flatNo ? 'Flat ' + p.flatNo : '', p.society, p.bhk].filter(Boolean).join(' · ') || p.propertyCode;
  }
  function ownerSubtitle(o) {
    return o.mobile || 'Owner';
  }
  function tenantSubtitle(t) {
    const status = t.status || '';
    return [t.mobile, status].filter(Boolean).join(' · ');
  }

  function renderResults(results) {
    const box = document.getElementById('globalSearchResults');
    if (!results) { box.classList.add('hidden'); box.innerHTML = ''; return; }

    const total = results.quickActions.length + results.properties.length + results.owners.length + results.tenants.length + results.bookings.length + results.brkFlats.length;
    if (total === 0) {
      box.innerHTML = '<div class="gs-empty">Kuch nahi mila. Alag naam, flat no, ya society try karo.</div>';
      box.classList.remove('hidden');
      return;
    }

    let html = '';

    if (results.quickActions.length) {
      html += '<div class="gs-group-label">Quick Add</div>';
      html += results.quickActions.map((qa, i) => `
        <div class="gs-item" data-type="quick" data-idx="${i}">
          <div class="gs-icon">${qa.icon}</div>
          <div class="gs-main"><div class="gs-title">${esc(qa.title)}</div><div class="gs-sub">${esc(qa.sub)}</div></div>
        </div>`).join('');
    }

    if (results.properties.length) {
      html += '<div class="gs-group-label">Properties</div>';
      html += results.properties.map((p) => `
        <div class="gs-item" data-type="property" data-id="${p.id}">
          <div class="gs-icon">🏢</div>
          <div class="gs-main"><div class="gs-title">${esc(p.society || p.name)}</div><div class="gs-sub">${esc(propertySubtitle(p))}</div></div>
        </div>`).join('');
    }

    if (results.owners.length) {
      html += '<div class="gs-group-label">Owners</div>';
      html += results.owners.map((o) => `
        <div class="gs-item" data-type="owner" data-id="${o.id}">
          <div class="gs-icon">👤</div>
          <div class="gs-main"><div class="gs-title">${esc(o.fullName)}</div><div class="gs-sub">${esc(ownerSubtitle(o))}</div></div>
        </div>`).join('');
    }

    if (results.tenants.length) {
      html += '<div class="gs-group-label">Tenants</div>';
      html += results.tenants.map((t) => `
        <div class="gs-item" data-type="tenant" data-id="${t.id}">
          <div class="gs-icon">🧑‍🤝‍🧑</div>
          <div class="gs-main"><div class="gs-title">${esc(t.fullName)}</div><div class="gs-sub">${esc(tenantSubtitle(t))}</div></div>
        </div>`).join('');
    }

    if (results.bookings.length) {
      html += '<div class="gs-group-label">Bookings</div>';
      html += results.bookings.map((b) => `
        <div class="gs-item" data-type="booking" data-id="${b.id}">
          <div class="gs-icon">🔖</div>
          <div class="gs-main"><div class="gs-title">${esc(b.clientName)}</div><div class="gs-sub">${esc(b.bookingCode)} · ${esc(b.status)}</div></div>
        </div>`).join('');
    }

    if (results.brkFlats.length) {
      html += '<div class="gs-group-label">Brokerage-Only Flats</div>';
      html += results.brkFlats.map((f) => `
        <div class="gs-item" data-type="brkFlat" data-id="${f.id}">
          <div class="gs-icon">🤝</div>
          <div class="gs-main"><div class="gs-title">${esc(f.society)} — Flat ${esc(f.flatNo)}</div><div class="gs-sub">${esc(f.bhk)} · ₹${f.rent}</div></div>
        </div>`).join('');
    }

    box.innerHTML = html;
    box.classList.remove('hidden');

    let currentResults = results;
    box.querySelectorAll('.gs-item').forEach((item) => {
      item.addEventListener('click', () => {
        const type = item.dataset.type;
        if (type === 'quick') {
          currentResults.quickActions[Number(item.dataset.idx)].action();
        } else if (type === 'property') {
          NavController.goToPage('properties');
          PropertiesController.openDetail(item.dataset.id);
        } else if (type === 'owner') {
          NavController.goToPage('owners');
          OwnersController.openDetail(item.dataset.id);
        } else if (type === 'tenant') {
          NavController.goToPage('tenants');
          TenantsController.openDetail(item.dataset.id);
        } else if (type === 'booking') {
          NavController.goToPage('bookings');
        } else if (type === 'brkFlat') {
          NavController.goToPage('brokerageFlats');
        }
        closeResults();
        document.getElementById('globalSearchInput').value = '';
      });
    });
  }

  function closeResults() {
    document.getElementById('globalSearchResults').classList.add('hidden');
  }

  function bindEvents() {
    const input = document.getElementById('globalSearchInput');
    input.addEventListener('input', (e) => renderResults(runSearch(e.target.value)));
    input.addEventListener('focus', (e) => { if (e.target.value.trim()) renderResults(runSearch(e.target.value)); });
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.global-search-wrap')) closeResults();
    });
  }

  function init() {
    bindEvents();
  }

  return { init };
})();
