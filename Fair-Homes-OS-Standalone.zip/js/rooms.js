/* ==========================================================================
   Fair Homes OS — Rooms Module (Redesigned)
   Rooms are now minimal — just Property, Room Number/Name, Notes. No
   pre-defined capacity, sharing mode, or "Beds" as a separate entity.
   A Room's occupancy is derived directly from which Tenants currently
   have their allocation pointing at it — Room and Tenant connect
   directly, with nothing in between.
   Tenant-Type Restriction (Boys/Girls/Couple/Family compatibility across
   a property's rooms) lives here too, since it's fundamentally about
   room-to-room compatibility within one property.
   ========================================================================== */

const RoomsController = (() => {
  const ROOMS_KEY = 'fh_rooms';

  let rooms = [];
  let currentPropertyId = null;
  let currentRoomId = null;
  let editingRoomId = null;

  const ROOM_STATUS_CLASS = { 'Available': 'room-vacant', 'Occupied': 'room-fully' };

  // ---------------- Storage ----------------
  function load() {
    try { rooms = JSON.parse(localStorage.getItem(ROOMS_KEY)) || []; } catch (e) { rooms = []; }
    CloudSync.watch('rooms', (cloudRooms) => {
      rooms = cloudRooms;
      localStorage.setItem(ROOMS_KEY, JSON.stringify(rooms));
      if (currentRoomId) renderRoomDetail();
      else if (currentPropertyId) renderRoomsForProperty();
    });
  }
  function persistRooms() {
    localStorage.setItem(ROOMS_KEY, JSON.stringify(rooms));
    CloudSync.sync('rooms', rooms);
  }

  function generateId() {
    return (crypto.randomUUID ? crypto.randomUUID() : 'id_' + Date.now() + '_' + Math.random().toString(16).slice(2));
  }

  // ---------------- Computed Helpers ----------------
  function roomsForProperty(propertyId) { return rooms.filter((r) => r.propertyId === propertyId); }

  /** A room's occupants are whichever Tenants currently have their
   *  allocation pointing at it — no separate Bed layer to keep in sync. */
  function activeTenantsInRoom(roomId) {
    if (typeof TenantsController === 'undefined') return [];
    return TenantsController.getAll().filter((t) => t.status === 'Active' && t.currentAllocation && t.currentAllocation.roomId === roomId);
  }

  function computeRoomStatus(roomId) {
    return activeTenantsInRoom(roomId).length > 0 ? 'Occupied' : 'Available';
  }

  function computePropertyStats(propertyId) {
    const propRooms = roomsForProperty(propertyId);
    const totalRooms = propRooms.length;
    const occupiedRooms = propRooms.filter((r) => computeRoomStatus(r.id) === 'Occupied').length;
    const availableRooms = totalRooms - occupiedRooms;
    const occupancyPct = totalRooms > 0 ? Math.round((occupiedRooms / totalRooms) * 100) : 0;
    return { totalRooms, occupiedRooms, availableRooms, occupancyPct };
  }

  // ---------------- Tenant-Type Restriction (Boys/Girls/Couple/Family) ----------------
  /** What tenant types are allowed for the NEXT booking in this
   *  property, given whichever type is already living there. Boys and
   *  Family are exclusive to themselves; Girls and Couple are
   *  cross-compatible with each other. No restriction (null) means
   *  anything goes — this is the state right after the property is
   *  fully vacant. */
  function getAllowedTenantTypes(propertyId) {
    const property = PropertiesController.getAll().find((p) => p.id === propertyId);
    const current = property ? property.tenantTypeRestriction : null;
    if (!current) return ['Boys', 'Girls', 'Couple', 'Family'];
    if (current === 'Boys') return ['Boys'];
    if (current === 'Family') return ['Family'];
    if (current === 'Girls' || current === 'Couple') return ['Girls', 'Couple'];
    return ['Boys', 'Girls', 'Couple', 'Family'];
  }

  /** Call this whenever a booking/tenant sets a property's first tenant
   *  type, or after a move-out to check if the property is now fully
   *  vacant and the restriction should reset. Both Bookings and Tenants
   *  modules call this — it's the single source of truth. */
  function setTenantTypeRestriction(propertyId, type) {
    if (typeof PropertiesController === 'undefined' || !PropertiesController.updateTenantTypeRestriction) return;
    PropertiesController.updateTenantTypeRestriction(propertyId, type);
  }

  /** Checks all rooms of a property — if NONE have active tenants, the
   *  property is fully vacant and its tenant-type restriction resets
   *  so any type can move in next. */
  function checkAndResetTenantTypeIfVacant(propertyId) {
    const propRooms = roomsForProperty(propertyId);
    const anyOccupied = propRooms.some((r) => computeRoomStatus(r.id) === 'Occupied');
    if (!anyOccupied) setTenantTypeRestriction(propertyId, null);
  }

  // ---------------- LEVEL 1: Property Selection ----------------
  function renderPropertySelect() {
    const query = (document.getElementById('rbPropertySearch')?.value || '').toLowerCase().trim();
    const properties = PropertiesController.getAll().filter((p) =>
      p.name.toLowerCase().includes(query) || p.city.toLowerCase().includes(query)
    );

    const grid = document.getElementById('rbPropertyGrid');
    if (!properties.length) {
      grid.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="ico">🏢</div>
          <div class="title">${PropertiesController.getAll().length === 0 ? 'No properties yet' : 'No matching properties'}</div>
          <div class="desc">${PropertiesController.getAll().length === 0 ? 'Add a property first in the Properties module.' : 'Try a different search term.'}</div>
        </div>`;
      return;
    }

    grid.innerHTML = properties.map((p) => {
      const stats = computePropertyStats(p.id);
      return `
        <div class="property-select-card" data-id="${p.id}">
          <div class="ps-name">${esc(p.name)}</div>
          <div class="ps-sub">${esc(p.propertyCode)}${p.tenantTypeRestriction ? ' · Currently: ' + esc(p.tenantTypeRestriction) : ''}</div>
          <div class="ps-row"><span>Rooms Added</span><span>${stats.totalRooms}</span></div>
          <div class="ps-row"><span>Available</span><span>${stats.availableRooms}</span></div>
          <div class="ps-row"><span>Occupancy</span><span>${stats.occupancyPct}%</span></div>
          <div class="ps-occ-bar"><div class="ps-occ-fill" style="width:${stats.occupancyPct}%"></div></div>
        </div>`;
    }).join('');

    grid.querySelectorAll('.property-select-card').forEach((card) => {
      card.addEventListener('click', () => openProperty(card.dataset.id));
    });
  }

  function openProperty(propertyId) {
    currentPropertyId = propertyId;
    const p = PropertiesController.getAll().find((x) => x.id === propertyId);
    if (!p) return;
    document.getElementById('rbCurrentPropertyName').textContent = p.name;
    renderRoomsForProperty();
    document.getElementById('roomsPropertySelectView').classList.add('hidden');
    document.getElementById('roomBedsView').classList.add('hidden');
    document.getElementById('roomsPropertyView').classList.remove('hidden');
  }

  function backToPropertySelect() {
    currentPropertyId = null;
    currentRoomId = null;
    document.getElementById('roomsPropertyView').classList.add('hidden');
    document.getElementById('roomBedsView').classList.add('hidden');
    document.getElementById('roomsPropertySelectView').classList.remove('hidden');
    renderPropertySelect();
  }

  // ---------------- LEVEL 2: Rooms for Property ----------------
  function renderRoomsForProperty() {
    const stats = computePropertyStats(currentPropertyId);
    document.getElementById('propertyRoomStats').innerHTML = `
      <div class="stat-card"><div class="label">Total Rooms</div><div class="value">${stats.totalRooms}</div></div>
      <div class="stat-card"><div class="label">Available</div><div class="value success">${stats.availableRooms}</div></div>
      <div class="stat-card"><div class="label">Occupied</div><div class="value">${stats.occupiedRooms}</div></div>
      <div class="stat-card"><div class="label">Occupancy %</div><div class="value">${stats.occupancyPct}%</div></div>
    `;

    const query = (document.getElementById('roomSearchInput')?.value || '').toLowerCase().trim();
    const statusFilter = document.getElementById('roomStatusFilter')?.value || 'all';

    const list = roomsForProperty(currentPropertyId).filter((r) => {
      const status = computeRoomStatus(r.id);
      return r.roomNumber.toLowerCase().includes(query) && (statusFilter === 'all' || status === statusFilter);
    });

    const grid = document.getElementById('roomsGrid');
    if (!list.length) {
      grid.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="ico">🚪</div>
          <div class="title">${roomsForProperty(currentPropertyId).length === 0 ? 'No rooms yet' : 'No matching rooms'}</div>
          <div class="desc">${roomsForProperty(currentPropertyId).length === 0 ? 'Add the first room for this property.' : 'Try a different search or filter.'}</div>
        </div>`;
      return;
    }

    grid.innerHTML = list.map((r) => {
      const status = computeRoomStatus(r.id);
      const occupants = activeTenantsInRoom(r.id);
      return `
        <div class="owner-card" data-id="${r.id}">
          <div class="oc-top">
            <div class="oc-avatar">🚪</div>
            <div>
              <div class="oc-name">Room ${esc(r.roomNumber)}</div>
              ${occupants.length ? `<div class="oc-sub">${occupants.map((t) => esc(t.fullName)).join(', ')}</div>` : ''}
            </div>
          </div>
          <div style="margin-top:8px;"><span class="badge ${ROOM_STATUS_CLASS[status]}">${status}</span></div>
          <div class="oc-actions">
            <button class="btn small secondary rc-edit-btn" data-id="${r.id}">Edit</button>
            <button class="btn small rc-delete-btn" data-id="${r.id}" style="background:var(--error);">Delete</button>
          </div>
        </div>`;
    }).join('');

    grid.querySelectorAll('.owner-card').forEach((card) => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('.rc-edit-btn') || e.target.closest('.rc-delete-btn')) return;
        openRoom(card.dataset.id);
      });
    });
    grid.querySelectorAll('.rc-edit-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => { e.stopPropagation(); openEditRoomModal(btn.dataset.id); });
    });
    grid.querySelectorAll('.rc-delete-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => { e.stopPropagation(); handleDeleteRoom(btn.dataset.id); });
    });
  }

  // ---------------- Room Add/Edit ----------------
  const BHK_ROOM_LIMIT = { '1 RK': 1, '1 BHK': 1, '2 BHK': 2, '3 BHK': 3, '4 BHK': 4 };

  function openAddRoomModal() {
    editingRoomId = null;
    document.getElementById('roomModalTitle').textContent = 'Add Room';
    document.getElementById('roomForm').reset();
    document.getElementById('roomId').value = '';
    clearErrors('roomForm');

    const property = PropertiesController.getAll().find((p) => p.id === currentPropertyId);
    const onboarding = property ? property.onboardingOccupancy : 'Vacant';
    document.getElementById('roomOccupancyQuestionGroup').classList.toggle('hidden', onboarding !== 'Partially Occupied');
    document.getElementById('roomFullyOccupiedNote').classList.toggle('hidden', onboarding !== 'Already Occupied');
    document.getElementById('roomOccupancyChoice').value = 'Available';
    const forcedOccupied = onboarding === 'Already Occupied';
    document.getElementById('roomOccupiedFields').classList.toggle('hidden', !forcedOccupied);
    if (forcedOccupied) { populateWhoIsLivingOptions(); rebuildRoomTenantSections(); }

    document.getElementById('roomModalOverlay').classList.add('open');
  }

  function onRoomOccupancyChoiceChange() {
    const occupied = document.getElementById('roomOccupancyChoice').value === 'Occupied';
    document.getElementById('roomOccupiedFields').classList.toggle('hidden', !occupied);
    if (occupied) { populateWhoIsLivingOptions(); rebuildRoomTenantSections(); }
  }

  function populateWhoIsLivingOptions() {
    const sel = document.getElementById('roomWhoIsLiving');
    const allowed = getAllowedTenantTypes(currentPropertyId);
    sel.innerHTML = allowed.map((t) => `<option value="${t}">${t}</option>`).join('');
  }

  function roomTenantFieldHTML(idx, key, label, type, extra) {
    return `
      <div class="field-group">
        <label class="field-label" for="roomTenant_${idx}_${key}">${label}</label>
        <input type="${type}" id="roomTenant_${idx}_${key}" ${extra || ''} />
        <div class="form-error" id="err-roomTenant_${idx}_${key}"></div>
      </div>`;
  }

  function buildRoomTenantSectionHTML(idx) {
    return `
      <div class="settings-card" style="margin-bottom:12px;">
        <h3 style="margin-bottom:8px;">Tenant ${idx + 1}</h3>
        ${roomTenantFieldHTML(idx, 'fullName', 'Full Name *', 'text')}
        <div class="form-row-2">
          ${roomTenantFieldHTML(idx, 'mobile', 'Mobile Number *', 'text', 'maxlength="10"')}
          ${roomTenantFieldHTML(idx, 'altMobile', 'Alternate Mobile', 'text', 'maxlength="10"')}
        </div>
        ${roomTenantFieldHTML(idx, 'email', 'Email', 'email')}
        <div class="field-group">
          <label class="field-label" for="roomTenant_${idx}_aadhaar">Aadhaar Number</label>
          <input type="text" id="roomTenant_${idx}_aadhaar" placeholder="1234 5678 9012" maxlength="14" />
        </div>
        <div class="form-row-2">
          ${roomTenantFieldHTML(idx, 'fatherName', "Father's Name", 'text')}
          ${roomTenantFieldHTML(idx, 'emergencyContact', 'Emergency Contact', 'text', 'maxlength="10"')}
        </div>
        <div class="form-row-2">
          ${roomTenantFieldHTML(idx, 'dob', 'Date of Birth', 'date')}
          <div class="field-group">
            <label class="field-label" for="roomTenant_${idx}_gender">Gender</label>
            <select id="roomTenant_${idx}_gender"><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select>
          </div>
        </div>
        <div class="form-row-2">
          <div class="field-group">
            <label class="field-label" for="roomTenant_${idx}_occupation">Occupation</label>
            <select id="roomTenant_${idx}_occupation"><option value="">Select</option><option>Student</option><option>Employed</option><option>Business</option></select>
          </div>
          ${roomTenantFieldHTML(idx, 'companyOrCollege', 'Company / College (Optional)', 'text')}
        </div>
        ${roomTenantFieldHTML(idx, 'permanentAddress', 'Permanent Address', 'text')}
        ${roomTenantFieldHTML(idx, 'notes', 'Notes', 'text')}
      </div>`;
  }

  function rebuildRoomTenantSections() {
    const count = Number(document.getElementById('roomTenantCount').value) || 0;
    const container = document.getElementById('roomTenantSectionsContainer');
    container.innerHTML = Array.from({ length: count }, (_, i) => buildRoomTenantSectionHTML(i)).join('');
    for (let i = 0; i < count; i++) wireAadhaarFormatting(`roomTenant_${i}_aadhaar`);
  }

  function openEditRoomModal(roomId) {
    const r = rooms.find((x) => x.id === roomId);
    if (!r) return;
    editingRoomId = roomId;
    document.getElementById('roomModalTitle').textContent = 'Edit Room';
    document.getElementById('roomId').value = r.id;
    document.getElementById('roomNumber').value = r.roomNumber;
    document.getElementById('roomNotes').value = r.notes || '';
    document.getElementById('roomOccupancyQuestionGroup').classList.add('hidden');
    document.getElementById('roomFullyOccupiedNote').classList.add('hidden');
    document.getElementById('roomOccupiedFields').classList.add('hidden');
    clearErrors('roomForm');
    document.getElementById('roomModalOverlay').classList.add('open');
  }

  function closeRoomModal() {
    document.getElementById('roomModalOverlay').classList.remove('open');
    editingRoomId = null;
  }

  function handleSaveRoom() {
    const roomNumber = document.getElementById('roomNumber').value.trim();
    const notes = document.getElementById('roomNotes').value.trim();
    const property = PropertiesController.getAll().find((p) => p.id === currentPropertyId);
    const isOccupiedFlow = !editingRoomId && !document.getElementById('roomOccupiedFields').classList.contains('hidden');

    const errors = {};
    if (!roomNumber) errors.roomNumber = 'Room number is required';
    else if (!/^[1-9]$/.test(roomNumber)) errors.roomNumber = 'Room number must be a single digit (1-9)';
    else {
      const duplicate = roomsForProperty(currentPropertyId).some((r) => r.roomNumber === roomNumber && r.id !== editingRoomId);
      if (duplicate) errors.roomNumber = 'A room with this number already exists in this property';
    }
    if (!editingRoomId && property) {
      const limit = BHK_ROOM_LIMIT[property.bhk];
      const existingCount = roomsForProperty(currentPropertyId).length;
      if (limit && existingCount >= limit) errors.roomNumber = `${property.bhk} property can have at most ${limit} room(s) — already added.`;
    }

    let tenantSections = [];
    let whoIsLiving = '', tenantCount = 0, existingRent = 0, existingSecurity = 0, moveInDate = '';
    if (isOccupiedFlow) {
      whoIsLiving = document.getElementById('roomWhoIsLiving').value;
      tenantCount = Number(document.getElementById('roomTenantCount').value) || 0;
      existingRent = document.getElementById('roomExistingRent').value;
      existingSecurity = document.getElementById('roomExistingSecurity').value;
      moveInDate = document.getElementById('roomExistingMoveInDate').value;
      if (!tenantCount || tenantCount < 1) errors.roomTenantCount = 'Enter how many tenants are living here';
      if (existingRent === '' || Number(existingRent) < 0) errors.roomExistingRent = 'Enter monthly rent';
      if (existingSecurity === '' || Number(existingSecurity) < 0) errors.roomExistingSecurity = 'Enter security amount';
      if (!moveInDate) errors.roomExistingMoveInDate = 'Original move-in date is required';

      for (let i = 0; i < tenantCount; i++) {
        const fullName = document.getElementById(`roomTenant_${i}_fullName`)?.value.trim() || '';
        const mobile = document.getElementById(`roomTenant_${i}_mobile`)?.value.trim() || '';
        if (!fullName) errors[`roomTenant_${i}_fullName`] = 'Full name is required';
        if (!mobile || !/^\d{10}$/.test(mobile)) errors[`roomTenant_${i}_mobile`] = 'Enter a valid 10-digit mobile number';
        tenantSections.push({
          fullName, mobile,
          altMobile: document.getElementById(`roomTenant_${i}_altMobile`)?.value.trim() || '',
          email: document.getElementById(`roomTenant_${i}_email`)?.value.trim() || '',
          aadhaar: document.getElementById(`roomTenant_${i}_aadhaar`)?.value.replace(/\s/g, '') || '',
          fatherName: document.getElementById(`roomTenant_${i}_fatherName`)?.value.trim() || '',
          emergencyContact: document.getElementById(`roomTenant_${i}_emergencyContact`)?.value.trim() || '',
          dob: document.getElementById(`roomTenant_${i}_dob`)?.value || '',
          gender: document.getElementById(`roomTenant_${i}_gender`)?.value || '',
          occupation: document.getElementById(`roomTenant_${i}_occupation`)?.value || '',
          companyOrCollege: document.getElementById(`roomTenant_${i}_companyOrCollege`)?.value.trim() || '',
          permanentAddress: document.getElementById(`roomTenant_${i}_permanentAddress`)?.value.trim() || '',
          notes: document.getElementById(`roomTenant_${i}_notes`)?.value.trim() || '',
        });
      }
    }

    clearErrors('roomForm');
    document.querySelectorAll('#roomTenantSectionsContainer .form-error').forEach((el) => (el.textContent = ''));
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const now = new Date().toISOString();
    const roomData = { propertyId: currentPropertyId, roomNumber, notes, updatedAt: now };
    let newRoomId;

    if (editingRoomId) {
      const idx = rooms.findIndex((r) => r.id === editingRoomId);
      if (idx !== -1) rooms[idx] = { ...rooms[idx], ...roomData };
      newRoomId = editingRoomId;
    } else {
      newRoomId = generateId();
      rooms.unshift({ id: newRoomId, createdAt: now, ...roomData });
    }
    persistRooms();

    if (isOccupiedFlow && typeof TenantsController !== 'undefined') {
      tenantSections.forEach((s, i) => {
        TenantsController.createTenantDirect({
          ...s, tenantSource: 'Existing at Management Onboarding',
          currentAllocation: {
            propertyId: currentPropertyId, roomId: newRoomId, moveInDate,
            rent: i === 0 ? Number(existingRent) || 0 : 0, deposit: i === 0 ? Number(existingSecurity) || 0 : 0,
            maintCharge: 0, brokerage: 0, agreementStart: null, agreementEnd: null, paymentDueDate: null, lockInPeriod: null,
          },
        });
      });
      setTenantTypeRestriction(currentPropertyId, whoIsLiving);
      syncRoomVacancyTracking(newRoomId);
    }

    closeRoomModal();
    renderRoomsForProperty();
  }

  function handleDeleteRoom(roomId) {
    const room = rooms.find((r) => r.id === roomId);
    if (!room) return;
    if (computeRoomStatus(roomId) === 'Occupied') {
      alert('This room currently has an active tenant — move them out first before deleting the room.');
      return;
    }
    ConfirmModal.show('Delete this room? You can restore it later from Settings → Trash.', () => {
      TrashController.moveToTrash('room', room, 'Room ' + room.roomNumber);
      rooms = rooms.filter((r) => r.id !== roomId);
      persistRooms();
      renderRoomsForProperty();
      if (currentRoomId === roomId) backToRooms();
    });
  }

  // ---------------- LEVEL 3: Room Detail (active tenants + maintenance) ----------------
  function openRoom(roomId) {
    currentRoomId = roomId;
    const r = rooms.find((x) => x.id === roomId);
    if (!r) return;
    document.getElementById('rbCurrentRoomName').textContent = 'Room ' + r.roomNumber;
    document.getElementById('rbBackToRooms').textContent = document.getElementById('rbCurrentPropertyName').textContent;
    renderRoomDetail();
    document.getElementById('roomsPropertyView').classList.add('hidden');
    document.getElementById('roomBedsView').classList.remove('hidden');
  }

  function backToRooms() {
    currentRoomId = null;
    document.getElementById('roomBedsView').classList.add('hidden');
    document.getElementById('roomsPropertyView').classList.remove('hidden');
    renderRoomsForProperty();
  }

  function renderRoomDetail() {
    const r = rooms.find((x) => x.id === currentRoomId);
    if (!r) return;
    const status = computeRoomStatus(r.id);

    document.getElementById('roomDetailName').textContent = 'Room ' + r.roomNumber;
    document.getElementById('roomDetailMeta').textContent = r.notes || 'No notes';
    const badge = document.getElementById('roomDetailStatusBadge');
    badge.textContent = status;
    badge.className = 'badge ' + ROOM_STATUS_CLASS[status];

    document.getElementById('editRoomBtn').onclick = () => openEditRoomModal(r.id);
    document.getElementById('deleteRoomBtn').onclick = () => handleDeleteRoom(r.id);

    const tenantsBox = document.getElementById('roomActiveTenants');
    const occupants = activeTenantsInRoom(r.id);
    tenantsBox.innerHTML = occupants.length
      ? occupants.map((t) => `
          <div class="history-item">
            <div class="hi-title">${esc(t.fullName)}</div>
            <div class="hi-row">${phoneLinks(t.mobile)} · Since ${t.currentAllocation.moveInDate ? esc(t.currentAllocation.moveInDate) : '—'} · ₹${t.currentAllocation.rent}/mo</div>
          </div>`).join('')
      : '<div class="empty-state"><div class="desc">Room is currently available — no active tenant.</div></div>';

    renderRoomMaintenanceHistory();
  }

  function renderRoomMaintenanceHistory() {
    const box = document.getElementById('roomMaintenanceHistory');
    if (!box) return;
    if (typeof MaintenanceController === 'undefined') { box.innerHTML = ''; return; }
    const tickets = MaintenanceController.getTicketsByRoom(currentRoomId);
    const statusClassMap = { Open: 'status-open', Assigned: 'status-assigned', 'In Progress': 'status-inprogress', Completed: 'status-completed', Closed: 'status-closed', Cancelled: 'status-cancelled' };
    box.innerHTML = tickets.length
      ? tickets.slice().sort((a, b) => b.dateTime.localeCompare(a.dateTime)).map((t) => `
          <div class="history-item">
            <div class="hi-title">${esc(t.category)} — ${esc(t.ticketId)} <span class="badge ${statusClassMap[t.status]}" style="margin-left:6px;">${t.status}</span></div>
            <div class="hi-row">${t.dateTime.replace('T', ' ')} · Priority: ${esc(t.priority)}</div>
          </div>`).join('')
      : '<div class="empty-state"><div class="desc">No maintenance history for this room yet.</div></div>';
  }

  // ---------------- Helpers ----------------
  function clearErrors(formId) {
    document.querySelectorAll('#' + formId + ' .form-error').forEach((el) => (el.textContent = ''));
  }
  function showErrors(errors) {
    Object.entries(errors).forEach(([id, msg]) => {
      const el = document.getElementById('err-' + id);
      if (el) el.textContent = msg;
    });
  }
  function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // ---------------- Init / Bindings ----------------
  function bindEvents() {
    document.getElementById('rbPropertySearch').addEventListener('input', renderPropertySelect);
    document.getElementById('rbBackToProperties').addEventListener('click', backToPropertySelect);
    document.getElementById('rbBackToPropertiesFromRoom').addEventListener('click', backToPropertySelect);
    document.getElementById('rbBackToRooms').addEventListener('click', backToRooms);

    document.getElementById('addRoomBtn').addEventListener('click', openAddRoomModal);
    document.getElementById('roomModalCloseBtn').addEventListener('click', closeRoomModal);
    document.getElementById('roomCancelBtn').addEventListener('click', closeRoomModal);
    document.getElementById('roomSaveBtn').addEventListener('click', handleSaveRoom);
    document.getElementById('roomModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'roomModalOverlay') closeRoomModal(); });
    document.getElementById('roomSearchInput').addEventListener('input', renderRoomsForProperty);
    document.getElementById('roomStatusFilter').addEventListener('change', renderRoomsForProperty);
    document.getElementById('roomOccupancyChoice').addEventListener('change', onRoomOccupancyChoiceChange);
    document.getElementById('roomTenantCount').addEventListener('input', rebuildRoomTenantSections);
  }

  function onPageShow() {
    if (currentRoomId) { renderRoomDetail(); }
    else if (currentPropertyId) { renderRoomsForProperty(); }
    else { renderPropertySelect(); }
  }

  // ---------------- Public getters/mutators ----------------
  function getRoomsByProperty(propertyId) { return roomsForProperty(propertyId); }
  function getRoomById(id) { return rooms.find((r) => r.id === id); }
  function getAvailableRoomsByProperty(propertyId) { return roomsForProperty(propertyId).filter((r) => computeRoomStatus(r.id) === 'Available'); }

  /** Keeps a Room's own vacantSince timestamp in sync with its actual
   *  occupancy — stamped the moment it empties out, cleared the moment
   *  someone moves back in. Call this after any allocation/move-out/
   *  delete-tenant action. Replaces what used to live on Bed. */
  function syncRoomVacancyTracking(roomId) {
    const idx = rooms.findIndex((r) => r.id === roomId);
    if (idx === -1) return;
    const isOccupied = computeRoomStatus(roomId) === 'Occupied';
    if (isOccupied) {
      rooms[idx].vacantSince = null;
    } else if (!rooms[idx].vacantSince) {
      rooms[idx].vacantSince = new Date().toISOString();
    }
    persistRooms();
  }

  function init() {
    load();
    bindEvents();
    renderPropertySelect();
  }

  function getAllRooms() { return [...rooms]; }
  function reload() { load(); onPageShow(); }

  /** Records the occupant-count for a room after Notifications has
   *  processed it — lets the next scan detect a CHANGE (someone joined
   *  or left) rather than just seeing a static current count. */
  function updateLastKnownOccupancy(roomId, count) {
    const idx = rooms.findIndex((r) => r.id === roomId);
    if (idx === -1) return;
    rooms[idx].lastKnownOccupancy = count;
    persistRooms();
  }

  return {
    init, onPageShow,
    getRoomsByProperty, getRoomById, getAvailableRoomsByProperty,
    getAllRooms, reload, updateLastKnownOccupancy,
    computeRoomStatus, computePropertyStats, activeTenantsInRoom,
    getAllowedTenantTypes, setTenantTypeRestriction, checkAndResetTenantTypeIfVacant,
    syncRoomVacancyTracking,
  };
})();
