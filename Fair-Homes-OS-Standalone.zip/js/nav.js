/* ==========================================================================
   Fair Homes OS — Navigation Controller
   Handles sidebar + bottom nav page switching. No business logic here —
   purely UI/navigation state (Phase 1 scope).
   ========================================================================== */

const NavController = (() => {
  const PAGE_TITLES = {
    dashboard: 'Dashboard',
    owners: 'Owners',
    properties: 'Properties',
    rooms: 'Rooms & Beds',
    bookings: 'Bookings',
    brokerageFlats: 'Brokerage-Only Flats',
    tenants: 'Tenants',
    finance: 'Finance',
    maintenance: 'Maintenance',
    socialMediaTasks: 'Social Media Tasks',
    reports: 'Reports',
    notifications: 'Notifications',
    settings: 'Settings',
  };

  function goToPage(pageId) {
    if (typeof AccessController !== 'undefined' && !AccessController.guardPageAccess(pageId)) return;

    document.querySelectorAll('.page-section').forEach((el) => el.classList.remove('active'));
    const target = document.getElementById('page-' + pageId);
    if (target) target.classList.add('active');

    document.querySelectorAll('.nav-item').forEach((el) => el.classList.toggle('active', el.dataset.page === pageId));
    document.querySelectorAll('.bn-item').forEach((el) => el.classList.toggle('active', el.dataset.page === pageId));

    const titleEl = document.getElementById('pageTitle');
    if (titleEl) titleEl.textContent = PAGE_TITLES[pageId] || '';

    closeSidebar();
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });

    if (pageId === 'rooms' && typeof RoomsController !== 'undefined') {
      RoomsController.onPageShow();
    }
    if (pageId === 'dashboard' && typeof DashboardController !== 'undefined') {
      DashboardController.render();
    }
    if (pageId === 'bookings' && typeof BookingsController !== 'undefined') {
      BookingsController.onPageShow();
    }
    if (pageId === 'brokerageFlats' && typeof BrokerageFlatsController !== 'undefined') {
      BrokerageFlatsController.onPageShow();
    }
    if (pageId === 'socialMediaTasks' && typeof SocialMediaController !== 'undefined') {
      SocialMediaController.onPageShow();
    }
    if (pageId === 'tenants' && typeof TenantsController !== 'undefined') {
      TenantsController.onPageShow();
    }
    if (pageId === 'finance' && typeof FinanceController !== 'undefined') {
      FinanceController.onPageShow();
    }
    if (pageId === 'maintenance' && typeof MaintenanceController !== 'undefined') {
      MaintenanceController.onPageShow();
    }
    if (pageId === 'reports' && typeof ReportsController !== 'undefined') {
      ReportsController.onPageShow();
    }
    if (pageId === 'notifications' && typeof NotificationsController !== 'undefined') {
      NotificationsController.onPageShow();
    }
    if (pageId === 'settings' && typeof SettingsController !== 'undefined') {
      SettingsController.onPageShow();
    }
  }

  function openSidebar() {
    document.getElementById('sidebar').classList.add('open');
    document.getElementById('sidebarOverlay').classList.add('open');
  }

  function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('open');
  }

  function toggleSidebar() {
    const isOpen = document.getElementById('sidebar').classList.contains('open');
    if (isOpen) closeSidebar(); else openSidebar();
  }

  function bindNavClicks() {
    document.querySelectorAll('.nav-item[data-page]').forEach((el) => {
      el.addEventListener('click', () => goToPage(el.dataset.page));
    });
    document.querySelectorAll('.bn-item[data-page]').forEach((el) => {
      el.addEventListener('click', () => goToPage(el.dataset.page));
    });
    document.getElementById('hamburgerBtn')?.addEventListener('click', toggleSidebar);
    document.getElementById('sidebarOverlay')?.addEventListener('click', closeSidebar);
    document.getElementById('bnMoreBtn')?.addEventListener('click', openSidebar);
  }

  return { goToPage, bindNavClicks, openSidebar, closeSidebar };
})();
