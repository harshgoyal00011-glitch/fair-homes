/* ==========================================================================
   Fair Homes OS — Tenant Management & Room Allocation
   Fully integrated with Owners -> Properties -> Rooms.
   A tenant can only be assigned to an AVAILABLE room. Room occupancy is
   derived live from which tenants have their allocation pointing at it —
   there's no separate Bed layer to keep in sync.
   ========================================================================== */

const TenantsController = (() => {
  const STORAGE_KEY = 'fh_tenants';
  const SEQ_KEY = 'fh_tenant_id_seq';
  let tenants = [];
  let editingId = null;
  let pendingBookingConversionData = null;
  let viewingId = null;

  const STATUS_CLASS = {
    'Unassigned': 'tenant-unassigned',
    'Active': 'tenant-active',
    'Notice Period': 'tenant-notice',
    'Moved Out': 'tenant-moved-out',
  };

  // ---------------- Storage ----------------
  function load() {
    try { tenants = JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; } catch (e) { tenants = []; }
    CloudSync.watch('tenants', (cloudTenants) => {
      tenants = cloudTenants;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tenants));
      renderList();
      if (viewingId) renderDetail(viewingId);
    });
  }
  function persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tenants));
    CloudSync.sync('tenants', tenants);
  }

  function generateId() {
    return (crypto.randomUUID ? crypto.randomUUID() : 'ten_' + Date.now() + '_' + Math.random().toString(16).slice(2));
  }
  function nextTenantCode() {
    let seq = parseInt(localStorage.getItem(SEQ_KEY) || '0', 10) + 1;
    localStorage.setItem(SEQ_KEY, String(seq));
    return 'TEN-' + String(seq).padStart(4, '0');
  }

  // ---------------- Tenant Add/Edit Validation ----------------
  function validateTenant(f) {
    const errors = {};
    if (!f.fullName.trim()) errors.tenantFullName = 'Full name is required';

    if (!f.mobile.trim()) errors.tenantMobile = 'Mobile number is required';
    else if (!/^[6-9]\d{9}$/.test(f.mobile.trim())) errors.tenantMobile = 'Enter a valid 10-digit mobile number';
    else {
      const dup = tenants.some((t) => t.mobile === f.mobile.trim() && t.id !== editingId);
      if (dup) errors.tenantMobile = 'A tenant with this mobile number already exists';
    }

    if (f.altMobile.trim() && !/^[6-9]\d{9}$/.test(f.altMobile.trim())) errors.tenantAltMobile = 'Enter a valid 10-digit number';
    if (f.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.trim())) errors.tenantEmail = 'Enter a valid email address';
    if (f.aadhaar.trim() && !/^\d{12}$/.test(f.aadhaar.replace(/\s/g, ''))) errors.tenantAadhaar = 'Aadhaar must be exactly 12 digits';
    if (f.emergencyContact.trim() && !/^[6-9]\d{9}$/.test(f.emergencyContact.trim())) errors.tenantEmergencyContact = 'Enter a valid 10-digit number';

    return errors;
  }

  function clearErrors(formId) {
    document.querySelectorAll('#' + formId + ' .form-error').forEach((el) => (el.textContent = ''));
  }
  function showErrors(errors) {
    Object.entries(errors).forEach(([id, msg]) => {
      const el = document.getElementById('err-' + id);
      if (el) el.textContent = msg;
    });
  }

  // ---------------- Tenant Modal ----------------
  function openAddModal(prefill) {
    editingId = null;
    document.getElementById('tenantModalTitle').textContent = 'Add Tenant';
    document.getElementById('tenantForm').reset();
    document.getElementById('tenantId').value = '';
    document.getElementById('isExistingTenant').checked = false;
    document.getElementById('existingTenantToggleGroup').classList.add('hidden');
    document.getElementById('existingTenancyFields').classList.add('hidden');
    if (prefill) {
      if (prefill.fullName) document.getElementById('tenantFullName').value = prefill.fullName;
      if (prefill.mobile) document.getElementById('tenantMobile').value = prefill.mobile;
      if (prefill.referralSource) document.getElementById('tenantReferralSource').value = prefill.referralSource;
      pendingBookingConversionData = prefill.pendingBookingConversion || null;
    } else {
      pendingBookingConversionData = null;
    }
    clearErrors('tenantForm');
    document.getElementById('tenantModalOverlay').classList.add('open');
  }

  /** Existing tenants (already living in a property before Fair Homes
   *  took over management) go straight to full details + Room, no
   *  Booking involved. Reuses the same Add Tenant modal — just with the
   *  tenancy-details section pre-shown and required. */
  function openAddExistingTenantModal() {
    openAddModal();
    document.getElementById('tenantModalTitle').textContent = 'Add Existing Tenant';
    document.getElementById('isExistingTenant').checked = true;
    document.getElementById('existingTenancyFields').classList.remove('hidden');
    populateExistTenantPropertySelect();
    document.getElementById('existMoveInDate').value = '';
  }

  function populateExistTenantPropertySelect() {
    const sel = document.getElementById('existTenantProperty');
    sel.innerHTML = '<option value="">Select Property</option>' + PropertiesController.getAll().map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
  }

  function onExistTenantPropertyChange() {
    const propertyId = document.getElementById('existTenantProperty').value;
    const roomSel = document.getElementById('existTenantRoom');
    if (!propertyId) { roomSel.innerHTML = '<option value="">Select Property First</option>'; return; }
    const availableRooms = RoomsController.getAvailableRoomsByProperty(propertyId);
    if (!availableRooms.length) { roomSel.innerHTML = '<option value="">No available rooms in this property</option>'; return; }
    roomSel.innerHTML = '<option value="">Select Room</option>' + availableRooms.map((r) => `<option value="${r.id}">Room ${esc(r.roomNumber)}</option>`).join('');
  }

  function openEditModal(id) {
    const t = tenants.find((x) => x.id === id);
    if (!t) return;
    editingId = id;
    document.getElementById('tenantModalTitle').textContent = 'Edit Tenant';
    document.getElementById('tenantId').value = t.id;
    document.getElementById('existingTenantToggleGroup').classList.add('hidden');
    document.getElementById('existingTenancyFields').classList.add('hidden');
    document.getElementById('tenantFullName').value = t.fullName || '';
    document.getElementById('tenantMobile').value = t.mobile || '';
    document.getElementById('tenantAltMobile').value = t.altMobile || '';
    document.getElementById('tenantEmail').value = t.email || '';
    document.getElementById('tenantAadhaar').value = formatAadhaar(t.aadhaar || '');
    document.getElementById('tenantFatherName').value = t.fatherName || '';
    document.getElementById('tenantEmergencyContact').value = t.emergencyContact || '';
    document.getElementById('tenantDob').value = t.dob || '';
    document.getElementById('tenantGender').value = t.gender || '';
    document.getElementById('tenantOccupation').value = t.occupation || '';
    document.getElementById('tenantCompany').value = t.companyOrCollege || '';
    document.getElementById('tenantPermAddress').value = t.permanentAddress || '';
    document.getElementById('tenantCurrAddress').value = t.currentAddress || '';
    document.getElementById('tenantReferralSource').value = t.referralSource || '';
    document.getElementById('tenantNotes').value = t.notes || '';
    clearErrors('tenantForm');
    document.getElementById('tenantModalOverlay').classList.add('open');
  }

  function closeModal() {
    document.getElementById('tenantModalOverlay').classList.remove('open');
    editingId = null;
  }

  function handleSaveTenant() {
    const isExisting = document.getElementById('isExistingTenant').checked;
    const f = {
      fullName: document.getElementById('tenantFullName').value,
      mobile: document.getElementById('tenantMobile').value,
      altMobile: document.getElementById('tenantAltMobile').value,
      email: document.getElementById('tenantEmail').value,
      aadhaar: document.getElementById('tenantAadhaar').value.replace(/\s/g, ''),
      fatherName: document.getElementById('tenantFatherName').value,
      emergencyContact: document.getElementById('tenantEmergencyContact').value,
      dob: document.getElementById('tenantDob').value,
      gender: document.getElementById('tenantGender').value,
      occupation: document.getElementById('tenantOccupation').value,
      companyOrCollege: document.getElementById('tenantCompany').value,
      permanentAddress: document.getElementById('tenantPermAddress').value,
      currentAddress: document.getElementById('tenantCurrAddress').value,
      referralSource: document.getElementById('tenantReferralSource').value,
      notes: document.getElementById('tenantNotes').value,
    };

    let existingTenancy = null;
    if (isExisting && !editingId) {
      const propertyId = document.getElementById('existTenantProperty').value;
      const roomId = document.getElementById('existTenantRoom').value;
      const occupancyType = document.getElementById('existOccupancyType').value;
      const monthlyRent = document.getElementById('existMonthlyRent').value;
      const securityAmount = document.getElementById('existSecurityAmount').value;
      const moveInDate = document.getElementById('existMoveInDate').value;
      const agreementStart = document.getElementById('existAgreementStart').value;
      const agreementEnd = document.getElementById('existAgreementEnd').value;

      const existErrors = {};
      if (!propertyId) existErrors.existTenantProperty = 'Select a property';
      if (!roomId) existErrors.existTenantRoom = 'Select a room';
      if (!monthlyRent || Number(monthlyRent) < 0) existErrors.existMonthlyRent = 'Enter monthly rent';
      if (!moveInDate) existErrors.existMoveInDate = 'Original move-in date is required';
      clearErrors('tenantForm');
      if (Object.keys(existErrors).length) { showErrors(existErrors); return; }

      const property = PropertiesController.getAll().find((p) => p.id === propertyId);
      if (property && !f.currentAddress.trim()) f.currentAddress = property.address || '';

      existingTenancy = {
        propertyId, roomId, occupancyType,
        rent: Number(monthlyRent) || 0, deposit: Number(securityAmount) || 0,
        moveInDate, agreementStart: agreementStart || null, agreementEnd: agreementEnd || null,
      };
    }

    clearErrors('tenantForm');
    const errors = validateTenant(f);
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const now = new Date().toISOString();
    const tenantData = {
      fullName: f.fullName.trim(), mobile: f.mobile.trim(), altMobile: f.altMobile.trim(),
      email: f.email.trim(), aadhaar: f.aadhaar.trim(),
      fatherName: f.fatherName.trim(), emergencyContact: f.emergencyContact.trim(),
      dob: f.dob, gender: f.gender, occupation: f.occupation.trim(), companyOrCollege: f.companyOrCollege.trim(),
      permanentAddress: f.permanentAddress.trim(), currentAddress: f.currentAddress.trim(),
      referralSource: f.referralSource, notes: f.notes.trim(), updatedAt: now,
    };

    if (editingId) {
      const idx = tenants.findIndex((t) => t.id === editingId);
      if (idx !== -1) tenants[idx] = { ...tenants[idx], ...tenantData };
    } else {
      const newTenantId = generateId();
      const tenantSource = isExisting ? 'Existing at Management Onboarding' : 'Booked Through Fair Homes';
      const newTenant = {
        id: newTenantId, tenantCode: nextTenantCode(), createdAt: now,
        status: existingTenancy ? 'Active' : 'Unassigned',
        currentAllocation: existingTenancy ? {
          propertyId: existingTenancy.propertyId, roomId: existingTenancy.roomId,
          moveInDate: existingTenancy.moveInDate, rent: existingTenancy.rent, deposit: existingTenancy.deposit,
          maintCharge: 0, brokerage: 0,
          agreementStart: existingTenancy.agreementStart, agreementEnd: existingTenancy.agreementEnd,
          paymentDueDate: null, lockInPeriod: null,
        } : null,
        moveOutHistory: [], pendingBookingConversion: pendingBookingConversionData, tenantSource,
        ...tenantData,
      };
      tenants.unshift(newTenant);
      if (existingTenancy && typeof RoomsController !== 'undefined') {
        RoomsController.syncRoomVacancyTracking(existingTenancy.roomId);
      }
      // New tenant onboarding needs Google Form, Agreement, Police
      // Verification, and a Review — auto-create these as tracked
      // checklist items in Social Media Tasks, so nothing has to be
      // remembered manually and progress is visible in one place.
      if (typeof SocialMediaController !== 'undefined' && SocialMediaController.createOnboardingChecklist) {
        SocialMediaController.createOnboardingChecklist(newTenantId, tenantData.fullName);
      }
    }
    persist();
    closeModal();
    populatePropertyFilter();
    renderList();
    if (viewingId) renderDetail(viewingId);
  }

  function handleDeleteTenant(id) {
    const t = tenants.find((x) => x.id === id);
    if (!t) return;
    const message = t.currentAllocation
      ? 'This tenant currently occupies a room. Deleting will free up that room. Continue?'
      : 'Delete this tenant? You can restore it later from Settings → Trash.';
    ConfirmModal.show(message, () => {
      const propertyId = t.currentAllocation ? t.currentAllocation.propertyId : null;
      const roomId = t.currentAllocation ? t.currentAllocation.roomId : null;
      TrashController.moveToTrash('tenant', t, t.fullName);
      tenants = tenants.filter((x) => x.id !== id);
      persist();
      if (roomId) RoomsController.syncRoomVacancyTracking(roomId);
      if (propertyId) RoomsController.checkAndResetTenantTypeIfVacant(propertyId);
      renderList();
      if (viewingId === id) backToList();
    });
  }

  // ---------------- List Rendering ----------------
  function populatePropertyFilter() {
    const sel = document.getElementById('tenantPropertyFilter');
    const current = sel.value;
    const properties = PropertiesController.getAll();
    sel.innerHTML = '<option value="all">All Properties</option>' +
      properties.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
    sel.value = current || 'all';
  }

  function locationText(t) {
    if (!t.currentAllocation) return 'Not Allocated';
    const room = RoomsController.getRoomById(t.currentAllocation.roomId);
    const property = PropertiesController.getAll().find((p) => p.id === t.currentAllocation.propertyId);
    return `${property ? property.name : 'Property'} · Room ${room ? room.roomNumber : '?'}`;
  }

  function renderList() {
    const query = (document.getElementById('tenantSearchInput')?.value || '').toLowerCase().trim();
    const statusFilter = document.getElementById('tenantStatusFilter')?.value || 'all';
    const propertyFilter = document.getElementById('tenantPropertyFilter')?.value || 'all';

    const filtered = tenants.filter((t) => {
      const loc = locationText(t).toLowerCase();
      const matchesSearch = t.fullName.toLowerCase().includes(query) || t.mobile.includes(query) || loc.includes(query);
      const matchesStatus = statusFilter === 'all' || t.status === statusFilter;
      const matchesProperty = propertyFilter === 'all' || (t.currentAllocation && t.currentAllocation.propertyId === propertyFilter);
      return matchesSearch && matchesStatus && matchesProperty;
    });

    document.getElementById('tenantCountChip').textContent = tenants.length + (tenants.length === 1 ? ' tenant' : ' tenants');

    const grid = document.getElementById('tenantsGrid');
    if (!filtered.length) {
      grid.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="ico">🧑‍🤝‍🧑</div>
          <div class="title">${tenants.length === 0 ? 'No tenants yet' : 'No matching tenants'}</div>
          <div class="desc">${tenants.length === 0 ? 'Add your first tenant to get started.' : 'Try a different search or filter.'}</div>
        </div>`;
      return;
    }

    grid.innerHTML = filtered.map((t) => `
      <div class="owner-card" data-id="${t.id}">
        <div class="oc-top">
          <div class="oc-avatar">${initials(t.fullName)}</div>
          <div>
            <div class="oc-name">${esc(t.fullName)}</div>
            <div class="oc-sub">${esc(t.tenantCode)}</div>
          </div>
        </div>
        <div class="oc-row">📱 ${esc(t.mobile)}</div>
        <div class="oc-row">🏠 ${esc(locationText(t))}</div>
        <div style="margin-top:8px;"><span class="badge ${STATUS_CLASS[t.status]}">${t.status}</span></div>
        <div class="oc-actions">
          <button class="btn small secondary tc-edit-btn" data-id="${t.id}">Edit</button>
          <button class="btn small tc-delete-btn" data-id="${t.id}" style="background:var(--error);">Delete</button>
        </div>
      </div>
    `).join('');

    grid.querySelectorAll('.owner-card').forEach((card) => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('.tc-edit-btn') || e.target.closest('.tc-delete-btn')) return;
        renderDetail(card.dataset.id);
      });
    });
    grid.querySelectorAll('.tc-edit-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => { e.stopPropagation(); openEditModal(btn.dataset.id); });
    });
    grid.querySelectorAll('.tc-delete-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => { e.stopPropagation(); handleDeleteTenant(btn.dataset.id); });
    });
  }

  // ---------------- Detail / Profile View ----------------
  function renderDetail(id) {
    const t = tenants.find((x) => x.id === id);
    if (!t) return;
    viewingId = id;

    document.getElementById('tdAvatar').textContent = initials(t.fullName);
    document.getElementById('tdName').textContent = t.fullName;
    document.getElementById('tdCode').textContent = t.tenantCode + ' · Added ' + formatDate(t.createdAt);
    const badge = document.getElementById('tdStatusBadge');
    badge.textContent = t.status;
    badge.className = 'badge ' + STATUS_CLASS[t.status];

    setVal('tdMobile', t.mobile);
    if (t.mobile) document.getElementById('tdMobile').innerHTML = phoneLinks(t.mobile);
    setVal('tdAltMobile', t.altMobile);
    setVal('tdEmail', t.email);
    setVal('tdDob', t.dob ? formatDate(t.dob) : '');
    setVal('tdGender', t.gender);
    setVal('tdOccupation', t.occupation);
    setVal('tdCompany', t.companyOrCollege);
    setVal('tdFather', t.fatherName);
    setVal('tdEmergency', t.emergencyContact);
    setVal('tdAadhaar', t.aadhaar ? formatAadhaar(t.aadhaar) : '');
    setVal('tdPermAddress', t.permanentAddress);
    setVal('tdCurrAddress', t.currentAddress);
    setVal('tdReferralSource', t.referralSource);
    setVal('tdTenantSource', t.tenantSource);
    renderOnboardingChecklist(t);
    setVal('tdNotes', t.notes);
    renderTenantInteractionLog(t);

    // Current allocation box
    const allocBox = document.getElementById('tdAllocationBox');
    if (t.currentAllocation) {
      const a = t.currentAllocation;
      const room = RoomsController.getRoomById(a.roomId);
      const property = PropertiesController.getAll().find((p) => p.id === a.propertyId);
      allocBox.innerHTML = `
        <div class="allocation-card">
          <div class="ac-path">📍 <b>${esc(property ? property.name : '—')}</b> · Room <b>${esc(room ? room.roomNumber : '—')}</b></div>
          <div class="detail-grid">
            <div class="detail-item"><div class="di-label">Move In Date</div><div class="di-value">${formatDate(a.moveInDate)}</div></div>
            <div class="detail-item"><div class="di-label">Monthly Rent</div><div class="di-value">₹${a.rent}</div></div>
            <div class="detail-item"><div class="di-label">Security Deposit</div><div class="di-value">₹${a.deposit || 0}</div></div>
            <div class="detail-item"><div class="di-label">Maintenance Charges</div><div class="di-value">₹${a.maintCharge || 0}</div></div>
            <div class="detail-item"><div class="di-label">Brokerage</div><div class="di-value">₹${a.brokerage || 0}</div></div>
            <div class="detail-item"><div class="di-label">Agreement Period</div><div class="di-value">${formatDate(a.agreementStart)} → ${formatDate(a.agreementEnd)} <button class="btn small secondary" id="renewLeaseBtn" style="margin-left:8px;">Renew Lease</button></div></div>
            <div class="detail-item"><div class="di-label">Payment Due Date</div><div class="di-value">${a.paymentDueDate ? 'Day ' + a.paymentDueDate + ' of month' : 'Not set'}</div></div>
            <div class="detail-item"><div class="di-label">Payment Status</div><div class="di-value">${paymentStatusText(a.paymentDueDate)}</div></div>
            <div class="detail-item"><div class="di-label">Lock-In Period</div><div class="di-value">${a.lockInPeriod ? a.lockInPeriod + ' months' : 'None'}</div></div>
          </div>
        </div>`;
    } else {
      allocBox.innerHTML = '<div class="empty-state"><div class="desc">Not currently allocated to any bed.</div></div>';
    }

    // Payment history (from FinanceController — Rent Collection, Deposits, Phase 6)
    renderPaymentHistory(t.id);
    renderTenantComplaintHistory(t.id);

    // Move-out history
    const historyBox = document.getElementById('tdHistoryBox');
    if (t.moveOutHistory && t.moveOutHistory.length) {
      historyBox.innerHTML = t.moveOutHistory.slice().reverse().map((h) => `
        <div class="history-item">
          <div class="hi-title">${esc(h.propertyName)} · Room ${esc(h.roomNumber)}</div>
          <div class="hi-row">Stayed: ${formatDate(h.moveInDate)} → ${formatDate(h.moveOutDate)}</div>
          ${h.reason ? `<div class="hi-row">Reason: ${esc(h.reason)}</div>` : ''}
          <div class="hi-row">Pending Rent: ₹${h.pendingRent} · Maintenance Deduction: ₹${h.maintenanceDeduction ?? h.pendingMaintenance ?? 0} · Refunded: ₹${h.refundDeposit}</div>
          ${h.notes ? `<div class="hi-row">Notes: ${esc(h.notes)}</div>` : ''}
        </div>
      `).join('');
    } else {
      historyBox.innerHTML = '<div class="empty-state"><div class="desc">No move-out history yet.</div></div>';
    }

    // Action buttons visibility
    document.getElementById('tdAllocateBtn').classList.toggle('hidden', !!t.currentAllocation);
    document.getElementById('tdMoveOutBtn').classList.toggle('hidden', !t.currentAllocation);
    document.getElementById('tdNoticeBtn').classList.toggle('hidden', !t.currentAllocation);
    document.getElementById('tdNoticeBtn').textContent = t.status === 'Notice Period' ? 'Mark Active' : 'Mark Notice Period';

    document.getElementById('tdEditBtn').onclick = () => openEditModal(t.id);
    document.getElementById('tdDeleteBtn').onclick = () => handleDeleteTenant(t.id);
    document.getElementById('tdAllocateBtn').onclick = () => openAllocateModal(t.id);
    document.getElementById('tdMoveOutBtn').onclick = () => openMoveOutModal(t.id);
    document.getElementById('tdNoticeBtn').onclick = () => toggleNoticePeriod(t.id);
    const renewBtn = document.getElementById('renewLeaseBtn');
    if (renewBtn) renewBtn.onclick = () => openRenewLeaseModal(t.id);

    document.getElementById('tenantsListView').classList.add('hidden');
    document.getElementById('tenantDetailView').classList.remove('hidden');
  }

  function toggleNoticePeriod(id) {
    const t = tenants.find((x) => x.id === id);
    if (!t) return;
    t.status = t.status === 'Notice Period' ? 'Active' : 'Notice Period';
    t.updatedAt = new Date().toISOString();
    persist();
    renderDetail(id);
    renderList();
  }

  function setVal(elId, value) {
    const el = document.getElementById(elId);
    if (value && String(value).trim()) { el.textContent = value; el.classList.remove('empty'); }
    else { el.textContent = 'Not provided'; el.classList.add('empty'); }
  }

  function renderPaymentHistory(tenantId) {
    if (typeof FinanceController === 'undefined') return;
    const summary = FinanceController.getTenantFinanceSummary(tenantId);

    document.getElementById('tdPaymentSummaryGrid').innerHTML = `
      <div class="stat-card"><div class="label">Total Paid</div><div class="value success">₹${summary.totalPaid}</div></div>
      <div class="stat-card"><div class="label">Outstanding Balance</div><div class="value ${summary.outstandingBalance > 0 ? 'warning' : ''}">₹${summary.outstandingBalance}</div></div>
      <div class="stat-card"><div class="label">Late Payments</div><div class="value ${summary.latePayments > 0 ? 'error' : ''}">${summary.latePayments}</div></div>
      <div class="stat-card"><div class="label">Pending Payments</div><div class="value ${summary.pendingPayments > 0 ? 'warning' : ''}">${summary.pendingPayments}</div></div>
    `;

    const statusClassMap = { Paid: 'pay-paid', Partial: 'pay-partial', Pending: 'pay-pending', Overdue: 'pay-overdue' };
    const rentBox = document.getElementById('tdRentHistoryBox');
    rentBox.innerHTML = summary.rents.length
      ? summary.rents.map((r) => `
          <div class="history-item">
            <div class="hi-title">${r.rentMonth} — ₹${r.amountPaid} / ₹${r.totalPayable} <span class="badge ${statusClassMap[r.paymentStatus]}" style="margin-left:6px;">${r.paymentStatus}</span></div>
            <div class="hi-row">Due ${r.dueDate}${r.paymentDate ? ' · Paid ' + r.paymentDate : ''} · ${r.paymentMethod}</div>
          </div>`).join('')
      : '<div class="empty-state"><div class="desc">No rent entries recorded yet.</div></div>';

    const depStatusClassMap = { Held: 'dep-held', Refunded: 'dep-refunded', 'Partially Refunded': 'dep-partial', Forfeited: 'dep-forfeited' };
    const depBox = document.getElementById('tdDepositHistoryBox');
    depBox.innerHTML = summary.deposits.length
      ? summary.deposits.map((d) => `
          <div class="history-item">
            <div class="hi-title">₹${d.amount} <span class="badge ${depStatusClassMap[d.status]}" style="margin-left:6px;">${d.status}</span></div>
            <div class="hi-row">Received ${d.depositDate}${d.refundDate ? ' · Refunded ' + d.refundDate + ' (₹' + d.refundedAmount + ')' : ''}</div>
          </div>`).join('')
      : '<div class="empty-state"><div class="desc">No deposit records yet.</div></div>';
  }

  function renderTenantComplaintHistory(tenantId) {
    const box = document.getElementById('tdComplaintHistory');
    if (!box) return;
    if (typeof MaintenanceController === 'undefined') { box.innerHTML = ''; return; }
    const tickets = MaintenanceController.getTicketsByTenant(tenantId);
    const statusClassMap = { Open: 'status-open', Assigned: 'status-assigned', 'In Progress': 'status-inprogress', Completed: 'status-completed', Closed: 'status-closed', Cancelled: 'status-cancelled' };
    box.innerHTML = tickets.length
      ? tickets.slice().sort((a, b) => b.dateTime.localeCompare(a.dateTime)).map((t) => `
          <div class="history-item">
            <div class="hi-title">${esc(t.category)} — ${esc(t.ticketId)} <span class="badge ${statusClassMap[t.status]}" style="margin-left:6px;">${t.status}</span></div>
            <div class="hi-row">${t.dateTime.replace('T', ' ')} · Priority: ${esc(t.priority)}</div>
          </div>`).join('')
      : '<div class="empty-state"><div class="desc">No maintenance complaints from this tenant yet.</div></div>';
  }

  function backToList() {
    viewingId = null;
    document.getElementById('tenantDetailView').classList.add('hidden');
    document.getElementById('tenantsListView').classList.remove('hidden');
    renderList();
  }

  // ---------------- Allocate Bed ----------------
  let allocatingTenantId = null;

  function openAllocateModal(tenantId) {
    allocatingTenantId = tenantId;
    document.getElementById('allocateForm').reset();
    clearErrors('allocateForm');

    const sel = document.getElementById('allocProperty');
    sel.innerHTML = '<option value="">Select Property</option>' +
      PropertiesController.getAll().map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
    document.getElementById('allocRoom').innerHTML = '<option value="">Select Property First</option>';

    document.getElementById('allocateModalOverlay').classList.add('open');

    const tenant = tenants.find((t) => t.id === tenantId);
    const pending = tenant?.pendingBookingConversion;
    if (pending) {
      document.getElementById('allocRent').value = pending.monthlyRent || '';
      document.getElementById('allocDeposit').value = pending.securityAmount || '';
      document.getElementById('allocBrokerage').value = pending.brokerageAmount || '';
    }
  }

  function closeAllocateModal() {
    document.getElementById('allocateModalOverlay').classList.remove('open');
    allocatingTenantId = null;
  }

  function onAllocPropertyChange() {
    const propertyId = document.getElementById('allocProperty').value;
    const roomSel = document.getElementById('allocRoom');
    if (!propertyId) { roomSel.innerHTML = '<option value="">Select Property First</option>'; return; }
    const availableRooms = RoomsController.getAvailableRoomsByProperty(propertyId);
    if (!availableRooms.length) {
      roomSel.innerHTML = '<option value="">No available rooms in this property</option>';
      return;
    }
    roomSel.innerHTML = '<option value="">Select Room</option>' +
      availableRooms.map((r) => `<option value="${r.id}">Room ${esc(r.roomNumber)}</option>`).join('');
  }

  function handleSaveAllocation() {
    const propertyId = document.getElementById('allocProperty').value;
    const roomId = document.getElementById('allocRoom').value;
    const moveInDate = document.getElementById('allocMoveInDate').value;
    const rent = document.getElementById('allocRent').value;
    const deposit = document.getElementById('allocDeposit').value;
    const maintCharge = document.getElementById('allocMaintCharge').value;
    const brokerage = document.getElementById('allocBrokerage').value;
    const agreementStart = document.getElementById('allocAgreementStart').value;
    const agreementEnd = document.getElementById('allocAgreementEnd').value;
    const paymentDueDate = document.getElementById('allocPaymentDueDate').value;
    const lockInPeriod = document.getElementById('allocLockIn').value;

    const errors = {};
    if (!propertyId) errors.allocProperty = 'Select a property';
    if (!roomId) errors.allocRoom = 'Select a room';
    else if (RoomsController.computeRoomStatus(roomId) === 'Occupied') {
      errors.allocRoom = 'This room is no longer available. Please choose another.';
    }
    if (!moveInDate) errors.allocMoveInDate = 'Move in date is required';
    if (rent === '' || Number(rent) < 0) errors.allocRent = 'Enter monthly rent';
    if (!agreementStart) errors.allocAgreementStart = 'Agreement start date is required';
    if (!agreementEnd) errors.allocAgreementEnd = 'Agreement end date is required';
    else if (agreementStart && new Date(agreementEnd) <= new Date(agreementStart)) {
      errors.allocAgreementEnd = 'Agreement end date must be after the start date';
    }

    clearErrors('allocateForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const tenant = tenants.find((t) => t.id === allocatingTenantId);
    if (!tenant) return;

    tenant.currentAllocation = {
      propertyId, roomId, moveInDate,
      rent: Number(rent) || 0, deposit: Number(deposit) || 0,
      maintCharge: Number(maintCharge) || 0, brokerage: Number(brokerage) || 0,
      agreementStart, agreementEnd,
      paymentDueDate: paymentDueDate ? Number(paymentDueDate) : null,
      lockInPeriod: lockInPeriod ? Number(lockInPeriod) : null,
    };
    tenant.status = 'Active';
    tenant.updatedAt = new Date().toISOString();
    RoomsController.syncRoomVacancyTracking(roomId);

    const pending = tenant.pendingBookingConversion;
    let conversionSummary = '';
    if (pending && typeof FinanceController !== 'undefined' && FinanceController.createInitialRentFromBooking) {
      const result = FinanceController.createInitialRentFromBooking({
        tenantId: tenant.id, monthlyRent: pending.monthlyRent, tokenCollected: pending.tokenCollected, moveInDate,
      });
      const stillNeeded = [];
      if (result.rentRemaining > 0) stillNeeded.push(`₹${result.rentRemaining} more rent`);
      if (pending.securityAmount > 0) stillNeeded.push(`₹${pending.securityAmount} Security Deposit (collect separately in Finance)`);
      if (pending.brokerageAmount > 0) stillNeeded.push(`₹${pending.brokerageAmount} Brokerage (collect separately in Finance)`);
      conversionSummary = `\n\nFirst month's rent entry created — ₹${result.rentApplied} of the token applied.${stillNeeded.length ? ' Still to collect: ' + stillNeeded.join(', ') + '.' : ''}`;
      tenant.pendingBookingConversion = null;
    }
    persist();

    closeAllocateModal();
    populatePropertyFilter();
    renderList();
    renderDetail(tenant.id);
    if (conversionSummary) alert('Allocation saved.' + conversionSummary);
  }

  // ---------------- Move Out ----------------
  let movingOutTenantId = null;
  let renewingLeaseTenantId = null;

  /** Renders the dated Interaction Log for a Tenant — same pattern as
   *  Owners. Stored as tenant.interactionLog: [{id, text, date}]. */
  /** Shows live onboarding progress (Google Form/Agreement/Police
   *  Verification/Review) pulled directly from Social Media Tasks — no
   *  separate copy of this data to keep in sync, just a read-through. */
  function renderOnboardingChecklist(tenant) {
    const box = document.getElementById('tdOnboardingChecklist');
    if (typeof SocialMediaController === 'undefined' || !SocialMediaController.getOnboardingChecklistForTenant) {
      box.innerHTML = '<div class="di-value empty">Not available</div>';
      return;
    }
    const items = SocialMediaController.getOnboardingChecklistForTenant(tenant.id);
    if (!items.length) { box.innerHTML = '<div class="di-value empty">Not created yet</div>'; return; }
    const doneCount = items.filter((i) => i.status === 'Done').length;
    box.innerHTML = `
      <div style="font-weight:700; margin-bottom:4px;">${doneCount} / ${items.length} Done</div>
      ${items.map((i) => `<div style="font-size:13px; color:var(--text-secondary);">${i.status === 'Done' ? '✅' : '⏳'} ${esc(i.checklistItem)}</div>`).join('')}
    `;
  }

  function renderTenantInteractionLog(tenant) {
    const box = document.getElementById('tdInteractionLog');
    const log = tenant.interactionLog || [];
    if (!log.length) { box.innerHTML = '<div class="empty-state"><div class="desc">No entries yet.</div></div>'; return; }
    const sorted = [...log].sort((a, b) => b.date.localeCompare(a.date));
    box.innerHTML = sorted.map((entry) => `
      <div class="history-item">
        <div class="hi-title">${esc(entry.text)}</div>
        <div class="hi-row">${formatDate(entry.date)}</div>
      </div>`).join('');
  }

  function handleAddTenantLogEntry() {
    const input = document.getElementById('tdNewLogEntry');
    const text = input.value.trim();
    if (!text || !viewingId) return;
    const tenant = tenants.find((t) => t.id === viewingId);
    if (!tenant) return;
    if (!tenant.interactionLog) tenant.interactionLog = [];
    tenant.interactionLog.push({ id: generateId(), text, date: new Date().toISOString().slice(0, 10) });
    tenant.updatedAt = new Date().toISOString();
    persist();
    input.value = '';
    renderTenantInteractionLog(tenant);
  }


  let moveOutPendingLinkedTicketIds = [];
  let moveOutNewWorkMaterialRows = [];
  const MOVEOUT_MATERIAL_CATEGORIES = ['Electrical Material', 'Plumbing Material', 'Carpenter Material', 'Painting Material', 'AC Material', 'RO Material', 'Cleaning Material', 'Other Material'];
  const MOVEOUT_WORK_CATEGORIES = ['Electrical', 'Plumbing', 'AC', 'RO', 'Furniture', 'Painting', 'Internet', 'Cleaning', 'Pest Control', 'Appliance', 'Civil Work', 'Miscellaneous'];

  /** Sums linked tickets' labour + material — same aggregation shape as
   *  Setup Expense, so a work's cost is never re-entered here either. */
  function computeMoveOutWorkAggregate(ticketIds) {
    if (typeof MaintenanceController === 'undefined') return { vendorCost: 0, chargeable: 0, margin: 0, linkedCount: 0 };
    const allTickets = MaintenanceController.getAllTickets();
    const linked = allTickets.filter((t) => ticketIds.includes(t.id) && t.closingDetails);
    let vendorCost = 0, chargeable = 0;
    linked.forEach((t) => { vendorCost += t.closingDetails.totalActual || 0; chargeable += t.closingDetails.totalBilled || 0; });
    return { vendorCost, chargeable, margin: chargeable - vendorCost, linkedCount: linked.length };
  }

  function openMoveOutModal(tenantId) {
    movingOutTenantId = tenantId;
    document.getElementById('moveOutForm').reset();
    clearErrors('moveOutForm');
    moveOutPendingLinkedTicketIds = [];
    const tenant = tenants.find((t) => t.id === tenantId);
    if (tenant && tenant.currentAllocation) {
      document.getElementById('moveOutRefund').value = tenant.currentAllocation.deposit || 0;
      if (typeof FinanceController !== 'undefined' && FinanceController.getTenantPendingBalance) {
        document.getElementById('moveOutPendingRent').value = FinanceController.getTenantPendingBalance(tenantId) || '';
      }
    }
    renderMoveOutLinkedWorksList();
    document.getElementById('moveOutModalOverlay').classList.add('open');
  }

  function closeMoveOutModal() {
    document.getElementById('moveOutModalOverlay').classList.remove('open');
    movingOutTenantId = null;
  }

  /** Renders linked works + auto-recomputes the security refund —
   *  Security − (Pending Rent + Maintenance Deductions). */
  function renderMoveOutLinkedWorksList() {
    const listBox = document.getElementById('moveOutLinkedWorksList');
    const allTickets = typeof MaintenanceController !== 'undefined' ? MaintenanceController.getAllTickets() : [];
    const linked = allTickets.filter((t) => moveOutPendingLinkedTicketIds.includes(t.id));
    listBox.innerHTML = linked.length ? linked.map((t) => `
      <div class="history-item">
        <div class="hi-title">${esc(t.category)} — ${esc(t.ticketId)}
          <button class="btn small secondary moveout-unlink-btn" data-id="${t.id}" style="margin-left:8px; padding:2px 8px;">Remove</button>
        </div>
        <div class="hi-row">Vendor: ${esc(t.closingDetails.vendorName || '—')} · Cost ₹${t.closingDetails.totalActual} · Charged ₹${t.closingDetails.totalBilled}</div>
      </div>`).join('') : '<div class="empty-state"><div class="desc">Koi maintenance deduction linked nahi hai.</div></div>';
    listBox.querySelectorAll('.moveout-unlink-btn').forEach((btn) => btn.addEventListener('click', () => {
      moveOutPendingLinkedTicketIds = moveOutPendingLinkedTicketIds.filter((id) => id !== btn.dataset.id);
      renderMoveOutLinkedWorksList();
    }));

    const agg = computeMoveOutWorkAggregate(moveOutPendingLinkedTicketIds);
    document.getElementById('moveOutWorkSummaryBox').innerHTML = `
      <div class="calc-row"><span>Vendor Cost</span><span>₹${agg.vendorCost}</span></div>
      <div class="calc-row"><span>Chargeable to Tenant</span><span>₹${agg.chargeable}</span></div>
      <div class="calc-row total"><span>Fair Homes Margin</span><span>₹${agg.margin}</span></div>
    `;
    updateMoveOutRefundCalc();
  }

  function updateMoveOutRefundCalc() {
    const tenant = tenants.find((t) => t.id === movingOutTenantId);
    if (!tenant || !tenant.currentAllocation) return;
    const security = tenant.currentAllocation.deposit || 0;
    const pendingRent = Number(document.getElementById('moveOutPendingRent').value) || 0;
    const agg = computeMoveOutWorkAggregate(moveOutPendingLinkedTicketIds);
    const refund = security - pendingRent - agg.chargeable;
    document.getElementById('moveOutRefund').value = refund;
  }

  // ---------------- Add Work from Maintenance (Move-Out picker) ----------------
  function openMoveOutAddWorkModal() {
    switchMoveOutWorkTab('existing');
    renderMoveOutExistingWorksList();
    moveOutNewWorkMaterialRows = [];
    document.getElementById('moveOutNewWorkCategory').innerHTML = MOVEOUT_WORK_CATEGORIES.map((c) => `<option>${c}</option>`).join('');
    document.getElementById('moveOutNewWorkDescription').value = '';
    document.getElementById('moveOutNewWorkVendorCost').value = '';
    document.getElementById('moveOutNewWorkChargeable').value = '';
    document.getElementById('moveOutNewWorkVendorName').value = '';
    populateMoveOutWorkTypeSelect();
    renderMoveOutNewWorkMaterialRows();
    document.querySelectorAll('#moveOutWorkNewPane .form-error').forEach((el) => (el.textContent = ''));
    document.getElementById('moveOutAddWorkModalOverlay').classList.add('open');
  }
  function closeMoveOutAddWorkModal() { document.getElementById('moveOutAddWorkModalOverlay').classList.remove('open'); }

  function switchMoveOutWorkTab(tab) {
    const isExisting = tab === 'existing';
    document.getElementById('moveOutWorkExistingPane').classList.toggle('hidden', !isExisting);
    document.getElementById('moveOutWorkNewPane').classList.toggle('hidden', isExisting);
    document.getElementById('moveOutWorkTabExisting').className = 'btn small' + (isExisting ? '' : ' secondary');
    document.getElementById('moveOutWorkTabNew').className = 'btn small' + (isExisting ? ' secondary' : '');
    document.getElementById('moveOutCreateWorkSaveBtn').classList.toggle('hidden', isExisting);
  }

  function renderMoveOutExistingWorksList() {
    const box = document.getElementById('moveOutExistingWorksList');
    const tenant = tenants.find((t) => t.id === movingOutTenantId);
    if (typeof MaintenanceController === 'undefined' || !tenant || !tenant.currentAllocation) { box.innerHTML = ''; return; }
    const unlinked = MaintenanceController.getUnlinkedClosedTicketsForProperty(tenant.currentAllocation.propertyId)
      .filter((t) => !moveOutPendingLinkedTicketIds.includes(t.id));
    box.innerHTML = unlinked.length ? unlinked.map((t) => `
      <div class="history-item" style="cursor:pointer;" data-id="${t.id}">
        <div class="hi-title">${esc(t.category)} — ${esc(t.ticketId)}</div>
        <div class="hi-row">Vendor: ${esc(t.closingDetails.vendorName || '—')} · Cost ₹${t.closingDetails.totalActual} · Charged ₹${t.closingDetails.totalBilled}</div>
      </div>`).join('') : '<div class="empty-state"><div class="desc">Is property ke liए koi unlinked closed work nahi mila.</div></div>';
    box.querySelectorAll('.history-item').forEach((el) => el.addEventListener('click', () => {
      moveOutPendingLinkedTicketIds.push(el.dataset.id);
      renderMoveOutLinkedWorksList();
      closeMoveOutAddWorkModal();
    }));
  }

  function populateMoveOutWorkTypeSelect() {
    const sel = document.getElementById('moveOutNewWorkTypeSelect');
    if (typeof MaintenanceController === 'undefined') return;
    const works = MaintenanceController.getActiveWorkTypesFlat();
    const grouped = {};
    works.forEach((w) => { if (!grouped[w.categoryName]) grouped[w.categoryName] = []; grouped[w.categoryName].push(w); });
    let html = '<option value="">Not from master — enter manually below</option>';
    Object.keys(grouped).sort().forEach((catName) => {
      html += `<optgroup label="${esc(catName)}">` + grouped[catName].map((w) => `<option value="${w.id}" data-vendor-cost="${w.defaultVendorCost}" data-chargeable="${w.defaultChargeableAmount}">${esc(w.name)}</option>`).join('') + '</optgroup>';
    });
    sel.innerHTML = html;
  }
  function onMoveOutWorkTypeSelected() {
    const sel = document.getElementById('moveOutNewWorkTypeSelect');
    const opt = sel.selectedOptions[0];
    if (opt && opt.dataset.vendorCost !== undefined) {
      document.getElementById('moveOutNewWorkVendorCost').value = opt.dataset.vendorCost;
      document.getElementById('moveOutNewWorkChargeable').value = opt.dataset.chargeable;
    }
  }

  function buildMoveOutMaterialRowHTML(row) {
    return `
      <div class="form-row-2" data-material-row="${row.id}" style="align-items:flex-end;">
        <div class="field-group">
          <label class="field-label">Category</label>
          <select class="moveout-material-category-select" data-id="${row.id}">${MOVEOUT_MATERIAL_CATEGORIES.map((c) => `<option value="${c}" ${row.category === c ? 'selected' : ''}>${c}</option>`).join('')}</select>
        </div>
        <div class="field-group"><label class="field-label">Actual Cost</label><input type="number" class="moveout-material-actual-input" data-id="${row.id}" min="0" value="${row.actualCost || ''}" /></div>
        <div class="field-group">
          <label class="field-label">Charged Amount</label>
          <div style="display:flex; gap:6px;">
            <input type="number" class="moveout-material-charged-input" data-id="${row.id}" min="0" value="${row.chargedAmount || ''}" style="flex:1;" />
            <button type="button" class="btn small secondary moveout-material-remove-btn" data-id="${row.id}" style="padding:4px 8px;">✕</button>
          </div>
        </div>
      </div>`;
  }
  function renderMoveOutNewWorkMaterialRows() {
    const container = document.getElementById('moveOutNewWorkMaterialRows');
    container.innerHTML = moveOutNewWorkMaterialRows.map(buildMoveOutMaterialRowHTML).join('');
    container.querySelectorAll('.moveout-material-category-select').forEach((sel) => sel.addEventListener('change', (e) => {
      const row = moveOutNewWorkMaterialRows.find((r) => r.id === e.target.dataset.id); if (row) row.category = e.target.value;
    }));
    container.querySelectorAll('.moveout-material-actual-input').forEach((inp) => inp.addEventListener('input', (e) => {
      const row = moveOutNewWorkMaterialRows.find((r) => r.id === e.target.dataset.id); if (row) row.actualCost = Number(e.target.value) || 0;
    }));
    container.querySelectorAll('.moveout-material-charged-input').forEach((inp) => inp.addEventListener('input', (e) => {
      const row = moveOutNewWorkMaterialRows.find((r) => r.id === e.target.dataset.id); if (row) row.chargedAmount = Number(e.target.value) || 0;
    }));
    container.querySelectorAll('.moveout-material-remove-btn').forEach((btn) => btn.addEventListener('click', (e) => {
      moveOutNewWorkMaterialRows = moveOutNewWorkMaterialRows.filter((r) => r.id !== e.target.dataset.id);
      renderMoveOutNewWorkMaterialRows();
    }));
  }
  function addMoveOutMaterialRow() {
    moveOutNewWorkMaterialRows.push({ id: generateId(), category: MOVEOUT_MATERIAL_CATEGORIES[0], actualCost: 0, chargedAmount: 0 });
    renderMoveOutNewWorkMaterialRows();
  }

  function handleCreateAndLinkMoveOutWork() {
    const tenant = tenants.find((t) => t.id === movingOutTenantId);
    if (!tenant || !tenant.currentAllocation) return;
    const category = document.getElementById('moveOutNewWorkCategory').value;
    const description = document.getElementById('moveOutNewWorkDescription').value.trim();
    const vendorCost = Number(document.getElementById('moveOutNewWorkVendorCost').value) || 0;
    const chargeable = Number(document.getElementById('moveOutNewWorkChargeable').value) || 0;
    const vendorName = document.getElementById('moveOutNewWorkVendorName').value.trim();

    if (!description) { showErrors({ moveOutNewWorkDescription: 'Description is required' }); return; }
    document.querySelectorAll('#moveOutWorkNewPane .form-error').forEach((el) => (el.textContent = ''));

    const newTicket = MaintenanceController.createSetupWorkTicket({
      propertyId: tenant.currentAllocation.propertyId, category, description, vendorName,
      labourActual: vendorCost, labourBilled: chargeable, materials: moveOutNewWorkMaterialRows, costBearer: 'Tenant',
    });
    moveOutPendingLinkedTicketIds.push(newTicket.id);
    renderMoveOutLinkedWorksList();
    closeMoveOutAddWorkModal();
  }

  // ---------------- Renew Lease (extend agreement, no reallocation needed) ----------------
  function openRenewLeaseModal(tenantId) {
    const tenant = tenants.find((t) => t.id === tenantId);
    if (!tenant || !tenant.currentAllocation) return;
    renewingLeaseTenantId = tenantId;
    document.getElementById('renewLeaseTenantId').value = tenantId;
    document.getElementById('renewLeaseCurrentInfo').textContent = `Current agreement ends ${formatDate(tenant.currentAllocation.agreementEnd)} — Rent ₹${tenant.currentAllocation.rent}/month.`;
    document.getElementById('renewLeaseNewEndDate').value = '';
    document.getElementById('renewLeaseNewRent').value = '';
    clearErrors('renewLeaseForm');
    document.getElementById('renewLeaseModalOverlay').classList.add('open');
  }
  function closeRenewLeaseModal() {
    document.getElementById('renewLeaseModalOverlay').classList.remove('open');
    renewingLeaseTenantId = null;
  }
  function handleSaveRenewLease() {
    const tenant = tenants.find((t) => t.id === renewingLeaseTenantId);
    if (!tenant || !tenant.currentAllocation) return;
    const newEndDate = document.getElementById('renewLeaseNewEndDate').value;
    const newRent = document.getElementById('renewLeaseNewRent').value;

    clearErrors('renewLeaseForm');
    if (!newEndDate) { showErrors({ renewLeaseNewEndDate: 'Select the new end date' }); return; }
    if (new Date(newEndDate) <= new Date(tenant.currentAllocation.agreementEnd)) {
      showErrors({ renewLeaseNewEndDate: 'New end date must be after the current one' });
      return;
    }

    tenant.currentAllocation.agreementEnd = newEndDate;
    if (newRent && Number(newRent) > 0) tenant.currentAllocation.rent = Number(newRent);
    tenant.updatedAt = new Date().toISOString();
    persist();
    closeRenewLeaseModal();
    renderDetail(tenant.id);
    alert('Lease renewed.');
  }

  function handleSaveMoveOut() {
    const tenant = tenants.find((t) => t.id === movingOutTenantId);
    if (!tenant || !tenant.currentAllocation) return;

    const moveOutDate = document.getElementById('moveOutDate').value;
    const reason = document.getElementById('moveOutReason').value.trim();
    const pendingRent = document.getElementById('moveOutPendingRent').value;
    const refund = document.getElementById('moveOutRefund').value;
    const notes = document.getElementById('moveOutNotes').value.trim();
    const agg = computeMoveOutWorkAggregate(moveOutPendingLinkedTicketIds);

    const errors = {};
    if (!moveOutDate) errors.moveOutDate = 'Move out date is required';
    else if (new Date(moveOutDate) < new Date(tenant.currentAllocation.moveInDate)) {
      errors.moveOutDate = 'Move out date cannot be before the move in date';
    }

    clearErrors('moveOutForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const a = tenant.currentAllocation;
    const room = RoomsController.getRoomById(a.roomId);
    const property = PropertiesController.getAll().find((p) => p.id === a.propertyId);
    const moveOutRecordId = generateId();

    tenant.moveOutHistory = tenant.moveOutHistory || [];
    tenant.moveOutHistory.push({
      id: moveOutRecordId,
      propertyId: a.propertyId, roomId: a.roomId,
      propertyName: property ? property.name : '—',
      roomNumber: room ? room.roomNumber : '—',
      moveInDate: a.moveInDate,
      moveOutDate,
      reason,
      pendingRent: Number(pendingRent) || 0,
      maintenanceDeduction: agg.chargeable,
      linkedTicketIds: [...moveOutPendingLinkedTicketIds],
      refundDeposit: Number(refund) || 0,
      notes,
    });

    if (typeof MaintenanceController !== 'undefined' && moveOutPendingLinkedTicketIds.length) {
      MaintenanceController.linkTicketsTo(moveOutPendingLinkedTicketIds, 'moveOut', moveOutRecordId);
    }

    tenant.currentAllocation = null;
    tenant.status = 'Moved Out';
    tenant.updatedAt = new Date().toISOString();
    persist();
    // Room's status is derived live from active tenants, so it's
    // already "Available" the moment status flips above — this just
    // checks whether the WHOLE property emptied out, so the next
    // tenant-type restriction can reset if so.
    RoomsController.syncRoomVacancyTracking(a.roomId);
    RoomsController.checkAndResetTenantTypeIfVacant(a.propertyId);

    closeMoveOutModal();
    populatePropertyFilter();
    renderList();
    renderDetail(tenant.id);

    // Jump straight into settling their security deposit, pre-filled with
    // the refund amount just entered above — instead of leaving the
    // manager to separately remember to go do this in Finance later.
    if (typeof FinanceController !== 'undefined') {
      const heldDeposit = FinanceController.getAllDeposits().find((d) => d.tenantId === tenant.id && (d.status === 'Held' || d.status === 'Partially Refunded'));
      if (heldDeposit) {
        const refundAmt = Number(refund) || 0;
        NavController.goToPage('finance');
        setTimeout(() => {
          document.querySelector('#financeSubnav .fs-tab[data-sub="deposits"]')?.click();
          FinanceController.openRefundModal(heldDeposit.id, refundAmt > 0 ? 'refund' : 'forfeit', refundAmt);
        }, 50);
      }
    }
  }

  // ---------------- Helpers ----------------
  function initials(name) {
    const parts = name.trim().split(/\s+/);
    return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase() || '?';
  }
  function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  /**
   * Computed, reminder-only payment status derived from the Payment Due
   * Date (day of month) captured during allocation. This is NOT real
   * rent-payment tracking (no transactions/ledger exist yet — that's the
   * Finance/Rent Collection module, explicitly out of scope for Phase 5).
   * It simply tells the manager whether this month's due date has passed.
   */
  function paymentStatusText(paymentDueDate) {
    if (!paymentDueDate) return 'Not set';
    const today = new Date();
    const todayDay = today.getDate();
    if (todayDay === paymentDueDate) return '🟠 Due Today';
    if (todayDay < paymentDueDate) return `🟢 Due in ${paymentDueDate - todayDay} day(s)`;
    return `🔴 Overdue by ${todayDay - paymentDueDate} day(s) (this month)`;
  }

  function formatDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (isNaN(d)) return iso;
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  // ---------------- Init / Bindings ----------------
  function bindEvents() {
    document.getElementById('addTenantBtn').addEventListener('click', openAddModal);
    document.getElementById('addExistingTenantBtn').addEventListener('click', openAddExistingTenantModal);
    document.getElementById('isExistingTenant').addEventListener('change', (e) => {
      document.getElementById('existingTenancyFields').classList.toggle('hidden', !e.target.checked);
    });
    document.getElementById('existTenantProperty').addEventListener('change', onExistTenantPropertyChange);
    document.getElementById('tdAddLogBtn').addEventListener('click', handleAddTenantLogEntry);
    document.getElementById('tenantModalCloseBtn').addEventListener('click', closeModal);
    document.getElementById('tenantCancelBtn').addEventListener('click', closeModal);
    document.getElementById('tenantSaveBtn').addEventListener('click', handleSaveTenant);
    document.getElementById('tenantModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'tenantModalOverlay') closeModal(); });

    document.getElementById('tenantSearchInput').addEventListener('input', renderList);
    document.getElementById('tenantStatusFilter').addEventListener('change', renderList);
    document.getElementById('tenantPropertyFilter').addEventListener('change', renderList);
    document.getElementById('tenantBackBtn').addEventListener('click', backToList);

    ['tenantMobile', 'tenantAltMobile', 'tenantEmergencyContact'].forEach((id) => {
      document.getElementById(id).addEventListener('input', (e) => { e.target.value = e.target.value.replace(/\D/g, ''); });
    });
    wireAadhaarFormatting('tenantAadhaar');

    // Allocate modal
    document.getElementById('allocateModalCloseBtn').addEventListener('click', closeAllocateModal);
    document.getElementById('allocCancelBtn').addEventListener('click', closeAllocateModal);
    document.getElementById('allocSaveBtn').addEventListener('click', handleSaveAllocation);
    document.getElementById('allocateModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'allocateModalOverlay') closeAllocateModal(); });
    document.getElementById('allocProperty').addEventListener('change', onAllocPropertyChange);

    // Move out modal
    document.getElementById('moveOutModalCloseBtn').addEventListener('click', closeMoveOutModal);
    document.getElementById('moveOutCancelBtn').addEventListener('click', closeMoveOutModal);
    document.getElementById('moveOutSaveBtn').addEventListener('click', handleSaveMoveOut);
    document.getElementById('moveOutPendingRent').addEventListener('input', updateMoveOutRefundCalc);

    document.getElementById('moveOutAddWorkBtn').addEventListener('click', openMoveOutAddWorkModal);
    document.getElementById('moveOutAddWorkModalCloseBtn').addEventListener('click', closeMoveOutAddWorkModal);
    document.getElementById('moveOutAddWorkCancelBtn').addEventListener('click', closeMoveOutAddWorkModal);
    document.getElementById('moveOutAddWorkModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'moveOutAddWorkModalOverlay') closeMoveOutAddWorkModal(); });
    document.getElementById('moveOutWorkTabExisting').addEventListener('click', () => switchMoveOutWorkTab('existing'));
    document.getElementById('moveOutWorkTabNew').addEventListener('click', () => switchMoveOutWorkTab('new'));
    document.getElementById('moveOutNewWorkTypeSelect').addEventListener('change', onMoveOutWorkTypeSelected);
    document.getElementById('moveOutNewWorkAddMaterialBtn').addEventListener('click', addMoveOutMaterialRow);
    document.getElementById('moveOutCreateWorkSaveBtn').addEventListener('click', handleCreateAndLinkMoveOutWork);
    document.getElementById('renewLeaseModalCloseBtn').addEventListener('click', closeRenewLeaseModal);
    document.getElementById('renewLeaseCancelBtn').addEventListener('click', closeRenewLeaseModal);
    document.getElementById('renewLeaseModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'renewLeaseModalOverlay') closeRenewLeaseModal(); });
    document.getElementById('renewLeaseSaveBtn').addEventListener('click', handleSaveRenewLease);
    document.getElementById('moveOutModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'moveOutModalOverlay') closeMoveOutModal(); });
  }

  function onPageShow() {
    populatePropertyFilter();
    if (viewingId) renderDetail(viewingId);
    else renderList();
  }

  function init() {
    load();
    bindEvents();
    populatePropertyFilter();
    renderList();
  }

  function getAll() { return [...tenants]; }
  function getById(id) { return tenants.find((t) => t.id === id); }

  function reload() { load(); renderList(); }

  function bulkImport(records) {
    const now = new Date().toISOString();
    records.forEach((r) => {
      tenants.unshift({
        id: (crypto.randomUUID ? crypto.randomUUID() : 'ten_' + Date.now() + '_' + Math.random().toString(16).slice(2)),
        tenantCode: nextTenantCode(),
        fullName: r.fullName || '', mobile: r.mobile || '', altMobile: '', email: r.email || '',
        aadhaar: '', fatherName: '', emergencyContact: '', dob: '', gender: '', occupation: '', companyOrCollege: '',
        permanentAddress: '', currentAddress: '', notes: '',
        status: 'Unassigned', currentAllocation: null, moveOutHistory: [], createdAt: now, updatedAt: now,
      });
    });
    persist();
    renderList();
  }

  /** Creates one full Tenant record directly from data, without going
   *  through the Add Tenant modal — used by Booking's multi-tenant
   *  Convert flow, which needs to create several tenants at once from
   *  its own dedicated form. */
  function createTenantDirect(data) {
    const now = new Date().toISOString();
    const newId = generateId();
    const tenant = {
      id: newId, tenantCode: nextTenantCode(), createdAt: now, updatedAt: now,
      status: data.currentAllocation ? 'Active' : 'Unassigned',
      currentAllocation: data.currentAllocation || null,
      moveOutHistory: [], pendingBookingConversion: null,
      tenantSource: data.tenantSource || 'Booked Through Fair Homes',
      fullName: data.fullName, mobile: data.mobile, altMobile: data.altMobile || '',
      email: data.email || '', aadhaar: data.aadhaar || '',
      fatherName: data.fatherName || '', emergencyContact: data.emergencyContact || '',
      dob: data.dob || '', gender: data.gender || '', occupation: data.occupation || '',
      companyOrCollege: data.companyOrCollege || '',
      permanentAddress: data.permanentAddress || '', currentAddress: data.currentAddress || '',
      referralSource: data.referralSource || '', notes: data.notes || '',
    };
    tenants.unshift(tenant);
    persist();
    if (tenant.currentAllocation && typeof RoomsController !== 'undefined') {
      RoomsController.syncRoomVacancyTracking(tenant.currentAllocation.roomId);
    }
    if (typeof SocialMediaController !== 'undefined' && SocialMediaController.createOnboardingChecklist) {
      SocialMediaController.createOnboardingChecklist(newId, tenant.fullName);
    }
    return newId;
  }

  return { init, onPageShow, getAll, getById, reload, bulkImport, openDetail: renderDetail, openAddModal, createTenantDirect };
})();
