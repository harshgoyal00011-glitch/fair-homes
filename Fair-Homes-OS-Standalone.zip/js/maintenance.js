/* ==========================================================================
   Fair Homes OS — Maintenance Management Module (Phase 7)
   Fully integrated with Owners / Properties / Rooms & Beds / Tenants /
   Finance (Expense auto-sync on ticket close).
   ========================================================================== */

const MaintenanceController = (() => {
  const STORAGE_KEY = 'fh_tickets';
  const SEQ_KEY = 'fh_ticket_seq';
  let tickets = [];
  let editingTicketId = null;
  let viewingTicketId = null;
  let assigningTicketId = null;
  let closingTicketId = null;
  let cancellingTicketId = null;

  const CATEGORIES = ['Electrical', 'Plumbing', 'AC', 'RO', 'Furniture', 'Painting', 'Internet', 'Cleaning', 'Pest Control', 'Appliance', 'Civil Work', 'Miscellaneous'];
  const MATERIAL_CATEGORIES = ['Electrical Material', 'Plumbing Material', 'Carpenter Material', 'Painting Material', 'AC Material', 'RO Material', 'Cleaning Material', 'Other Material'];
  const STATUS_FLOW = ['Open', 'Assigned', 'In Progress', 'Completed', 'Closed'];
  const TENANT_APPROVAL_STATUS_FLOW = ['Open', 'Tenant Approval Pending', 'Tenant Approved', 'Assigned', 'In Progress', 'Completed', 'Closed'];
  /** Only tenant-chargeable work with an estimated amount goes through
   *  the approval gate — Owner/Fair Homes tickets keep the original,
   *  simpler flow since the tenant has no payment stake in those. */
  function needsTenantApproval(t) { return t.costBearer === 'Tenant' && Number(t.estimatedAmount) > 0; }
  function getStatusFlow(t) { return needsTenantApproval(t) ? TENANT_APPROVAL_STATUS_FLOW : STATUS_FLOW; }
  const STATUS_CLASS = { Open: 'status-open', Assigned: 'status-assigned', 'In Progress': 'status-inprogress', Completed: 'status-completed', Closed: 'status-closed', Cancelled: 'status-cancelled' };
  const PRIORITY_CLASS = { Low: 'priority-low', Medium: 'priority-medium', High: 'priority-high', Emergency: 'priority-emergency' };

  // Maps a complaint category to the closest Finance expense category, so
  // every closed ticket produces a validly-categorized Expense record.
  const CATEGORY_TO_EXPENSE = {
    Electrical: 'Electrician', Plumbing: 'Plumber', AC: 'Maintenance', RO: 'Maintenance',
    Furniture: 'Furniture', Painting: 'Painting', Internet: 'Maintenance', Cleaning: 'Cleaning',
    'Pest Control': 'Maintenance', Appliance: 'Appliances', 'Civil Work': 'Maintenance', Miscellaneous: 'Miscellaneous',
  };

  // ---------------- Storage ----------------
  const VENDOR_CAT_KEY = 'fh_vendor_categories';
  const VENDOR_BILL_KEY = 'fh_vendor_bills';
  const VISITING_CHARGE_KEY = 'fh_visiting_charge_rule';
  const MAID_KEY = 'fh_maids';
  const MAID_ASSIGN_KEY = 'fh_maid_assignments';
  const MAID_ATTEND_KEY = 'fh_maid_attendance';
  const MAID_PAYMENT_KEY = 'fh_maid_payments';
  let maids = [], maidAssignments = [], maidAttendance = [], maidPayments = [];
  let viewingMaidId = null;
  let editingMaidAssignmentId = null;
  let visitingChargeRule = { targetAmount: 300, maxCharge: 150, vendorShare: 100, marginShare: 50 };
  let vendorBills = [];
  const WORK_TYPE_KEY = 'fh_work_types';
  let vendorCategories = [];
  let workTypes = [];
  let editingVendorCategoryId = null;
  let editingWorkTypeId = null;
  const DEFAULT_VENDOR_CATEGORIES = ['Electrician', 'Plumber', 'Carpenter', 'Painter', 'AC Technician', 'RO Technician', 'Chimney Technician', 'Washing Machine Technician', 'Cleaning', 'Mason', 'Other Service', 'Other Vendor'];

  function load() {
    try { tickets = JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; } catch (e) { tickets = []; }
    CloudSync.watch('tickets', (arr) => {
      tickets = arr;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tickets));
      renderTicketsList();
      renderDashboard();
      if (viewingTicketId) renderTicketDetail(viewingTicketId);
    });

    try { vendorCategories = JSON.parse(localStorage.getItem(VENDOR_CAT_KEY)) || []; } catch (e) { vendorCategories = []; }
    try { workTypes = JSON.parse(localStorage.getItem(WORK_TYPE_KEY)) || []; } catch (e) { workTypes = []; }
    CloudSync.watch('vendorCategories', (arr) => {
      vendorCategories = arr;
      localStorage.setItem(VENDOR_CAT_KEY, JSON.stringify(arr));
      renderVendorCategoryList();
    });
    CloudSync.watch('workTypes', (arr) => {
      workTypes = arr;
      localStorage.setItem(WORK_TYPE_KEY, JSON.stringify(arr));
      renderVendorCategoryList();
    });

    try { vendorBills = JSON.parse(localStorage.getItem(VENDOR_BILL_KEY)) || []; } catch (e) { vendorBills = []; }
    CloudSync.watch('vendorBills', (arr) => {
      vendorBills = arr;
      localStorage.setItem(VENDOR_BILL_KEY, JSON.stringify(arr));
      renderUnbilledVendorList();
      renderVendorBillHistory();
    });

    try {
      const savedRule = JSON.parse(localStorage.getItem(VISITING_CHARGE_KEY));
      if (savedRule) visitingChargeRule = savedRule;
    } catch (e) { /* keep default */ }
    CloudSync.watchDoc(VISITING_CHARGE_KEY, (data) => {
      if (data) {
        visitingChargeRule = data;
        localStorage.setItem(VISITING_CHARGE_KEY, JSON.stringify(data));
        renderVisitingChargeRuleForm();
      }
    });
    try { maids = JSON.parse(localStorage.getItem(MAID_KEY)) || []; } catch (e) { maids = []; }
    CloudSync.watch('maids', (arr) => { maids = arr; localStorage.setItem(MAID_KEY, JSON.stringify(arr)); onMaidServiceDataChange(); });
    try { maidAssignments = JSON.parse(localStorage.getItem(MAID_ASSIGN_KEY)) || []; } catch (e) { maidAssignments = []; }
    CloudSync.watch('maidAssignments', (arr) => { maidAssignments = arr; localStorage.setItem(MAID_ASSIGN_KEY, JSON.stringify(arr)); onMaidServiceDataChange(); });
    try { maidAttendance = JSON.parse(localStorage.getItem(MAID_ATTEND_KEY)) || []; } catch (e) { maidAttendance = []; }
    CloudSync.watch('maidAttendance', (arr) => { maidAttendance = arr; localStorage.setItem(MAID_ATTEND_KEY, JSON.stringify(arr)); onMaidServiceDataChange(); });
    try { maidPayments = JSON.parse(localStorage.getItem(MAID_PAYMENT_KEY)) || []; } catch (e) { maidPayments = []; }
    CloudSync.watch('maidPayments', (arr) => { maidPayments = arr; localStorage.setItem(MAID_PAYMENT_KEY, JSON.stringify(arr)); onMaidServiceDataChange(); });
  }
  function persistVendorBills() {
    localStorage.setItem(VENDOR_BILL_KEY, JSON.stringify(vendorBills));
    CloudSync.sync('vendorBills', vendorBills);
  }
  function persistMaids() { localStorage.setItem(MAID_KEY, JSON.stringify(maids)); CloudSync.sync('maids', maids); }
  function persistMaidAssignments() { localStorage.setItem(MAID_ASSIGN_KEY, JSON.stringify(maidAssignments)); CloudSync.sync('maidAssignments', maidAssignments); }
  function persistMaidAttendance() { localStorage.setItem(MAID_ATTEND_KEY, JSON.stringify(maidAttendance)); CloudSync.sync('maidAttendance', maidAttendance); }
  function persistMaidPayments() { localStorage.setItem(MAID_PAYMENT_KEY, JSON.stringify(maidPayments)); CloudSync.sync('maidPayments', maidPayments); }
  function onMaidServiceDataChange() {
    if (document.getElementById('sub-maintMaidService')?.classList.contains('active')) {
      if (viewingMaidId) renderMaidProfile(viewingMaidId); else { renderMaidTodayAttendance(); renderMaidCardsList(); }
    }
  }
  function persistVisitingChargeRule() {
    localStorage.setItem(VISITING_CHARGE_KEY, JSON.stringify(visitingChargeRule));
    CloudSync.syncDoc(VISITING_CHARGE_KEY, visitingChargeRule);
  }
  function persistVendorCategories() {
    localStorage.setItem(VENDOR_CAT_KEY, JSON.stringify(vendorCategories));
    CloudSync.sync('vendorCategories', vendorCategories);
  }
  function persistWorkTypes() {
    localStorage.setItem(WORK_TYPE_KEY, JSON.stringify(workTypes));
    CloudSync.sync('workTypes', workTypes);
  }
  /** Seeds the standard vendor categories the very first time this
   *  business uses the Work Master — only if nothing's been added yet,
   *  so it never overwrites categories the user has already customized. */
  function seedDefaultVendorCategoriesIfEmpty() {
    if (vendorCategories.length > 0) return;
    const now = new Date().toISOString();
    vendorCategories = DEFAULT_VENDOR_CATEGORIES.map((name) => ({ id: generateId(), name, createdAt: now }));
    persistVendorCategories();
  }
  function persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tickets));
    CloudSync.sync('tickets', tickets);
  }
  function generateId() { return (crypto.randomUUID ? crypto.randomUUID() : 'tk_' + Date.now() + '_' + Math.random().toString(16).slice(2)); }
  function nextTicketCode() {
    let seq = parseInt(localStorage.getItem(SEQ_KEY) || '0', 10) + 1;
    localStorage.setItem(SEQ_KEY, String(seq));
    return 'TKT-' + String(seq).padStart(4, '0');
  }

  // ---------------- Helpers ----------------
  function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function fmtDate(iso) { if (!iso) return '—'; const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }); }
  function fmtDateTime(iso) { if (!iso) return '—'; const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }
  function todayIso() { return new Date().toISOString().slice(0, 10); }
  function nowLocalInput() {
    const d = new Date();
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 16);
  }
  function clearErrors(formId) { document.querySelectorAll('#' + formId + ' .form-error').forEach((el) => (el.textContent = '')); }
  function showErrors(errors) { Object.entries(errors).forEach(([id, msg]) => { const el = document.getElementById('err-' + id); if (el) el.textContent = msg; }); }

  function pushHistory(ticket, status, note) {
    ticket.statusHistory = ticket.statusHistory || [];
    ticket.statusHistory.push({ status, timestamp: new Date().toISOString(), note: note || '' });
  }

  // ---------------- Location / property-room-bed cascades ----------------
  function populatePropertySelects() {
    const properties = PropertiesController.getAll();
    ['ticketProperty', 'ticketPropertyFilter'].forEach((id) => {
      const sel = document.getElementById(id);
      const current = sel.value;
      const placeholder = id === 'ticketPropertyFilter' ? '<option value="all">All Properties</option>' : '<option value="">Select Property</option>';
      sel.innerHTML = placeholder + properties.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
      sel.value = current || (id === 'ticketPropertyFilter' ? 'all' : '');
    });
  }

  function populateCategoryFilter() {
    const sel = document.getElementById('ticketCategoryFilter');
    const current = sel.value;
    sel.innerHTML = '<option value="all">All Categories</option>' + CATEGORIES.map((c) => `<option value="${c}">${c}</option>`).join('');
    sel.value = current || 'all';
  }

  function onTicketPropertyChange() {
    const propertyId = document.getElementById('ticketProperty').value;
    const roomSel = document.getElementById('ticketRoom');
    if (!propertyId) { roomSel.innerHTML = '<option value="">Select Property First</option>'; populateTenantSelectForProperty(''); return; }
    const rooms = RoomsController.getRoomsByProperty(propertyId);
    roomSel.innerHTML = '<option value="">Select Room (optional)</option>' + rooms.map((r) => `<option value="${r.id}">Room ${esc(r.roomNumber)}</option>`).join('');
    populateTenantSelectForProperty(propertyId);
  }

  function populateTenantSelectForProperty(propertyId) {
    const sel = document.getElementById('ticketTenant');
    const current = sel.value;
    const tenants = TenantsController.getAll().filter((t) => t.currentAllocation && (!propertyId || t.currentAllocation.propertyId === propertyId));
    sel.innerHTML = '<option value="">Select Tenant (optional)</option>' + tenants.map((t) => `<option value="${t.id}">${esc(t.fullName)}</option>`).join('');
    sel.value = current;
  }

  // ======================================================================
  // ADD / EDIT TICKET
  // ======================================================================
  function openAddTicketModal() {
    editingTicketId = null;
    document.getElementById('ticketModalTitle').textContent = 'New Maintenance Ticket';
    document.getElementById('ticketForm').reset();
    document.getElementById('ticketRecId').value = '';
    populatePropertySelects();
    document.getElementById('ticketRoom').innerHTML = '<option value="">Select Property First</option>';
    populateTenantSelectForProperty('');
    document.getElementById('ticketDateTime').value = nowLocalInput();
    document.getElementById('ticketCostBearer').value = 'Tenant';
    updateTicketApprovalHint();
    clearErrors('ticketForm');
    document.getElementById('ticketModalOverlay').classList.add('open');
  }

  function updateTicketApprovalHint() {
    const costBearer = document.getElementById('ticketCostBearer').value;
    const amount = Number(document.getElementById('ticketEstimatedAmount').value) || 0;
    document.getElementById('ticketApprovalHint').classList.toggle('hidden', !(costBearer === 'Tenant' && amount > 0));
  }

  function openEditTicketModal(id) {
    const t = tickets.find((x) => x.id === id);
    if (!t) return;
    editingTicketId = id;
    document.getElementById('ticketModalTitle').textContent = 'Edit Ticket';
    populatePropertySelects();
    document.getElementById('ticketRecId').value = t.id;
    document.getElementById('ticketRaisedBy').value = t.raisedBy;
    document.getElementById('ticketProperty').value = t.propertyId;
    onTicketPropertyChange();
    document.getElementById('ticketRoom').value = t.roomId || '';
    document.getElementById('ticketTenant').value = t.tenantId || '';
    document.getElementById('ticketCategory').value = t.category;
    document.getElementById('ticketPriority').value = t.priority;
    document.getElementById('ticketDescription').value = t.description;
    document.getElementById('ticketDateTime').value = t.dateTime;
    document.getElementById('ticketCostBearer').value = t.costBearer || 'Tenant';
    document.getElementById('ticketEstimatedAmount').value = t.estimatedAmount || '';
    updateTicketApprovalHint();
    clearErrors('ticketForm');
    document.getElementById('ticketModalOverlay').classList.add('open');
  }

  function closeTicketFormModal() { document.getElementById('ticketModalOverlay').classList.remove('open'); editingTicketId = null; }

  function handleSaveTicket() {
    const raisedBy = document.getElementById('ticketRaisedBy').value;
    const propertyId = document.getElementById('ticketProperty').value;
    const roomId = document.getElementById('ticketRoom').value || null;
    const tenantId = document.getElementById('ticketTenant').value || null;
    const category = document.getElementById('ticketCategory').value;
    const priority = document.getElementById('ticketPriority').value;
    const description = document.getElementById('ticketDescription').value.trim();
    const dateTime = document.getElementById('ticketDateTime').value;
    const costBearer = document.getElementById('ticketCostBearer').value;
    const estimatedAmount = Number(document.getElementById('ticketEstimatedAmount').value) || 0;

    const errors = {};
    if (!propertyId) errors.ticketProperty = 'Select a property';
    if (!category) errors.ticketCategory = 'Select a complaint category';
    if (!description) errors.ticketDescription = 'Description is required';
    if (!dateTime) errors.ticketDateTime = 'Date & time is required';

    clearErrors('ticketForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const now = new Date().toISOString();
    if (editingTicketId) {
      const idx = tickets.findIndex((t) => t.id === editingTicketId);
      if (idx !== -1) {
        tickets[idx] = { ...tickets[idx], raisedBy, propertyId, roomId, tenantId, category, priority, description, dateTime, costBearer, estimatedAmount, updatedAt: now };
      }
    } else {
      const newTicket = {
        id: generateId(), ticketId: nextTicketCode(), raisedBy, propertyId, roomId, tenantId,
        category, priority, description, images: [], dateTime, costBearer, estimatedAmount, status: 'Open',
        assignment: null, closingDetails: null, approval: null, statusHistory: [],
        createdAt: now, updatedAt: now,
      };
      pushHistory(newTicket, 'Open', 'Ticket created');
      tickets.unshift(newTicket);
    }
    persist();
    closeTicketFormModal();
    populateCategoryFilter();
    renderTicketsList();
    renderDashboard();
    if (viewingTicketId) renderTicketDetail(viewingTicketId);
  }

  function handleDeleteTicket(id) {
    const t = tickets.find((x) => x.id === id);
    if (!t) return;
    ConfirmModal.show('Delete this ticket? You can restore it later from Settings → Trash.', () => {
      TrashController.moveToTrash('ticket', t, t.ticketId);
      tickets = tickets.filter((x) => x.id !== id);
      persist();
      renderTicketsList();
      renderDashboard();
      if (viewingTicketId === id) backToTicketsList();
    });
  }

  // ======================================================================
  // LIST RENDERING
  // ======================================================================
  function renderTicketsList() {
    const query = (document.getElementById('ticketSearchInput')?.value || '').toLowerCase().trim();
    const propFilter = document.getElementById('ticketPropertyFilter')?.value || 'all';
    const priorityFilter = document.getElementById('ticketPriorityFilter')?.value || 'all';
    const statusFilter = document.getElementById('ticketStatusFilter')?.value || 'all';
    const categoryFilter = document.getElementById('ticketCategoryFilter')?.value || 'all';
    const dateFilter = document.getElementById('ticketDateFilter')?.value || '';

    const list = tickets.filter((t) => {
      const tenant = t.tenantId ? TenantsController.getById(t.tenantId) : null;
      const assignment = t.assignment;
      const room = t.roomId ? RoomsController.getRoomById(t.roomId) : null;
      const searchText = [t.ticketId, tenant?.fullName, assignment?.vendorName, assignment?.staffName, room?.roomNumber].filter(Boolean).join(' ').toLowerCase();
      return searchText.includes(query) &&
        (propFilter === 'all' || t.propertyId === propFilter) &&
        (priorityFilter === 'all' || t.priority === priorityFilter) &&
        (statusFilter === 'all' || t.status === statusFilter) &&
        (categoryFilter === 'all' || t.category === categoryFilter) &&
        (!dateFilter || t.dateTime.startsWith(dateFilter));
    });

    const grid = document.getElementById('ticketsGrid');
    if (!list.length) {
      grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;"><div class="ico">🔧</div><div class="title">${tickets.length === 0 ? 'No tickets yet' : 'No matching tickets'}</div><div class="desc">${tickets.length === 0 ? 'Create the first maintenance ticket above.' : 'Try a different search or filter.'}</div></div>`;
      return;
    }

    grid.innerHTML = list.map((t) => {
      const property = PropertiesController.getAll().find((p) => p.id === t.propertyId);
      const room = t.roomId ? RoomsController.getRoomById(t.roomId) : null;
      const tenant = t.tenantId ? TenantsController.getById(t.tenantId) : null;
      const prClass = PRIORITY_CLASS[t.priority] || '';
      return `
        <div class="owner-card ticket-card pr-${t.priority.toLowerCase()}" data-id="${t.id}">
          <div class="oc-top">
            <div class="oc-avatar">🔧</div>
            <div>
              <div class="oc-name">${esc(t.category)}</div>
              <div class="oc-sub">${esc(t.ticketId)}</div>
            </div>
          </div>
          <div class="oc-row">📍 ${esc(property ? property.name : '—')}${room ? ' · Room ' + esc(room.roomNumber) : ''}</div>
          ${tenant ? `<div class="oc-row">🧑 ${esc(tenant.fullName)}</div>` : ''}
          <div class="oc-row">🕒 ${fmtDateTime(t.dateTime)}</div>
          <div style="margin-top:8px; display:flex; gap:6px; flex-wrap:wrap;">
            <span class="badge ${PRIORITY_CLASS[t.priority]}">${t.priority}</span>
            <span class="badge ${STATUS_CLASS[t.status]}">${t.status}</span>
          </div>
          <div class="oc-actions">
            <button class="btn small secondary tk-delete-btn" data-id="${t.id}" style="background:var(--error); color:#fff;">Delete</button>
          </div>
        </div>`;
    }).join('');

    grid.querySelectorAll('.owner-card').forEach((card) => {
      card.addEventListener('click', (e) => { if (e.target.closest('.tk-delete-btn')) return; renderTicketDetail(card.dataset.id); });
    });
    grid.querySelectorAll('.tk-delete-btn').forEach((btn) => btn.addEventListener('click', (e) => { e.stopPropagation(); handleDeleteTicket(btn.dataset.id); }));
  }

  // ======================================================================
  // TICKET DETAIL VIEW
  // ======================================================================
  function renderTicketDetail(id) {
    const t = tickets.find((x) => x.id === id);
    if (!t) return;
    viewingTicketId = id;

    const property = PropertiesController.getAll().find((p) => p.id === t.propertyId);
    const room = t.roomId ? RoomsController.getRoomById(t.roomId) : null;
    const tenant = t.tenantId ? TenantsController.getById(t.tenantId) : null;

    document.getElementById('tkTitle').textContent = t.category + ' — ' + t.ticketId;
    document.getElementById('tkMeta').textContent = fmtDateTime(t.dateTime);
    const prBadge = document.getElementById('tkPriorityBadge'); prBadge.textContent = t.priority; prBadge.className = 'badge ' + PRIORITY_CLASS[t.priority];
    const stBadge = document.getElementById('tkStatusBadge'); stBadge.textContent = t.status; stBadge.className = 'badge ' + STATUS_CLASS[t.status];

    document.getElementById('tkCategory').textContent = t.category;
    document.getElementById('tkRaisedBy').textContent = t.raisedBy;
    document.getElementById('tkDateTime').textContent = fmtDateTime(t.dateTime);
    document.getElementById('tkTenant').textContent = tenant ? tenant.fullName : 'Not specified';
    document.getElementById('tkProperty').textContent = property ? property.name : '—';
    document.getElementById('tkRoomBed').textContent = room ? 'Room ' + room.roomNumber : 'Not specified';
    document.getElementById('tkCostBearer').textContent = t.costBearer || '—';
    document.getElementById('tkEstimatedAmount').textContent = t.estimatedAmount ? '₹' + t.estimatedAmount : '—';
    document.getElementById('tkDescription').textContent = t.description;

    // Status flow visual
    document.getElementById('tkStatusFlow').innerHTML = renderStatusFlow(t);

    // Tenant Approval box — full traceability for tenant-chargeable work
    const approvalSection = document.getElementById('tkApprovalSection');
    if (needsTenantApproval(t) || t.approval) {
      approvalSection.classList.remove('hidden');
      const approvalBox = document.getElementById('tkApprovalBox');
      if (t.approval) {
        approvalBox.innerHTML = `
          <div class="detail-grid">
            <div class="detail-item"><div class="di-label">Status</div><div class="di-value">${esc(t.approval.status)}</div></div>
            <div class="detail-item"><div class="di-label">Approved Amount</div><div class="di-value">₹${t.approval.approvedAmount}</div></div>
            <div class="detail-item"><div class="di-label">Response Date &amp; Time</div><div class="di-value">${fmtDateTime(t.approval.respondedAt)}</div></div>
          </div>`;
      } else {
        approvalBox.innerHTML = '<div class="empty-state"><div class="desc">Tenant approval abhi pending hai.</div></div>';
      }
    } else {
      approvalSection.classList.add('hidden');
    }

    // Assignment box
    const assignBox = document.getElementById('tkAssignmentBox');
    if (t.assignment) {
      const a = t.assignment;
      assignBox.innerHTML = `
        <div class="detail-grid">
          <div class="detail-item"><div class="di-label">Staff Name</div><div class="di-value">${a.staffName || 'Not provided'}</div></div>
          <div class="detail-item"><div class="di-label">Vendor Name</div><div class="di-value">${a.vendorName || 'Not provided'}</div></div>
          <div class="detail-item"><div class="di-label">Contact Number</div><div class="di-value">${a.contactNumber || 'Not provided'}</div></div>
          <div class="detail-item"><div class="di-label">Assigned Date</div><div class="di-value">${fmtDate(a.assignedDate)}</div></div>
          <div class="detail-item"><div class="di-label">Expected Completion</div><div class="di-value">${a.expectedCompletionDate ? fmtDate(a.expectedCompletionDate) : 'Not set'}</div></div>
        </div>`;
    } else {
      assignBox.innerHTML = '<div class="empty-state"><div class="desc">Not yet assigned.</div></div>';
    }

    // Closing box
    const closingBox = document.getElementById('tkClosingBox');
    if (t.closingDetails) {
      const c = t.closingDetails;
      const serviceMargin = c.labourBilled - c.labourActual;
      const materialMargin = c.materialBilled - c.materialActual;
      closingBox.innerHTML = `
        <div class="detail-grid">
          <div class="detail-item"><div class="di-label">Vendor Cost</div><div class="di-value">₹${c.labourActual}</div></div>
          <div class="detail-item"><div class="di-label">Service Charge</div><div class="di-value">₹${c.labourBilled}</div></div>
          <div class="detail-item"><div class="di-label">Service Margin</div><div class="di-value">₹${serviceMargin}</div></div>
          <div class="detail-item"><div class="di-label">Material Margin</div><div class="di-value">₹${materialMargin}</div></div>
          <div class="detail-item"><div class="di-label">Total Cost</div><div class="di-value">₹${c.totalActual}</div></div>
          <div class="detail-item"><div class="di-label">Total Billed</div><div class="di-value">₹${c.totalBilled}</div></div>
          <div class="detail-item"><div class="di-label">Vendor Name</div><div class="di-value">${c.vendorName || 'Not provided'}</div></div>
          <div class="detail-item"><div class="di-label">Invoice Number</div><div class="di-value">${c.invoiceNumber || 'Not provided'}</div></div>
        </div>
        ${c.materials && c.materials.length ? `
          <div class="form-subtitle">Material Breakdown</div>
          ${c.materials.map((m) => `<div class="hi-row">${esc(m.category)}: Cost ₹${m.actualCost} · Charged ₹${m.chargedAmount} · Margin ₹${m.margin}</div>`).join('')}
        ` : ''}
        <div class="form-hint" style="margin-top:8px;">✅ Synced to Finance → Expenses automatically.</div>`;
    } else {
      closingBox.innerHTML = '<div class="empty-state"><div class="desc">Ticket not closed yet.</div></div>';
    }

    // Timeline
    const timelineBox = document.getElementById('tkTimelineBox');
    const history = [...(t.statusHistory || [])].reverse();
    timelineBox.innerHTML = history.length
      ? history.map((h) => `<div class="tt-item"><div class="tt-dot"></div><div><div class="tt-status">${esc(h.status)}</div><div class="tt-meta">${fmtDateTime(h.timestamp)}</div>${h.note ? `<div class="tt-note">${esc(h.note)}</div>` : ''}</div></div>`).join('')
      : '<div class="empty-state"><div class="desc">No history yet.</div></div>';

    // Action buttons
    renderActionButtons(t);

    document.getElementById('tkDeleteBtn').onclick = () => handleDeleteTicket(t.id);

    document.getElementById('ticketsListView').classList.add('hidden');
    document.getElementById('ticketDetailView').classList.remove('hidden');
  }

  function renderStatusFlow(t) {
    const currentStatus = t.status;
    if (currentStatus === 'Cancelled') {
      return `<span class="flow-step" style="background:rgba(220,38,38,0.15); color:var(--error);">Cancelled</span>`;
    }
    const flow = getStatusFlow(t);
    const currentIdx = flow.indexOf(currentStatus);
    return flow.map((s, i) => {
      const cls = i < currentIdx ? 'done' : i === currentIdx ? 'current' : '';
      const arrow = i < flow.length - 1 ? '<span class="flow-arrow">→</span>' : '';
      return `<span class="flow-step ${cls}">${s}</span>${arrow}`;
    }).join('');
  }

  function renderActionButtons(t) {
    const box = document.getElementById('tkActionButtons');
    const buttons = [];

    if (t.status !== 'Closed' && t.status !== 'Cancelled') {
      buttons.push(`<button class="btn small secondary" id="tkEditBtn">Edit Details</button>`);
    }

    if (t.status === 'Open') {
      if (needsTenantApproval(t)) {
        buttons.push(`<button class="btn small" id="tkSendApprovalBtn">Send for Tenant Approval</button>`);
      } else {
        buttons.push(`<button class="btn small" id="tkAssignBtn">Assign Work</button>`);
      }
    }
    if (t.status === 'Tenant Approval Pending') {
      buttons.push(`<button class="btn small" id="tkOpenApprovalBtn">Record Tenant Response</button>`);
      buttons.push(`<button class="btn small secondary" id="tkGoBackBtn" data-prev="Open">← Go Back to Open</button>`);
    }
    if (t.status === 'Tenant Approved') {
      buttons.push(`<button class="btn small" id="tkAssignBtn">Assign Work</button>`);
    }
    if (t.status === 'Assigned') {
      buttons.push(`<button class="btn small" id="tkNextStatusBtn" data-next="In Progress">Mark In Progress</button>`);
      buttons.push(`<button class="btn small secondary" id="tkReassignBtn">Edit Assignment</button>`);
      buttons.push(`<button class="btn small secondary" id="tkGoBackBtn" data-prev="Open">← Go Back to Open</button>`);
    }
    if (t.status === 'In Progress') {
      buttons.push(`<button class="btn small" id="tkNextStatusBtn" data-next="Completed">Mark Completed</button>`);
      buttons.push(`<button class="btn small secondary" id="tkGoBackBtn" data-prev="Assigned">← Go Back to Assigned</button>`);
    }
    if (t.status === 'Completed') {
      if (t.assignment && t.assignment.handledBy === 'TenantSelfService') {
        buttons.push(`<button class="btn small" id="tkVerifySelfServiceBtn">Verify &amp; Close (No Charge)</button>`);
      } else {
        buttons.push(`<button class="btn small" id="tkCloseBtn">Close Ticket</button>`);
      }
      buttons.push(`<button class="btn small secondary" id="tkGoBackBtn" data-prev="In Progress">← Go Back to In Progress</button>`);
    }
    if (t.status !== 'Closed' && t.status !== 'Cancelled') {
      buttons.push(`<button class="btn small" id="tkCancelBtn" style="background:var(--error);">Cancel Ticket</button>`);
    }

    box.innerHTML = buttons.join('');

    document.getElementById('tkEditBtn')?.addEventListener('click', () => openEditTicketModal(t.id));
    document.getElementById('tkAssignBtn')?.addEventListener('click', () => openAssignModal(t.id));
    document.getElementById('tkSendApprovalBtn')?.addEventListener('click', () => handleSendForApproval(t.id));
    document.getElementById('tkOpenApprovalBtn')?.addEventListener('click', () => openApprovalModal(t.id));
    document.getElementById('tkReassignBtn')?.addEventListener('click', () => openAssignModal(t.id));
    document.getElementById('tkNextStatusBtn')?.addEventListener('click', (e) => advanceStatus(t.id, e.target.dataset.next));
    document.getElementById('tkGoBackBtn')?.addEventListener('click', (e) => revertStatus(t.id, e.target.dataset.prev));
    document.getElementById('tkCloseBtn')?.addEventListener('click', () => openCloseModal(t.id));
    document.getElementById('tkVerifySelfServiceBtn')?.addEventListener('click', () => openVerifySelfServiceModal(t.id));
    document.getElementById('tkCancelBtn')?.addEventListener('click', () => openCancelModal(t.id));
  }

  function advanceStatus(ticketId, nextStatus) {
    const t = tickets.find((x) => x.id === ticketId);
    if (!t) return;
    // Enforces sequential progression only — cannot skip a step, satisfying
    // "Cannot close ticket without status update."
    const flow = getStatusFlow(t);
    const currentIdx = flow.indexOf(t.status);
    const nextIdx = flow.indexOf(nextStatus);
    if (nextIdx !== currentIdx + 1) { alert('Status must move forward one step at a time.'); return; }
    t.status = nextStatus;
    t.updatedAt = new Date().toISOString();
    pushHistory(t, nextStatus, '');
    persist();
    renderTicketDetail(ticketId);
    renderTicketsList();
    renderDashboard();
  }

  /**
   * Steps a ticket back exactly one status — only for undoing an
   * accidental forward click (e.g. tapped "Mark Completed" by mistake).
   * Only moves one step at a time, same as advanceStatus, so it can't be
   * used to skip backward past the previous status either.
   */
  function revertStatus(ticketId, prevStatus) {
    const t = tickets.find((x) => x.id === ticketId);
    if (!t) return;
    const flow = getStatusFlow(t);
    const currentIdx = flow.indexOf(t.status);
    const prevIdx = flow.indexOf(prevStatus);
    if (prevIdx !== currentIdx - 1) { alert('Can only go back one step at a time.'); return; }
    ConfirmModal.show(`Move this ticket back to "${prevStatus}"? Use this only if the status was moved forward by mistake.`, () => {
      t.status = prevStatus;
      t.updatedAt = new Date().toISOString();
      pushHistory(t, prevStatus, 'Reverted — moved back one step (corrected an accidental status change)');
      persist();
      renderTicketDetail(ticketId);
      renderTicketsList();
      renderDashboard();
    }, 'Go Back a Step');
  }

  function backToTicketsList() {
    viewingTicketId = null;
    document.getElementById('ticketDetailView').classList.add('hidden');
    document.getElementById('ticketsListView').classList.remove('hidden');
    renderTicketsList();
  }

  // ======================================================================
  // ASSIGN WORK
  // ======================================================================
  // ======================================================================
  // TENANT APPROVAL — for tenant-chargeable work only. Fair Homes never
  // treats such work as assigned/complete without recording the
  // tenant's response first (approved amount, date/time), so there's a
  // clear record against later "we never agreed to that" disputes.
  // ======================================================================
  let approvingTicketId = null;

  function handleSendForApproval(ticketId) {
    const t = tickets.find((x) => x.id === ticketId);
    if (!t) return;
    t.status = 'Tenant Approval Pending';
    t.updatedAt = new Date().toISOString();
    pushHistory(t, 'Tenant Approval Pending', `Approval requested — ₹${t.estimatedAmount} for ${t.category}`);
    persist();
    renderTicketDetail(t.id);
    renderTicketsList();
    renderDashboard();
    openApprovalModal(ticketId);
  }

  function openApprovalModal(ticketId) {
    approvingTicketId = ticketId;
    const t = tickets.find((x) => x.id === ticketId);
    if (!t) return;
    const property = PropertiesController.getAll().find((p) => p.id === t.propertyId);
    const room = t.roomId ? RoomsController.getRoomById(t.roomId) : null;
    const tenant = t.tenantId ? TenantsController.getById(t.tenantId) : null;
    document.getElementById('approvalSummaryBox').innerHTML = `
      <div class="calc-row"><span>Work</span><span>${esc(t.category)}</span></div>
      <div class="calc-row"><span>Property / Room</span><span>${property ? esc(property.name) : '—'}${room ? ' — Room ' + esc(room.roomNumber) : ''}</span></div>
      <div class="calc-row"><span>Tenant</span><span>${tenant ? esc(tenant.fullName) : '—'}</span></div>
      <div class="calc-row total"><span>Chargeable Amount</span><span>₹${t.estimatedAmount}</span></div>
      ${t.approval ? `<div class="calc-row"><span>Current Status</span><span>${esc(t.approval.status)}</span></div>` : ''}
    `;
    document.getElementById('approvalModalOverlay').classList.add('open');
  }
  function closeApprovalModal() { document.getElementById('approvalModalOverlay').classList.remove('open'); approvingTicketId = null; }

  function handleSendApprovalWhatsapp() {
    const t = tickets.find((x) => x.id === approvingTicketId);
    if (!t) return;
    const tenant = t.tenantId ? TenantsController.getById(t.tenantId) : null;
    if (!tenant || !tenant.mobile) { alert('Is ticket ke tenant ka mobile number nahi mila.'); return; }
    const property = PropertiesController.getAll().find((p) => p.id === t.propertyId);
    const room = t.roomId ? RoomsController.getRoomById(t.roomId) : null;
    const message = `Maintenance Work Approval\n\nAapke dwara "${t.category}" ki maintenance request ki gayi hai.\n${property ? property.name : ''}${room ? ' — Room ' + room.roomNumber : ''}\n\nIs work ka total charge ₹${t.estimatedAmount} hai. Yeh amount aapke agle month's rent ke saath payable hoga.\n\nKripya reply karke bataye: Approve / Reject.`;
    shareViaWhatsApp(tenant.mobile, message);
  }

  function handleMarkApproval(approved) {
    const t = tickets.find((x) => x.id === approvingTicketId);
    if (!t) return;
    const now = new Date().toISOString();
    t.approval = {
      status: approved ? 'Approved' : 'Rejected',
      approvedAmount: t.estimatedAmount, respondedAt: now,
    };
    if (approved) {
      t.status = 'Tenant Approved';
      pushHistory(t, 'Tenant Approved', `Tenant approved ₹${t.estimatedAmount}`);
    } else {
      t.status = 'Cancelled';
      pushHistory(t, 'Cancelled', 'Tenant rejected the chargeable work — ticket cancelled.');
    }
    t.updatedAt = now;
    persist();
    closeApprovalModal();
    renderTicketDetail(t.id);
    renderTicketsList();
    renderDashboard();
  }

  function openAssignModal(ticketId) {
    assigningTicketId = ticketId;
    const t = tickets.find((x) => x.id === ticketId);
    document.getElementById('assignForm').reset();
    clearErrors('assignForm');
    if (t.assignment) {
      document.getElementById('assignHandledBy').value = t.assignment.handledBy || 'FairHomes';
      document.getElementById('assignStaffName').value = t.assignment.staffName || '';
      document.getElementById('assignVendorName').value = t.assignment.vendorName || '';
      document.getElementById('assignContactNumber').value = t.assignment.contactNumber || '';
      document.getElementById('assignAssignedDate').value = t.assignment.assignedDate || todayIso();
      document.getElementById('assignExpectedDate').value = t.assignment.expectedCompletionDate || '';
    } else {
      document.getElementById('assignHandledBy').value = 'FairHomes';
      document.getElementById('assignAssignedDate').value = todayIso();
    }
    toggleAssignHandledByFields();
    document.getElementById('assignModalOverlay').classList.add('open');
  }
  function closeAssignModal() { document.getElementById('assignModalOverlay').classList.remove('open'); assigningTicketId = null; }

  function toggleAssignHandledByFields() {
    const isSelfService = document.getElementById('assignHandledBy').value === 'TenantSelfService';
    document.getElementById('assignFairHomesFields').classList.toggle('hidden', isSelfService);
    document.getElementById('assignSelfServiceFields').classList.toggle('hidden', !isSelfService);
  }

  function handleSaveAssignment() {
    const t = tickets.find((x) => x.id === assigningTicketId);
    if (!t) return;

    const handledBy = document.getElementById('assignHandledBy').value;
    const staffName = document.getElementById('assignStaffName').value.trim();
    const vendorName = document.getElementById('assignVendorName').value.trim();
    const contactNumber = document.getElementById('assignContactNumber').value.trim();
    const assignedDate = document.getElementById('assignAssignedDate').value;
    const expectedCompletionDate = document.getElementById('assignExpectedDate').value;

    const errors = {};
    if (handledBy === 'FairHomes' && !staffName && !vendorName) errors.assignBoth = 'Enter a staff name or a vendor name';
    if (contactNumber && !/^[6-9]\d{9}$/.test(contactNumber)) errors.assignContactNumber = 'Enter a valid 10-digit number';
    if (!assignedDate) errors.assignAssignedDate = 'Assigned date is required';

    clearErrors('assignForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    // "Cannot assign same ticket twice simultaneously" — a ticket holds a
    // single assignment object at a time; re-opening this modal always
    // edits that one record rather than creating a duplicate, so
    // simultaneous double-assignment is structurally impossible.
    t.assignment = {
      handledBy, staffName: handledBy === 'FairHomes' ? staffName : '', vendorName: handledBy === 'FairHomes' ? vendorName : '',
      contactNumber, assignedDate, expectedCompletionDate: expectedCompletionDate || null,
    };
    const wasOpen = t.status === 'Open';
    if (wasOpen) t.status = 'Assigned';
    t.updatedAt = new Date().toISOString();
    const assignedToLabel = handledBy === 'TenantSelfService' ? 'Tenant (Self-Service)' : (staffName || vendorName);
    pushHistory(t, wasOpen ? 'Assigned' : t.status, wasOpen ? `Assigned to ${assignedToLabel}` : `Assignment updated (${assignedToLabel})`);
    persist();
    closeAssignModal();
    renderTicketDetail(t.id);
    renderTicketsList();
    renderDashboard();
  }

  // ======================================================================
  // CLOSE TICKET (with Expense sync)
  // ======================================================================
  // ======================================================================
  // TENANT SELF-SERVICE VERIFICATION — no vendor cost, no chargeable
  // amount, no Expense entry. Fair Homes just confirms the required
  // work got done, whether by them or the tenant.
  // ======================================================================
  let verifyingSelfServiceTicketId = null;
  let verifyingSelfServicePhotoData = null;

  function openVerifySelfServiceModal(ticketId) {
    verifyingSelfServiceTicketId = ticketId;
    verifyingSelfServicePhotoData = null;
    document.getElementById('verifySelfServicePhoto').value = '';
    document.getElementById('verifySelfServicePreview').classList.add('hidden');
    document.getElementById('verifySelfServiceNotes').value = '';
    document.getElementById('verifySelfServiceModalOverlay').classList.add('open');
  }
  function closeVerifySelfServiceModal() { document.getElementById('verifySelfServiceModalOverlay').classList.remove('open'); verifyingSelfServiceTicketId = null; }

  function handleSelfServicePhotoSelect(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      verifyingSelfServicePhotoData = reader.result;
      document.getElementById('verifySelfServicePreviewImg').src = reader.result;
      document.getElementById('verifySelfServicePreview').classList.remove('hidden');
    };
    reader.readAsDataURL(file);
  }

  function handleVerifySelfService() {
    const t = tickets.find((x) => x.id === verifyingSelfServiceTicketId);
    if (!t) return;
    const notes = document.getElementById('verifySelfServiceNotes').value.trim();

    if (verifyingSelfServicePhotoData) {
      t.images = t.images || [];
      t.images.push(verifyingSelfServicePhotoData);
    }
    // No costBearer, no vendor/chargeable amount, no Expense entry —
    // this work never cost Fair Homes or the Owner anything, and the
    // tenant handled it themselves.
    t.closingDetails = {
      labourActual: 0, labourBilled: 0, materialActual: 0, materialBilled: 0,
      totalActual: 0, totalBilled: 0, margin: 0, vendorName: '', invoiceNumber: '',
      costBearer: 'Tenant (Self-Service)', expenseId: null, verificationNotes: notes,
    };
    t.status = 'Closed';
    t.updatedAt = new Date().toISOString();
    pushHistory(t, 'Closed', 'Verified as Tenant Self-Service — no charge.' + (notes ? ' ' + notes : ''));
    persist();
    closeVerifySelfServiceModal();
    renderTicketDetail(t.id);
    renderTicketsList();
    renderDashboard();
  }

  let materialRows = []; // [{ id, category, actualCost, chargedAmount }]

  function buildMaterialRowHTML(row) {
    return `
      <div class="form-row-2" data-material-row="${row.id}" style="align-items:flex-end;">
        <div class="field-group">
          <label class="field-label">Category</label>
          <select class="material-category-select" data-id="${row.id}">${MATERIAL_CATEGORIES.map((c) => `<option value="${c}" ${row.category === c ? 'selected' : ''}>${c}</option>`).join('')}</select>
        </div>
        <div class="field-group">
          <label class="field-label">Actual Cost</label>
          <input type="number" class="material-actual-input" data-id="${row.id}" min="0" value="${row.actualCost || ''}" placeholder="₹ 0" />
        </div>
        <div class="field-group">
          <label class="field-label">Charged Amount</label>
          <div style="display:flex; gap:6px; align-items:center;">
            <input type="number" class="material-charged-input" data-id="${row.id}" min="0" value="${row.chargedAmount || ''}" placeholder="₹ 0" style="flex:1;" />
            <button type="button" class="btn small secondary material-remove-btn" data-id="${row.id}" style="padding:4px 8px;">✕</button>
          </div>
        </div>
      </div>`;
  }

  function renderMaterialRows() {
    const container = document.getElementById('closeMaterialRowsContainer');
    container.innerHTML = materialRows.map(buildMaterialRowHTML).join('');
    container.querySelectorAll('.material-category-select').forEach((sel) => sel.addEventListener('change', (e) => {
      const row = materialRows.find((r) => r.id === e.target.dataset.id);
      if (row) row.category = e.target.value;
    }));
    container.querySelectorAll('.material-actual-input').forEach((inp) => inp.addEventListener('input', (e) => {
      const row = materialRows.find((r) => r.id === e.target.dataset.id);
      if (row) row.actualCost = Number(e.target.value) || 0;
      updateCloseTotalBox();
    }));
    container.querySelectorAll('.material-charged-input').forEach((inp) => inp.addEventListener('input', (e) => {
      const row = materialRows.find((r) => r.id === e.target.dataset.id);
      if (row) row.chargedAmount = Number(e.target.value) || 0;
      updateCloseTotalBox();
    }));
    container.querySelectorAll('.material-remove-btn').forEach((btn) => btn.addEventListener('click', (e) => {
      materialRows = materialRows.filter((r) => r.id !== e.target.dataset.id);
      renderMaterialRows();
      updateCloseTotalBox();
    }));
  }

  function addMaterialRow() {
    materialRows.push({ id: generateId(), category: MATERIAL_CATEGORIES[0], actualCost: 0, chargedAmount: 0 });
    renderMaterialRows();
    updateCloseTotalBox();
  }

  function openCloseModal(ticketId) {
    closingTicketId = ticketId;
    document.getElementById('closeForm').reset();
    materialRows = [];
    renderMaterialRows();
    document.getElementById('closeWorkQuantityGroup').classList.add('hidden');
    populateWorkTypeSelectInTicketForm();
    updateCloseTotalBox();
    document.getElementById('closeModalOverlay').classList.add('open');
  }
  function closeCloseModal() { document.getElementById('closeModalOverlay').classList.remove('open'); closingTicketId = null; }

  function updateCloseTotalBox() {
    const labourActual = Number(document.getElementById('closeLabourActual').value) || 0;
    const labourBilled = Number(document.getElementById('closeLabourBilled').value) || 0;
    const materialActual = materialRows.reduce((s, r) => s + (r.actualCost || 0), 0);
    const materialBilled = materialRows.reduce((s, r) => s + (r.chargedAmount || 0), 0);
    const serviceMargin = labourBilled - labourActual;
    const materialMargin = materialBilled - materialActual;
    const totalActual = labourActual + materialActual;
    const totalBilled = labourBilled + materialBilled;
    const margin = totalBilled - totalActual;
    document.getElementById('closeTotalBox').innerHTML = `
      <div class="calc-row"><span>Service Margin (Vendor)</span><span>₹${serviceMargin}</span></div>
      <div class="calc-row"><span>Material Margin (${materialRows.length} categor${materialRows.length === 1 ? 'y' : 'ies'})</span><span>₹${materialMargin}</span></div>
      <div class="calc-row"><span>Total Actual Cost</span><span>₹${totalActual}</span></div>
      <div class="calc-row"><span>Total Billed (Owner/Tenant)</span><span>₹${totalBilled}</span></div>
      <div class="calc-row total"><span>Total Fair Homes Maintenance Margin</span><span>₹${margin}</span></div>
    `;
  }

  function handleSaveClose() {
    const t = tickets.find((x) => x.id === closingTicketId);
    if (!t) return;

    const labourActual = Number(document.getElementById('closeLabourActual').value) || 0;
    const labourBilled = Number(document.getElementById('closeLabourBilled').value) || 0;
    const materials = materialRows.filter((r) => r.actualCost > 0 || r.chargedAmount > 0)
      .map((r) => ({ category: r.category, actualCost: r.actualCost, chargedAmount: r.chargedAmount, margin: r.chargedAmount - r.actualCost }));
    const materialActual = materials.reduce((s, r) => s + r.actualCost, 0);
    const materialBilled = materials.reduce((s, r) => s + r.chargedAmount, 0);
    const vendorName = document.getElementById('closeVendorName').value.trim();
    const invoiceNumber = document.getElementById('closeInvoiceNumber').value.trim();
    const costBearer = document.getElementById('closeCostBearer').value;
    const totalActual = labourActual + materialActual;
    const totalBilled = labourBilled + materialBilled;
    const margin = totalBilled - totalActual;

    // Sync to Finance -> Expenses using the BILLED amount — that's what's
    // actually charged to the Owner/Tenant. Fair Homes itself never
    // absorbs the actual cost; costBearer records who it's recovered from.
    const expenseCategory = CATEGORY_TO_EXPENSE[t.category] || 'Maintenance';
    const expenseId = FinanceController.createExpenseFromMaintenance({
      propertyId: t.propertyId, category: expenseCategory, amount: totalBilled, date: todayIso(),
      vendor: vendorName, invoiceNumber, notes: `Auto-logged from Maintenance Ticket ${t.ticketId}`,
      costBearer, sourceLabel: t.category,
    });

    // The gap between what Owner/Tenant were billed and what the vendor
    // actually cost is Fair Homes' own margin/profit on this job —
    // service margin and material margin combined, matching "Total
    // Fair Homes Maintenance Margin" kept as one figure, while the
    // category breakdown stays available in materials[] for detail.
    if (margin > 0) {
      FinanceController.recordMarginIncome({
        source: 'maintenance', propertyId: t.propertyId, amount: margin,
        label: t.category + ' — ' + t.ticketId, date: todayIso(),
      });
    }

    t.closingDetails = { labourActual, labourBilled, materialActual, materialBilled, materials, totalActual, totalBilled, margin, vendorName, invoiceNumber, expenseId, costBearer };
    t.status = 'Closed';
    t.updatedAt = new Date().toISOString();
    pushHistory(t, 'Closed', `Billed ₹${totalBilled} logged to Finance — Fair Homes margin ₹${margin}`);
    persist();
    closeCloseModal();
    renderTicketDetail(t.id);
    renderTicketsList();
    renderDashboard();
  }

  // ======================================================================
  // CANCEL TICKET
  // ======================================================================
  function openCancelModal(ticketId) {
    cancellingTicketId = ticketId;
    document.getElementById('cancelTicketForm').reset();
    document.getElementById('cancelTicketModalOverlay').classList.add('open');
  }
  function closeCancelModal() { document.getElementById('cancelTicketModalOverlay').classList.remove('open'); cancellingTicketId = null; }

  function handleConfirmCancel() {
    const t = tickets.find((x) => x.id === cancellingTicketId);
    if (!t) return;
    const reason = document.getElementById('cancelReason').value.trim();
    t.status = 'Cancelled';
    t.updatedAt = new Date().toISOString();
    pushHistory(t, 'Cancelled', reason);
    persist();
    closeCancelModal();
    renderTicketDetail(t.id);
    renderTicketsList();
    renderDashboard();
  }

  // ======================================================================
  // DASHBOARD & ANALYTICS
  // ======================================================================
  function avgResolutionDays() {
    const closedTickets = tickets.filter((t) => t.status === 'Closed' && t.statusHistory?.length);
    if (!closedTickets.length) return 0;
    const totalDays = closedTickets.reduce((sum, t) => {
      const opened = new Date(t.createdAt);
      const closedEntry = [...t.statusHistory].reverse().find((h) => h.status === 'Closed');
      const closed = closedEntry ? new Date(closedEntry.timestamp) : new Date(t.updatedAt);
      return sum + Math.max(0, (closed - opened) / (1000 * 60 * 60 * 24));
    }, 0);
    return Math.round((totalDays / closedTickets.length) * 10) / 10;
  }

  function renderDashboard() {
    const today = todayIso();
    const open = tickets.filter((t) => t.status === 'Open').length;
    const inProgress = tickets.filter((t) => t.status === 'In Progress').length;
    const completed = tickets.filter((t) => t.status === 'Completed').length;
    const cancelled = tickets.filter((t) => t.status === 'Cancelled').length;
    const emergency = tickets.filter((t) => t.priority === 'Emergency' && t.status !== 'Closed' && t.status !== 'Cancelled').length;
    const todaysComplaints = tickets.filter((t) => t.dateTime.startsWith(today)).length;
    const thisMonth = today.slice(0, 7);
    const monthlyCost = tickets.filter((t) => t.closingDetails && t.updatedAt.startsWith(thisMonth)).reduce((s, t) => s + t.closingDetails.totalBilled, 0);

    document.getElementById('maintStatGrid').innerHTML = `
      <div class="stat-card"><div class="label">Open Complaints</div><div class="value">${open}</div></div>
      <div class="stat-card"><div class="label">In Progress</div><div class="value warning">${inProgress}</div></div>
      <div class="stat-card"><div class="label">Completed</div><div class="value success">${completed}</div></div>
      <div class="stat-card"><div class="label">Cancelled</div><div class="value error">${cancelled}</div></div>
      <div class="stat-card"><div class="label">Emergency Tickets</div><div class="value error">${emergency}</div></div>
      <div class="stat-card"><div class="label">Today's Complaints</div><div class="value">${todaysComplaints}</div></div>
      <div class="stat-card"><div class="label">Monthly Maintenance Cost</div><div class="value error">₹${monthlyCost}</div></div>
      <div class="stat-card"><div class="label">Avg. Resolution Time</div><div class="value">${avgResolutionDays()} days</div></div>
    `;
  }

  function renderAnalytics() {
    const catCounts = {};
    const propCosts = {};
    const catCosts = {};
    tickets.forEach((t) => {
      catCounts[t.category] = (catCounts[t.category] || 0) + 1;
      if (t.closingDetails) {
        propCosts[t.propertyId] = (propCosts[t.propertyId] || 0) + t.closingDetails.totalBilled;
        catCosts[t.category] = (catCosts[t.category] || 0) + t.closingDetails.totalBilled;
      }
    });

    const mostCommonCat = Object.entries(catCounts).sort((a, b) => b[1] - a[1])[0];
    const mostExpensivePropEntry = Object.entries(propCosts).sort((a, b) => b[1] - a[1])[0];
    const mostExpensiveCatEntry = Object.entries(catCosts).sort((a, b) => b[1] - a[1])[0];
    const mostExpensiveProp = mostExpensivePropEntry ? PropertiesController.getAll().find((p) => p.id === mostExpensivePropEntry[0]) : null;
    const pendingCount = tickets.filter((t) => ['Open', 'Assigned', 'In Progress'].includes(t.status)).length;
    const thisMonth = todayIso().slice(0, 7);
    const monthlyExpense = tickets.filter((t) => t.closingDetails && t.updatedAt.startsWith(thisMonth)).reduce((s, t) => s + t.closingDetails.totalBilled, 0);

    document.getElementById('maintAnalyticsGrid').innerHTML = `
      <div class="analytics-card"><div class="an-label">Most Common Complaint</div><div class="an-value">${mostCommonCat ? esc(mostCommonCat[0]) : '—'}</div><div class="an-sub">${mostCommonCat ? mostCommonCat[1] + ' tickets' : 'No data yet'}</div></div>
      <div class="analytics-card"><div class="an-label">Most Expensive Property</div><div class="an-value">${mostExpensiveProp ? esc(mostExpensiveProp.name) : '—'}</div><div class="an-sub">${mostExpensivePropEntry ? '₹' + mostExpensivePropEntry[1] + ' spent' : 'No closed tickets yet'}</div></div>
      <div class="analytics-card"><div class="an-label">Most Expensive Category</div><div class="an-value">${mostExpensiveCatEntry ? esc(mostExpensiveCatEntry[0]) : '—'}</div><div class="an-sub">${mostExpensiveCatEntry ? '₹' + mostExpensiveCatEntry[1] + ' spent' : 'No closed tickets yet'}</div></div>
      <div class="analytics-card"><div class="an-label">Pending Complaints</div><div class="an-value">${pendingCount}</div></div>
      <div class="analytics-card"><div class="an-label">Average Resolution Time</div><div class="an-value">${avgResolutionDays()} days</div></div>
      <div class="analytics-card"><div class="an-label">Monthly Maintenance Expense</div><div class="an-value">₹${monthlyExpense}</div></div>
    `;
  }

  // ======================================================================
  // Public getters (used for Property / Room / Tenant history integration)
  // ======================================================================
  function getTicketsByProperty(propertyId) { return tickets.filter((t) => t.propertyId === propertyId); }
  function getTicketsByTenant(tenantId) { return tickets.filter((t) => t.tenantId === tenantId); }
  function getTicketsByRoom(roomId) { return tickets.filter((t) => t.roomId === roomId); }

  // ======================================================================
  // ROUTINE MAINTENANCE CHECKLIST — Fair Homes' own fixed monthly tasks
  // per property (not tenant complaints). Auto-generated each month,
  // idempotent — never duplicates a task already created for that
  // property + category + month.
  // ======================================================================
  const ROUTINE_KEY = 'fh_routine_tasks';
  const ROUTINE_CATEGORIES = ['RO Candle Change', 'AC Filter Cleaning', 'Inverter Water Level Check', 'Chimney Filter Cleaning', 'Chimney Cleaning', 'Maid Services'];
  let routineTasks = [];
  let markingDoneTaskId = null;
  let vendorPayTaskId = null;

  function loadRoutine() {
    try { routineTasks = JSON.parse(localStorage.getItem(ROUTINE_KEY)) || []; } catch (e) { routineTasks = []; }
    CloudSync.watch('routineTasks', (arr) => {
      routineTasks = arr;
      localStorage.setItem(ROUTINE_KEY, JSON.stringify(routineTasks));
      renderRoutineChecklist();
    });
  }
  function persistRoutine() {
    localStorage.setItem(ROUTINE_KEY, JSON.stringify(routineTasks));
    CloudSync.sync('routineTasks', routineTasks);
  }
  function currentMonthStr() { return new Date().toISOString().slice(0, 7); }

  const CATEGORY_TO_SERVICE_KEY = {
    'RO Candle Change': 'roCandle', 'AC Filter Cleaning': 'acFilter', 'Inverter Water Level Check': 'inverter',
    'Maid Services': 'maid', 'Chimney Filter Cleaning': 'chimney', 'Chimney Cleaning': 'chimney',
  };

  function generateThisMonthRoutineTasks() {
    if (typeof PropertiesController === 'undefined') return;
    const thisMonth = currentMonthStr();
    const now = new Date().toISOString();
    PropertiesController.getAll().forEach((p) => {
      // Properties saved before this opt-in existed have no
      // routineServices field at all — treat that as "everything
      // applicable" so existing setups don't silently lose their
      // routine tasks after this update.
      const rs = p.routineServices || { roCandle: true, acFilter: true, inverter: true, maid: true, chimney: true };
      ROUTINE_CATEGORIES.forEach((cat) => {
        const serviceKey = CATEGORY_TO_SERVICE_KEY[cat];
        if (serviceKey && rs[serviceKey] === false) return; // opted out for this property
        const exists = routineTasks.some((t) => t.propertyId === p.id && t.category === cat && t.month === thisMonth);
        if (!exists) {
          routineTasks.push({
            id: generateId(), propertyId: p.id, category: cat, month: thisMonth,
            status: 'Pending', completedDate: null,
            actualCost: 0, billedCost: 0, margin: 0, notes: '',
            costBearer: 'Tenant', expenseId: null,
            // Vendor payment and Tenant collection are tracked completely
            // independently of each other and of task completion — a
            // vendor can be paid in advance (before the task is even
            // marked Done), and the tenant's bill can be settled before
            // or after that, in any order.
            vendorPaid: false, vendorPaidAmount: 0, vendorPaymentDate: null,
            tenantCollected: false,
            createdAt: now,
          });
        }
      });
    });
    persistRoutine();
  }

  function populateRoutineFilters() {
    const propSel = document.getElementById('routinePropertyFilter');
    const currentP = propSel.value;
    propSel.innerHTML = '<option value="all">All Properties</option>' + PropertiesController.getAll().map((p) => `<option value="${p.id}">${esc(p.society || p.name)}</option>`).join('');
    propSel.value = currentP || 'all';

    const months = [...new Set(routineTasks.map((t) => t.month))].sort().reverse();
    const monthSel = document.getElementById('routineMonthFilter');
    const currentM = monthSel.value;
    monthSel.innerHTML = months.map((m) => `<option value="${m}">${fmtMonthLabel(m)}</option>`).join('');
    monthSel.value = months.includes(currentM) ? currentM : currentMonthStr();
  }

  function fmtMonthLabel(ym) {
    const [y, m] = ym.split('-');
    return new Date(Number(y), Number(m) - 1, 1).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
  }

  function renderRoutineChecklist() {
    const propFilter = document.getElementById('routinePropertyFilter').value;
    const monthFilter = document.getElementById('routineMonthFilter').value || currentMonthStr();
    const properties = PropertiesController.getAll().filter((p) => propFilter === 'all' || p.id === propFilter);

    const box = document.getElementById('routineChecklistBox');
    if (!properties.length) { box.innerHTML = '<div class="empty-state"><div class="desc">No properties yet.</div></div>'; return; }

    box.innerHTML = properties.map((p) => {
      const tasksForProperty = routineTasks.filter((t) => t.propertyId === p.id && t.month === monthFilter);
      const rows = ROUTINE_CATEGORIES.map((cat) => {
        const task = tasksForProperty.find((t) => t.category === cat);
        if (!task) return '';
        const done = task.status === 'Done';
        const vendorBadge = task.vendorPaid
          ? `<span class="badge pay-paid">Vendor Paid ₹${task.vendorPaidAmount}</span>`
          : `<span class="badge pay-pending">Vendor Not Paid</span>`;
        const tenantBadge = task.billedCost > 0
          ? (task.tenantCollected ? `<span class="badge pay-paid">Tenant Collected</span>` : `<span class="badge pay-overdue">Tenant Pending ₹${task.billedCost}</span>`)
          : '';
        return `
          <div class="danger-row" style="border-bottom:1px solid var(--border); flex-wrap:wrap; align-items:flex-start;">
            <div>
              <div class="dr-label">${done ? '✅' : '⬜'} ${esc(cat)}</div>
              <div class="dr-desc">${done ? 'Done ' + fmtDate(task.completedDate) + (task.billedCost ? ' · Billed ₹' + task.billedCost + (task.margin ? ' (Margin ₹' + task.margin + ')' : '') : '') : 'Pending this month'}</div>
              <div style="margin-top:6px; display:flex; gap:6px; flex-wrap:wrap;">${vendorBadge}${tenantBadge}</div>
            </div>
            <div style="display:flex; flex-direction:column; gap:6px; align-items:flex-end;">
              ${!done ? `<button class="btn small routine-done-btn" data-id="${task.id}">Mark Done</button>` : `<button class="btn small secondary routine-undo-btn" data-id="${task.id}">Undo</button>`}
              ${!task.vendorPaid ? `<button class="btn small secondary routine-vendorpay-btn" data-id="${task.id}">Mark Vendor Paid</button>` : ''}
            </div>
          </div>`;
      }).join('');
      return `
        <div class="settings-card">
          <h3 style="margin-bottom:2px;">${esc(p.society || p.name)}</h3>
          <div class="sc-desc">${fmtMonthLabel(monthFilter)}</div>
          ${rows}
        </div>`;
    }).join('');

    box.querySelectorAll('.routine-done-btn').forEach((b) => b.addEventListener('click', () => openRoutineDoneModal(b.dataset.id)));
    box.querySelectorAll('.routine-undo-btn').forEach((b) => b.addEventListener('click', () => undoRoutineTask(b.dataset.id)));
    box.querySelectorAll('.routine-vendorpay-btn').forEach((b) => b.addEventListener('click', () => openVendorPayModal(b.dataset.id)));
  }

  // ---------------- Mark Done (Actual/Billed + Margin) ----------------
  function openRoutineDoneModal(taskId) {
    markingDoneTaskId = taskId;
    const task = routineTasks.find((t) => t.id === taskId);
    document.getElementById('routineTaskId').value = taskId;
    document.getElementById('routineCompletedDate').value = todayIso();
    document.getElementById('routineActualCost').value = '';
    document.getElementById('routineBilledCost').value = '';
    document.getElementById('routineVendorName').value = '';
    document.getElementById('routineQuantity').value = 1;
    document.getElementById('routineQuantityGroup').classList.add('hidden');
    document.getElementById('routineNotes').value = '';
    populateRoutineWorkTypeSelect(task ? task.category : '');
    updateRoutineDoneCalcBox();
    document.getElementById('routineDoneModalOverlay').classList.add('open');
  }
  function closeRoutineDoneModal() { document.getElementById('routineDoneModalOverlay').classList.remove('open'); markingDoneTaskId = null; }

  /** Populates the Work Master dropdown for Mark Done, and auto-selects
   *  whichever Work Type's name matches this routine task's category —
   *  e.g. a "AC Filter Cleaning" work type auto-fills the AC Filter
   *  Cleaning task's rate/vendor, no manual re-entry needed. Still
   *  fully editable/overridable, and falls back to blank manual entry
   *  when no matching work type exists yet. */
  function populateRoutineWorkTypeSelect(matchCategory) {
    const sel = document.getElementById('routineWorkTypeSelect');
    const works = getActiveWorkTypesFlat();
    const grouped = {};
    works.forEach((w) => { if (!grouped[w.categoryName]) grouped[w.categoryName] = []; grouped[w.categoryName].push(w); });
    let html = '<option value="">Not from master — enter manually below</option>';
    Object.keys(grouped).sort().forEach((catName) => {
      html += `<optgroup label="${esc(catName)}">` + grouped[catName].map((w) => `<option value="${w.id}" data-vendor-cost="${w.defaultVendorCost}" data-chargeable="${w.defaultChargeableAmount}" data-vendor-name="${esc(w.defaultVendorName || '')}">${esc(w.name)}</option>`).join('') + '</optgroup>';
    });
    sel.innerHTML = html;
    const autoMatch = works.find((w) => w.name.trim().toLowerCase() === (matchCategory || '').trim().toLowerCase());
    if (autoMatch) {
      sel.value = autoMatch.id;
      onRoutineWorkTypeSelected();
    }
  }

  function onRoutineWorkTypeSelected() {
    const sel = document.getElementById('routineWorkTypeSelect');
    const opt = sel.selectedOptions[0];
    const qtyGroup = document.getElementById('routineQuantityGroup');
    if (opt && opt.dataset.vendorCost !== undefined) {
      qtyGroup.classList.remove('hidden');
      document.getElementById('routineVendorName').value = opt.dataset.vendorName || '';
      applyRoutineWorkTypeRateWithQuantity();
    } else {
      qtyGroup.classList.add('hidden');
    }
  }

  function applyRoutineWorkTypeRateWithQuantity() {
    const sel = document.getElementById('routineWorkTypeSelect');
    const opt = sel.selectedOptions[0];
    if (!opt || opt.dataset.vendorCost === undefined) return;
    const quantity = Math.max(1, Number(document.getElementById('routineQuantity').value) || 1);
    let actual = Number(opt.dataset.vendorCost) * quantity;
    let billed = Number(opt.dataset.chargeable) * quantity;
    const visitingCharge = getApplicableVisitingCharge(billed);
    if (visitingCharge > 0) {
      const ruleTotalShare = visitingChargeRule.vendorShare + visitingChargeRule.marginShare;
      const vendorPortion = ruleTotalShare > 0 ? Math.round(visitingCharge * (visitingChargeRule.vendorShare / ruleTotalShare)) : visitingCharge;
      actual += vendorPortion;
      billed += visitingCharge;
    }
    document.getElementById('routineActualCost').value = actual;
    document.getElementById('routineBilledCost').value = billed;
    updateRoutineDoneCalcBox();
  }

  function updateRoutineDoneCalcBox() {
    const actual = Number(document.getElementById('routineActualCost').value) || 0;
    const billed = Number(document.getElementById('routineBilledCost').value) || 0;
    document.getElementById('routineDoneCalcBox').innerHTML = `
      <div class="calc-row"><span>Actual Cost</span><span>₹${actual}</span></div>
      <div class="calc-row"><span>Billed to Tenant</span><span>₹${billed}</span></div>
      <div class="calc-row total"><span>Fair Homes Margin</span><span>₹${billed - actual}</span></div>
    `;
  }

  function handleSaveRoutineDone() {
    const task = routineTasks.find((t) => t.id === markingDoneTaskId);
    if (!task) return;
    task.status = 'Done';
    task.completedDate = document.getElementById('routineCompletedDate').value || todayIso();
    task.actualCost = Number(document.getElementById('routineActualCost').value) || 0;
    task.billedCost = Number(document.getElementById('routineBilledCost').value) || 0;
    task.vendorName = document.getElementById('routineVendorName').value.trim();
    task.margin = task.billedCost - task.actualCost;
    task.notes = document.getElementById('routineNotes').value.trim();

    // Sync the BILLED amount to Finance -> Expenses, same pattern as
    // Maintenance Tickets — so routine work counts in overall business
    // expense tracking, and the margin is recorded as Fair Homes income.
    if (task.billedCost > 0 && !task.expenseId) {
      task.expenseId = FinanceController.createExpenseFromMaintenance({
        propertyId: task.propertyId, category: 'Maintenance', amount: task.billedCost, date: task.completedDate,
        notes: `Routine Checklist — ${task.category}`, costBearer: task.costBearer, sourceLabel: task.category,
      });
    }
    if (task.margin > 0) {
      FinanceController.recordMarginIncome({ source: 'routine', propertyId: task.propertyId, amount: task.margin, label: task.category + ' (Routine)', date: task.completedDate });
    }

    persistRoutine();
    closeRoutineDoneModal();
    renderRoutineChecklist();
  }

  function undoRoutineTask(taskId) {
    const task = routineTasks.find((t) => t.id === taskId);
    if (!task) return;
    ConfirmModal.show('Undo this task? Cost and billing details will be cleared.', () => {
      if (task.expenseId) {
        FinanceController.removeExpenseSilently(task.expenseId);
        task.expenseId = null;
      }
      task.status = 'Pending';
      task.completedDate = null;
      task.actualCost = 0;
      task.billedCost = 0;
      task.margin = 0;
      task.tenantCollected = false;
      persistRoutine();
      renderRoutineChecklist();
    });
  }

  // ---------------- Vendor Payment (independent of task status) ----------------
  function openVendorPayModal(taskId) {
    vendorPayTaskId = taskId;
    document.getElementById('vendorPayTaskId').value = taskId;
    document.getElementById('vendorPayAmount').value = '';
    document.getElementById('vendorPayDate').value = todayIso();
    clearErrors('vendorPayForm');
    document.getElementById('vendorPayModalOverlay').classList.add('open');
  }
  function closeVendorPayModal() { document.getElementById('vendorPayModalOverlay').classList.remove('open'); vendorPayTaskId = null; }

  function handleSaveVendorPay() {
    const task = routineTasks.find((t) => t.id === vendorPayTaskId);
    if (!task) return;
    const amount = document.getElementById('vendorPayAmount').value;
    const date = document.getElementById('vendorPayDate').value;
    clearErrors('vendorPayForm');
    if (!amount || Number(amount) <= 0) { showErrors({ vendorPayAmount: 'Enter a valid amount' }); return; }
    task.vendorPaid = true;
    task.vendorPaidAmount = Number(amount);
    task.vendorPaymentDate = date || todayIso();
    persistRoutine();
    closeVendorPayModal();
    renderRoutineChecklist();
  }

  /** Used by Reports to build the "Fair Homes Saved You" section — Done
   *  routine tasks for a property in a given month, tenant-borne by
   *  default (cost never disclosed as tenant-paid to the owner). */
  function getRoutineTasksForProperty(propertyId, month) {
    return routineTasks.filter((t) => t.propertyId === propertyId && t.month === month && t.status === 'Done');
  }

  /** Unsettled routine-task billing for a property — Done tasks with a
   *  billed cost that hasn't yet been collected from the tenant. Used by
   *  Finance's Rent Collection to show the automatic "Routine Maintenance
   *  Due" notice. */
  function getRoutinePendingBilling(propertyId) {
    return routineTasks.filter((t) => t.propertyId === propertyId && t.status === 'Done' && t.billedCost > 0 && !t.tenantCollected);
  }

  /** Marks a set of routine tasks as collected from the tenant — called
   *  once the manager confirms while saving a Rent Collection entry. */
  function markRoutineTasksCollected(taskIds) {
    routineTasks.forEach((t) => { if (taskIds.includes(t.id)) t.tenantCollected = true; });
    persistRoutine();
  }

  /** Closed, tenant-approved, tenant-chargeable tickets whose charge
   *  hasn't yet ridden along with a rent bill — this is what lets
   *  "Monthly Rent + Tenant Payable Maintenance Work = Total Tenant
   *  Receivable" actually happen automatically instead of the manager
   *  tracking it separately. */
  function getTenantPendingMaintenanceBilling(tenantId) {
    return tickets.filter((t) => t.tenantId === tenantId && t.status === 'Closed' && t.closingDetails
      && t.closingDetails.costBearer === 'Tenant' && (t.closingDetails.totalBilled || 0) > 0 && !t.tenantCollected);
  }
  function markMaintenanceTicketsCollected(ticketIds) {
    tickets.forEach((t) => { if (ticketIds.includes(t.id)) t.tenantCollected = true; });
    persist();
  }


  function switchSubTab(subId) {
    document.querySelectorAll('#maintSubnav .fs-tab').forEach((t) => t.classList.toggle('active', t.dataset.sub === subId));
    document.querySelectorAll('#page-maintenance .finance-subview').forEach((v) => v.classList.toggle('active', v.id === 'sub-' + subId));
    if (subId === 'maintDashboard') renderDashboard();
    if (subId === 'maintTickets') { populatePropertySelects(); populateCategoryFilter(); renderTicketsList(); }
    if (subId === 'maintRoutine') { generateThisMonthRoutineTasks(); populateRoutineFilters(); renderRoutineChecklist(); }
    if (subId === 'maintAnalytics') renderAnalytics();
    if (subId === 'maintVendorMaster') { renderVendorCategoryList(); renderVisitingChargeRuleForm(); }
    if (subId === 'maintVendorBills') { renderUnbilledVendorList(); renderVendorBillHistory(); }
    if (subId === 'maintMaidService') {
      viewingMaidId = null;
      document.getElementById('maidProfileView').classList.add('hidden');
      document.getElementById('maidListView').classList.remove('hidden');
      renderMaidTodayAttendance();
      renderMaidCardsList();
    }
  }

  function bindEvents() {
    document.querySelectorAll('#maintSubnav .fs-tab').forEach((tab) => tab.addEventListener('click', () => switchSubTab(tab.dataset.sub)));

    document.getElementById('addVendorCategoryBtn').addEventListener('click', openAddVendorCategoryModal);
    document.getElementById('vcSaveBtn').addEventListener('click', handleSaveVisitingChargeRule);
    ['vcTargetAmount', 'vcMaxCharge', 'vcVendorShare', 'vcMarginShare'].forEach((id) => {
      document.getElementById(id).addEventListener('input', updateVisitingChargeMismatchHint);
    });

    document.getElementById('addMaidBtn').addEventListener('click', openAddMaidModal);
    document.getElementById('maidModalCloseBtn').addEventListener('click', closeMaidModal);
    document.getElementById('maidCancelBtn').addEventListener('click', closeMaidModal);
    document.getElementById('maidModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'maidModalOverlay') closeMaidModal(); });
    document.getElementById('maidSaveBtn').addEventListener('click', handleSaveMaid);

    document.getElementById('maidProfileBackBtn').addEventListener('click', backToMaidList);
    document.getElementById('addMaidAssignmentBtn').addEventListener('click', openAddMaidAssignmentModal);
    document.getElementById('maidAssignmentModalCloseBtn').addEventListener('click', closeMaidAssignmentModal);
    document.getElementById('maidAssignmentCancelBtn').addEventListener('click', closeMaidAssignmentModal);
    document.getElementById('maidAssignmentModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'maidAssignmentModalOverlay') closeMaidAssignmentModal(); });
    document.getElementById('maidAssignmentSaveBtn').addEventListener('click', handleSaveMaidAssignment);

    document.getElementById('recordMaidPaymentBtn').addEventListener('click', openMaidPaymentModal);
    document.getElementById('maidPaymentModalCloseBtn').addEventListener('click', closeMaidPaymentModal);
    document.getElementById('maidPaymentCancelBtn').addEventListener('click', closeMaidPaymentModal);
    document.getElementById('maidPaymentModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'maidPaymentModalOverlay') closeMaidPaymentModal(); });
    document.getElementById('maidPaymentSaveBtn').addEventListener('click', handleSaveMaidPayment);
    document.getElementById('vendorCategoryModalCloseBtn').addEventListener('click', closeVendorCategoryModal);
    document.getElementById('vendorCategoryCancelBtn').addEventListener('click', closeVendorCategoryModal);
    document.getElementById('vendorCategoryModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'vendorCategoryModalOverlay') closeVendorCategoryModal(); });
    document.getElementById('vendorCategorySaveBtn').addEventListener('click', handleSaveVendorCategory);

    document.getElementById('workTypeModalCloseBtn').addEventListener('click', closeWorkTypeModal);
    document.getElementById('workTypeCancelBtn').addEventListener('click', closeWorkTypeModal);
    document.getElementById('workTypeModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'workTypeModalOverlay') closeWorkTypeModal(); });
    document.getElementById('workTypeSaveBtn').addEventListener('click', handleSaveWorkType);

    document.getElementById('vendorBillModalCloseBtn').addEventListener('click', closeVendorBillModal);
    document.getElementById('vendorBillCancelBtn').addEventListener('click', closeVendorBillModal);
    document.getElementById('vendorBillModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'vendorBillModalOverlay') closeVendorBillModal(); });
    document.getElementById('vendorBillGenerateBtn').addEventListener('click', handleGenerateVendorBill);

    document.getElementById('vendorBillPayModalCloseBtn').addEventListener('click', closeVendorBillPayModal);
    document.getElementById('vendorBillPayCancelBtn').addEventListener('click', closeVendorBillPayModal);
    document.getElementById('vendorBillPayModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'vendorBillPayModalOverlay') closeVendorBillPayModal(); });
    document.getElementById('vendorBillPaySaveBtn').addEventListener('click', handleSaveVendorBillPayment);
    ['workTypeVendorCost', 'workTypeChargeable'].forEach((id) => document.getElementById(id).addEventListener('input', updateWorkTypeMarginBox));

    document.getElementById('addTicketBtn').addEventListener('click', openAddTicketModal);
    document.getElementById('ticketModalCloseBtn').addEventListener('click', closeTicketFormModal);
    document.getElementById('ticketCancelBtn').addEventListener('click', closeTicketFormModal);
    document.getElementById('ticketSaveBtn').addEventListener('click', handleSaveTicket);
    document.getElementById('ticketModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'ticketModalOverlay') closeTicketFormModal(); });
    document.getElementById('ticketProperty').addEventListener('change', onTicketPropertyChange);
    document.getElementById('ticketCostBearer').addEventListener('change', updateTicketApprovalHint);
    document.getElementById('ticketEstimatedAmount').addEventListener('input', updateTicketApprovalHint);

    document.getElementById('ticketSearchInput').addEventListener('input', renderTicketsList);
    document.getElementById('ticketPropertyFilter').addEventListener('change', renderTicketsList);
    document.getElementById('ticketPriorityFilter').addEventListener('change', renderTicketsList);
    document.getElementById('ticketStatusFilter').addEventListener('change', renderTicketsList);
    document.getElementById('ticketCategoryFilter').addEventListener('change', renderTicketsList);
    document.getElementById('ticketDateFilter').addEventListener('change', renderTicketsList);
    document.getElementById('ticketBackBtn').addEventListener('click', backToTicketsList);

    document.getElementById('assignModalCloseBtn').addEventListener('click', closeAssignModal);
    document.getElementById('assignCancelBtn').addEventListener('click', closeAssignModal);
    document.getElementById('assignSaveBtn').addEventListener('click', handleSaveAssignment);
    document.getElementById('assignModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'assignModalOverlay') closeAssignModal(); });
    document.getElementById('assignHandledBy').addEventListener('change', toggleAssignHandledByFields);

    document.getElementById('approvalModalCloseBtn').addEventListener('click', closeApprovalModal);
    document.getElementById('approvalCancelBtn').addEventListener('click', closeApprovalModal);
    document.getElementById('approvalModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'approvalModalOverlay') closeApprovalModal(); });
    document.getElementById('approvalSendWhatsappBtn').addEventListener('click', handleSendApprovalWhatsapp);
    document.getElementById('approvalMarkApprovedBtn').addEventListener('click', () => handleMarkApproval(true));
    document.getElementById('approvalMarkRejectedBtn').addEventListener('click', () => handleMarkApproval(false));

    document.getElementById('verifySelfServiceModalCloseBtn').addEventListener('click', closeVerifySelfServiceModal);
    document.getElementById('verifySelfServiceCancelBtn').addEventListener('click', closeVerifySelfServiceModal);
    document.getElementById('verifySelfServiceModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'verifySelfServiceModalOverlay') closeVerifySelfServiceModal(); });
    document.getElementById('verifySelfServiceSaveBtn').addEventListener('click', handleVerifySelfService);
    document.getElementById('verifySelfServicePhoto').addEventListener('change', handleSelfServicePhotoSelect);

    document.getElementById('closeModalCloseBtn').addEventListener('click', closeCloseModal);
    document.getElementById('closeCancelBtn').addEventListener('click', closeCloseModal);
    document.getElementById('closeSaveBtn').addEventListener('click', handleSaveClose);
    document.getElementById('closeModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'closeModalOverlay') closeCloseModal(); });
    ['closeLabourActual', 'closeLabourBilled'].forEach((id) => {
      document.getElementById(id).addEventListener('input', updateCloseTotalBox);
    });
    document.getElementById('closeAddMaterialRowBtn').addEventListener('click', addMaterialRow);
    document.getElementById('closeWorkTypeSelect').addEventListener('change', onWorkTypeSelectedInClose);
    document.getElementById('closeWorkQuantity').addEventListener('input', applyWorkTypeRateWithQuantity);
    document.getElementById('closeAddNewWorkBtn').addEventListener('click', openAddWorkTypeModalInline);

    document.getElementById('cancelTicketModalCloseBtn').addEventListener('click', closeCancelModal);
    document.getElementById('cancelTicketCancelBtn').addEventListener('click', closeCancelModal);
    document.getElementById('cancelTicketSaveBtn').addEventListener('click', handleConfirmCancel);
    document.getElementById('cancelTicketModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'cancelTicketModalOverlay') closeCancelModal(); });

    document.getElementById('routinePropertyFilter').addEventListener('change', renderRoutineChecklist);
    document.getElementById('routineMonthFilter').addEventListener('change', renderRoutineChecklist);
    document.getElementById('routineDoneModalCloseBtn').addEventListener('click', closeRoutineDoneModal);
    document.getElementById('routineDoneCancelBtn').addEventListener('click', closeRoutineDoneModal);
    document.getElementById('routineDoneSaveBtn').addEventListener('click', handleSaveRoutineDone);
    document.getElementById('routineDoneModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'routineDoneModalOverlay') closeRoutineDoneModal(); });
    ['routineActualCost', 'routineBilledCost'].forEach((id) => {
      document.getElementById(id).addEventListener('input', updateRoutineDoneCalcBox);
    });
    document.getElementById('routineWorkTypeSelect').addEventListener('change', onRoutineWorkTypeSelected);
    document.getElementById('routineQuantity').addEventListener('input', applyRoutineWorkTypeRateWithQuantity);
    document.getElementById('vendorPayModalCloseBtn').addEventListener('click', closeVendorPayModal);
    document.getElementById('vendorPayCancelBtn').addEventListener('click', closeVendorPayModal);
    document.getElementById('vendorPaySaveBtn').addEventListener('click', handleSaveVendorPay);
    document.getElementById('vendorPayModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'vendorPayModalOverlay') closeVendorPayModal(); });
  }

  function onPageShow() {
    const activeTab = document.querySelector('#maintSubnav .fs-tab.active');
    switchSubTab(activeTab ? activeTab.dataset.sub : 'maintDashboard');
  }

  function init() {
    load();
    loadRoutine();
    bindEvents();
    renderDashboard();
    seedDefaultVendorCategoriesIfEmpty();
  }

  // ======================================================================
  // VENDOR & WORK MASTER — categories with unlimited custom work types,
  // each carrying default Vendor Cost / Chargeable Amount. Fully
  // editable from the app; no code changes or deployment ever needed to
  // add a new work. Editing a default never touches past tickets, since
  // each ticket stores its OWN actual numbers at creation time, not a
  // live reference to this master.
  // ======================================================================
  function renderVisitingChargeRuleForm() {
    document.getElementById('vcTargetAmount').value = visitingChargeRule.targetAmount;
    document.getElementById('vcMaxCharge').value = visitingChargeRule.maxCharge;
    document.getElementById('vcVendorShare').value = visitingChargeRule.vendorShare;
    document.getElementById('vcMarginShare').value = visitingChargeRule.marginShare;
    updateVisitingChargeMismatchHint();
  }

  function updateVisitingChargeMismatchHint() {
    const maxCharge = Number(document.getElementById('vcMaxCharge').value) || 0;
    const vendorShare = Number(document.getElementById('vcVendorShare').value) || 0;
    const marginShare = Number(document.getElementById('vcMarginShare').value) || 0;
    const hint = document.getElementById('vcMismatchHint');
    if (vendorShare + marginShare !== maxCharge) {
      hint.textContent = `Vendor Share + Margin (₹${vendorShare + marginShare}) doesn't add up to the Max Visiting Charge (₹${maxCharge}).`;
      hint.style.color = 'var(--warning)';
    } else {
      hint.textContent = '';
    }
  }

  function handleSaveVisitingChargeRule() {
    visitingChargeRule = {
      targetAmount: Number(document.getElementById('vcTargetAmount').value) || 0,
      maxCharge: Number(document.getElementById('vcMaxCharge').value) || 0,
      vendorShare: Number(document.getElementById('vcVendorShare').value) || 0,
      marginShare: Number(document.getElementById('vcMarginShare').value) || 0,
    };
    persistVisitingChargeRule();
    alert('Visiting Charge Rule saved — applies to future maintenance entries only, past completed work is unaffected.');
  }

  /** Given a work value, returns the applicable Visiting Charge (0 if
   *  the work already meets the threshold) — used when a Work Type is
   *  selected at ticket closing, purely as a suggestion the manager can
   *  still override for the specific job. */
  /** Visiting Charge fills the gap between the work's value and the
   *  target payable (e.g. ₹300), capped at maxCharge (e.g. ₹150) —
   *  never negative, never adds anything once the work already meets
   *  the target on its own. */
  function getApplicableVisitingCharge(workValue) {
    if (workValue >= visitingChargeRule.targetAmount) return 0;
    const needed = visitingChargeRule.targetAmount - workValue;
    return Math.min(needed, visitingChargeRule.maxCharge);
  }

  function renderVendorCategoryList() {
    const box = document.getElementById('vendorCategoryList');
    if (!box) return;
    if (!vendorCategories.length) { box.innerHTML = '<div class="empty-state"><div class="desc">No vendor categories yet.</div></div>'; return; }

    box.innerHTML = vendorCategories.map((cat) => {
      const works = workTypes.filter((w) => w.categoryId === cat.id);
      return `
        <div class="settings-card" style="margin-bottom:12px;">
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
            <h3 style="margin:0;">${esc(cat.name)}</h3>
            <div style="display:flex; gap:6px;">
              <button class="btn small secondary vc-edit-btn" data-id="${cat.id}">Rename</button>
              <button class="btn small secondary vc-add-work-btn" data-id="${cat.id}">+ Add Work</button>
            </div>
          </div>
          ${works.length ? works.map((w) => `
            <div class="history-item" style="${w.active === false ? 'opacity:0.5;' : ''}">
              <div class="hi-title">${esc(w.name)}${w.active === false ? ' (Disabled)' : ''}
                <button class="btn small secondary wt-edit-btn" data-id="${w.id}" style="margin-left:8px; padding:2px 8px;">Edit</button>
                <button class="btn small secondary wt-toggle-btn" data-id="${w.id}" style="margin-left:4px; padding:2px 8px;">${w.active === false ? 'Enable' : 'Disable'}</button>
              </div>
              <div class="hi-row">Vendor Cost ₹${w.defaultVendorCost} · Chargeable ₹${w.defaultChargeableAmount} · Margin ₹${w.defaultChargeableAmount - w.defaultVendorCost}</div>
            </div>`).join('') : '<div class="sc-desc" style="margin-top:8px;">No works added yet in this category.</div>'}
        </div>`;
    }).join('');

    box.querySelectorAll('.vc-edit-btn').forEach((b) => b.addEventListener('click', () => openEditVendorCategoryModal(b.dataset.id)));
    box.querySelectorAll('.vc-add-work-btn').forEach((b) => b.addEventListener('click', () => openAddWorkTypeModal(b.dataset.id)));
    box.querySelectorAll('.wt-edit-btn').forEach((b) => b.addEventListener('click', () => openEditWorkTypeModal(b.dataset.id)));
    box.querySelectorAll('.wt-toggle-btn').forEach((b) => b.addEventListener('click', () => toggleWorkTypeActive(b.dataset.id)));
  }

  function openAddVendorCategoryModal() {
    editingVendorCategoryId = null;
    document.getElementById('vendorCategoryModalTitle').textContent = 'Add Vendor Category';
    document.getElementById('vendorCategoryForm').reset();
    document.getElementById('vendorCategoryId').value = '';
    clearErrors('vendorCategoryForm');
    document.getElementById('vendorCategoryModalOverlay').classList.add('open');
  }
  function openEditVendorCategoryModal(id) {
    const cat = vendorCategories.find((c) => c.id === id);
    if (!cat) return;
    editingVendorCategoryId = id;
    document.getElementById('vendorCategoryModalTitle').textContent = 'Rename Vendor Category';
    document.getElementById('vendorCategoryId').value = id;
    document.getElementById('vendorCategoryName').value = cat.name;
    clearErrors('vendorCategoryForm');
    document.getElementById('vendorCategoryModalOverlay').classList.add('open');
  }
  function closeVendorCategoryModal() { document.getElementById('vendorCategoryModalOverlay').classList.remove('open'); editingVendorCategoryId = null; }

  function handleSaveVendorCategory() {
    const name = document.getElementById('vendorCategoryName').value.trim();
    clearErrors('vendorCategoryForm');
    if (!name) { showErrors({ vendorCategoryName: 'Category name is required' }); return; }
    const dup = vendorCategories.some((c) => c.id !== editingVendorCategoryId && c.name.toLowerCase() === name.toLowerCase());
    if (dup) { showErrors({ vendorCategoryName: 'This category already exists' }); return; }

    if (editingVendorCategoryId) {
      const idx = vendorCategories.findIndex((c) => c.id === editingVendorCategoryId);
      if (idx !== -1) vendorCategories[idx].name = name;
    } else {
      vendorCategories.push({ id: generateId(), name, createdAt: new Date().toISOString() });
    }
    persistVendorCategories();
    closeVendorCategoryModal();
    renderVendorCategoryList();
  }

  let workTypeInlineMode = false; // true when opened from the Ticket Closing form, not a category card

  function openAddWorkTypeModal(categoryId) {
    editingWorkTypeId = null;
    workTypeInlineMode = false;
    document.getElementById('workTypeModalTitle').textContent = 'Add Work';
    document.getElementById('workTypeForm').reset();
    document.getElementById('workTypeId').value = '';
    document.getElementById('workTypeCategoryId').value = categoryId;
    document.getElementById('workTypeCategorySelectGroup').classList.add('hidden');
    clearErrors('workTypeForm');
    updateWorkTypeMarginBox();
    document.getElementById('workTypeModalOverlay').classList.add('open');
  }

  /** "+ Add New Work" right from the Ticket Closing form — lets the
   *  manager create a missing Work Type without ever leaving the page,
   *  then automatically selects it so the ticket keeps flowing. */
  function openAddWorkTypeModalInline() {
    editingWorkTypeId = null;
    workTypeInlineMode = true;
    document.getElementById('workTypeModalTitle').textContent = 'Add New Work';
    document.getElementById('workTypeForm').reset();
    document.getElementById('workTypeId').value = '';
    document.getElementById('workTypeCategoryId').value = '';
    const catSel = document.getElementById('workTypeCategorySelect');
    catSel.innerHTML = '<option value="">Select Category</option>' + vendorCategories.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
    document.getElementById('workTypeCategorySelectGroup').classList.remove('hidden');
    clearErrors('workTypeForm');
    updateWorkTypeMarginBox();
    document.getElementById('workTypeModalOverlay').classList.add('open');
  }

  function openEditWorkTypeModal(id) {
    const w = workTypes.find((x) => x.id === id);
    if (!w) return;
    editingWorkTypeId = id;
    workTypeInlineMode = false;
    document.getElementById('workTypeModalTitle').textContent = 'Edit Work';
    document.getElementById('workTypeId').value = w.id;
    document.getElementById('workTypeCategoryId').value = w.categoryId;
    document.getElementById('workTypeCategorySelectGroup').classList.add('hidden');
    document.getElementById('workTypeName').value = w.name;
    document.getElementById('workTypeVendorCost').value = w.defaultVendorCost;
    document.getElementById('workTypeChargeable').value = w.defaultChargeableAmount;
    document.getElementById('workTypeDefaultVendorName').value = w.defaultVendorName || '';
    clearErrors('workTypeForm');
    updateWorkTypeMarginBox();
    document.getElementById('workTypeModalOverlay').classList.add('open');
  }
  function closeWorkTypeModal() { document.getElementById('workTypeModalOverlay').classList.remove('open'); editingWorkTypeId = null; workTypeInlineMode = false; }

  function updateWorkTypeMarginBox() {
    const vendorCost = Number(document.getElementById('workTypeVendorCost').value) || 0;
    const chargeable = Number(document.getElementById('workTypeChargeable').value) || 0;
    document.getElementById('workTypeMarginBox').innerHTML = `
      <div class="calc-row"><span>Vendor Cost</span><span>₹${vendorCost}</span></div>
      <div class="calc-row"><span>Chargeable Amount</span><span>₹${chargeable}</span></div>
      <div class="calc-row total"><span>Fair Homes Margin</span><span>₹${chargeable - vendorCost}</span></div>
    `;
  }

  function handleSaveWorkType() {
    const categoryId = workTypeInlineMode ? document.getElementById('workTypeCategorySelect').value : document.getElementById('workTypeCategoryId').value;
    const name = document.getElementById('workTypeName').value.trim();
    const defaultVendorCost = document.getElementById('workTypeVendorCost').value;
    const defaultChargeableAmount = document.getElementById('workTypeChargeable').value;
    const defaultVendorName = document.getElementById('workTypeDefaultVendorName').value.trim();

    const errors = {};
    if (workTypeInlineMode && !categoryId) errors.workTypeCategorySelect = 'Select a vendor category';
    if (!name) errors.workTypeName = 'Work name is required';
    if (defaultVendorCost === '' || Number(defaultVendorCost) < 0) errors.workTypeVendorCost = 'Enter a valid vendor cost';
    if (defaultChargeableAmount === '' || Number(defaultChargeableAmount) < 0) errors.workTypeChargeable = 'Enter a valid chargeable amount';
    clearErrors('workTypeForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const now = new Date().toISOString();
    let newWorkId = null;
    if (editingWorkTypeId) {
      const idx = workTypes.findIndex((w) => w.id === editingWorkTypeId);
      if (idx !== -1) {
        workTypes[idx] = { ...workTypes[idx], name, defaultVendorCost: Number(defaultVendorCost), defaultChargeableAmount: Number(defaultChargeableAmount), defaultVendorName, updatedAt: now };
      }
    } else {
      newWorkId = generateId();
      workTypes.push({
        id: newWorkId, categoryId, name,
        defaultVendorCost: Number(defaultVendorCost), defaultChargeableAmount: Number(defaultChargeableAmount), defaultVendorName,
        active: true, createdAt: now, updatedAt: now,
      });
    }
    persistWorkTypes();
    const wasInline = workTypeInlineMode;
    closeWorkTypeModal();
    renderVendorCategoryList();
    populateWorkTypeSelectInTicketForm();
    // Came from the Ticket Closing form's "+ Add New Work" — pick up
    // right where the manager left off, with the new work already
    // selected and its costs filled in, instead of dropping them back
    // to a blank Ticket form.
    if (wasInline && newWorkId) {
      const sel = document.getElementById('closeWorkTypeSelect');
      sel.value = newWorkId;
      onWorkTypeSelectedInClose();
    }
  }

  function toggleWorkTypeActive(id) {
    const idx = workTypes.findIndex((w) => w.id === id);
    if (idx === -1) return;
    workTypes[idx].active = workTypes[idx].active === false ? true : false;
    workTypes[idx].updatedAt = new Date().toISOString();
    persistWorkTypes();
    renderVendorCategoryList();
    populateWorkTypeSelectInTicketForm();
  }

  /** Exposed for Ticket creation — only active work types, flattened
   *  with their category name, so a Ticket's "Work" dropdown can pick
   *  straight from the master and auto-fill costs. */
  function getActiveWorkTypesFlat() {
    return workTypes.filter((w) => w.active !== false).map((w) => {
      const cat = vendorCategories.find((c) => c.id === w.categoryId);
      return { ...w, categoryName: cat ? cat.name : '' };
    });
  }

  /** Populates the ticket-closing form's Work Type dropdown, grouped by
   *  vendor category, from the active Work Master entries. */
  function populateWorkTypeSelectInTicketForm() {
    const sel = document.getElementById('closeWorkTypeSelect');
    if (!sel) return;
    const current = sel.value;
    const grouped = {};
    getActiveWorkTypesFlat().forEach((w) => {
      if (!grouped[w.categoryName]) grouped[w.categoryName] = [];
      grouped[w.categoryName].push(w);
    });
    let html = '<option value="">Not from master — enter manually below</option>';
    Object.keys(grouped).sort().forEach((catName) => {
      html += `<optgroup label="${esc(catName)}">` + grouped[catName].map((w) => `<option value="${w.id}" data-vendor-cost="${w.defaultVendorCost}" data-chargeable="${w.defaultChargeableAmount}">${esc(w.name)}</option>`).join('') + '</optgroup>';
    });
    sel.innerHTML = html;
    sel.value = current;
  }

  function onWorkTypeSelectedInClose() {
    const sel = document.getElementById('closeWorkTypeSelect');
    const opt = sel.selectedOptions[0];
    const qtyGroup = document.getElementById('closeWorkQuantityGroup');
    if (opt && opt.dataset.vendorCost !== undefined) {
      qtyGroup.classList.remove('hidden');
      document.getElementById('closeWorkQuantity').value = document.getElementById('closeWorkQuantity').value || 1;
      applyWorkTypeRateWithQuantity();
    } else {
      qtyGroup.classList.add('hidden');
    }
  }

  /** Recomputes Vendor Cost/Chargeable as (per-unit rate × quantity),
   *  THEN applies Visiting Charge on top of that quantity-adjusted
   *  work value — matches "Fan Installation ₹300/piece × 3 = ₹900". */
  function applyWorkTypeRateWithQuantity() {
    const sel = document.getElementById('closeWorkTypeSelect');
    const opt = sel.selectedOptions[0];
    if (!opt || opt.dataset.vendorCost === undefined) return;
    const quantity = Math.max(1, Number(document.getElementById('closeWorkQuantity').value) || 1);
    let vendorCost = Number(opt.dataset.vendorCost) * quantity;
    let chargeable = Number(opt.dataset.chargeable) * quantity;
    const visitingCharge = getApplicableVisitingCharge(chargeable);
    if (visitingCharge > 0) {
      const ruleTotalShare = visitingChargeRule.vendorShare + visitingChargeRule.marginShare;
      const vendorPortion = ruleTotalShare > 0 ? Math.round(visitingCharge * (visitingChargeRule.vendorShare / ruleTotalShare)) : visitingCharge;
      vendorCost += vendorPortion;
      chargeable += visitingCharge;
    }
    document.getElementById('closeLabourActual').value = vendorCost;
    document.getElementById('closeLabourBilled').value = chargeable;
    updateCloseTotalBox();
  }

  // ======================================================================
  // VENDOR BILLS — aggregates closed tickets' vendor cost by vendor name
  // into a payable bill, tracked separately from the ticket-level
  // Owner/Tenant recovery so Vendor Payable, Owner Payable and Tenant
  // Receivable never get mixed together.
  // ======================================================================
  function nextVendorBillCode() {
    const key = 'fh_vendor_bill_seq';
    let seq = parseInt(localStorage.getItem(key) || '0', 10) + 1;
    localStorage.setItem(key, String(seq));
    return 'VBILL-' + String(seq).padStart(4, '0');
  }

  /** Tickets that have vendor cost recorded (closed, with a vendor
   *  name) and aren't part of any bill yet, grouped by vendor. */
  function getUnbilledTicketsByVendor() {
    const billedTicketIds = new Set(vendorBills.flatMap((b) => b.ticketIds));
    const grouped = {};
    tickets.forEach((t) => {
      const cd = t.closingDetails;
      if (!cd || !cd.vendorName || !cd.vendorName.trim()) return;
      if (billedTicketIds.has(t.id)) return;
      const vendorCost = (cd.labourActual || 0) + (cd.materialActual || 0);
      if (vendorCost <= 0) return;
      const key = cd.vendorName.trim();
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push({ ticketId: t.id, ticketCode: t.ticketId, category: t.category, date: t.dateTime, vendorCost, propertyId: t.propertyId });
    });
    return grouped;
  }

  function renderUnbilledVendorList() {
    const box = document.getElementById('unbilledVendorList');
    if (!box) return;
    const grouped = getUnbilledTicketsByVendor();
    const vendorNames = Object.keys(grouped);
    if (!vendorNames.length) { box.innerHTML = '<div class="empty-state"><div class="desc">No unbilled vendor work right now.</div></div>'; return; }

    box.innerHTML = vendorNames.map((name) => {
      const items = grouped[name];
      const total = items.reduce((s, i) => s + i.vendorCost, 0);
      return `
        <div class="settings-card" style="margin-bottom:10px; display:flex; justify-content:space-between; align-items:center;">
          <div>
            <div class="hi-title">${esc(name)}</div>
            <div class="hi-row">${items.length} work(s) pending · Total ₹${total}</div>
          </div>
          <button class="btn small vb-generate-btn" data-vendor="${esc(name)}">Generate Bill</button>
        </div>`;
    }).join('');
    box.querySelectorAll('.vb-generate-btn').forEach((b) => b.addEventListener('click', () => openVendorBillModal(b.dataset.vendor)));
  }

  function openVendorBillModal(vendorName) {
    document.getElementById('vendorBillVendorName').value = vendorName;
    document.getElementById('vendorBillModalTitle').textContent = 'Generate Bill — ' + vendorName;
    const grouped = getUnbilledTicketsByVendor();
    const items = grouped[vendorName] || [];
    const listBox = document.getElementById('vendorBillTicketsList');
    listBox.innerHTML = items.map((i) => {
      const property = PropertiesController.getAll().find((p) => p.id === i.propertyId);
      return `
        <label class="checkbox-item" style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid var(--border);">
          <span><input type="checkbox" class="vb-item-check" data-cost="${i.vendorCost}" value="${i.ticketId}" checked /> ${esc(i.category)} — ${property ? esc(property.name) : ''} (${esc(i.ticketCode)}, ${fmtDate(i.date)})</span>
          <span>₹${i.vendorCost}</span>
        </label>`;
    }).join('');
    listBox.querySelectorAll('.vb-item-check').forEach((cb) => cb.addEventListener('change', updateVendorBillTotal));
    updateVendorBillTotal();
    document.getElementById('vendorBillModalOverlay').classList.add('open');
  }
  function closeVendorBillModal() { document.getElementById('vendorBillModalOverlay').classList.remove('open'); }

  function updateVendorBillTotal() {
    const checked = [...document.querySelectorAll('.vb-item-check:checked')];
    const total = checked.reduce((s, cb) => s + Number(cb.dataset.cost), 0);
    document.getElementById('vendorBillTotalBox').innerHTML = `<div class="calc-row total"><span>Total Payable (${checked.length} work${checked.length === 1 ? '' : 's'})</span><span>₹${total}</span></div>`;
  }

  function handleGenerateVendorBill() {
    const vendorName = document.getElementById('vendorBillVendorName').value;
    const checked = [...document.querySelectorAll('.vb-item-check:checked')];
    if (!checked.length) { alert('Select at least one work item to include in the bill.'); return; }
    const ticketIds = checked.map((cb) => cb.value);
    const totalAmount = checked.reduce((s, cb) => s + Number(cb.dataset.cost), 0);
    const now = new Date().toISOString();
    vendorBills.unshift({
      id: generateId(), billCode: nextVendorBillCode(), vendorName, ticketIds, totalAmount,
      status: 'Unpaid', amountPaid: 0, paymentDate: null, paymentMethod: null,
      createdAt: now, updatedAt: now,
    });
    persistVendorBills();
    closeVendorBillModal();
    renderUnbilledVendorList();
    renderVendorBillHistory();
  }

  const VENDOR_BILL_STATUS_CLASS = { Unpaid: 'status-open', 'Partially Paid': 'status-assigned', Paid: 'status-completed' };

  function renderVendorBillHistory() {
    const box = document.getElementById('vendorBillHistory');
    if (!box) return;
    if (!vendorBills.length) { box.innerHTML = '<div class="empty-state"><div class="desc">No vendor bills generated yet.</div></div>'; return; }
    box.innerHTML = vendorBills.map((b) => `
      <div class="settings-card" style="margin-bottom:10px;">
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
          <div>
            <div class="hi-title">${esc(b.vendorName)} — ${esc(b.billCode)} <span class="badge ${VENDOR_BILL_STATUS_CLASS[b.status]}" style="margin-left:6px;">${b.status}</span></div>
            <div class="hi-row">${b.ticketIds.length} work(s) · Total ₹${b.totalAmount} · Paid ₹${b.amountPaid}${b.status !== 'Paid' ? ' · Remaining ₹' + (b.totalAmount - b.amountPaid) : ''}</div>
          </div>
          <div style="display:flex; gap:6px;">
            ${b.status !== 'Paid' ? `<button class="btn small secondary vb-pay-btn" data-id="${b.id}">Record Payment</button>` : ''}
            <button class="btn small secondary vb-pdf-btn" data-id="${b.id}">Download PDF</button>
          </div>
        </div>
      </div>`).join('');
    box.querySelectorAll('.vb-pay-btn').forEach((btn) => btn.addEventListener('click', () => openVendorBillPayModal(btn.dataset.id)));
    box.querySelectorAll('.vb-pdf-btn').forEach((btn) => btn.addEventListener('click', () => generateVendorBillPdf(btn.dataset.id)));
  }

  function openVendorBillPayModal(billId) {
    const b = vendorBills.find((x) => x.id === billId);
    if (!b) return;
    document.getElementById('vendorBillPayId').value = billId;
    document.getElementById('vendorBillPaySummary').innerHTML = `
      <div class="calc-row"><span>Total Bill</span><span>₹${b.totalAmount}</span></div>
      <div class="calc-row"><span>Already Paid</span><span>₹${b.amountPaid}</span></div>
      <div class="calc-row total"><span>Remaining</span><span>₹${b.totalAmount - b.amountPaid}</span></div>
    `;
    document.getElementById('vendorBillPayAmount').value = b.totalAmount - b.amountPaid;
    document.getElementById('vendorBillPayDate').value = todayIso();
    document.getElementById('vendorBillPayMethod').value = 'Cash';
    document.querySelectorAll('#vendorBillPayModalOverlay .form-error').forEach((el) => (el.textContent = ''));
    document.getElementById('vendorBillPayModalOverlay').classList.add('open');
  }
  function closeVendorBillPayModal() { document.getElementById('vendorBillPayModalOverlay').classList.remove('open'); }

  function handleSaveVendorBillPayment() {
    const billId = document.getElementById('vendorBillPayId').value;
    const amount = document.getElementById('vendorBillPayAmount').value;
    const date = document.getElementById('vendorBillPayDate').value;
    const method = document.getElementById('vendorBillPayMethod').value;
    const errors = {};
    if (!amount || Number(amount) <= 0) errors.vendorBillPayAmount = 'Enter a valid amount';
    if (!date) errors.vendorBillPayDate = 'Payment date is required';
    document.querySelectorAll('#vendorBillPayModalOverlay .form-error').forEach((el) => (el.textContent = ''));
    if (Object.keys(errors).length) {
      Object.entries(errors).forEach(([id, msg]) => { const el = document.getElementById('err-' + id); if (el) el.textContent = msg; });
      return;
    }
    const idx = vendorBills.findIndex((b) => b.id === billId);
    if (idx === -1) return;
    const newPaid = vendorBills[idx].amountPaid + Number(amount);
    vendorBills[idx].amountPaid = newPaid;
    vendorBills[idx].paymentDate = date;
    vendorBills[idx].paymentMethod = method;
    vendorBills[idx].status = newPaid >= vendorBills[idx].totalAmount ? 'Paid' : 'Partially Paid';
    vendorBills[idx].updatedAt = new Date().toISOString();
    persistVendorBills();
    closeVendorBillPayModal();
    renderVendorBillHistory();
  }

  /** Vendor Bill PDF — vendor name, every work item with its date and
   *  cost, total payable, payment status. Same open-in-tab pattern as
   *  the Tenant Receipt. */
  function generateVendorBillPdf(billId) {
    const b = vendorBills.find((x) => x.id === billId);
    if (!b) return;
    if (typeof window.jspdf === 'undefined' || typeof window.jspdf.jsPDF !== 'function') {
      alert('PDF library (jsPDF) failed to load from the CDN — check your internet connection.');
      return;
    }
    let companyName = 'Fair Homes';
    try { const c = JSON.parse(localStorage.getItem('fh_company_profile')); if (c && c.companyName) companyName = c.companyName; } catch (e) { /* default */ }

    const jsPDFCtor = window.jspdf.jsPDF;
    const doc = new jsPDFCtor();
    let y = 18;
    doc.setFontSize(18); doc.setFont(undefined, 'bold');
    doc.text(companyName, 14, y);
    doc.setFontSize(11); doc.setFont(undefined, 'normal');
    doc.text('Vendor Bill', 14, y + 7);
    doc.setFontSize(9);
    doc.text('Bill No: ' + b.billCode, 196, y, { align: 'right' });
    doc.text('Date: ' + fmtDate(b.createdAt.slice(0, 10)), 196, y + 5, { align: 'right' });
    y += 16;
    doc.line(14, y, 196, y); y += 8;

    doc.setFontSize(10); doc.setFont(undefined, 'bold');
    doc.text('Vendor: ' + b.vendorName, 14, y); y += 10;

    doc.text('Work Description', 14, y); doc.text('Property', 100, y); doc.text('Date', 155, y); doc.text('Amount', 196, y, { align: 'right' });
    y += 5; doc.line(14, y, 196, y); y += 6;
    doc.setFont(undefined, 'normal');
    b.ticketIds.forEach((ticketId) => {
      const t = tickets.find((tk) => tk.id === ticketId);
      if (!t) return;
      const property = PropertiesController.getAll().find((p) => p.id === t.propertyId);
      const cost = (t.closingDetails.labourActual || 0) + (t.closingDetails.materialActual || 0);
      if (y > 270) { doc.addPage(); y = 16; }
      doc.text(String(t.category).slice(0, 35), 14, y);
      doc.text((property ? property.name : '—').slice(0, 25), 100, y);
      doc.text(fmtDate(t.dateTime), 155, y);
      doc.text('₹' + cost, 196, y, { align: 'right' });
      y += 6;
    });
    y += 4; doc.line(14, y, 196, y); y += 7;
    doc.setFont(undefined, 'bold');
    doc.text('Total Payable', 14, y); doc.text('₹' + b.totalAmount, 196, y, { align: 'right' }); y += 8;
    doc.setFont(undefined, 'normal');
    doc.text('Status: ' + b.status, 14, y);
    if (b.amountPaid > 0) doc.text('Paid ₹' + b.amountPaid + ' on ' + fmtDate(b.paymentDate), 90, y);
    y += 10;
    doc.setFontSize(8); doc.setFont(undefined, 'italic');
    doc.text('This is a system-generated bill from ' + companyName + '.', 14, y);

    const blob = doc.output('blob');
    const url = URL.createObjectURL(blob);
    let opened = null;
    try { opened = window.open(url, '_blank'); } catch (e) { opened = null; }
    if (!opened) {
      const a = document.createElement('a');
      a.href = url; a.download = 'VendorBill_' + b.billCode + '.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  // ======================================================================
  // MAID SERVICE — separate from the tenant-billed "Maid Service" routine
  // task; this is Fair Homes paying its own maids directly, with simple
  // daily attendance and a running advance/pending payment ledger.
  // ======================================================================
  function nextMaidCode() {
    const key = 'fh_maid_seq';
    let seq = parseInt(localStorage.getItem(key) || '0', 10) + 1;
    localStorage.setItem(key, String(seq));
    return 'MAID-' + String(seq).padStart(3, '0');
  }

  function activeAssignmentsForMaid(maidId) { return maidAssignments.filter((a) => a.maidId === maidId && a.active !== false); }

  /** Overall running balance for a maid — cumulative months owed
   *  (based on how long they've been assigned) vs cumulative amount
   *  paid. Positive totalPaid over totalOwed becomes Advance; the
   *  reverse becomes Pending. Kept as one simple running number rather
   *  than a strict per-month allocation, matching "keep it simple". */
  function computeMaidLedger(maidId) {
    const assignments = maidAssignments.filter((a) => a.maidId === maidId);
    const monthlyPayableTotal = activeAssignmentsForMaid(maidId).reduce((s, a) => s + a.monthlyPayment, 0);
    const payments = maidPayments.filter((p) => p.maidId === maidId);
    const totalPaid = payments.reduce((s, p) => s + p.amountPaid, 0);

    let monthsElapsed = 1;
    if (assignments.length) {
      const earliest = assignments.reduce((min, a) => (a.createdAt < min ? a.createdAt : min), assignments[0].createdAt);
      const start = new Date(earliest.slice(0, 7) + '-01');
      const now = new Date();
      monthsElapsed = Math.max(1, (now.getFullYear() - start.getFullYear()) * 12 + (now.getMonth() - start.getMonth()) + 1);
    }
    const totalOwed = monthlyPayableTotal * monthsElapsed;
    const balance = totalPaid - totalOwed; // positive = advance, negative = pending
    let status;
    if (balance > 0) status = 'Advance';
    else if (balance < 0) status = totalPaid > 0 ? 'Partially Paid' : 'Pending';
    else status = 'Paid';
    return { monthlyPayableTotal, totalOwed, totalPaid, balance, status, flatsCount: activeAssignmentsForMaid(maidId).length };
  }

  const MAID_STATUS_ICON = { Paid: '🟢', 'Partially Paid': '🟡', Advance: '🔵', Pending: '🔴' };

  function renderMaidTodayAttendance() {
    const box = document.getElementById('maidTodayAttendance');
    if (!box) return;
    const today = todayIso();
    const rows = [];
    maids.forEach((m) => {
      activeAssignmentsForMaid(m.id).forEach((a) => {
        const property = PropertiesController.getAll().find((p) => p.id === a.propertyId);
        const record = maidAttendance.find((r) => r.maidId === m.id && r.propertyId === a.propertyId && r.date === today);
        rows.push({ maid: m, assignment: a, property, record });
      });
    });
    if (!rows.length) { box.innerHTML = '<div class="empty-state"><div class="desc">Koi maid abhi kisi flat mein assign nahi hai.</div></div>'; return; }

    box.innerHTML = rows.map((r) => `
      <div class="danger-row" style="align-items:center;">
        <div><b>${esc(r.maid.name)}</b> — ${r.property ? esc(r.property.name) : '—'}</div>
        <div style="display:flex; gap:6px;">
          <button class="btn small ${r.record?.status === 'Done' ? '' : 'secondary'} maid-att-btn" data-maid="${r.maid.id}" data-property="${r.assignment.propertyId}" data-status="Done" style="${r.record?.status === 'Done' ? 'background:var(--success);' : ''}">✓ Done</button>
          <button class="btn small ${r.record?.status === 'Not Done' ? '' : 'secondary'} maid-att-btn" data-maid="${r.maid.id}" data-property="${r.assignment.propertyId}" data-status="Not Done" style="${r.record?.status === 'Not Done' ? 'background:var(--error);' : ''}">✗ Not Done</button>
        </div>
      </div>`).join('');
    box.querySelectorAll('.maid-att-btn').forEach((btn) => btn.addEventListener('click', () => toggleMaidAttendance(btn.dataset.maid, btn.dataset.property, btn.dataset.status)));
  }

  function toggleMaidAttendance(maidId, propertyId, status) {
    const today = todayIso();
    const idx = maidAttendance.findIndex((r) => r.maidId === maidId && r.propertyId === propertyId && r.date === today);
    if (idx !== -1) maidAttendance[idx].status = status;
    else maidAttendance.push({ id: generateId(), maidId, propertyId, date: today, status });
    persistMaidAttendance();
    renderMaidTodayAttendance();
    if (viewingMaidId === maidId) renderMaidProfile(maidId);
  }

  function renderMaidCardsList() {
    const box = document.getElementById('maidCardsList');
    if (!box) return;
    if (!maids.length) { box.innerHTML = '<div class="empty-state"><div class="desc">Abhi tak koi maid add nahi hui.</div></div>'; return; }
    box.innerHTML = maids.map((m) => {
      const ledger = computeMaidLedger(m.id);
      return `
        <div class="owner-card maid-card" data-id="${m.id}" style="cursor:pointer;">
          <div class="oc-top">
            <div class="oc-avatar">🧹</div>
            <div><div class="oc-name">${esc(m.name)}</div><div class="oc-sub">${phoneLinks(m.mobile)}</div></div>
          </div>
          <div class="oc-row">Flats: ${ledger.flatsCount} · ${MAID_STATUS_ICON[ledger.status]} ${esc(ledger.status)}</div>
        </div>`;
    }).join('');
    box.querySelectorAll('.maid-card').forEach((card) => card.addEventListener('click', () => openMaidProfile(card.dataset.id)));
  }

  function openMaidProfile(maidId) {
    viewingMaidId = maidId;
    document.getElementById('maidListView').classList.add('hidden');
    document.getElementById('maidProfileView').classList.remove('hidden');
    renderMaidProfile(maidId);
  }
  function backToMaidList() {
    viewingMaidId = null;
    document.getElementById('maidProfileView').classList.add('hidden');
    document.getElementById('maidListView').classList.remove('hidden');
    renderMaidTodayAttendance();
    renderMaidCardsList();
  }

  function renderMaidProfile(maidId) {
    const m = maids.find((x) => x.id === maidId);
    if (!m) return;
    const ledger = computeMaidLedger(maidId);
    document.getElementById('maidProfileName').textContent = m.name;
    const badge = document.getElementById('maidProfileStatusBadge');
    badge.textContent = MAID_STATUS_ICON[ledger.status] + ' ' + ledger.status;

    document.getElementById('maidProfileStats').innerHTML = `
      <div class="stat-card"><div class="label">Flats</div><div class="value">${ledger.flatsCount}</div></div>
      <div class="stat-card"><div class="label">Monthly Payable</div><div class="value">₹${ledger.monthlyPayableTotal}</div></div>
      <div class="stat-card"><div class="label">Total Paid</div><div class="value">₹${ledger.totalPaid}</div></div>
      <div class="stat-card"><div class="label">${ledger.balance >= 0 ? 'Advance' : 'Pending'}</div><div class="value ${ledger.balance >= 0 ? 'success' : ''}">₹${Math.abs(ledger.balance)}</div></div>
    `;

    const assignBox = document.getElementById('maidAssignmentsList');
    const assignments = maidAssignments.filter((a) => a.maidId === maidId);
    assignBox.innerHTML = assignments.length ? assignments.map((a) => {
      const property = PropertiesController.getAll().find((p) => p.id === a.propertyId);
      return `
        <div class="history-item">
          <div class="hi-title">${property ? esc(property.name) : '—'} ${a.active === false ? '<span class="badge" style="margin-left:6px;">Inactive</span>' : ''}</div>
          <div class="hi-row">${esc(a.frequency)} · ₹${a.monthlyPayment}/month
            <button class="btn small secondary maid-assign-toggle-btn" data-id="${a.id}" style="margin-left:8px; padding:2px 8px;">${a.active === false ? 'Reactivate' : 'End Assignment'}</button>
          </div>
        </div>`;
    }).join('') : '<div class="empty-state"><div class="desc">Koi flat assign nahi hai.</div></div>';
    assignBox.querySelectorAll('.maid-assign-toggle-btn').forEach((btn) => btn.addEventListener('click', () => toggleMaidAssignmentActive(btn.dataset.id)));

    const payBox = document.getElementById('maidPaymentHistory');
    const payments = maidPayments.filter((p) => p.maidId === maidId).sort((a, b) => b.paymentDate.localeCompare(a.paymentDate));
    payBox.innerHTML = payments.length ? payments.map((p) => `
      <div class="history-item">
        <div class="hi-title">${fmtMonth(p.forMonth)} — ₹${p.amountPaid}</div>
        <div class="hi-row">${fmtDate(p.paymentDate)}${p.note ? ' · ' + esc(p.note) : ''}</div>
      </div>`).join('') : '<div class="empty-state"><div class="desc">Koi payment record nahi hai.</div></div>';

    const attBox = document.getElementById('maidAttendanceHistory');
    const records = maidAttendance.filter((r) => r.maidId === maidId).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 30);
    attBox.innerHTML = records.length ? records.map((r) => {
      const property = PropertiesController.getAll().find((p) => p.id === r.propertyId);
      return `<div class="history-item"><div class="hi-title">${fmtDate(r.date)} — ${property ? esc(property.name) : '—'}</div><div class="hi-row">${r.status === 'Done' ? '✓ Done' : '✗ Not Done'}</div></div>`;
    }).join('') : '<div class="empty-state"><div class="desc">Koi attendance record nahi hai.</div></div>';
  }

  function toggleMaidAssignmentActive(assignmentId) {
    const idx = maidAssignments.findIndex((a) => a.id === assignmentId);
    if (idx === -1) return;
    maidAssignments[idx].active = maidAssignments[idx].active === false ? true : false;
    persistMaidAssignments();
    renderMaidProfile(viewingMaidId);
  }

  function populateMaidFlatSelect(selectId) {
    const sel = document.getElementById(selectId);
    sel.innerHTML = '<option value="">Select Property</option>' + PropertiesController.getAll().map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
  }

  function openAddMaidModal() {
    document.getElementById('maidForm').reset();
    clearErrors('maidForm');
    populateMaidFlatSelect('maidFlatSelect');
    document.getElementById('maidModalOverlay').classList.add('open');
  }
  function closeMaidModal() { document.getElementById('maidModalOverlay').classList.remove('open'); }

  function handleSaveMaid() {
    const name = document.getElementById('maidName').value.trim();
    const mobile = document.getElementById('maidMobile').value.trim();
    const flatId = document.getElementById('maidFlatSelect').value;
    const frequency = document.getElementById('maidFrequency').value;
    const monthlyPayment = document.getElementById('maidMonthlyPayment').value;

    const errors = {};
    if (!name) errors.maidName = 'Maid name is required';
    if (!mobile || !/^\d{10}$/.test(mobile)) errors.maidMobile = 'Enter a valid 10-digit mobile number';
    if (!flatId) errors.maidFlatSelect = 'Select a flat';
    if (!monthlyPayment || Number(monthlyPayment) <= 0) errors.maidMonthlyPayment = 'Enter monthly payment';
    clearErrors('maidForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const now = new Date().toISOString();
    const newMaidId = generateId();
    maids.push({ id: newMaidId, maidCode: nextMaidCode(), name, mobile, createdAt: now });
    maidAssignments.push({ id: generateId(), maidId: newMaidId, propertyId: flatId, frequency, monthlyPayment: Number(monthlyPayment), active: true, createdAt: now });
    persistMaids();
    persistMaidAssignments();
    closeMaidModal();
    renderMaidTodayAttendance();
    renderMaidCardsList();
  }

  function openAddMaidAssignmentModal() {
    document.getElementById('maidAssignmentForm').reset();
    clearErrors('maidAssignmentForm');
    populateMaidFlatSelect('maidAssignFlatSelect');
    document.getElementById('maidAssignmentModalOverlay').classList.add('open');
  }
  function closeMaidAssignmentModal() { document.getElementById('maidAssignmentModalOverlay').classList.remove('open'); }

  function handleSaveMaidAssignment() {
    const flatId = document.getElementById('maidAssignFlatSelect').value;
    const frequency = document.getElementById('maidAssignFrequency').value;
    const monthlyPayment = document.getElementById('maidAssignMonthlyPayment').value;
    const errors = {};
    if (!flatId) errors.maidAssignFlatSelect = 'Select a flat';
    if (!monthlyPayment || Number(monthlyPayment) <= 0) errors.maidAssignMonthlyPayment = 'Enter monthly payment';
    clearErrors('maidAssignmentForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    maidAssignments.push({ id: generateId(), maidId: viewingMaidId, propertyId: flatId, frequency, monthlyPayment: Number(monthlyPayment), active: true, createdAt: new Date().toISOString() });
    persistMaidAssignments();
    closeMaidAssignmentModal();
    renderMaidProfile(viewingMaidId);
  }

  function openMaidPaymentModal() {
    const ledger = computeMaidLedger(viewingMaidId);
    document.getElementById('maidPaymentSummaryBox').innerHTML = `
      <div class="calc-row"><span>Monthly Payable</span><span>₹${ledger.monthlyPayableTotal}</span></div>
      <div class="calc-row total"><span>${ledger.balance >= 0 ? 'Current Advance' : 'Current Pending'}</span><span>₹${Math.abs(ledger.balance)}</span></div>
    `;
    document.getElementById('maidPaymentAmount').value = ledger.monthlyPayableTotal;
    document.getElementById('maidPaymentDate').value = todayIso();
    document.getElementById('maidPaymentForMonth').value = todayIso().slice(0, 7);
    document.getElementById('maidPaymentNote').value = '';
    document.querySelectorAll('#maidPaymentModalOverlay .form-error').forEach((el) => (el.textContent = ''));
    document.getElementById('maidPaymentModalOverlay').classList.add('open');
  }
  function closeMaidPaymentModal() { document.getElementById('maidPaymentModalOverlay').classList.remove('open'); }

  function handleSaveMaidPayment() {
    const amountPaid = document.getElementById('maidPaymentAmount').value;
    const paymentDate = document.getElementById('maidPaymentDate').value;
    const forMonth = document.getElementById('maidPaymentForMonth').value;
    const note = document.getElementById('maidPaymentNote').value.trim();
    const errors = {};
    if (!amountPaid || Number(amountPaid) <= 0) errors.maidPaymentAmount = 'Enter amount paid';
    if (!paymentDate) errors.maidPaymentDate = 'Payment date is required';
    if (!forMonth) errors.maidPaymentForMonth = 'Select which month this is for';
    document.querySelectorAll('#maidPaymentModalOverlay .form-error').forEach((el) => (el.textContent = ''));
    if (Object.keys(errors).length) {
      Object.entries(errors).forEach(([id, msg]) => { const el = document.getElementById('err-' + id); if (el) el.textContent = msg; });
      return;
    }
    maidPayments.push({ id: generateId(), maidId: viewingMaidId, amountPaid: Number(amountPaid), paymentDate, forMonth, note, createdAt: new Date().toISOString() });
    persistMaidPayments();
    closeMaidPaymentModal();
    renderMaidProfile(viewingMaidId);
  }

  // ======================================================================
  // SETUP EXPENSE INTEGRATION — Property's Initial Setup Expense links to
  // real Maintenance tickets instead of duplicating their cost data.
  // Tickets created here are immediately Closed (setup work is usually
  // already-known-cost), with the exact same closingDetails shape as a
  // normal ticket close, so Vendor Bills / Owner Work Report / Finance
  // all pick them up naturally with zero special-casing.
  // ======================================================================
  function createSetupWorkTicket({ propertyId, category, description, vendorName, labourActual, labourBilled, materials, costBearer }) {
    const now = new Date().toISOString();
    const matList = (materials || []).filter((m) => m.actualCost > 0 || m.chargedAmount > 0)
      .map((m) => ({ category: m.category, actualCost: m.actualCost, chargedAmount: m.chargedAmount, margin: m.chargedAmount - m.actualCost }));
    const materialActual = matList.reduce((s, m) => s + m.actualCost, 0);
    const materialBilled = matList.reduce((s, m) => s + m.chargedAmount, 0);
    const totalActual = (labourActual || 0) + materialActual;
    const totalBilled = (labourBilled || 0) + materialBilled;
    const newTicket = {
      id: generateId(), ticketId: nextTicketCode(), raisedBy: 'Fair Homes Staff', propertyId, roomId: null, tenantId: null,
      category, priority: 'Medium', description, images: [], dateTime: nowLocalInput(),
      costBearer: costBearer || 'Owner', estimatedAmount: totalBilled,
      status: 'Closed', assignment: null, approval: null, statusHistory: [],
      closingDetails: {
        labourActual: labourActual || 0, labourBilled: labourBilled || 0,
        materialActual, materialBilled, materials: matList,
        totalActual, totalBilled, margin: totalBilled - totalActual,
        vendorName: vendorName || '', invoiceNumber: '', expenseId: null, costBearer: costBearer || 'Owner',
      },
      linkedTo: null, // set once linked to Setup Expense, Move-Out, etc.
      createdAt: now, updatedAt: now,
    };
    pushHistory(newTicket, 'Closed', 'Created directly as Initial Setup Work');
    tickets.unshift(newTicket);
    persist();
    return newTicket;
  }

  /** Closed tickets for a property that aren't yet linked to ANY other
   *  module (Setup Expense, Move-Out Security Adjustment, etc.) — what
   *  "Link Existing Work" should offer, regardless of which module is
   *  asking. */
  function getUnlinkedClosedTicketsForProperty(propertyId) {
    return tickets.filter((t) => t.propertyId === propertyId && t.status === 'Closed' && t.closingDetails && !t.linkedTo);
  }
  /** type: 'setupExpense' | 'moveOut' — generic so any module can claim
   *  a ticket as "already accounted for" without a separate field per
   *  module, keeping the same ticket from being double-counted. */
  function linkTicketsTo(ticketIds, type, id) {
    tickets.forEach((t) => { if (ticketIds.includes(t.id)) t.linkedTo = { type, id }; });
    persist();
  }
  function unlinkTicket(ticketId) {
    const t = tickets.find((x) => x.id === ticketId);
    if (t) { t.linkedTo = null; persist(); }
  }
  function getTicketsLinkedTo(type, id) {
    return tickets.filter((t) => t.linkedTo && t.linkedTo.type === type && t.linkedTo.id === id);
  }

  function getAllTickets() { return [...tickets]; }
  function reload() { load(); onPageShow(); }

  return {
    init, onPageShow, getTicketsByProperty, getTicketsByTenant, getTicketsByRoom, getAllTickets, reload,
    getRoutineTasksForProperty, getRoutinePendingBilling, markRoutineTasksCollected,
    getActiveWorkTypesFlat, getTenantPendingMaintenanceBilling, markMaintenanceTicketsCollected,
    createSetupWorkTicket, getUnlinkedClosedTicketsForProperty, linkTicketsTo,
    unlinkTicket, getTicketsLinkedTo,
  };
})();
