/* ==========================================================================
   Fair Homes OS — Properties Module (updated: no manual name, BHK-driven
   rooms, rent-type-conditional beds, percentage-based auto-renewing
   brokerage). Full CRUD + validation + search/filter + owner linking +
   localStorage. Amenities as checklist+counts+notes.
   ========================================================================== */

const PropertiesController = (() => {
  const STORAGE_KEY = 'fh_properties';
  const SEQ_KEY = 'fh_property_id_seq';
  let properties = [];
  let setupExpenses = [];
  let electricityBills = [];
  let editingElectricityBillId = null;
  let viewingElectricityBillId = null;
  let electricityBillModalPropertyId = null;
  let setupExpenseModalPropertyId = null;
  let editingId = null;
  let viewingId = null;

  const STATUS_CLASS = {
    'Fully Vacant': 'status-available',
    'Partially Occupied': 'status-partial',
    'Fully Occupied': 'status-full',
    'Under Maintenance': 'status-maintenance',
  };

  const AMENITY_CHECKBOXES = [
    ['amParking', 'parking', 'Parking'], ['amLift', 'lift', 'Lift'], ['amPowerBackup', 'powerBackup', 'Power Backup'],
    ['amWifi', 'wifi', 'WiFi'], ['amRo', 'ro', 'RO'], ['amFridge', 'fridge', 'Fridge'], ['amChimney', 'chimney', 'Chimney'],
    ['amExhaustFan', 'exhaustFan', 'Exhaust Fan'], ['amStove', 'stove', 'Stove'], ['amCylinder', 'cylinder', 'Cylinder'],
    ['amInverter', 'inverter', 'Inverter'], ['amSofaSet', 'sofaSet', 'Sofa Set'], ['amBeds', 'beds', 'Beds'],
    ['amInduction', 'induction', 'Induction'], ['amSpeaker', 'speaker', 'Speaker'], ['amMicrowave', 'microwave', 'Microwave'],
  ];
  const AMENITY_COUNTS = [
    ['amAcCount', 'acCount', 'AC'], ['amGeyserCount', 'geyserCount', 'Geyser'], ['amFanCount', 'fanCount', 'Fan'],
    ['amLedCount', 'ledCount', 'LED'], ['amExtraMattress', 'extraMattress', 'Extra Mattress'], ['amExtraSofa', 'extraSofa', 'Extra Sofa'],
  ];

  // ---------------- Storage ----------------
  function load() {
    try { properties = JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
    catch (e) { properties = []; }
    CloudSync.watch('properties', (cloudProperties) => {
      properties = cloudProperties;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(properties));
      renderList();
      if (viewingId) renderDetail(viewingId);
    });

    try { setupExpenses = JSON.parse(localStorage.getItem('fh_setup_expenses')) || []; }
    catch (e) { setupExpenses = []; }
    CloudSync.watch('setupExpenses', (arr) => {
      setupExpenses = arr;
      localStorage.setItem('fh_setup_expenses', JSON.stringify(arr));
      if (viewingId) renderSetupExpenseList(viewingId);
    });

    try { electricityBills = JSON.parse(localStorage.getItem('fh_electricity_bills')) || []; }
    catch (e) { electricityBills = []; }
    CloudSync.watch('electricityBills', (arr) => {
      electricityBills = arr;
      localStorage.setItem('fh_electricity_bills', JSON.stringify(arr));
      if (viewingId) renderElectricityBillList(viewingId);
    });
  }
  function persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(properties));
    CloudSync.sync('properties', properties);
  }
  function persistSetupExpenses() {
    localStorage.setItem('fh_setup_expenses', JSON.stringify(setupExpenses));
    CloudSync.sync('setupExpenses', setupExpenses);
  }
  function persistElectricityBills() {
    localStorage.setItem('fh_electricity_bills', JSON.stringify(electricityBills));
    CloudSync.sync('electricityBills', electricityBills);
  }
  function generateId() {
    return (crypto.randomUUID ? crypto.randomUUID() : 'prop_' + Date.now() + '_' + Math.random().toString(16).slice(2));
  }
  function nextPropertyCode() {
    let seq = parseInt(localStorage.getItem(SEQ_KEY) || '0', 10) + 1;
    localStorage.setItem(SEQ_KEY, String(seq));
    return 'PROP-' + String(seq).padStart(4, '0');
  }
  function todayIso() { return new Date().toISOString().slice(0, 10); }
  function addOneYear(dateStr) {
    const d = new Date(dateStr);
    d.setFullYear(d.getFullYear() + 1);
    return d.toISOString().slice(0, 10);
  }
  function fmtDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return isNaN(d) ? iso : d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  // ---------------- Validation ----------------
  function validate(f) {
    const errors = {};
    if (!f.type) errors.propType = 'Select a property type';
    if (!f.ownerId) errors.propOwnerSelect = 'Select an owner';
    if (!f.address.trim()) errors.propAddress = 'Full address is required';
    if (!f.city.trim()) errors.propCity = 'City is required';
    if (!f.state.trim()) errors.propState = 'State is required';
    if (!f.pincode.trim()) errors.propPincode = 'Pincode is required';
    else if (!/^\d{6}$/.test(f.pincode.trim())) errors.propPincode = 'Enter a valid 6-digit pincode';
    if (f.society.trim() && f.flatNo.trim()) {
      const dup = properties.some((p) => p.id !== editingId && (p.society || '').trim().toLowerCase() === f.society.trim().toLowerCase() && (p.flatNo || '').trim().toLowerCase() === f.flatNo.trim().toLowerCase());
      if (dup) errors.propFlatNo = 'This flat number already exists in this society';
    }
    if (!f.bhk) errors.propBhk = 'Select BHK';
    if (!f.furnish) errors.propFurnish = 'Select furnishing status';
    if (f.rent === '' || Number(f.rent) < 0) errors.propRent = 'Enter monthly rent';
    if (f.mgmtFeePerRoom === '' || Number(f.mgmtFeePerRoom) < 0) errors.propMgmtFeePerRoom = 'Enter management fee per occupied room';
    if (!f.managementStartDate) errors.propManagementStartDate = 'Management start date is required';
    return errors;
  }
  function clearErrors() { document.querySelectorAll('#propertyForm .form-error').forEach((el) => (el.textContent = '')); }
  function showErrors(errors) { Object.entries(errors).forEach(([id, msg]) => { const el = document.getElementById('err-' + id); if (el) el.textContent = msg; }); }

  // ---------------- Owner select population ----------------
  function populateOwnerSelect() {
    const owners = OwnersController.getAll();
    const sel = document.getElementById('propOwnerSelect');
    const current = sel.value;
    sel.innerHTML = '<option value="">Select Owner</option>' + owners.map((o) => `<option value="${o.id}">${esc(o.fullName)}</option>`).join('');
    sel.value = current;
  }
  function ownerName(ownerId) {
    const owner = OwnersController.getAll().find((o) => o.id === ownerId);
    return owner ? owner.fullName : 'Unknown Owner';
  }

  // ---------------- BHK / Rent Type live behavior ----------------
  function updateBrokerageComputation() {
    const rent = Number(document.getElementById('propRent').value) || 0;
    const pct = Number(document.getElementById('propBrokeragePercent').value) || 0;
    const amount = Math.round(rent * pct / 100);
    document.getElementById('propBrokerageComputed').value = '₹' + amount;

    const startDate = document.getElementById('propBrokerageStartDate').value;
    document.getElementById('propNextBrokerageDate').value = startDate ? fmtDate(addOneYear(startDate)) : '';
  }

  // ---------------- Modal ----------------
  function openAddModal() {
    editingId = null;
    document.getElementById('propModalTitle').textContent = 'Add Property';
    document.getElementById('propertyForm').reset();
    document.getElementById('propId').value = '';
    document.getElementById('propBrokerageStartDate').value = todayIso();
    document.getElementById('propManagementStartDate').value = todayIso();
    document.getElementById('propTrialFeeFields').classList.add('hidden');
    populateOwnerSelect();
    clearErrors();
    updateBrokerageComputation();
    document.getElementById('propModalOverlay').classList.add('open');
  }

  function openEditModal(id) {
    const p = properties.find((x) => x.id === id);
    if (!p) return;
    editingId = id;
    document.getElementById('propModalTitle').textContent = 'Edit Property';
    populateOwnerSelect();

    document.getElementById('propId').value = p.id;
    document.getElementById('propType').value = p.type || '';
    document.getElementById('propOwnerSelect').value = p.ownerId || '';
    document.getElementById('propSociety').value = p.society || '';
    document.getElementById('propBlock').value = p.block || '';
    document.getElementById('propFloor').value = p.floor || '';
    document.getElementById('propFlatNo').value = p.flatNo || '';
    document.getElementById('propAddress').value = p.address || '';
    document.getElementById('propCity').value = p.city || '';
    document.getElementById('propState').value = p.state || '';
    document.getElementById('propPincode').value = p.pincode || '';
    document.getElementById('propBhk').value = p.bhk || '';
    document.getElementById('propFurnish').value = p.furnish || '';

    const am = p.amenities || {};
    AMENITY_CHECKBOXES.forEach(([elId, key]) => { document.getElementById(elId).checked = !!am[key]; });
    AMENITY_COUNTS.forEach(([elId, key]) => { document.getElementById(elId).value = am[key] ?? ''; });
    document.getElementById('amWashingMachine').value = am.washingMachine || 'None';
    document.getElementById('amOtherNotes').value = am.otherNotes || '';

    document.getElementById('propRent').value = p.rent ?? '';
    document.getElementById('propDeposit').value = p.deposit ?? '';
    document.getElementById('propMgmtFeePerRoom').value = p.mgmtFeePerRoom ?? '';
    document.getElementById('propHasTrialFee').checked = !!p.hasTrialFee;
    document.getElementById('propTrialFeeFields').classList.toggle('hidden', !p.hasTrialFee);
    document.getElementById('propTrialFeePerRoom').value = p.trialFeePerRoom ?? '';
    document.getElementById('propTrialStartDate').value = p.trialStartDate || '';
    document.getElementById('propTrialEndDate').value = p.trialEndDate || '';
    document.getElementById('propBrokeragePercent').value = p.brokeragePercent ?? '';
    document.getElementById('propBrokerageStartDate').value = p.brokerageStartDate || todayIso();
    document.getElementById('propOnboardingOccupancy').value = p.onboardingOccupancy || 'Vacant';
    document.getElementById('propManagementStartDate').value = p.managementStartDate || '';
    document.getElementById('propUnderMaintenance').checked = !!p.underMaintenance;
    updateBrokerageComputation();

    clearErrors();
    document.getElementById('propModalOverlay').classList.add('open');
  }

  function closeModal() { document.getElementById('propModalOverlay').classList.remove('open'); editingId = null; }

  function handleSave() {
    const f = {
      type: document.getElementById('propType').value,
      ownerId: document.getElementById('propOwnerSelect').value,
      society: document.getElementById('propSociety').value,
      block: document.getElementById('propBlock').value,
      floor: document.getElementById('propFloor').value,
      flatNo: document.getElementById('propFlatNo').value,
      address: document.getElementById('propAddress').value,
      city: document.getElementById('propCity').value,
      state: document.getElementById('propState').value,
      pincode: document.getElementById('propPincode').value,
      bhk: document.getElementById('propBhk').value,
      furnish: document.getElementById('propFurnish').value,
      rent: document.getElementById('propRent').value,
      deposit: document.getElementById('propDeposit').value,
      mgmtFeePerRoom: document.getElementById('propMgmtFeePerRoom').value,
      hasTrialFee: document.getElementById('propHasTrialFee').checked,
      trialFeePerRoom: document.getElementById('propTrialFeePerRoom').value,
      trialStartDate: document.getElementById('propTrialStartDate').value,
      trialEndDate: document.getElementById('propTrialEndDate').value,
      brokeragePercent: document.getElementById('propBrokeragePercent').value,
      brokerageStartDate: document.getElementById('propBrokerageStartDate').value,
      onboardingOccupancy: document.getElementById('propOnboardingOccupancy').value,
      managementStartDate: document.getElementById('propManagementStartDate').value,
      underMaintenance: document.getElementById('propUnderMaintenance').checked,
    };

    clearErrors();
    const errors = validate(f);
    if (Object.keys(errors).length > 0) { showErrors(errors); return; }

    const amenities = {};
    AMENITY_CHECKBOXES.forEach(([elId, key]) => { amenities[key] = document.getElementById(elId).checked; });
    AMENITY_COUNTS.forEach(([elId, key]) => { amenities[key] = Number(document.getElementById(elId).value) || 0; });
    amenities.washingMachine = document.getElementById('amWashingMachine').value;
    amenities.otherNotes = document.getElementById('amOtherNotes').value.trim();

    // Property Name is no longer manually entered — auto-derived so every
    // other module (Rooms, Tenants, Finance, Maintenance, Reports,
    // Notifications, Settings) that displays/selects properties by `name`
    // keeps working unchanged.
    const autoName = [f.society.trim(), f.flatNo.trim() ? 'Flat ' + f.flatNo.trim() : ''].filter(Boolean).join(' — ')
      || (f.type + ' Property');

    const now = new Date().toISOString();
    const rentNum = Number(f.rent) || 0;
    const brokeragePercent = Number(f.brokeragePercent) || 0;
    const propData = {
      name: autoName, type: f.type, ownerId: f.ownerId,
      society: f.society.trim(), block: f.block.trim(), floor: f.floor.trim(), flatNo: f.flatNo.trim(),
      address: f.address.trim(), city: f.city.trim(), state: f.state.trim(), pincode: f.pincode.trim(),
      bhk: f.bhk,
      furnish: f.furnish, amenities,
      rent: rentNum, deposit: Number(f.deposit) || 0,
      mgmtFeePerRoom: Number(f.mgmtFeePerRoom) || 0, hasTrialFee: f.hasTrialFee,
      trialFeePerRoom: Number(f.trialFeePerRoom) || 0, trialStartDate: f.trialStartDate || null, trialEndDate: f.trialEndDate || null,
      brokeragePercent, brokerage: Math.round(rentNum * brokeragePercent / 100),
      brokerageStartDate: f.brokerageStartDate || todayIso(),
      onboardingOccupancy: f.onboardingOccupancy, managementStartDate: f.managementStartDate,
      underMaintenance: f.underMaintenance, updatedAt: now,
    };

    if (editingId) {
      const idx = properties.findIndex((p) => p.id === editingId);
      if (idx !== -1) properties[idx] = { ...properties[idx], ...propData };
    } else {
      properties.unshift({ id: generateId(), propertyCode: nextPropertyCode(), createdAt: now, ...propData });
    }

    persist();
    closeModal();
    populateFilters();
    renderList();
    if (viewingId) renderDetail(viewingId);
  }

  function handleDelete(id) {
    const p = properties.find((x) => x.id === id);
    if (!p) return;
    ConfirmModal.show(`Delete "${p.society || p.name}"?`, () => {
      TrashController.moveToTrash('property', p, p.society || p.name);
      properties = properties.filter((x) => x.id !== id);
      persist();
      renderList();
      if (viewingId === id) backToList();
    }, 'Delete Property');
  }

  // ---------------- Filters ----------------
  function populateFilters() {
    const types = [...new Set(properties.map((p) => p.type))].sort();
    const typeSel = document.getElementById('propTypeFilter');
    const currentType = typeSel.value;
    typeSel.innerHTML = '<option value="all">All Types</option>' + types.map((t) => `<option value="${t}">${t}</option>`).join('');
    typeSel.value = currentType || 'all';
  }

  /** Live occupancy from Rooms — never stored/stale. */
  function computeOccupancy(propertyId) {
    if (typeof RoomsController === 'undefined') return { status: 'Not tracked', tags: [] };
    const rooms = RoomsController.getRoomsByProperty(propertyId);
    if (!rooms.length) return { status: 'Not tracked (no rooms added)', tags: [] };

    const property = properties.find((p) => p.id === propertyId);
    const tags = property && property.tenantTypeRestriction ? [property.tenantTypeRestriction] : [];
    const vacantRooms = rooms.filter((r) => RoomsController.computeRoomStatus(r.id) === 'Available');

    if (vacantRooms.length === 0) return { status: 'Fully Occupied', detail: '', tags };
    if (vacantRooms.length === rooms.length) return { status: 'Fully Vacant', detail: '', tags };
    return { status: 'Partially Occupied', detail: `${vacantRooms.length} of ${rooms.length} room(s) vacant`, tags };
  }

  // ---------------- List Rendering ----------------
  function renderList() {
    const query = (document.getElementById('propSearchInput')?.value || '').toLowerCase().trim();
    const typeFilter = document.getElementById('propTypeFilter')?.value || 'all';
    const statusFilter = document.getElementById('propStatusFilter')?.value || 'all';

    const filtered = properties.filter((p) => {
      const liveStatus = p.underMaintenance ? 'Under Maintenance' : computeOccupancy(p.id).status;
      return (p.name.toLowerCase().includes(query) || (p.society || '').toLowerCase().includes(query) || p.propertyCode.toLowerCase().includes(query)) &&
        (typeFilter === 'all' || p.type === typeFilter) &&
        (statusFilter === 'all' || liveStatus === statusFilter);
    });

    document.getElementById('propCountChip').textContent = properties.length + (properties.length === 1 ? ' property' : ' properties');

    const grid = document.getElementById('propertiesGrid');
    if (!filtered.length) {
      grid.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="ico">🏢</div>
          <div class="title">${properties.length === 0 ? 'No properties yet' : 'No matching properties'}</div>
          <div class="desc">${properties.length === 0 ? 'Add your first property to get started.' : 'Try a different search or filter.'}</div>
        </div>`;
      return;
    }

    grid.innerHTML = filtered.map((p) => {
      const occ = computeOccupancy(p.id);
      const displayStatus = p.underMaintenance ? 'Under Maintenance' : occ.status;
      const occBadgeClass = STATUS_CLASS[displayStatus] || (occ.status === 'Fully Occupied' ? 'status-full' : occ.status === 'Fully Vacant' ? 'status-available' : occ.status === 'Partially Occupied' ? 'status-partial' : '');
      const tagLabel = occ.tags.length ? (occ.status === 'Fully Occupied' ? 'Occupied by: ' : 'For: ') + occ.tags.join(', ') : '';
      return `
      <div class="owner-card" data-id="${p.id}">
        <div class="oc-top">
          <div class="oc-avatar">🏢</div>
          <div>
            <div class="oc-name">${esc(p.society || p.name)}${p.flatNo ? ' — Flat ' + esc(p.flatNo) : ''}</div>
            <div class="oc-sub">${esc(p.propertyCode)} · <span class="prop-type-badge">${esc(p.type)}</span></div>
          </div>
        </div>
        <div class="oc-row">👤 ${esc(ownerName(p.ownerId))}</div>
        <div class="oc-row">🛏️ ${esc(p.bhk || '—')}</div>
        <div class="oc-row">💰 ₹${p.rent}/mo</div>
        <div style="margin-top:8px; display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
          <span class="badge ${occBadgeClass}">${esc(displayStatus)}</span>
          ${occ.detail ? `<span class="na-note">${esc(occ.detail)}</span>` : ''}
        </div>
        ${tagLabel ? `<div class="oc-row" style="margin-top:4px;">🏷️ ${esc(tagLabel)}</div>` : ''}
        <div class="oc-actions">
          <button class="btn small secondary pc-edit-btn" data-id="${p.id}">Edit</button>
          <button class="btn small pc-delete-btn" data-id="${p.id}" style="background:var(--error);">Delete</button>
        </div>
      </div>
    `;
    }).join('');

    grid.querySelectorAll('.owner-card').forEach((card) => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('.pc-edit-btn') || e.target.closest('.pc-delete-btn')) return;
        renderDetail(card.dataset.id);
      });
    });
    grid.querySelectorAll('.pc-edit-btn').forEach((btn) => btn.addEventListener('click', (e) => { e.stopPropagation(); openEditModal(btn.dataset.id); }));
    grid.querySelectorAll('.pc-delete-btn').forEach((btn) => btn.addEventListener('click', (e) => { e.stopPropagation(); handleDelete(btn.dataset.id); }));
  }

  // ---------------- Detail View ----------------
  function renderDetail(id) {
    const p = properties.find((x) => x.id === id);
    if (!p) return;
    viewingId = id;

    document.getElementById('pdName').textContent = (p.society || p.name) + (p.flatNo ? ' — Flat ' + p.flatNo : '');
    document.getElementById('pdIdType').textContent = p.propertyCode + ' · ' + p.type;
    const statusBadge = document.getElementById('pdStatusBadge');
    const liveOcc = computeOccupancy(id);
    const displayStatus = p.underMaintenance ? 'Under Maintenance' : liveOcc.status;
    statusBadge.textContent = displayStatus;
    statusBadge.className = 'badge ' + (STATUS_CLASS[displayStatus] || '');

    setVal('pdOwner', ownerName(p.ownerId));
    const rs = p.routineServices || { roCandle: true, acFilter: true, inverter: true, maid: true, chimney: true };
    document.getElementById('pdRoutineRoCandle').checked = rs.roCandle !== false;
    document.getElementById('pdRoutineAcFilter').checked = rs.acFilter !== false;
    document.getElementById('pdRoutineInverter').checked = rs.inverter !== false;
    document.getElementById('pdRoutineMaid').checked = rs.maid !== false;
    document.getElementById('pdRoutineChimney').checked = rs.chimney !== false;
    setVal('pdPropId', p.propertyCode);
    setVal('pdType', p.type);
    setVal('pdSociety', p.society);
    setVal('pdBlock', p.block);
    setVal('pdFloor', p.floor);
    setVal('pdFlatNo', p.flatNo);
    setVal('pdCity', p.city);
    setVal('pdState', p.state);
    setVal('pdPincode', p.pincode);
    setVal('pdAddress', p.address);
    setVal('pdBhk', p.bhk);
    setVal('pdRooms', String(p.rooms));
    setVal('pdBeds', p.rentType === 'Seat-wise' ? String(p.beds) : 'N/A (' + (p.rentType || 'Whole Flat') + ')');
    setVal('pdFurnish', p.furnish);

    const am = p.amenities || {};
    const pills = [];
    AMENITY_CHECKBOXES.forEach(([, key, label]) => { if (am[key]) pills.push(label); });
    AMENITY_COUNTS.forEach(([, key, label]) => { if (am[key] > 0) pills.push(`${label} × ${am[key]}`); });
    if (am.washingMachine && am.washingMachine !== 'None') pills.push('Washing Machine (' + am.washingMachine + ')');
    document.getElementById('pdAmenities').innerHTML = pills.length
      ? pills.map((a) => `<span class="amenity-pill">${esc(a)}</span>`).join('')
      : '<span class="di-value empty">None selected</span>';
    setVal('pdAmenitiesNotes', am.otherNotes);

    setVal('pdRent', '₹' + p.rent);
    setVal('pdDeposit', p.deposit ? '₹' + p.deposit : '');
    setVal('pdBrokerage', p.brokeragePercent ? p.brokeragePercent + '% (₹' + p.brokerage + ')' : '');
    setVal('pdNextBrokerage', p.brokerageStartDate ? fmtDate(addOneYear(p.brokerageStartDate)) : '');
    let mgmtFeeDisplay = p.mgmtFeePerRoom ? '₹' + p.mgmtFeePerRoom + '/occupied room' : '';
    if (p.hasTrialFee && p.trialFeePerRoom) mgmtFeeDisplay += ` (Trial: ₹${p.trialFeePerRoom} till ${p.trialEndDate ? fmtDate(p.trialEndDate) : '—'})`;
    setVal('pdMgmtCharge', mgmtFeeDisplay);

    renderComplaintHistory(p.id);

    document.getElementById('pdEditBtn').onclick = () => openEditModal(p.id);
    document.getElementById('pdDeleteBtn').onclick = () => handleDelete(p.id);
    document.getElementById('pdSaveRoutineServicesBtn').onclick = () => handleSaveRoutineServices(p.id);
    document.getElementById('pdAddSetupExpenseBtn').onclick = () => openAddSetupExpenseModal(p.id);
    renderSetupExpenseList(p.id);
    document.getElementById('pdAddElectricityBillBtn').onclick = () => openAddElectricityBillModal(p.id);
    renderElectricityBillList(p.id);

    document.getElementById('propertiesListView').classList.add('hidden');
    document.getElementById('propertyDetailView').classList.remove('hidden');
  }

  function renderComplaintHistory(propertyId) {
    const box = document.getElementById('pdComplaintHistory');
    if (typeof MaintenanceController === 'undefined') { box.innerHTML = ''; return; }
    const tickets = MaintenanceController.getTicketsByProperty(propertyId);
    const statusClassMap = { Open: 'status-open', Assigned: 'status-assigned', 'In Progress': 'status-inprogress', Completed: 'status-completed', Closed: 'status-closed', Cancelled: 'status-cancelled' };
    box.innerHTML = tickets.length
      ? tickets.slice().sort((a, b) => b.dateTime.localeCompare(a.dateTime)).map((t) => `
          <div class="history-item">
            <div class="hi-title">${esc(t.category)} — ${esc(t.ticketId)} <span class="badge ${statusClassMap[t.status]}" style="margin-left:6px;">${t.status}</span></div>
            <div class="hi-row">${t.dateTime.replace('T', ' ')} · Priority: ${esc(t.priority)}</div>
          </div>`).join('')
      : '<div class="empty-state"><div class="desc">No maintenance complaints for this property yet.</div></div>';
  }

  function setVal(elId, value) {
    const el = document.getElementById(elId);
    if (value && String(value).trim()) { el.textContent = value; el.classList.remove('empty'); }
    else { el.textContent = 'Not provided'; el.classList.add('empty'); }
  }

  function backToList() {
    viewingId = null;
    document.getElementById('propertyDetailView').classList.add('hidden');
    document.getElementById('propertiesListView').classList.remove('hidden');
    renderList();
  }

  // ---------------- Helpers ----------------
  function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function getAll() { return [...properties]; }

  /**
   * Used by Finance's Rent Collection to detect and auto-record the
   * annual brokerage renewal. Returns whether it's currently due, the
   * computed amount, and the due date — never mutates state itself.
   */
  function getBrokerageDueInfo(propertyId) {
    const p = properties.find((x) => x.id === propertyId);
    if (!p || !p.brokeragePercent || !p.brokerageStartDate) return { due: false };
    const dueDate = addOneYear(p.brokerageStartDate);
    const due = todayIso() >= dueDate;
    return { due, amount: p.brokerage || Math.round((p.rent || 0) * p.brokeragePercent / 100), dueDate, propertyName: p.society || p.name };
  }

  /** Advances the brokerage cycle by exactly 1 year from the due date (not
   *  "today"), so the annual cadence never drifts even if collected late. */
  function advanceBrokerageCycle(propertyId) {
    const p = properties.find((x) => x.id === propertyId);
    if (!p || !p.brokerageStartDate) return;
    p.brokerageStartDate = addOneYear(p.brokerageStartDate);
    p.updatedAt = new Date().toISOString();
    persist();
    if (viewingId === propertyId) renderDetail(propertyId);
    renderList();
  }

  // ---------------- Init / Bindings ----------------
  function bindEvents() {
    document.getElementById('addPropertyBtn').addEventListener('click', openAddModal);
    document.getElementById('propModalCloseBtn').addEventListener('click', closeModal);
    document.getElementById('propCancelBtn').addEventListener('click', closeModal);
    document.getElementById('propSaveBtn').addEventListener('click', handleSave);
    document.getElementById('propHasTrialFee').addEventListener('change', (e) => {
      document.getElementById('propTrialFeeFields').classList.toggle('hidden', !e.target.checked);
    });
    document.getElementById('propModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'propModalOverlay') closeModal(); });

    document.getElementById('setupExpenseModalCloseBtn').addEventListener('click', closeSetupExpenseModal);
    document.getElementById('setupExpenseCancelBtn').addEventListener('click', closeSetupExpenseModal);
    document.getElementById('setupExpenseModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'setupExpenseModalOverlay') closeSetupExpenseModal(); });
    document.getElementById('setupExpenseSaveBtn').addEventListener('click', handleSaveSetupExpense);

    document.getElementById('electricityBillModalCloseBtn').addEventListener('click', closeElectricityBillModal);
    document.getElementById('electricityBillCancelBtn').addEventListener('click', closeElectricityBillModal);
    document.getElementById('electricityBillModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'electricityBillModalOverlay') closeElectricityBillModal(); });
    document.getElementById('electricityBillSaveBtn').addEventListener('click', handleSaveElectricityBill);
    ['electricityBillMonth', 'electricityBillAmount'].forEach((id) => {
      document.getElementById(id).addEventListener('input', updateElectricityBillPreview);
    });

    document.getElementById('electricityBillDetailModalCloseBtn').addEventListener('click', closeElectricityBillDetailModal);
    document.getElementById('electricityBillDetailCloseBtn').addEventListener('click', closeElectricityBillDetailModal);
    document.getElementById('electricityBillDetailModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'electricityBillDetailModalOverlay') closeElectricityBillDetailModal(); });
    document.getElementById('electricityBillDetailEditBtn').addEventListener('click', () => openEditElectricityBillModal(viewingElectricityBillId));
    document.getElementById('setupExpenseScenario').addEventListener('change', toggleSetupExpenseScenarioFields);
    document.getElementById('setupOwnerAdvanceReceived').addEventListener('input', updateSetupScenario1Calc);

    document.getElementById('setupAddWorkBtn').addEventListener('click', openAddWorkModal);
    document.getElementById('setupAddWorkModalCloseBtn').addEventListener('click', closeAddWorkModal);
    document.getElementById('setupAddWorkCancelBtn').addEventListener('click', closeAddWorkModal);
    document.getElementById('setupAddWorkModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'setupAddWorkModalOverlay') closeAddWorkModal(); });
    document.getElementById('setupWorkTabExisting').addEventListener('click', () => switchSetupWorkTab('existing'));
    document.getElementById('setupWorkTabNew').addEventListener('click', () => switchSetupWorkTab('new'));
    document.getElementById('setupNewWorkTypeSelect').addEventListener('change', onSetupWorkTypeSelected);
    document.getElementById('setupNewWorkAddMaterialBtn').addEventListener('click', addSetupMaterialRow);
    document.getElementById('setupCreateWorkSaveBtn').addEventListener('click', handleCreateAndLinkWork);

    document.getElementById('propSearchInput').addEventListener('input', renderList);
    document.getElementById('propTypeFilter').addEventListener('change', renderList);
    document.getElementById('propStatusFilter').addEventListener('change', renderList);
    document.getElementById('propBackBtn').addEventListener('click', backToList);
    document.getElementById('propPincode').addEventListener('input', (e) => { e.target.value = e.target.value.replace(/\D/g, ''); });

    document.getElementById('propRent').addEventListener('input', updateBrokerageComputation);
    document.getElementById('propBrokeragePercent').addEventListener('input', updateBrokerageComputation);
    document.getElementById('propBrokerageStartDate').addEventListener('change', updateBrokerageComputation);
  }

  function init() {
    load();
    bindEvents();
    populateFilters();
    renderList();
  }

  function reload() { load(); renderList(); }

  function bulkImport(records) {
    const now = new Date().toISOString();
    records.forEach((r) => {
      properties.unshift({
        id: (crypto.randomUUID ? crypto.randomUUID() : 'prop_' + Date.now() + '_' + Math.random().toString(16).slice(2)),
        propertyCode: nextPropertyCode(),
        name: r.name || (r.city || 'Imported Property'), type: r.type || 'Flat', ownerId: null,
        society: r.name || '', block: '', floor: '', flatNo: '',
        address: r.address || '', city: r.city || '', state: r.state || '', pincode: r.pincode || '',
        bhk: '', rentType: 'Whole Flat', rooms: 0, beds: 0, furnish: 'Unfurnished',
        amenities: {},
        rent: Number(r.rent) || 0, deposit: 0, maintCharge: 0, mgmtCharge: 0,
        brokeragePercent: 0, brokerage: 0, brokerageStartDate: now.slice(0, 10),
        status: 'Available', createdAt: now, updatedAt: now,
      });
    });
    persist();
    renderList();
  }

  /** Sets or clears a property's tenant-type restriction — called by
   *  Rooms/Bookings when the first tenant type is decided, or when a
   *  property becomes fully vacant again (pass null to clear). */
  function updateTenantTypeRestriction(propertyId, type) {
    const idx = properties.findIndex((p) => p.id === propertyId);
    if (idx === -1) return;
    properties[idx].tenantTypeRestriction = type;
    properties[idx].updatedAt = new Date().toISOString();
    persist();
  }

  /** Reconstructs a room's occupied date-intervals from whoever's
   *  currently allocated there plus everyone's move-out history for
   *  that room — used to figure out exactly how many days in a given
   *  month the room was actually occupied, for pro-rata Management Fee. */
  function getRoomOccupancyIntervals(roomId) {
    if (typeof TenantsController === 'undefined') return [];
    const intervals = [];
    const today = new Date().toISOString().slice(0, 10);
    TenantsController.getAll().forEach((t) => {
      if (t.currentAllocation && t.currentAllocation.roomId === roomId && t.currentAllocation.moveInDate) {
        intervals.push({ start: t.currentAllocation.moveInDate, end: today });
      }
      (t.moveOutHistory || []).forEach((h) => {
        if (h.roomId === roomId && h.moveInDate) {
          intervals.push({ start: h.moveInDate, end: h.moveOutDate || h.moveInDate });
        }
      });
    });
    return intervals;
  }

  /** Counts how many distinct calendar days within [monthStart,
   *  monthEnd] fall inside ANY occupancy interval — merges overlapping
   *  co-tenant stays automatically (a day is only counted once even if
   *  2-3 tenants were in the room that day). */
  function countOccupiedDaysInMonth(intervals, year, month) {
    const daysInMonth = new Date(year, month, 0).getDate();
    const occupied = new Set();
    intervals.forEach((iv) => {
      const start = new Date(iv.start);
      const end = new Date(iv.end);
      for (let d = 1; d <= daysInMonth; d++) {
        const day = new Date(year, month - 1, d);
        if (day >= start && day <= end) occupied.add(d);
      }
    });
    return occupied.size;
  }

  /** Same shape as getRoomOccupancyIntervals but keeps WHO was in the
   *  room for each interval — needed to split a room's electricity
   *  share among tenants when the room changed hands mid-period. */
  function getRoomOccupancyIntervalsWithTenant(roomId) {
    if (typeof TenantsController === 'undefined') return [];
    const intervals = [];
    const today = new Date().toISOString().slice(0, 10);
    TenantsController.getAll().forEach((t) => {
      if (t.currentAllocation && t.currentAllocation.roomId === roomId && t.currentAllocation.moveInDate) {
        intervals.push({ tenantId: t.id, tenantName: t.fullName, start: t.currentAllocation.moveInDate, end: today });
      }
      (t.moveOutHistory || []).forEach((h) => {
        if (h.roomId === roomId && h.moveInDate) {
          intervals.push({ tenantId: t.id, tenantName: t.fullName, start: h.moveInDate, end: h.moveOutDate || h.moveInDate });
        }
      });
    });
    return intervals;
  }

  /** Counts distinct days within [rangeStart, rangeEnd] (inclusive,
   *  arbitrary dates — not locked to a calendar month, since electricity
   *  billing periods rarely align exactly) that fall inside ANY given
   *  interval — merges overlaps so a day is never double-counted. */
  function countOccupiedDaysInRange(rangeStart, rangeEnd, intervals) {
    const start = new Date(rangeStart);
    const end = new Date(rangeEnd);
    const occupied = new Set();
    intervals.forEach((iv) => {
      const ivStart = new Date(iv.start);
      const ivEnd = new Date(iv.end);
      const from = ivStart > start ? ivStart : start;
      const to = ivEnd < end ? ivEnd : end;
      for (let d = new Date(from); d <= to; d.setDate(d.getDate() + 1)) {
        occupied.add(d.toISOString().slice(0, 10));
      }
    });
    return occupied.size;
  }

  /** The full Room-Day electricity split: Total Bill ÷ Total Occupied
   *  Room-Days × each room's own occupied days, then within a room
   *  further split by each tenant's day-count there (handles both a
   *  mid-period tenant change AND simultaneous co-tenants uniformly,
   *  since either way tenants' day-counts sum correctly against the
   *  room total). Vacant rooms get ₹0. Rounding is swept into the
   *  LAST room/tenant so the total always matches the bill exactly. */
  function addDaysIso(dateStr, n) {
    const d = new Date(dateStr);
    d.setDate(d.getDate() + n);
    return d.toISOString().slice(0, 10);
  }
  function daysBetweenIso(d1, d2) {
    return Math.round((new Date(d2) - new Date(d1)) / 86400000);
  }

  /** Period-Based Equal-Split electricity calculation — NOT a simple
   *  room-day proportion. The billing period is first cut into
   *  sub-periods at every point where the SET of occupied rooms
   *  changes (a move-in or move-out). Each sub-period's own bill
   *  (daily rate × its days) is split EQUALLY among however many
   *  rooms were occupied during THAT sub-period — 3 occupied rooms
   *  share a sub-period equally, 1 occupied room takes all of it, a
   *  vacant room gets nothing for that stretch. A room's final amount
   *  is the sum of its share across every sub-period it was occupied
   *  in. Room headcount never enters this — 1 or 2 tenants in a room
   *  make no difference to the room's own share. Only afterward is a
   *  room's total divided among ITS tenants, by each tenant's own
   *  occupied days, exactly as for a mid-period tenant replacement. */
  function computeElectricitySplit(propertyId, periodStart, periodEnd, totalAmount) {
    const rooms = typeof RoomsController !== 'undefined' ? RoomsController.getRoomsByProperty(propertyId) : [];
    const roomData = rooms.map((r) => ({ roomId: r.id, roomNumber: r.roomNumber, intervals: getRoomOccupancyIntervalsWithTenant(r.id) }));

    const totalDays = daysBetweenIso(periodStart, periodEnd) + 1;
    if (totalDays <= 0 || !roomData.length) return { totalRoomDays: 0, rate: 0, roomBreakdown: roomData.map((r) => ({ roomId: r.roomId, roomNumber: r.roomNumber, occupiedDays: 0, amount: 0, tenantBreakdown: [] })) };
    const dailyRate = totalAmount / totalDays;
    const periodEndExclusive = addDaysIso(periodEnd, 1);

    // Every date where some room's occupancy starts or ends (clamped to
    // the billing period) is a sub-period boundary.
    const breakpoints = new Set([periodStart, periodEndExclusive]);
    roomData.forEach((r) => r.intervals.forEach((iv) => {
      const s = iv.start < periodStart ? periodStart : iv.start;
      const eNext = addDaysIso(iv.end, 1);
      if (s >= periodStart && s <= periodEndExclusive) breakpoints.add(s);
      if (eNext >= periodStart && eNext <= periodEndExclusive) breakpoints.add(eNext);
    }));
    const sortedBP = [...breakpoints].sort();

    const roomTotals = {};
    const roomOccupiedDays = {};
    const roomTenantDays = {};
    roomData.forEach((r) => { roomTotals[r.roomId] = 0; roomOccupiedDays[r.roomId] = 0; roomTenantDays[r.roomId] = {}; });

    for (let i = 0; i < sortedBP.length - 1; i++) {
      const pStart = sortedBP[i];
      const pEndExcl = sortedBP[i + 1];
      const pDays = daysBetweenIso(pStart, pEndExcl);
      if (pDays <= 0) continue;
      const periodBill = dailyRate * pDays;

      const occupiedRoomIds = roomData.filter((r) => r.intervals.some((iv) => iv.start <= pStart && pStart < addDaysIso(iv.end, 1))).map((r) => r.roomId);
      if (!occupiedRoomIds.length) continue;
      const perRoomShare = periodBill / occupiedRoomIds.length;

      occupiedRoomIds.forEach((rid) => {
        roomTotals[rid] += perRoomShare;
        roomOccupiedDays[rid] += pDays;
        const room = roomData.find((r) => r.roomId === rid);
        room.intervals.forEach((iv) => {
          if (iv.start <= pStart && pStart < addDaysIso(iv.end, 1)) {
            roomTenantDays[rid][iv.tenantId] = roomTenantDays[rid][iv.tenantId] || { tenantName: iv.tenantName, days: 0 };
            roomTenantDays[rid][iv.tenantId].days += pDays;
          }
        });
      });
    }

    // Rounding: sweep any leftover paise into the last room, and
    // within each room into that room's last tenant, so the total
    // always matches the bill exactly.
    const roomIds = roomData.map((r) => r.roomId);
    let runningTotal = 0;
    const roomBreakdown = roomIds.map((rid, idx) => {
      const room = roomData.find((r) => r.roomId === rid);
      const isLastRoom = idx === roomIds.length - 1;
      let roomAmount = isLastRoom ? Math.round((totalAmount - runningTotal) * 100) / 100 : Math.round(roomTotals[rid] * 100) / 100;
      if (!isLastRoom) runningTotal += roomAmount;

      const tenantIds = Object.keys(roomTenantDays[rid]);
      const totalTenantDays = tenantIds.reduce((s, id) => s + roomTenantDays[rid][id].days, 0);
      let tenantRunning = 0;
      const tenantBreakdown = tenantIds.map((tid, tIdx) => {
        const isLastTenant = tIdx === tenantIds.length - 1;
        let share = isLastTenant ? Math.round((roomAmount - tenantRunning) * 100) / 100 : Math.round((roomAmount * (roomTenantDays[rid][tid].days / totalTenantDays)) * 100) / 100;
        if (!isLastTenant) tenantRunning += share;
        return { tenantId: tid, tenantName: roomTenantDays[rid][tid].tenantName, days: roomTenantDays[rid][tid].days, amount: share };
      });

      return { roomId: rid, roomNumber: room.roomNumber, occupiedDays: roomOccupiedDays[rid], amount: roomAmount, tenantBreakdown };
    });

    return { totalRoomDays: Object.values(roomOccupiedDays).reduce((s, d) => s + d, 0), rate: Math.round(dailyRate * 100) / 100, roomBreakdown };
  }

  /** Whether the given month should use the Trial rate — whole-month
   *  granularity (a month either fully uses trial rate or fully uses
   *  permanent rate, matching "4 months trial means 4 months at that
   *  rate", not a day-level split mid-month). */
  function isMonthInTrialPeriod(property, monthStr) {
    if (!property.hasTrialFee || !property.trialStartDate || !property.trialEndDate) return false;
    return monthStr >= property.trialStartDate.slice(0, 7) && monthStr <= property.trialEndDate.slice(0, 7);
  }

  /** The full per-room, pro-rata Management Fee for one property in one
   *  month — replaces the old flat per-property amount entirely.
   *  Returns both the total and a per-room breakdown for display. */
  function computeManagementFeeForMonth(propertyId, monthStr) {
    const property = properties.find((p) => p.id === propertyId);
    if (!property || typeof RoomsController === 'undefined') return { total: 0, breakdown: [], rateUsed: 0, isTrialRate: false };

    const [year, month] = monthStr.split('-').map(Number);
    const daysInMonth = new Date(year, month, 0).getDate();
    const isTrial = isMonthInTrialPeriod(property, monthStr);
    const rate = isTrial ? (property.trialFeePerRoom || 0) : (property.mgmtFeePerRoom || 0);

    const rooms = RoomsController.getRoomsByProperty(propertyId);
    const breakdown = rooms.map((r) => {
      const intervals = getRoomOccupancyIntervals(r.id);
      const occupiedDays = countOccupiedDaysInMonth(intervals, year, month);
      const fee = Math.round((occupiedDays / daysInMonth) * rate * 100) / 100;
      return { roomId: r.id, roomNumber: r.roomNumber, occupiedDays, daysInMonth, fee };
    });
    const total = Math.round(breakdown.reduce((s, b) => s + b.fee, 0) * 100) / 100;
    return { total, breakdown, rateUsed: rate, isTrialRate: isTrial };
  }

  function handleSaveRoutineServices(propertyId) {
    const idx = properties.findIndex((p) => p.id === propertyId);
    if (idx === -1) return;
    properties[idx].routineServices = {
      roCandle: document.getElementById('pdRoutineRoCandle').checked,
      acFilter: document.getElementById('pdRoutineAcFilter').checked,
      inverter: document.getElementById('pdRoutineInverter').checked,
      maid: document.getElementById('pdRoutineMaid').checked,
      chimney: document.getElementById('pdRoutineChimney').checked,
    };
    properties[idx].updatedAt = new Date().toISOString();
    persist();
    alert('Routine services saved. Only checked services will be auto-generated as monthly tasks from now on.');
  }

  // ======================================================================
  // INITIAL SETUP EXPENSES — work done before a property is rented out.
  // Maintenance is the single source of truth for what work was done and
  // what it cost; Setup Expense only LINKS to those tickets and
  // aggregates their numbers, so nothing is ever entered twice. Only
  // Scenario 2 (Fair Homes pays, adjusts later) creates an Owner
  // Advance for automatic recovery — the other two are already settled
  // and must never be deducted again.
  // ======================================================================
  let pendingLinkedTicketIds = []; // during the Add Setup Expense session, before Save
  let setupNewWorkMaterialRows = [];
  const SETUP_MATERIAL_CATEGORIES = ['Electrical Material', 'Plumbing Material', 'Carpenter Material', 'Painting Material', 'AC Material', 'RO Material', 'Cleaning Material', 'Other Material'];

  // ======================================================================
  // ELECTRICITY BILLS — enter the whole flat's bill once; the app splits
  // it by Room-Days (never by headcount), and within a room further by
  // each tenant's own days there if the room changed hands mid-period.
  // ======================================================================
  /** Converts a YYYY-MM month value into that full calendar month's
   *  first and last date — the electricity billing period is always
   *  one whole month, so no separate start/end date entry is needed. */
  function monthToDateRange(monthStr) {
    const [year, month] = monthStr.split('-').map(Number);
    const start = `${monthStr}-01`;
    const lastDay = new Date(year, month, 0).getDate();
    const end = `${monthStr}-${String(lastDay).padStart(2, '0')}`;
    return { start, end };
  }
  function fmtMonth(ym) {
    if (!ym) return '—';
    const [y, m] = ym.split('-');
    const d = new Date(Number(y), Number(m) - 1, 1);
    return d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
  }

  function nextElectricityBillCode() {
    const key = 'fh_electricity_bill_seq';
    let seq = parseInt(localStorage.getItem(key) || '0', 10) + 1;
    localStorage.setItem(key, String(seq));
    return 'ELEC-' + String(seq).padStart(4, '0');
  }

  function renderElectricityBillList(propertyId) {
    const box = document.getElementById('pdElectricityBillList');
    if (!box) return;
    const items = electricityBills.filter((b) => b.propertyId === propertyId).sort((a, b) => b.month.localeCompare(a.month));
    if (!items.length) { box.innerHTML = '<div class="empty-state"><div class="desc">No electricity bills recorded yet.</div></div>'; return; }
    box.innerHTML = items.map((b) => `
      <div class="history-item" style="cursor:pointer;" data-id="${b.id}">
        <div class="hi-title">${fmtMonth(b.month)} <span class="badge cat-system" style="margin-left:6px;">${esc(b.billCode)}</span></div>
        <div class="hi-row">Total ₹${b.totalAmount} · ${b.roomBreakdown.length} room(s) · ${b.totalRoomDays} occupied room-days</div>
      </div>`).join('');
    box.querySelectorAll('.history-item').forEach((el) => el.addEventListener('click', () => openElectricityBillDetailModal(el.dataset.id)));
  }

  function openAddElectricityBillModal(propertyId) {
    editingElectricityBillId = null;
    electricityBillModalPropertyId = propertyId;
    document.getElementById('electricityBillModalTitle').textContent = 'Add Electricity Bill';
    document.getElementById('electricityBillForm').reset();
    document.getElementById('electricityBillId').value = '';
    document.getElementById('electricityBillPropertyId').value = propertyId;
    document.getElementById('electricityBillMonth').value = todayIso().slice(0, 7);
    clearErrors('electricityBillForm');
    updateElectricityBillPreview();
    document.getElementById('electricityBillModalOverlay').classList.add('open');
  }

  function openEditElectricityBillModal(billId) {
    const b = electricityBills.find((x) => x.id === billId);
    if (!b) return;
    editingElectricityBillId = billId;
    electricityBillModalPropertyId = b.propertyId;
    document.getElementById('electricityBillModalTitle').textContent = 'Edit Electricity Bill';
    document.getElementById('electricityBillId').value = b.id;
    document.getElementById('electricityBillPropertyId').value = b.propertyId;
    document.getElementById('electricityBillMonth').value = b.month;
    document.getElementById('electricityBillAmount').value = b.totalAmount;
    clearErrors('electricityBillForm');
    updateElectricityBillPreview();
    closeElectricityBillDetailModal();
    document.getElementById('electricityBillModalOverlay').classList.add('open');
  }

  function closeElectricityBillModal() {
    document.getElementById('electricityBillModalOverlay').classList.remove('open');
    editingElectricityBillId = null;
  }

  function updateElectricityBillPreview() {
    const month = document.getElementById('electricityBillMonth').value;
    const amount = Number(document.getElementById('electricityBillAmount').value) || 0;
    const box = document.getElementById('electricityBillPreviewBox');
    if (!month || !amount) { box.innerHTML = ''; return; }
    const { start, end } = monthToDateRange(month);
    const split = computeElectricitySplit(electricityBillModalPropertyId, start, end, amount);
    if (split.totalRoomDays === 0) { box.innerHTML = '<div class="form-hint">Is month mein koi room occupied nahi tha.</div>'; return; }
    box.innerHTML = `
      <div class="calc-row"><span>Total Occupied Room-Days</span><span>${split.totalRoomDays}</span></div>
      <div class="calc-row"><span>Rate per Room-Day</span><span>₹${split.rate}</span></div>
      ${split.roomBreakdown.map((r) => `<div class="calc-row"><span>Room ${esc(r.roomNumber)} (${r.occupiedDays} days)</span><span>₹${r.amount}</span></div>`).join('')}
      <div class="calc-row total"><span>Total</span><span>₹${split.roomBreakdown.reduce((s, r) => s + r.amount, 0)}</span></div>
    `;
  }

  function handleSaveElectricityBill() {
    const propertyId = document.getElementById('electricityBillPropertyId').value;
    const month = document.getElementById('electricityBillMonth').value;
    const totalAmount = document.getElementById('electricityBillAmount').value;

    const errors = {};
    if (!month) errors.electricityBillMonth = 'Select a month';
    else {
      const duplicate = electricityBills.some((b) => b.propertyId === propertyId && b.month === month && b.id !== editingElectricityBillId);
      if (duplicate) errors.electricityBillMonth = 'An electricity bill for this month already exists — edit that one instead';
    }
    if (totalAmount === '' || Number(totalAmount) <= 0) errors.electricityBillAmount = 'Enter the total bill amount';
    clearErrors('electricityBillForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const { start, end } = monthToDateRange(month);
    const split = computeElectricitySplit(propertyId, start, end, Number(totalAmount));
    const now = new Date().toISOString();

    if (editingElectricityBillId) {
      const idx = electricityBills.findIndex((b) => b.id === editingElectricityBillId);
      if (idx !== -1) {
        electricityBills[idx] = {
          ...electricityBills[idx], month, periodStart: start, periodEnd: end, totalAmount: Number(totalAmount),
          totalRoomDays: split.totalRoomDays, roomBreakdown: split.roomBreakdown, updatedAt: now,
        };
      }
    } else {
      electricityBills.unshift({
        id: generateId(), billCode: nextElectricityBillCode(), propertyId,
        month, periodStart: start, periodEnd: end, totalAmount: Number(totalAmount),
        totalRoomDays: split.totalRoomDays, roomBreakdown: split.roomBreakdown,
        createdAt: now, updatedAt: now,
      });
    }
    persistElectricityBills();
    closeElectricityBillModal();
    renderElectricityBillList(propertyId);
  }

  function openElectricityBillDetailModal(billId) {
    viewingElectricityBillId = billId;
    const b = electricityBills.find((x) => x.id === billId);
    if (!b) return;
    const box = document.getElementById('electricityBillDetailBox');
    box.innerHTML = `
      <div class="calc-row"><span>Month</span><span>${fmtMonth(b.month)}</span></div>
      <div class="calc-row"><span>Total Bill</span><span>₹${b.totalAmount}</span></div>
      <div class="calc-row total"><span>Total Occupied Room-Days</span><span>${b.totalRoomDays}</span></div>
      <div class="form-subtitle">Room-Wise Split</div>
      ${b.roomBreakdown.map((r) => `
        <div class="history-item">
          <div class="hi-title">Room ${esc(r.roomNumber)} — ₹${r.amount} (${r.occupiedDays} days)</div>
          ${r.tenantBreakdown.length > 1 ? r.tenantBreakdown.map((t) => `<div class="hi-row">${esc(t.tenantName)}: ${t.days} days — ₹${t.amount}</div>`).join('') : (r.tenantBreakdown[0] ? `<div class="hi-row">${esc(r.tenantBreakdown[0].tenantName)}</div>` : '<div class="hi-row">Vacant</div>')}
        </div>`).join('')}
    `;
    document.getElementById('electricityBillDetailModalOverlay').classList.add('open');
  }
  function closeElectricityBillDetailModal() {
    document.getElementById('electricityBillDetailModalOverlay').classList.remove('open');
    viewingElectricityBillId = null;
  }

  function nextSetupExpenseCode() {
    const key = 'fh_setup_expense_seq';
    let seq = parseInt(localStorage.getItem(key) || '0', 10) + 1;
    localStorage.setItem(key, String(seq));
    return 'SETUP-' + String(seq).padStart(4, '0');
  }

  /** Sums linked tickets' labour + material into one aggregate — this
   *  IS the Setup Expense's cost; nothing here is separately entered. */
  function computeSetupExpenseAggregate(ticketIds) {
    if (typeof MaintenanceController === 'undefined') return { vendorCost: 0, chargeable: 0, serviceMargin: 0, materialCost: 0, materialCharge: 0, materialMargin: 0, totalActual: 0, totalChargeable: 0, totalMargin: 0, byVendor: {} };
    const allTickets = MaintenanceController.getAllTickets();
    const linked = allTickets.filter((t) => ticketIds.includes(t.id) && t.closingDetails);
    let vendorCost = 0, chargeable = 0, materialCost = 0, materialCharge = 0;
    const byVendor = {};
    linked.forEach((t) => {
      const c = t.closingDetails;
      vendorCost += c.labourActual || 0;
      chargeable += c.labourBilled || 0;
      materialCost += c.materialActual || 0;
      materialCharge += c.materialBilled || 0;
      const vname = c.vendorName || 'Unspecified';
      if (!byVendor[vname]) byVendor[vname] = { vendorCost: 0, category: t.category };
      byVendor[vname].vendorCost += (c.labourActual || 0) + (c.materialActual || 0);
    });
    const serviceMargin = chargeable - vendorCost;
    const materialMargin = materialCharge - materialCost;
    return {
      vendorCost, chargeable, serviceMargin, materialCost, materialCharge, materialMargin,
      totalActual: vendorCost + materialCost, totalChargeable: chargeable + materialCharge, totalMargin: serviceMargin + materialMargin,
      byVendor, linkedCount: linked.length,
    };
  }

  function renderSetupExpenseList(propertyId) {
    const box = document.getElementById('pdSetupExpenseList');
    if (!box) return;
    const items = setupExpenses.filter((e) => e.propertyId === propertyId);
    if (!items.length) { box.innerHTML = '<div class="empty-state"><div class="desc">No setup expenses recorded yet.</div></div>'; return; }

    const scenarioLabel = { OwnerPaysFirst: 'Owner Paid First', FairHomesPaysLater: 'Fair Homes Paid — Owner Adjustment', OwnerPaysImmediately: 'Owner Paid Immediately' };
    box.innerHTML = items.map((e) => {
      const agg = computeSetupExpenseAggregate(e.linkedTicketIds || []);
      let amountLine = '';
      if (e.scenario === 'OwnerPaysFirst') {
        const balance = e.ownerAdvanceReceived - agg.totalChargeable;
        amountLine = `Advance ₹${e.ownerAdvanceReceived} · Work Total ₹${agg.totalChargeable} · ${balance >= 0 ? 'Refund' : 'Balance Due'} ₹${Math.abs(balance)}`;
      } else if (e.scenario === 'FairHomesPaysLater') {
        amountLine = `Fair Homes Paid ₹${agg.totalChargeable} · Will be deducted from Owner Settlement`;
      } else {
        amountLine = `Owner Payable ₹${agg.totalChargeable} · Received ₹${e.ownerPaymentReceived || 0}`;
      }
      return `
        <div class="history-item">
          <div class="hi-title">${esc(scenarioLabel[e.scenario])} <span class="badge cat-system" style="margin-left:6px;">${esc(e.setupCode)}</span></div>
          <div class="hi-row">${agg.linkedCount} work(s) linked · ${amountLine}</div>
          ${e.notes ? `<div class="hi-row">${esc(e.notes)}</div>` : ''}
        </div>`;
    }).join('');
  }

  function openAddSetupExpenseModal(propertyId) {
    setupExpenseModalPropertyId = propertyId;
    document.getElementById('setupExpensePropertyId').value = propertyId;
    document.getElementById('setupExpenseForm').reset();
    document.getElementById('setupExpenseScenario').value = 'OwnerPaysFirst';
    pendingLinkedTicketIds = [];
    toggleSetupExpenseScenarioFields();
    renderLinkedWorksList();
    clearErrors('setupExpenseForm');
    document.getElementById('setupExpenseModalOverlay').classList.add('open');
  }
  function closeSetupExpenseModal() { document.getElementById('setupExpenseModalOverlay').classList.remove('open'); setupExpenseModalPropertyId = null; }

  function toggleSetupExpenseScenarioFields() {
    const scenario = document.getElementById('setupExpenseScenario').value;
    document.getElementById('setupExpenseScenario1Fields').classList.toggle('hidden', scenario !== 'OwnerPaysFirst');
    document.getElementById('setupExpenseScenario2Fields').classList.toggle('hidden', scenario !== 'FairHomesPaysLater');
    document.getElementById('setupExpenseScenario3Fields').classList.toggle('hidden', scenario !== 'OwnerPaysImmediately');
    updateSetupScenario1Calc();
  }

  function updateSetupScenario1Calc() {
    const advance = Number(document.getElementById('setupOwnerAdvanceReceived').value) || 0;
    const agg = computeSetupExpenseAggregate(pendingLinkedTicketIds);
    const balance = advance - agg.totalChargeable;
    document.getElementById('setupScenario1CalcBox').innerHTML = `
      <div class="calc-row"><span>Owner Advance Received</span><span>₹${advance}</span></div>
      <div class="calc-row"><span>Linked Work Total (Chargeable)</span><span>₹${agg.totalChargeable}</span></div>
      <div class="calc-row total"><span>${balance >= 0 ? 'Refund to Owner' : 'Balance Owner Owes'}</span><span>₹${Math.abs(balance)}</span></div>
    `;
  }

  /** Renders the linked-works list + the auto-computed Work/Material
   *  summary + vendor-wise payable — called any time pendingLinkedTicketIds
   *  changes so every dependent view stays in sync. */
  function renderLinkedWorksList() {
    const listBox = document.getElementById('setupLinkedWorksList');
    const allTickets = typeof MaintenanceController !== 'undefined' ? MaintenanceController.getAllTickets() : [];
    const linked = allTickets.filter((t) => pendingLinkedTicketIds.includes(t.id));
    listBox.innerHTML = linked.length ? linked.map((t) => `
      <div class="history-item">
        <div class="hi-title">${esc(t.category)} — ${esc(t.ticketId)}
          <button class="btn small secondary setup-unlink-btn" data-id="${t.id}" style="margin-left:8px; padding:2px 8px;">Remove</button>
        </div>
        <div class="hi-row">Vendor: ${esc(t.closingDetails.vendorName || '—')} · Cost ₹${t.closingDetails.totalActual} · Charged ₹${t.closingDetails.totalBilled}</div>
      </div>`).join('') : '<div class="empty-state"><div class="desc">Koi work linked nahi hai abhi.</div></div>';
    listBox.querySelectorAll('.setup-unlink-btn').forEach((btn) => btn.addEventListener('click', () => {
      pendingLinkedTicketIds = pendingLinkedTicketIds.filter((id) => id !== btn.dataset.id);
      renderLinkedWorksList();
    }));

    const agg = computeSetupExpenseAggregate(pendingLinkedTicketIds);
    document.getElementById('setupWorkSummaryBox').innerHTML = `
      <div class="calc-row"><span>Vendor/Service Cost</span><span>₹${agg.vendorCost}</span></div>
      <div class="calc-row"><span>Service Chargeable</span><span>₹${agg.chargeable}</span></div>
      <div class="calc-row"><span>Service Margin</span><span>₹${agg.serviceMargin}</span></div>
      <div class="calc-row"><span>Material Cost</span><span>₹${agg.materialCost}</span></div>
      <div class="calc-row"><span>Material Charge</span><span>₹${agg.materialCharge}</span></div>
      <div class="calc-row"><span>Material Margin</span><span>₹${agg.materialMargin}</span></div>
      <div class="calc-row"><span>Total Actual Cost</span><span>₹${agg.totalActual}</span></div>
      <div class="calc-row"><span>Total Chargeable Amount</span><span>₹${agg.totalChargeable}</span></div>
      <div class="calc-row total"><span>Total Fair Homes Margin</span><span>₹${agg.totalMargin}</span></div>
    `;
    const vendorNames = Object.keys(agg.byVendor);
    document.getElementById('setupVendorBreakdownBox').innerHTML = vendorNames.length ? `
      <div class="form-subtitle">Vendor Payable</div>
      <div class="report-table-wrap"><table class="report-table">
        <thead><tr><th>Vendor</th><th>Work</th><th style="text-align:right;">Amount</th></tr></thead>
        <tbody>${vendorNames.map((v) => `<tr><td>${esc(v)}</td><td>${esc(agg.byVendor[v].category)}</td><td style="text-align:right;">₹${agg.byVendor[v].vendorCost}</td></tr>`).join('')}</tbody>
      </table></div>` : '';
    updateSetupScenario1Calc();
  }

  // ---------------- Add Work from Maintenance (picker) ----------------
  function openAddWorkModal() {
    switchSetupWorkTab('existing');
    renderExistingWorksList();
    setupNewWorkMaterialRows = [];
    document.getElementById('setupNewWorkCategory').innerHTML = MATERIAL_CATEGORY_TO_TICKET.map((c) => `<option>${c}</option>`).join('');
    document.getElementById('setupNewWorkDescription').value = '';
    document.getElementById('setupNewWorkVendorCost').value = '';
    document.getElementById('setupNewWorkChargeable').value = '';
    document.getElementById('setupNewWorkVendorName').value = '';
    populateSetupWorkTypeSelect();
    renderSetupNewWorkMaterialRows();
    document.querySelectorAll('#setupWorkNewPane .form-error').forEach((el) => (el.textContent = ''));
    document.getElementById('setupAddWorkModalOverlay').classList.add('open');
  }
  function closeAddWorkModal() { document.getElementById('setupAddWorkModalOverlay').classList.remove('open'); }

  const MATERIAL_CATEGORY_TO_TICKET = ['Electrical', 'Plumbing', 'AC', 'RO', 'Furniture', 'Painting', 'Internet', 'Cleaning', 'Pest Control', 'Appliance', 'Civil Work', 'Miscellaneous'];

  function switchSetupWorkTab(tab) {
    const isExisting = tab === 'existing';
    document.getElementById('setupWorkExistingPane').classList.toggle('hidden', !isExisting);
    document.getElementById('setupWorkNewPane').classList.toggle('hidden', isExisting);
    document.getElementById('setupWorkTabExisting').className = 'btn small' + (isExisting ? '' : ' secondary');
    document.getElementById('setupWorkTabNew').className = 'btn small' + (isExisting ? ' secondary' : '');
    document.getElementById('setupCreateWorkSaveBtn').classList.toggle('hidden', isExisting);
  }

  function renderExistingWorksList() {
    const box = document.getElementById('setupExistingWorksList');
    if (typeof MaintenanceController === 'undefined') { box.innerHTML = ''; return; }
    const unlinked = MaintenanceController.getUnlinkedClosedTicketsForProperty(setupExpenseModalPropertyId)
      .filter((t) => !pendingLinkedTicketIds.includes(t.id));
    box.innerHTML = unlinked.length ? unlinked.map((t) => `
      <div class="history-item" style="cursor:pointer;" data-id="${t.id}">
        <div class="hi-title">${esc(t.category)} — ${esc(t.ticketId)}</div>
        <div class="hi-row">Vendor: ${esc(t.closingDetails.vendorName || '—')} · Cost ₹${t.closingDetails.totalActual} · Charged ₹${t.closingDetails.totalBilled}</div>
      </div>`).join('') : '<div class="empty-state"><div class="desc">Is property ke liए koi unlinked closed work nahi mila.</div></div>';
    box.querySelectorAll('.history-item').forEach((el) => el.addEventListener('click', () => {
      pendingLinkedTicketIds.push(el.dataset.id);
      renderLinkedWorksList();
      closeAddWorkModal();
    }));
  }

  function populateSetupWorkTypeSelect() {
    const sel = document.getElementById('setupNewWorkTypeSelect');
    if (typeof MaintenanceController === 'undefined') return;
    const works = MaintenanceController.getActiveWorkTypesFlat();
    const grouped = {};
    works.forEach((w) => { if (!grouped[w.categoryName]) grouped[w.categoryName] = []; grouped[w.categoryName].push(w); });
    let html = '<option value="">Not from master — enter manually below</option>';
    Object.keys(grouped).sort().forEach((catName) => {
      html += `<optgroup label="${esc(catName)}">` + grouped[catName].map((w) => `<option value="${w.id}" data-vendor-cost="${w.defaultVendorCost}" data-chargeable="${w.defaultChargeableAmount}">${esc(w.name)}</option>`).join('') + '</optgroup>';
    });
    sel.innerHTML = html;
  }

  function onSetupWorkTypeSelected() {
    const sel = document.getElementById('setupNewWorkTypeSelect');
    const opt = sel.selectedOptions[0];
    if (opt && opt.dataset.vendorCost !== undefined) {
      document.getElementById('setupNewWorkVendorCost').value = opt.dataset.vendorCost;
      document.getElementById('setupNewWorkChargeable').value = opt.dataset.chargeable;
    }
  }

  function buildSetupMaterialRowHTML(row) {
    return `
      <div class="form-row-2" data-material-row="${row.id}" style="align-items:flex-end;">
        <div class="field-group">
          <label class="field-label">Category</label>
          <select class="setup-material-category-select" data-id="${row.id}">${SETUP_MATERIAL_CATEGORIES.map((c) => `<option value="${c}" ${row.category === c ? 'selected' : ''}>${c}</option>`).join('')}</select>
        </div>
        <div class="field-group"><label class="field-label">Actual Cost</label><input type="number" class="setup-material-actual-input" data-id="${row.id}" min="0" value="${row.actualCost || ''}" /></div>
        <div class="field-group">
          <label class="field-label">Charged Amount</label>
          <div style="display:flex; gap:6px;">
            <input type="number" class="setup-material-charged-input" data-id="${row.id}" min="0" value="${row.chargedAmount || ''}" style="flex:1;" />
            <button type="button" class="btn small secondary setup-material-remove-btn" data-id="${row.id}" style="padding:4px 8px;">✕</button>
          </div>
        </div>
      </div>`;
  }
  function renderSetupNewWorkMaterialRows() {
    const container = document.getElementById('setupNewWorkMaterialRows');
    container.innerHTML = setupNewWorkMaterialRows.map(buildSetupMaterialRowHTML).join('');
    container.querySelectorAll('.setup-material-category-select').forEach((sel) => sel.addEventListener('change', (e) => {
      const row = setupNewWorkMaterialRows.find((r) => r.id === e.target.dataset.id); if (row) row.category = e.target.value;
    }));
    container.querySelectorAll('.setup-material-actual-input').forEach((inp) => inp.addEventListener('input', (e) => {
      const row = setupNewWorkMaterialRows.find((r) => r.id === e.target.dataset.id); if (row) row.actualCost = Number(e.target.value) || 0;
    }));
    container.querySelectorAll('.setup-material-charged-input').forEach((inp) => inp.addEventListener('input', (e) => {
      const row = setupNewWorkMaterialRows.find((r) => r.id === e.target.dataset.id); if (row) row.chargedAmount = Number(e.target.value) || 0;
    }));
    container.querySelectorAll('.setup-material-remove-btn').forEach((btn) => btn.addEventListener('click', (e) => {
      setupNewWorkMaterialRows = setupNewWorkMaterialRows.filter((r) => r.id !== e.target.dataset.id);
      renderSetupNewWorkMaterialRows();
    }));
  }
  function addSetupMaterialRow() {
    setupNewWorkMaterialRows.push({ id: generateId(), category: SETUP_MATERIAL_CATEGORIES[0], actualCost: 0, chargedAmount: 0 });
    renderSetupNewWorkMaterialRows();
  }

  function handleCreateAndLinkWork() {
    const category = document.getElementById('setupNewWorkCategory').value;
    const description = document.getElementById('setupNewWorkDescription').value.trim();
    const vendorCost = Number(document.getElementById('setupNewWorkVendorCost').value) || 0;
    const chargeable = Number(document.getElementById('setupNewWorkChargeable').value) || 0;
    const vendorName = document.getElementById('setupNewWorkVendorName').value.trim();

    if (!description) { showErrors({ setupNewWorkDescription: 'Description is required' }); return; }
    document.querySelectorAll('#setupWorkNewPane .form-error').forEach((el) => (el.textContent = ''));

    const newTicket = MaintenanceController.createSetupWorkTicket({
      propertyId: setupExpenseModalPropertyId, category, description, vendorName,
      labourActual: vendorCost, labourBilled: chargeable, materials: setupNewWorkMaterialRows, costBearer: 'Owner',
    });
    pendingLinkedTicketIds.push(newTicket.id);
    renderLinkedWorksList();
    closeAddWorkModal();
  }

  function handleSaveSetupExpense() {
    const propertyId = document.getElementById('setupExpensePropertyId').value;
    const scenario = document.getElementById('setupExpenseScenario').value;
    const notes = document.getElementById('setupExpenseNotes').value.trim();
    const errors = {};
    const record = { scenario, notes, linkedTicketIds: [...pendingLinkedTicketIds] };
    const agg = computeSetupExpenseAggregate(pendingLinkedTicketIds);

    if (scenario === 'OwnerPaysFirst') {
      const estimatedAmount = document.getElementById('setupEstimatedAmount').value;
      const ownerAdvanceReceived = document.getElementById('setupOwnerAdvanceReceived').value;
      if (estimatedAmount === '' || Number(estimatedAmount) < 0) errors.setupEstimatedAmount = 'Enter estimated amount';
      if (ownerAdvanceReceived === '' || Number(ownerAdvanceReceived) < 0) errors.setupOwnerAdvanceReceived = 'Enter advance received from owner';
      Object.assign(record, { estimatedAmount: Number(estimatedAmount) || 0, ownerAdvanceReceived: Number(ownerAdvanceReceived) || 0 });
    } else if (scenario === 'OwnerPaysImmediately') {
      Object.assign(record, {
        ownerPaymentReceived: Number(document.getElementById('setupOwnerPaymentReceived3').value) || 0,
        paymentDate: document.getElementById('setupPaymentDate3').value || null,
      });
    }

    clearErrors('setupExpenseForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const now = new Date().toISOString();
    const newExpense = { id: generateId(), setupCode: nextSetupExpenseCode(), propertyId, createdAt: now, updatedAt: now, ...record };
    setupExpenses.unshift(newExpense);
    persistSetupExpenses();

    if (typeof MaintenanceController !== 'undefined' && pendingLinkedTicketIds.length) {
      MaintenanceController.linkTicketsTo(pendingLinkedTicketIds, 'setupExpense', newExpense.id);
    }

    // Only "Fair Homes pays, owner adjusts later" creates a recoverable
    // Owner Advance — the other two scenarios are already settled at
    // the time of entry and must never reduce a future settlement.
    if (scenario === 'FairHomesPaysLater' && agg.totalChargeable > 0 && typeof FinanceController !== 'undefined' && FinanceController.createOwnerAdvance) {
      FinanceController.createOwnerAdvance({
        propertyId, amount: agg.totalChargeable, reason: 'Initial Setup Expense — ' + newExpense.setupCode,
        sourceType: 'setupExpense', sourceId: newExpense.id,
      });
    }

    closeSetupExpenseModal();
    renderSetupExpenseList(propertyId);
  }

  /** Finds this tenant's own share of a property's electricity bill
   *  for a given month, if one has been entered and not yet collected
   *  — this is what Rent Collection auto-pulls in, so the manager
   *  never re-types a number that's already been calculated. */
  function getTenantElectricityDue(tenantId, month) {
    const tenant = typeof TenantsController !== 'undefined' ? TenantsController.getAll().find((t) => t.id === tenantId) : null;
    if (!tenant || !tenant.currentAllocation) return null;
    const bill = electricityBills.find((b) => b.propertyId === tenant.currentAllocation.propertyId && b.month === month);
    if (!bill) return null;
    for (const room of bill.roomBreakdown) {
      const share = room.tenantBreakdown.find((t) => t.tenantId === tenantId);
      if (share && !share.collected) {
        return { billId: bill.id, roomId: room.roomId, amount: share.amount, days: share.days };
      }
    }
    return null;
  }
  function markElectricityShareCollected(billId, tenantId) {
    const bill = electricityBills.find((b) => b.id === billId);
    if (!bill) return;
    bill.roomBreakdown.forEach((room) => {
      const share = room.tenantBreakdown.find((t) => t.tenantId === tenantId);
      if (share) share.collected = true;
    });
    persistElectricityBills();
  }

  return { init, renderList, getAll, reload, bulkImport, getBrokerageDueInfo, advanceBrokerageCycle, openDetail: renderDetail, updateTenantTypeRestriction, computeManagementFeeForMonth, getTenantElectricityDue, markElectricityShareCollected };
})();
