/* ==========================================================================
   Fair Homes OS — Reports, Analytics & Business Intelligence (Phase 8)
   Read-only aggregation layer over Owners / Properties / Rooms & Beds /
   Tenants / Finance / Maintenance. Generates zero data of its own — every
   number here is computed live from what those modules already store.
   ========================================================================== */

const ReportsController = (() => {
  let charts = {}; // Chart.js instances, keyed by canvas id — destroyed/recreated on each render
  let currentExportData = { headers: [], rows: [], title: 'Report' }; // updated by whichever sub-report last rendered

  // ---------------- Helpers ----------------
  function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function todayIso() { return new Date().toISOString().slice(0, 10); }
  function currentMonthStr() { return new Date().toISOString().slice(0, 7); }
  function fmtMonth(ym) {
    if (!ym) return '—';
    const [y, m] = ym.split('-');
    return new Date(Number(y), Number(m) - 1, 1).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });
  }
  function lastNMonths(n) {
    const months = [];
    const d = new Date();
    for (let i = n - 1; i >= 0; i--) {
      const dt = new Date(d.getFullYear(), d.getMonth() - i, 1);
      months.push(dt.toISOString().slice(0, 7));
    }
    return months;
  }
  function themeColor(varName) { return getComputedStyle(document.documentElement).getPropertyValue(varName).trim(); }

  // ---------------- Filters ----------------
  function getFilters() {
    return {
      propertyId: document.getElementById('rpPropertyFilter').value,
      ownerId: document.getElementById('rpOwnerFilter').value,
      tenantId: document.getElementById('rpTenantFilter').value,
      month: document.getElementById('rpMonthFilter').value,
      year: document.getElementById('rpYearFilter').value,
      dateFrom: document.getElementById('rpDateFrom').value,
      dateTo: document.getElementById('rpDateTo').value,
      search: (document.getElementById('rpSearchInput').value || '').toLowerCase().trim(),
    };
  }

  function populateFilters() {
    const properties = PropertiesController.getAll();
    const owners = OwnersController.getAll();
    const tenants = TenantsController.getAll();
    const rentEntries = FinanceController.getAllRentEntries();

    setSelectOptions('rpPropertyFilter', properties.map((p) => ({ id: p.id, name: p.name })), 'All Properties');
    setSelectOptions('rpOwnerFilter', owners.map((o) => ({ id: o.id, name: o.fullName })), 'All Owners');
    setSelectOptions('rpTenantFilter', tenants.map((t) => ({ id: t.id, name: t.fullName })), 'All Tenants');

    const months = [...new Set(rentEntries.map((r) => r.rentMonth))].sort().reverse();
    setSelectOptions('rpMonthFilter', months.map((m) => ({ id: m, name: fmtMonth(m) })), 'All Months');

    const years = [...new Set(rentEntries.map((r) => r.rentMonth.split('-')[0]))].sort().reverse();
    setSelectOptions('rpYearFilter', years.map((y) => ({ id: y, name: y })), 'All Years');
  }

  function setSelectOptions(selId, items, placeholder) {
    const sel = document.getElementById(selId);
    const current = sel.value;
    sel.innerHTML = `<option value="all">${placeholder}</option>` + items.map((i) => `<option value="${i.id}">${esc(i.name)}</option>`).join('');
    sel.value = current || 'all';
  }

  function clearFilters() {
    ['rpPropertyFilter', 'rpOwnerFilter', 'rpTenantFilter', 'rpMonthFilter', 'rpYearFilter'].forEach((id) => document.getElementById(id).value = 'all');
    document.getElementById('rpDateFrom').value = '';
    document.getElementById('rpDateTo').value = '';
    document.getElementById('rpSearchInput').value = '';
    renderActiveTab();
  }

  // Applies the shared filter bar to a property-linked record. Returns true if it should be included.
  function passesFilters(record, f) {
    if (f.propertyId !== 'all' && record.propertyId && record.propertyId !== f.propertyId) return false;
    if (f.ownerId !== 'all') {
      const property = PropertiesController.getAll().find((p) => p.id === record.propertyId);
      if (!property || property.ownerId !== f.ownerId) return false;
    }
    if (f.tenantId !== 'all' && record.tenantId && record.tenantId !== f.tenantId) return false;
    if (f.month !== 'all' && record.rentMonth && record.rentMonth !== f.month) return false;
    if (f.year !== 'all' && record.rentMonth && !record.rentMonth.startsWith(f.year)) return false;
    if (f.dateFrom && record.date && record.date < f.dateFrom) return false;
    if (f.dateTo && record.date && record.date > f.dateTo) return false;
    return true;
  }

  // ======================================================================
  // 1. EXECUTIVE BUSINESS DASHBOARD + KPI CARDS
  // ======================================================================
  function renderExecutive() {
    const properties = PropertiesController.getAll();
    const owners = OwnersController.getAll();
    const tenants = TenantsController.getAll();
    const rooms = RoomsController.getAllRooms();
    const rentEntries = FinanceController.getAllRentEntries();
    const deposits = FinanceController.getAllDeposits();
    const expenses = FinanceController.getAllExpenses();
    const tickets = MaintenanceController.getAllTickets();

    const occupiedBeds = rooms.filter((r) => RoomsController.computeRoomStatus(r.id) === 'Occupied').length;
    const vacantBeds = rooms.length - occupiedBeds;
    const occupancyPct = rooms.length ? Math.round((occupiedBeds / rooms.length) * 100) : 0;

    const thisMonth = currentMonthStr();
    const lastMonth = lastNMonths(2)[0];
    const monthlyRevenue = rentEntries.filter((r) => r.paymentDate && r.paymentDate.startsWith(thisMonth)).reduce((s, r) => s + r.amountPaid, 0);
    const lastMonthRevenue = rentEntries.filter((r) => r.paymentDate && r.paymentDate.startsWith(lastMonth)).reduce((s, r) => s + r.amountPaid, 0);
    const monthlyExpenses = expenses.filter((e) => e.date.startsWith(thisMonth)).reduce((s, e) => s + e.amount, 0);
    const netProfit = monthlyRevenue - monthlyExpenses;
    const outstandingRent = rentEntries.filter((r) => r.paymentStatus !== 'Paid').reduce((s, r) => s + r.remainingBalance, 0);
    const depositsHeld = deposits.filter((d) => d.status === 'Held' || d.status === 'Partially Refunded').reduce((s, d) => s + (d.amount - d.refundedAmount), 0);
    const openTickets = tickets.filter((t) => !['Closed', 'Cancelled'].includes(t.status)).length;
    const closedTickets = tickets.filter((t) => t.status === 'Closed').length;
    const monthlyMaintCost = tickets.filter((t) => t.closingDetails && t.updatedAt.startsWith(thisMonth)).reduce((s, t) => s + t.closingDetails.totalBilled, 0);
    const growthPct = lastMonthRevenue > 0 ? Math.round(((monthlyRevenue - lastMonthRevenue) / lastMonthRevenue) * 100) : (monthlyRevenue > 0 ? 100 : 0);
    const pendingRent = rentEntries.filter((r) => r.paymentStatus === 'Pending' || r.paymentStatus === 'Overdue').reduce((s, r) => s + r.remainingBalance, 0);

    // Bookings & Brokerage-Only Flats — separate revenue streams, not part
    // of the core managed-property numbers above.
    let activeBookingsCount = 0, bookingPipelineValue = 0;
    if (typeof BookingsController !== 'undefined') {
      const bookings = BookingsController.getAll().filter((b) => b.status === 'Active');
      activeBookingsCount = bookings.length;
      bookingPipelineValue = bookings.reduce((s, b) => {
        const pkg = (Number(b.monthlyRent) || 0) + (Number(b.securityAmount) || 0) + (Number(b.brokerageAmount) || 0);
        const collected = (b.tokenPayments || []).reduce((sum, p) => sum + p.amount, 0);
        return s + (pkg - collected);
      }, 0);
    }
    let brkFlatsCount = 0, brkMonthlyIncome = 0;
    if (typeof BrokerageFlatsController !== 'undefined') {
      const brkFlats = BrokerageFlatsController.getAll();
      brkFlatsCount = brkFlats.length;
      brkFlats.forEach((f) => (f.deals || []).forEach((d) => { if (d.date.startsWith(thisMonth)) brkMonthlyIncome += d.totalAmount; }));
    }

    // KPI Cards (Section 13) — respects the "Show KPI Cards on Dashboard"
    // preference from Settings > App Settings (defaults to shown).
    let showKpi = true;
    try { const a = JSON.parse(localStorage.getItem('fh_app_settings')); if (a && a.showKpiCards === false) showKpi = false; } catch (e) { /* default shown */ }
    const kpiGridEl = document.getElementById('kpiGrid');
    kpiGridEl.style.display = showKpi ? '' : 'none';
    if (showKpi) kpiGridEl.innerHTML = [
      { icon: '💰', label: 'Revenue (This Month)', value: '₹' + monthlyRevenue },
      { icon: '📈', label: 'Profit (This Month)', value: '₹' + netProfit },
      { icon: '🏠', label: 'Occupancy', value: occupancyPct + '%' },
      { icon: '⏳', label: 'Pending Rent', value: '₹' + pendingRent },
      { icon: '🔧', label: 'Maintenance Cost', value: '₹' + monthlyMaintCost },
      { icon: '📊', label: 'Growth vs Last Month', value: (growthPct >= 0 ? '+' : '') + growthPct + '%', growth: growthPct },
    ].map((k, i) => `
      <div class="kpi-card" style="animation-delay:${i * 0.05}s">
        <div class="kpi-icon">${k.icon}</div>
        <div class="kpi-label">${k.label}</div>
        <div class="kpi-value">${k.value}</div>
        ${k.growth !== undefined ? `<div class="kpi-growth ${k.growth >= 0 ? 'up' : 'down'}">${k.growth >= 0 ? '▲' : '▼'} vs last month</div>` : ''}
      </div>`).join('');

    // Full Executive Dashboard widget list (Section 1)
    document.getElementById('execStatGrid').innerHTML = `
      <div class="stat-card"><div class="label">Total Properties</div><div class="value">${properties.length}</div></div>
      <div class="stat-card"><div class="label">Total Owners</div><div class="value">${owners.length}</div></div>
      <div class="stat-card"><div class="label">Total Tenants</div><div class="value">${tenants.length}</div></div>
      <div class="stat-card"><div class="label">Total Rooms</div><div class="value">${rooms.length}</div></div>
      <div class="stat-card"><div class="label">Occupied Rooms</div><div class="value">${occupiedBeds}</div></div>
      <div class="stat-card"><div class="label">Available Rooms</div><div class="value success">${vacantBeds}</div></div>
      <div class="stat-card"><div class="label">Occupancy %</div><div class="value">${occupancyPct}%</div></div>
      <div class="stat-card"><div class="label">Monthly Revenue</div><div class="value success">₹${monthlyRevenue}</div></div>
      <div class="stat-card"><div class="label">Monthly Expenses</div><div class="value error">₹${monthlyExpenses}</div></div>
      <div class="stat-card"><div class="label">Net Profit</div><div class="value ${netProfit >= 0 ? 'success' : 'error'}">₹${netProfit}</div></div>
      <div class="stat-card"><div class="label">Outstanding Rent</div><div class="value warning">₹${outstandingRent}</div></div>
      <div class="stat-card"><div class="label">Security Deposits Held</div><div class="value">₹${depositsHeld}</div></div>
      <div class="stat-card"><div class="label">Open Maintenance Tickets</div><div class="value warning">${openTickets}</div></div>
      <div class="stat-card"><div class="label">Closed Maintenance Tickets</div><div class="value success">${closedTickets}</div></div>
      <div class="stat-card"><div class="label">Active Bookings</div><div class="value">${activeBookingsCount}</div></div>
      <div class="stat-card"><div class="label">Booking Pipeline (Balance Due)</div><div class="value warning">₹${bookingPipelineValue}</div></div>
      <div class="stat-card"><div class="label">Brokerage-Only Flats</div><div class="value">${brkFlatsCount}</div></div>
      <div class="stat-card"><div class="label">Brokerage-Only Income (This Month)</div><div class="value success">₹${brkMonthlyIncome}</div></div>
    `;

    currentExportData = { title: 'Executive Dashboard', headers: ['Metric', 'Value'], rows: [
      ['Total Properties', properties.length], ['Total Owners', owners.length], ['Total Tenants', tenants.length],
      ['Total Rooms', rooms.length], ['Occupied Rooms', occupiedBeds], ['Available Rooms', vacantBeds],
      ['Occupancy %', occupancyPct + '%'], ['Monthly Revenue', monthlyRevenue], ['Monthly Expenses', monthlyExpenses],
      ['Net Profit', netProfit], ['Outstanding Rent', outstandingRent], ['Security Deposits Held', depositsHeld],
      ['Open Maintenance Tickets', openTickets], ['Closed Maintenance Tickets', closedTickets],
      ['Active Bookings', activeBookingsCount], ['Booking Pipeline (Balance Due)', bookingPipelineValue],
      ['Brokerage-Only Flats', brkFlatsCount], ['Brokerage-Only Income (This Month)', brkMonthlyIncome],
    ]};
  }

  // ======================================================================
  // 2. OCCUPANCY REPORT
  // ======================================================================
  function renderOccupancy() {
    const f = getFilters();
    const properties = PropertiesController.getAll().filter((p) => f.propertyId === 'all' || p.id === f.propertyId);
    const allRooms = RoomsController.getAllRooms();

    const vacantRoomsTotal = allRooms.filter((r) => RoomsController.computeRoomStatus(r.id) === 'Available').length;
    const occupiedRoomsTotal = allRooms.filter((r) => RoomsController.computeRoomStatus(r.id) === 'Occupied').length;
    document.getElementById('occSummaryGrid').innerHTML = `
      <div class="stat-card"><div class="label">Total Rooms</div><div class="value">${allRooms.length}</div></div>
      <div class="stat-card"><div class="label">Occupied</div><div class="value">${occupiedRoomsTotal}</div></div>
      <div class="stat-card"><div class="label">Available</div><div class="value success">${vacantRoomsTotal}</div></div>
      <div class="stat-card"><div class="label">Occupancy %</div><div class="value">${allRooms.length ? Math.round((occupiedRoomsTotal / allRooms.length) * 100) : 0}%</div></div>
    `;

    const propRows = properties.map((p) => {
      const stats = RoomsController.computePropertyStats(p.id);
      return { name: p.name, rooms: stats.totalRooms, occ: stats.occupiedRooms, vac: stats.availableRooms, pct: stats.occupancyPct };
    });
    renderTable('occPropertyTable', ['Property', 'Total Rooms', 'Occupied', 'Available', 'Occupancy %'],
      propRows.map((r) => [r.name, r.rooms, r.occ, r.vac, r.pct + '%']));

    const roomRows = allRooms.filter((r) => f.propertyId === 'all' || r.propertyId === f.propertyId).map((r) => {
      const property = PropertiesController.getAll().find((p) => p.id === r.propertyId);
      const status = RoomsController.computeRoomStatus(r.id);
      const occupants = RoomsController.activeTenantsInRoom(r.id).map((t) => t.fullName).join(', ');
      return { property: property?.name || '—', room: r.roomNumber, status, occupants: occupants || '—' };
    });
    renderTable('occRoomTable', ['Property', 'Room', 'Status', 'Occupant(s)'],
      roomRows.map((r) => [r.property, r.room, r.status, r.occupants]));

    currentExportData = { title: 'Occupancy Report', headers: ['Property', 'Total Rooms', 'Occupied', 'Available', 'Occupancy %'], rows: propRows.map((r) => [r.name, r.rooms, r.occ, r.vac, r.pct + '%']) };
  }

  // ======================================================================
  // 3. RENT REPORTS
  // ======================================================================
  function renderRent() {
    const f = getFilters();
    const allRent = FinanceController.getAllRentEntries().filter((r) => passesFilters(r, f));
    const thisMonth = currentMonthStr();

    const monthlyCollection = allRent.filter((r) => r.paymentDate && r.paymentDate.startsWith(thisMonth)).reduce((s, r) => s + r.amountPaid, 0);
    const pendingRent = allRent.filter((r) => r.paymentStatus === 'Pending').reduce((s, r) => s + r.remainingBalance, 0);
    const overdueRent = allRent.filter((r) => r.paymentStatus === 'Overdue').reduce((s, r) => s + r.remainingBalance, 0);
    const advancePayments = allRent.filter((r) => r.amountPaid > r.totalPayable).reduce((s, r) => s + (r.amountPaid - r.totalPayable), 0);
    const dueThisMonth = allRent.filter((r) => r.rentMonth === thisMonth).reduce((s, r) => s + r.totalPayable, 0);
    const paidThisMonth = allRent.filter((r) => r.rentMonth === thisMonth).reduce((s, r) => s + r.amountPaid, 0);
    const collectionPct = dueThisMonth ? Math.round((paidThisMonth / dueThisMonth) * 100) : 0;

    document.getElementById('rentReportGrid').innerHTML = `
      <div class="stat-card"><div class="label">Monthly Collection</div><div class="value success">₹${monthlyCollection}</div></div>
      <div class="stat-card"><div class="label">Pending Rent</div><div class="value warning">₹${pendingRent}</div></div>
      <div class="stat-card"><div class="label">Overdue Rent</div><div class="value error">₹${overdueRent}</div></div>
      <div class="stat-card"><div class="label">Advance Payments</div><div class="value">₹${advancePayments}</div></div>
      <div class="stat-card"><div class="label">Collection %</div><div class="value">${collectionPct}%</div></div>
    `;

    const months = lastNMonths(6);
    const monthRows = months.map((m) => {
      const entries = FinanceController.getAllRentEntries().filter((r) => r.rentMonth === m);
      const collected = entries.reduce((s, r) => s + r.amountPaid, 0);
      const due = entries.reduce((s, r) => s + r.totalPayable, 0);
      return [fmtMonth(m), '₹' + collected, '₹' + due, (due ? Math.round((collected / due) * 100) : 0) + '%'];
    });
    renderTable('rentMonthlyTable', ['Month', 'Collected', 'Due', 'Collection %'], monthRows);

    const byProperty = {};
    allRent.forEach((r) => { byProperty[r.propertyId] = (byProperty[r.propertyId] || 0) + r.amountPaid; });
    const propRows = Object.entries(byProperty).map(([pid, amt]) => {
      const p = PropertiesController.getAll().find((x) => x.id === pid);
      return [p?.name || 'Unknown', '₹' + amt];
    }).sort((a, b) => b[1].localeCompare ? 0 : 0);
    renderTable('rentPropertyTable', ['Property', 'Total Collected'], propRows);

    const byTenant = {};
    allRent.forEach((r) => { byTenant[r.tenantId] = (byTenant[r.tenantId] || 0) + r.amountPaid; });
    const tenantRows = Object.entries(byTenant).map(([tid, amt]) => {
      const t = TenantsController.getById(tid);
      return [t?.fullName || 'Unknown', '₹' + amt];
    });
    renderTable('rentTenantTable', ['Tenant', 'Total Collected'], tenantRows);

    currentExportData = { title: 'Rent Report', headers: ['Month', 'Collected', 'Due', 'Collection %'], rows: monthRows };
  }

  // ======================================================================
  // 4. OWNER REPORTS
  // ======================================================================
  function renderOwners() {
    populateWorkReportPropertySelect();
    const f = getFilters();
    const owners = OwnersController.getAll().filter((o) => (f.ownerId === 'all' || o.id === f.ownerId) && o.fullName.toLowerCase().includes(f.search));
    const thisMonth = currentMonthStr();

    const rows = owners.map((o) => {
      const ownerProperties = PropertiesController.getAll().filter((p) => p.ownerId === o.id);
      const propertyIds = ownerProperties.map((p) => p.id);
      const occupiedUnits = RoomsController.getAllRooms().filter((r) => propertyIds.includes(r.propertyId) && RoomsController.computeRoomStatus(r.id) === 'Occupied').length;
      const monthlyIncome = FinanceController.getAllRentEntries().filter((r) => propertyIds.includes(r.propertyId) && r.paymentDate && r.paymentDate.startsWith(thisMonth)).reduce((s, r) => s + r.amountPaid, 0);
      const mgmtCharges = FinanceController.getAllManagementFees().filter((mf) => propertyIds.includes(mf.propertyId) && mf.month === thisMonth).reduce((s, mf) => s + mf.amount, 0);
      // Owner-borne costs (maintenance + manual expenses tagged Owner) go
      // through the Owner Advance ledger and may be recovered gradually
      // across several rent cycles — so the true monthly deduction is
      // whatever was actually adjusted THIS month, not the full original
      // cost. Tenant-paid costs never touch the owner's income at all;
      // those show up instead as value Fair Homes delivered (see below).
      const expenses = FinanceController.getAdvanceAdjustmentsInMonth(propertyIds, thisMonth);
      const brokeragePaid = FinanceController.getAllBrokerage().filter((b) => propertyIds.includes(b.propertyId) && b.status === 'Paid' && b.paymentDate && b.paymentDate.startsWith(thisMonth)).reduce((s, b) => s + b.amount, 0);
      const netOwnerIncome = monthlyIncome - mgmtCharges - expenses - brokeragePaid;
      return [o.fullName, ownerProperties.length, occupiedUnits, '₹' + monthlyIncome, '₹' + mgmtCharges, '₹' + expenses, '₹' + brokeragePaid, '₹' + netOwnerIncome];
    });

    renderTable('ownerReportTable', ['Owner', 'Properties', 'Occupied Units', 'Monthly Income', 'Mgmt Charges', 'Expenses', 'Brokerage', 'Net Owner Income'], rows);
    currentExportData = { title: 'Owner Report', headers: ['Owner', 'Properties', 'Occupied Units', 'Monthly Income', 'Mgmt Charges', 'Expenses', 'Brokerage', 'Net Owner Income'], rows };

    renderOwnerSaved(owners, thisMonth);
  }

  /**
   * "Fair Homes Saved You" — for each owner, lists tenant-covered
   * maintenance costs (tickets + routine checklist tasks) this month.
   * Never discloses that the tenant paid — framed purely as value Fair
   * Homes delivered, per the agreed messaging.
   */
  function renderOwnerSaved(owners, thisMonth) {
    const box = document.getElementById('ownerSavedBox');
    if (!box) return;
    const sections = owners.map((o) => {
      const ownerProperties = PropertiesController.getAll().filter((p) => p.ownerId === o.id);
      const items = [];

      ownerProperties.forEach((p) => {
        // Both Maintenance Tickets AND Routine Checklist tasks now sync
        // their Tenant-borne costs into Finance -> Expenses automatically,
        // so this single source covers both — no separate pull needed.
        FinanceController.getAllExpenses()
          .filter((e) => e.propertyId === p.id && e.date.startsWith(thisMonth) && e.costBearer === 'Tenant')
          .forEach((e) => items.push({ label: e.sourceLabel || e.category, amount: e.amount }));
      });

      if (!items.length) return '';
      const total = items.reduce((s, i) => s + i.amount, 0);
      return `
        <div class="settings-card">
          <h3 style="margin-bottom:2px;">✅ Is Mahine Fair Homes Ne Yeh Kiya — ${esc(o.fullName)}</h3>
          <div class="sc-desc">Regular maintenance se aapki property ki value protect ho rahi hai.</div>
          ${items.map((i) => `<div class="danger-row"><div class="dr-label">${esc(i.label)}</div><div style="font-weight:700; color:var(--success);">Fair Homes Saved You ₹${i.amount}</div></div>`).join('')}
          <div class="danger-row" style="border-top:2px solid var(--border); margin-top:4px; padding-top:10px;">
            <div class="dr-label" style="font-size:14px;">Total Saved This Month</div>
            <div style="font-weight:800; font-size:16px; color:var(--success);">₹${total}</div>
          </div>
        </div>`;
    }).filter(Boolean).join('');

    box.innerHTML = sections || '';
  }

  // ======================================================================
  // ======================================================================
  // OWNER-FACING MONTHLY WORK REPORT
  // ======================================================================
  function populateWorkReportPropertySelect() {
    const sel = document.getElementById('workReportPropertySelect');
    if (!sel) return;
    const current = sel.value;
    sel.innerHTML = '<option value="">Select Property</option>' + PropertiesController.getAll().map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
    sel.value = current;
  }

  function renderOwnerWorkReport() {
    const propertyId = document.getElementById('workReportPropertySelect').value;
    const month = document.getElementById('workReportMonth').value;
    const box = document.getElementById('workReportBox');
    if (!propertyId || !month) { box.innerHTML = '<div class="empty-state"><div class="desc">Property aur Month select karo.</div></div>'; return; }

    const property = PropertiesController.getAll().find((p) => p.id === propertyId);
    const closedTickets = MaintenanceController.getTicketsByProperty(propertyId).filter((t) =>
      (t.status === 'Completed' || t.status === 'Closed') && t.closingDetails && t.dateTime && t.dateTime.startsWith(month)
    );

    if (!closedTickets.length) {
      box.innerHTML = `<div class="empty-state"><div class="ico">🔧</div><div class="title">No work recorded</div><div class="desc">${esc(property ? property.name : '')} ke liए ${fmtMonth(month)} mein koi closed work nahi mila.</div></div>`;
      return;
    }

    let totalWork = 0, recoveredFromTenant = 0, ownerDirectCost = 0, fairHomesBorne = 0;
    const rows = closedTickets.map((t) => {
      const cd = t.closingDetails;
      const chargeable = cd.totalBilled || 0;
      totalWork += chargeable;
      if (cd.costBearer === 'Tenant') recoveredFromTenant += chargeable;
      else if (cd.costBearer === 'Owner') ownerDirectCost += chargeable;
      else fairHomesBorne += chargeable;
      return { category: t.category, date: t.dateTime, chargeable, costBearer: cd.costBearer };
    });

    box.innerHTML = `
      <div class="stat-grid" style="margin-bottom:14px;">
        <div class="stat-card"><div class="label">Total Work Managed</div><div class="value">₹${totalWork}</div></div>
        <div class="stat-card"><div class="label">Recovered from Tenant</div><div class="value success">₹${recoveredFromTenant}</div></div>
        <div class="stat-card"><div class="label">Owner Direct Cost</div><div class="value">₹${ownerDirectCost}</div></div>
        <div class="stat-card"><div class="label">Fair Homes Borne</div><div class="value">₹${fairHomesBorne}</div></div>
      </div>
      <div class="report-table-wrap"><table class="report-table">
        <thead><tr><th>Date</th><th>Work</th><th>Payable By</th><th style="text-align:right;">Amount</th></tr></thead>
        <tbody>
          ${rows.map((r) => `<tr><td>${fmtDate(r.date)}</td><td>${esc(r.category)}</td><td>${esc(r.costBearer)}</td><td style="text-align:right;">₹${r.chargeable}</td></tr>`).join('')}
        </tbody>
      </table></div>
      <div class="sc-desc" style="margin-top:10px;">${recoveredFromTenant > 0 ? `Fair Homes ne ₹${totalWork} ka kaam manage kiya is mahine, jisमें se ₹${recoveredFromTenant} Tenant se recover hua — yeh Owner ki accounting mein expense nahi ginا jaाता, kyunki payment Tenant se aई.` : `Is mahine sab kaam Owner/Fair Homes ke through settle hua.`}</div>
    `;
  }

  // ======================================================================
  function renderPerformance() {
    const f = getFilters();
    const properties = PropertiesController.getAll().filter((p) => (f.propertyId === 'all' || p.id === f.propertyId) && p.name.toLowerCase().includes(f.search));

    const rows = properties.map((p) => {
      const revenue = FinanceController.getAllRentEntries().filter((r) => r.propertyId === p.id).reduce((s, r) => s + r.amountPaid, 0);
      const expenses = FinanceController.getAllExpenses().filter((e) => e.propertyId === p.id).reduce((s, e) => s + e.amount, 0);
      const maintCost = MaintenanceController.getTicketsByProperty(p.id).filter((t) => t.closingDetails).reduce((s, t) => s + t.closingDetails.totalBilled, 0);
      const profit = revenue - expenses;
      const occPct = RoomsController.computePropertyStats(p.id).occupancyPct;
      const pendingRent = FinanceController.getAllRentEntries().filter((r) => r.propertyId === p.id && r.paymentStatus !== 'Paid').reduce((s, r) => s + r.remainingBalance, 0);
      return { name: p.name, revenue, expenses, profit, occPct, maintCost, pendingRent };
    }).sort((a, b) => b.profit - a.profit);

    renderTable('performanceTable', ['Rank', 'Property', 'Revenue', 'Expenses', 'Profit', 'Occupancy %', 'Maintenance Cost', 'Pending Rent', 'ROI'],
      rows.map((r, i) => [
        `<span class="rank-badge ${i === 0 ? 'top' : ''}">${i + 1}</span>`, r.name, '₹' + r.revenue, '₹' + r.expenses,
        '₹' + r.profit, r.occPct + '%', '₹' + r.maintCost, '₹' + r.pendingRent, '<span class="na-note">N/A</span>',
      ]), true);

    currentExportData = { title: 'Property Performance', headers: ['Property', 'Revenue', 'Expenses', 'Profit', 'Occupancy %', 'Maintenance Cost', 'Pending Rent'], rows: rows.map((r) => [r.name, r.revenue, r.expenses, r.profit, r.occPct + '%', r.maintCost, r.pendingRent]) };
  }

  // ======================================================================
  // 6. TENANT REPORTS
  // ======================================================================
  function renderTenants() {
    const f = getFilters();
    const tenants = TenantsController.getAll().filter((t) => (f.tenantId === 'all' || t.id === f.tenantId) && t.fullName.toLowerCase().includes(f.search));

    const active = tenants.filter((t) => t.status === 'Active').length;
    const notice = tenants.filter((t) => t.status === 'Notice Period').length;
    const movedOut = tenants.filter((t) => t.status === 'Moved Out').length;
    const totalPendingRent = tenants.reduce((s, t) => s + FinanceController.getTenantFinanceSummary(t.id).outstandingBalance, 0);

    document.getElementById('tenantReportGrid').innerHTML = `
      <div class="stat-card"><div class="label">Active Tenants</div><div class="value success">${active}</div></div>
      <div class="stat-card"><div class="label">Notice Period</div><div class="value warning">${notice}</div></div>
      <div class="stat-card"><div class="label">Moved Out</div><div class="value">${movedOut}</div></div>
      <div class="stat-card"><div class="label">Total Pending Rent</div><div class="value warning">₹${totalPendingRent}</div></div>
    `;

    const rows = tenants.map((t) => {
      const summary = FinanceController.getTenantFinanceSummary(t.id);
      return [t.fullName, t.status, '₹' + summary.outstandingBalance, '₹' + summary.totalPaid, summary.latePayments, t.currentAllocation ? t.currentAllocation.moveInDate : '—'];
    });
    renderTable('tenantReportTable', ['Tenant', 'Status', 'Pending Rent', 'Total Paid', 'Late Payments', 'Move In Date'], rows);

    currentExportData = { title: 'Tenant Report', headers: ['Tenant', 'Status', 'Pending Rent', 'Total Paid', 'Late Payments'], rows: rows.map((r) => [r[0], r[1], r[2], r[3], r[4]]) };
  }

  // ======================================================================
  // 7. MAINTENANCE ANALYTICS
  // ======================================================================
  function renderMaintenanceAnalytics() {
    const tickets = MaintenanceController.getAllTickets();
    const open = tickets.filter((t) => t.status === 'Open' || t.status === 'Assigned' || t.status === 'In Progress').length;
    const completed = tickets.filter((t) => t.status === 'Completed' || t.status === 'Closed').length;
    const closedTickets = tickets.filter((t) => t.status === 'Closed' && t.statusHistory?.length);
    const avgResolution = closedTickets.length
      ? Math.round((closedTickets.reduce((sum, t) => {
          const opened = new Date(t.createdAt);
          const closedEntry = [...t.statusHistory].reverse().find((h) => h.status === 'Closed');
          const closed = closedEntry ? new Date(closedEntry.timestamp) : new Date(t.updatedAt);
          return sum + Math.max(0, (closed - opened) / 86400000);
        }, 0) / closedTickets.length) * 10) / 10
      : 0;
    const thisMonth = currentMonthStr();
    const monthlyCost = tickets.filter((t) => t.closingDetails && t.updatedAt.startsWith(thisMonth)).reduce((s, t) => s + t.closingDetails.totalBilled, 0);

    const catCounts = {};
    const propCosts = {};
    tickets.forEach((t) => {
      catCounts[t.category] = (catCounts[t.category] || 0) + 1;
      if (t.closingDetails) propCosts[t.propertyId] = (propCosts[t.propertyId] || 0) + t.closingDetails.totalBilled;
    });
    const mostCommon = Object.entries(catCounts).sort((a, b) => b[1] - a[1])[0];
    const mostExpensivePropEntry = Object.entries(propCosts).sort((a, b) => b[1] - a[1])[0];
    const mostExpensiveProp = mostExpensivePropEntry ? PropertiesController.getAll().find((p) => p.id === mostExpensivePropEntry[0]) : null;

    document.getElementById('maintReportGrid').innerHTML = `
      <div class="stat-card"><div class="label">Open Tickets</div><div class="value warning">${open}</div></div>
      <div class="stat-card"><div class="label">Completed Tickets</div><div class="value success">${completed}</div></div>
      <div class="stat-card"><div class="label">Avg. Resolution Time</div><div class="value">${avgResolution} days</div></div>
      <div class="stat-card"><div class="label">Monthly Maintenance Cost</div><div class="value error">₹${monthlyCost}</div></div>
      <div class="stat-card"><div class="label">Most Common Complaint</div><div class="value" style="font-size:16px;">${mostCommon ? esc(mostCommon[0]) : '—'}</div></div>
      <div class="stat-card"><div class="label">Highest Maintenance Cost Property</div><div class="value" style="font-size:16px;">${mostExpensiveProp ? esc(mostExpensiveProp.name) : '—'}</div></div>
    `;
    currentExportData = { title: 'Maintenance Analytics', headers: ['Metric', 'Value'], rows: [
      ['Open Tickets', open], ['Completed Tickets', completed], ['Avg Resolution (days)', avgResolution],
      ['Monthly Maintenance Cost', monthlyCost], ['Most Common Complaint', mostCommon ? mostCommon[0] : '—'],
    ]};
  }

  // ======================================================================
  // 8. FINANCIAL ANALYTICS
  // ======================================================================
  function renderFinancial() {
    const rentEntries = FinanceController.getAllRentEntries();
    const expenses = FinanceController.getAllExpenses();
    const brokerage = FinanceController.getAllBrokerage();
    const fees = FinanceController.getAllManagementFees();
    const deposits = FinanceController.getAllDeposits();
    const thisMonth = currentMonthStr();

    const monthlyIncome = rentEntries.filter((r) => r.paymentDate && r.paymentDate.startsWith(thisMonth)).reduce((s, r) => s + r.amountPaid, 0);
    const monthlyExp = expenses.filter((e) => e.date.startsWith(thisMonth)).reduce((s, e) => s + e.amount, 0);
    const brokerageEarned = brokerage.filter((b) => b.status === 'Paid').reduce((s, b) => s + b.amount, 0);
    const feesEarned = fees.filter((f) => f.status === 'Paid').reduce((s, f) => s + f.amount, 0);
    const outstanding = rentEntries.filter((r) => r.paymentStatus !== 'Paid').reduce((s, r) => s + r.remainingBalance, 0);
    const depositsHeld = deposits.filter((d) => d.status === 'Held' || d.status === 'Partially Refunded').reduce((s, d) => s + (d.amount - d.refundedAmount), 0);
    const depositsRefunded = deposits.filter((d) => d.status === 'Refunded' || d.status === 'Partially Refunded').reduce((s, d) => s + d.refundedAmount, 0);
    const cashFlow = monthlyIncome + brokerageEarned + feesEarned - monthlyExp;

    document.getElementById('finReportGrid').innerHTML = `
      <div class="stat-card"><div class="label">Monthly Profit &amp; Loss</div><div class="value ${monthlyIncome - monthlyExp >= 0 ? 'success' : 'error'}">₹${monthlyIncome - monthlyExp}</div></div>
      <div class="stat-card"><div class="label">Income vs Expenses</div><div class="value">₹${monthlyIncome} / ₹${monthlyExp}</div></div>
      <div class="stat-card"><div class="label">Cash Flow (This Month)</div><div class="value ${cashFlow >= 0 ? 'success' : 'error'}">₹${cashFlow}</div></div>
      <div class="stat-card"><div class="label">Brokerage Earned</div><div class="value success">₹${brokerageEarned}</div></div>
      <div class="stat-card"><div class="label">Management Fees Earned</div><div class="value success">₹${feesEarned}</div></div>
      <div class="stat-card"><div class="label">Outstanding Amount</div><div class="value warning">₹${outstanding}</div></div>
      <div class="stat-card"><div class="label">Deposits Held</div><div class="value">₹${depositsHeld}</div></div>
      <div class="stat-card"><div class="label">Deposits Refunded</div><div class="value">₹${depositsRefunded}</div></div>
    `;

    const months = lastNMonths(6);
    const plRows = months.map((m) => {
      const inc = rentEntries.filter((r) => r.paymentDate && r.paymentDate.startsWith(m)).reduce((s, r) => s + r.amountPaid, 0);
      const exp = expenses.filter((e) => e.date.startsWith(m)).reduce((s, e) => s + e.amount, 0);
      return [fmtMonth(m), '₹' + inc, '₹' + exp, '₹' + (inc - exp)];
    });
    renderTable('plTable', ['Month', 'Income', 'Expenses', 'Profit/Loss'], plRows);
    currentExportData = { title: 'Financial Analytics', headers: ['Month', 'Income', 'Expenses', 'Profit/Loss'], rows: plRows };
  }

  // ======================================================================
  // 9. CHARTS
  // ======================================================================
  function destroyChart(id) { if (charts[id]) { charts[id].destroy(); delete charts[id]; } }

  function renderCharts() {
    if (typeof Chart === 'undefined') return; // CDN not loaded (offline) — charts simply skip rendering
    const textColor = themeColor('--text-secondary') || '#64748B';
    const gridColor = themeColor('--border') || '#E2E8F0';
    Chart.defaults.color = textColor;
    Chart.defaults.borderColor = gridColor;

    const months = lastNMonths(6);
    const rentEntries = FinanceController.getAllRentEntries();
    const expenses = FinanceController.getAllExpenses();

    // Line: Monthly Revenue
    destroyChart('chartRevenueLine');
    charts.chartRevenueLine = new Chart(document.getElementById('chartRevenueLine'), {
      type: 'line',
      data: { labels: months.map(fmtMonth), datasets: [{ label: 'Revenue', data: months.map((m) => rentEntries.filter((r) => r.paymentDate && r.paymentDate.startsWith(m)).reduce((s, r) => s + r.amountPaid, 0)), borderColor: '#2563EB', backgroundColor: 'rgba(37,99,235,0.1)', tension: 0.3 }] },
      options: { responsive: true, plugins: { legend: { display: false } } },
    });

    // Bar: Property Revenue
    const properties = PropertiesController.getAll();
    destroyChart('chartPropertyBar');
    charts.chartPropertyBar = new Chart(document.getElementById('chartPropertyBar'), {
      type: 'bar',
      data: { labels: properties.map((p) => p.name), datasets: [{ label: 'Revenue', data: properties.map((p) => rentEntries.filter((r) => r.propertyId === p.id).reduce((s, r) => s + r.amountPaid, 0)), backgroundColor: '#0D9488' }] },
      options: { responsive: true, plugins: { legend: { display: false } } },
    });

    // Pie: Occupancy
    const roomsForChart = RoomsController.getAllRooms();
    destroyChart('chartOccupancyPie');
    charts.chartOccupancyPie = new Chart(document.getElementById('chartOccupancyPie'), {
      type: 'pie',
      data: { labels: ['Occupied', 'Available'], datasets: [{ data: ['Occupied', 'Available'].map((s) => roomsForChart.filter((r) => RoomsController.computeRoomStatus(r.id) === s).length), backgroundColor: ['#2563EB', '#16A34A'] }] },
      options: { responsive: true },
    });

    // Pie: Expense by Category
    const expByCat = {};
    expenses.forEach((e) => { expByCat[e.category] = (expByCat[e.category] || 0) + e.amount; });
    destroyChart('chartExpensePie');
    charts.chartExpensePie = new Chart(document.getElementById('chartExpensePie'), {
      type: 'pie',
      data: { labels: Object.keys(expByCat), datasets: [{ data: Object.values(expByCat), backgroundColor: ['#2563EB','#0D9488','#D97706','#DC2626','#16A34A','#64748B','#9333EA','#DB2777','#EA580C'] }] },
      options: { responsive: true },
    });

    // Pie: Maintenance by Category
    const tickets = MaintenanceController.getAllTickets();
    const maintByCat = {};
    tickets.forEach((t) => { maintByCat[t.category] = (maintByCat[t.category] || 0) + 1; });
    destroyChart('chartMaintPie');
    charts.chartMaintPie = new Chart(document.getElementById('chartMaintPie'), {
      type: 'pie',
      data: { labels: Object.keys(maintByCat), datasets: [{ data: Object.values(maintByCat), backgroundColor: ['#2563EB','#0D9488','#D97706','#DC2626','#16A34A','#64748B','#9333EA','#DB2777','#EA580C','#0891B2','#65A30D','#C026D3'] }] },
      options: { responsive: true },
    });

    // Area: Income vs Expense
    destroyChart('chartIncomeExpenseArea');
    charts.chartIncomeExpenseArea = new Chart(document.getElementById('chartIncomeExpenseArea'), {
      type: 'line',
      data: { labels: months.map(fmtMonth), datasets: [
        { label: 'Income', data: months.map((m) => rentEntries.filter((r) => r.paymentDate && r.paymentDate.startsWith(m)).reduce((s, r) => s + r.amountPaid, 0)), borderColor: '#16A34A', backgroundColor: 'rgba(22,163,74,0.25)', fill: true, tension: 0.3 },
        { label: 'Expense', data: months.map((m) => expenses.filter((e) => e.date.startsWith(m)).reduce((s, e) => s + e.amount, 0)), borderColor: '#DC2626', backgroundColor: 'rgba(220,38,38,0.2)', fill: true, tension: 0.3 },
      ] },
      options: { responsive: true, plugins: { legend: { display: true } } },
    });
  }

  // ---------------- Shared table renderer ----------------
  function renderTable(tableId, headers, rows, allowHtml) {
    const table = document.getElementById(tableId);
    if (!rows.length) { table.innerHTML = `<tr><td colspan="${headers.length}" style="padding:20px; text-align:center; color:var(--text-secondary);">No data available yet.</td></tr>`; return; }
    const headRow = '<tr>' + headers.map((h) => `<th>${h}</th>`).join('') + '</tr>';
    const bodyRows = rows.map((r) => '<tr>' + r.map((c) => `<td>${allowHtml ? c : esc(String(c))}</td>`).join('') + '</tr>').join('');
    table.innerHTML = headRow + bodyRows;
  }

  // ======================================================================
  // EXPORT (CSV, Excel, PDF, Print)
  // ======================================================================
  function toCsvString() {
    const lines = [currentExportData.headers.join(',')];
    currentExportData.rows.forEach((r) => lines.push(r.map((c) => `"${String(c).replace(/<[^>]*>/g, '').replace(/"/g, '""')}"`).join(',')));
    return lines.join('\n');
  }

  function exportCsv() {
    try {
      const blob = new Blob([toCsvString()], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = currentExportData.title.replace(/\s+/g, '_') + '.csv';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showExportStatus('CSV downloaded.', false);
    } catch (err) {
      showExportStatus('CSV export failed: ' + err.message, true);
    }
  }

  function exportExcel() {
    if (typeof XLSX === 'undefined') {
      showExportStatus('Excel library did not load — check your internet connection and try again.', true);
      return;
    }
    try {
      const cleanRows = currentExportData.rows.map((r) => r.map((c) => String(c).replace(/<[^>]*>/g, '')));
      const ws = XLSX.utils.aoa_to_sheet([currentExportData.headers, ...cleanRows]);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, currentExportData.title.slice(0, 30));
      XLSX.writeFile(wb, currentExportData.title.replace(/\s+/g, '_') + '.xlsx');
      showExportStatus('Excel file downloaded.', false);
    } catch (err) {
      showExportStatus('Excel export failed: ' + err.message, true);
    }
  }

  function showExportStatus(message, isError) {
    const el = document.getElementById('rpExportStatus');
    if (!el) return;
    el.textContent = message;
    el.style.color = isError ? 'var(--error)' : 'var(--success)';
  }

  function exportPdf() {
    showExportStatus('Generating PDF...', false);
    setTimeout(() => {
      try {
        if (typeof window.jspdf === 'undefined') {
          showExportStatus('PDF library (jsPDF) failed to load from the CDN — check your internet connection.', true);
          return;
        }
        const jsPDFCtor = window.jspdf.jsPDF;
        if (typeof jsPDFCtor !== 'function') {
          showExportStatus('PDF library loaded but is not the expected version. Try Export CSV or Excel instead.', true);
          return;
        }
        const doc = new jsPDFCtor();
        doc.setFontSize(14);
        doc.text(currentExportData.title + ' — Fair Homes OS', 14, 16);
        doc.setFontSize(9);
        let y = 26;
        doc.text(currentExportData.headers.join('  |  '), 14, y);
        y += 6;
        currentExportData.rows.forEach((r) => {
          const line = r.map((c) => String(c).replace(/<[^>]*>/g, '')).join('  |  ');
          if (y > 280) { doc.addPage(); y = 16; }
          doc.text(line.slice(0, 120), 14, y);
          y += 6;
        });
        const blob = doc.output('blob');
        const url = URL.createObjectURL(blob);

        // Try opening the PDF in a new tab first — this uses the browser's
        // own PDF viewer (with its own Download/Share/Print icons), which
        // often still works even in sandboxed previews that block a
        // direct forced-download click.
        let opened = null;
        try { opened = window.open(url, '_blank'); } catch (e) { opened = null; }

        if (opened) {
          showExportStatus('PDF opened in a new tab — use its Download/Share icon to save it.', false);
        } else {
          // Popup was blocked — fall back to the direct download click.
          const a = document.createElement('a');
          a.href = url; a.download = currentExportData.title.replace(/\s+/g, '_') + '.pdf';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          showExportStatus('PDF download triggered (' + Math.round(blob.size / 1024) + ' KB). If nothing appeared, this preview may not support file downloads at all — try Export CSV instead, which uses a simpler method.', false);
        }
        setTimeout(() => URL.revokeObjectURL(url), 30000);
      } catch (err) {
        showExportStatus('PDF export error: ' + (err && err.message ? err.message : String(err)) + '. Try Export CSV or Excel instead.', true);
      }
    }, 50);
  }

  function printReport() {
    try {
      const printWindow = window.open('', '_blank');
      if (!printWindow) {
        showExportStatus('Could not open a print window — this preview may be blocking pop-ups entirely, which print needs. Try Export CSV or PDF instead.', true);
        return;
      }
      const rows = currentExportData.rows.map((r) => '<tr>' + r.map((c) => `<td style="padding:6px 10px; border-bottom:1px solid #ddd;">${String(c).replace(/<[^>]*>/g, '')}</td>`).join('') + '</tr>').join('');
      const head = currentExportData.headers.map((h) => `<th style="padding:6px 10px; text-align:left; border-bottom:2px solid #333;">${h}</th>`).join('');
      printWindow.document.write(`
        <html><head><title>${currentExportData.title} — Fair Homes OS</title></head>
        <body style="font-family:sans-serif; padding:20px;">
          <h2>${currentExportData.title} — Fair Homes OS</h2>
          <table style="width:100%; border-collapse:collapse; font-size:13px;"><thead><tr>${head}</tr></thead><tbody>${rows}</tbody></table>
        </body></html>
      `);
      printWindow.document.close();
      setTimeout(() => {
        try { printWindow.print(); } catch (e) { /* user can still use the new tab's own menu */ }
      }, 300);
      showExportStatus('Opened a printable version in a new tab. If the print dialog didn\'t appear there automatically, use that tab\'s own menu to print.', false);
    } catch (err) {
      showExportStatus('Print isn\'t available in this preview. Try Export CSV or PDF instead.', true);
    }
  }

  // ======================================================================
  // Sub-nav + Init
  // ======================================================================
  function renderActiveTab() {
    const activeTab = document.querySelector('#reportSubnav .rs-tab.active');
    switchSubTab(activeTab ? activeTab.dataset.rsub : 'rpExecutive');
  }

  function switchSubTab(subId) {
    document.querySelectorAll('#reportSubnav .rs-tab').forEach((t) => t.classList.toggle('active', t.dataset.rsub === subId));
    document.querySelectorAll('#page-reports .report-subview').forEach((v) => v.classList.toggle('active', v.id === 'rsub-' + subId));
    const map = {
      rpExecutive: renderExecutive, rpOccupancy: renderOccupancy, rpRent: renderRent, rpOwners: renderOwners,
      rpPerformance: renderPerformance, rpTenants: renderTenants, rpMaintenance: renderMaintenanceAnalytics,
      rpFinancial: renderFinancial, rpCharts: renderCharts,
    };
    (map[subId] || renderExecutive)();
  }

  function bindEvents() {
    document.querySelectorAll('#reportSubnav .rs-tab').forEach((tab) => tab.addEventListener('click', () => switchSubTab(tab.dataset.rsub)));
    document.getElementById('workReportGenerateBtn').addEventListener('click', renderOwnerWorkReport);
    ['rpPropertyFilter', 'rpOwnerFilter', 'rpTenantFilter', 'rpMonthFilter', 'rpYearFilter', 'rpDateFrom', 'rpDateTo'].forEach((id) => {
      document.getElementById(id).addEventListener('change', renderActiveTab);
    });
    document.getElementById('rpSearchInput').addEventListener('input', renderActiveTab);
    document.getElementById('rpClearFiltersBtn').addEventListener('click', clearFilters);
    document.getElementById('rpExportCsvBtn').addEventListener('click', exportCsv);
    document.getElementById('rpExportExcelBtn').addEventListener('click', exportExcel);
    document.getElementById('rpExportPdfBtn').addEventListener('click', exportPdf);
    document.getElementById('rpPrintBtn').addEventListener('click', printReport);
  }

  function onPageShow() {
    populateFilters();
    renderActiveTab();
  }

  function init() {
    bindEvents();
  }

  return { init, onPageShow };
})();
