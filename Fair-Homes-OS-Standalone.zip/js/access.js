/* ==========================================================================
   Fair Homes OS — Role-Based Access Control
   Resolves the signed-in user's role (via their Firebase login matched
   against Settings > Users), loads that role's permission matrix, and
   applies it: hides sidebar/bottom-nav items for modules without View
   access, blocks direct navigation to them, and hides each module's main
   "+Add" button where Create access is off.

   Honest scope note: this covers PAGE-LEVEL access (can this role see
   this module at all, can they see the main Add button) — it does not
   enforce field-by-field Edit/Delete/Export permissions inside a page
   (e.g. a visible Edit button on an individual record isn't individually
   gated). Super Admin always has full access regardless of the matrix,
   as a safety valve against locking everyone out by mistake.
   ========================================================================== */

const AccessController = (() => {
  const MODULE_TO_PAGE = {
    Dashboard: 'dashboard', Owners: 'owners', Properties: 'properties', Rooms: 'rooms',
    Bookings: 'bookings', BrokerageFlats: 'brokerageFlats', Tenants: 'tenants', Finance: 'finance', Maintenance: 'maintenance',
    SocialMediaTasks: 'socialMediaTasks', Reports: 'reports',
    Notifications: 'notifications', Settings: 'settings',
  };
  // The main "Add new record" button per module, hidden when Create is off.
  const MODULE_ADD_BUTTONS = {
    Owners: ['addOwnerBtn'], Properties: ['addPropertyBtn'], Bookings: ['addBookingBtn'], BrokerageFlats: ['addBrokerageFlatBtn'], Tenants: ['addTenantBtn'],
    Finance: ['addRentBtn', 'addDepositBtn', 'addBrokerageBtn', 'addFeeBtn', 'addExpenseBtn', 'addAdvanceBtn', 'addBizExpenseBtn'],
    Maintenance: ['addTicketBtn'], SocialMediaTasks: ['addSmtBtn'], Notifications: ['addTaskBtn'],
  };

  let currentRole = null;
  let currentPermissions = null;
  let accessDenied = false;

  function esc(str) { return String(str ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

  /**
   * Looks up the signed-in user in Settings > Users (matched by email)
   * to find their role and current status.
   *
   * Security note: only a genuinely EMPTY Users list bootstraps a new
   * Super Admin (the very first person ever to sign up for this
   * business). If Users already has records but this signed-in email
   * isn't among them — e.g. because a Super Admin deleted them — they
   * get NO access, not a default Super Admin. Same for a record found
   * but marked Inactive (deactivated). Their Firebase login itself still
   * technically works (deleting/disabling the actual login needs a
   * backend, which this app doesn't have), but the app immediately
   * signs them back out the moment this resolves — so being removed
   * from the Users list is what actually revokes their access to the
   * app itself.
   */
  async function resolveCurrentUser() {
    const authUser = CloudSync.getCurrentUser();
    if (!authUser) { currentRole = null; currentPermissions = null; accessDenied = false; return; }

    let users = [];
    let fetchFailed = false;
    try { users = await CloudSync.getOnce('users'); } catch (e) { fetchFailed = true; }

    if (fetchFailed) {
      // Could not verify the team roster at all (e.g. network hiccup) —
      // never fall back to granting access, and NEVER bootstrap a new
      // Super Admin on an unreliable read. Deny safely; they can retry.
      accessDenied = true;
      currentRole = null;
      await CloudSync.signOutUser();
      alert('Could not verify your account — check your internet connection and try signing in again.');
      return;
    }

    const match = users.find((u) => (u.email || '').toLowerCase() === (authUser.email || '').toLowerCase());

    if (users.length === 0) {
      // An empty list is NOT proof this business has never been set up —
      // it could just as easily mean a real read glitch, or every user
      // was deleted. A persistent 'setup marker' (created the one time
      // bootstrap genuinely happens) is what actually distinguishes
      // "truly first ever sign-up" from "something's wrong, users list
      // came back empty" — only the former should ever create a new
      // Super Admin.
      let setupMarker = null;
      try { setupMarker = await CloudSync.getDocOnce('fh_setup_marker'); } catch (e) { setupMarker = null; }
      if (setupMarker && setupMarker.completed) {
        // Setup already happened before; an empty users list right now
        // is unexpected and unsafe to act on — deny rather than mint a
        // fresh Super Admin.
        accessDenied = true;
        currentRole = null;
        await CloudSync.signOutUser();
        alert('Your account could not be verified against the team roster. Contact your Super Admin — do not retry repeatedly.');
        return;
      }
      // Genuinely first-ever user for this business — bootstrap as Super Admin.
      currentRole = 'Super Admin';
      accessDenied = false;
      await bootstrapFirstUser(authUser);
      await CloudSync.syncDoc('fh_setup_marker', { completed: true, bootstrappedEmail: authUser.email, bootstrappedAt: new Date().toISOString() });
    } else if (!match) {
      // Existing team, but this email isn't (or is no longer) a member — deny.
      accessDenied = true;
      currentRole = null;
    } else if (match.status === 'Inactive' && match.role !== 'Super Admin') {
      // Super Admin is exempt from deactivation — the ultimate safety
      // valve so the business owner can never be locked out, even by
      // an accidental status change (whether their own or someone
      // else's mistake). Only a fully deleted Super Admin record (the
      // !match branch above) would end their access.
      accessDenied = true;
      currentRole = null;
    } else {
      currentRole = match.role;
      accessDenied = false;
      // Backfill safety: users clearly exist already, so make sure the
      // setup marker reflects that too (covers deployments upgrading
      // from before this marker existed).
      CloudSync.getDocOnce('fh_setup_marker').then((marker) => {
        if (!marker || !marker.completed) CloudSync.syncDoc('fh_setup_marker', { completed: true, backfilledAt: new Date().toISOString() });
      }).catch(() => {});
    }

    if (accessDenied) {
      currentPermissions = null;
      await CloudSync.signOutUser();
      alert('Your access to Fair Homes OS has been removed or deactivated. Contact your Super Admin if this is unexpected.');
      return;
    }

    let permMap = null;
    try { permMap = await SettingsController.ensurePermissionsBackfilled(); } catch (e) { permMap = null; }
    if (!permMap) { try { permMap = await CloudSync.getDocOnce('fh_role_permissions'); } catch (e2) { permMap = null; } }
    if (!permMap) { try { permMap = JSON.parse(localStorage.getItem('fh_role_permissions')); } catch (e3) { permMap = null; } }
    currentPermissions = permMap ? permMap[currentRole] : null;
  }

  /** The very first person to sign up (Users list genuinely empty)
   *  automatically gets a Super Admin record created for them — they're
   *  the one setting up the business, so they need full access from the
   *  start, and someone needs to be able to add the rest of the team
   *  afterward. */
  async function bootstrapFirstUser(authUser) {
    const now = new Date().toISOString();
    const newUser = {
      id: (crypto.randomUUID ? crypto.randomUUID() : 'user_' + Date.now()),
      uid: authUser.uid, name: authUser.email.split('@')[0], email: authUser.email,
      mobile: '', role: 'Super Admin', status: 'Active', createdAt: now, updatedAt: now,
    };
    // Additive write only — never risks deleting any other user record,
    // unlike a full-array sync() would if the local cache were stale.
    await CloudSync.addOneToCollection('users', newUser);
  }

  function canView(moduleName) {
    if (accessDenied) return false;
    if (currentRole === 'Super Admin') return true;
    if (!currentPermissions) return true; // no matrix configured yet — don't lock anyone out
    return !!currentPermissions[moduleName]?.View;
  }
  function canCreate(moduleName) {
    if (accessDenied) return false;
    if (currentRole === 'Super Admin') return true;
    if (!currentPermissions) return true;
    return !!currentPermissions[moduleName]?.Create;
  }

  /** Hides sidebar + bottom-nav entries for modules this role can't
   *  View, and hides each module's main "+Add" button where this role
   *  can't Create. Called once after login, and again if the user's own
   *  permissions change live (rare, but possible if an admin edits the
   *  matrix on another device mid-session). */
  function applyRestrictions() {
    Object.entries(MODULE_TO_PAGE).forEach(([moduleName, pageId]) => {
      const allowed = canView(moduleName);
      document.querySelectorAll(`.nav-item[data-page="${pageId}"]`).forEach((el) => { el.style.display = allowed ? '' : 'none'; });
      document.querySelectorAll(`.bn-item[data-page="${pageId}"]`).forEach((el) => { el.style.display = allowed ? '' : 'none'; });
    });
    Object.entries(MODULE_ADD_BUTTONS).forEach(([moduleName, btnIds]) => {
      const allowed = canCreate(moduleName);
      btnIds.forEach((id) => { const el = document.getElementById(id); if (el) el.style.display = allowed ? '' : 'none'; });
    });
  }

  /** Called from nav.js's goToPage before switching — redirects to
   *  Dashboard with a message if this role can't View the requested
   *  page, so direct navigation can't bypass the hidden sidebar item. */
  function guardPageAccess(pageId) {
    const moduleName = Object.keys(MODULE_TO_PAGE).find((m) => MODULE_TO_PAGE[m] === pageId);
    if (!moduleName) return true; // unknown page id — don't block
    if (canView(moduleName)) return true;
    alert("You don't have access to this section. Contact your Super Admin if you need it.");
    return false;
  }

  /**
   * Watches the Users list live (not just at login) — if the signed-in
   * person's own record gets deactivated or deleted by a Super Admin
   * while they're actively using the app on some device, this signs
   * them out immediately on that device too, instead of waiting for
   * their next login attempt.
   */
  const sessionStartedAt = new Date().toISOString();
  function watchOwnAccessLive() {
    CloudSync.watch('users', (users) => {
      const authUser = CloudSync.getCurrentUser();
      if (!authUser || accessDenied || users.length === 0) return; // don't fire during initial bootstrap
      const match = users.find((u) => (u.email || '').toLowerCase() === (authUser.email || '').toLowerCase());
      const nowDenied = !match || (match.status === 'Inactive' && match.role !== 'Super Admin');
      if (nowDenied && currentRole !== null) {
        accessDenied = true;
        currentRole = null;
        CloudSync.signOutUser();
        alert('Your access to Fair Homes OS has been removed or deactivated.');
        return;
      }
      // One-time Force Sign-Out — distinct from deactivation: this just
      // ends the CURRENT session; the person can sign straight back in
      // if they want to. Only fires if the force-signout timestamp is
      // newer than when this particular session began (so it doesn't
      // re-trigger on every subsequent snapshot).
      if (match && match.forceSignOutAt && match.forceSignOutAt > sessionStartedAt) {
        CloudSync.signOutUser();
        alert('You have been signed out by your Super Admin. You can sign back in anytime.');
      }
    }, 'accessControl');
  }

  /** Verifies the entered PIN against the stored hash — used to gate
   *  Super-Admin-only sensitive actions (approving credential-change
   *  requests, force sign-out) with a secret independent of the Gmail
   *  login itself, so a compromised email/password alone isn't enough. */
  async function verifySecurityPin(enteredPin) {
    const stored = await CloudSync.getDocOnce('fh_security_pin');
    if (!stored || !stored.hash) return { ok: false, reason: 'not_set' };
    const enteredHash = await CloudSync.hashPin(enteredPin);
    return { ok: enteredHash === stored.hash, reason: enteredHash === stored.hash ? null : 'wrong_pin' };
  }
  async function setSecurityPin(newPin) {
    const hash = await CloudSync.hashPin(newPin);
    CloudSync.syncDoc('fh_security_pin', { hash, updatedAt: new Date().toISOString() });
  }
  async function hasSecurityPinSet() {
    const stored = await CloudSync.getDocOnce('fh_security_pin');
    return !!(stored && stored.hash);
  }

  function getCurrentRole() { return currentRole; }
  function isAccessDenied() { return accessDenied; }

  /** Picks where to land right after login: Dashboard if this role can
   *  see it (the normal case), otherwise the first module they DO have
   *  View access to — so a restricted role like Social Media lands on
   *  their own module instead of hitting a blocked Dashboard first. */
  function getFirstAccessiblePage() {
    if (canView('Dashboard')) return 'dashboard';
    const firstAllowed = Object.keys(MODULE_TO_PAGE).find((mod) => mod !== 'Dashboard' && canView(mod));
    return firstAllowed ? MODULE_TO_PAGE[firstAllowed] : 'dashboard';
  }

  return {
    resolveCurrentUser, applyRestrictions, guardPageAccess, canView, canCreate, getCurrentRole, isAccessDenied, watchOwnAccessLive,
    verifySecurityPin, setSecurityPin, hasSecurityPinSet, getFirstAccessiblePage,
  };
})();
