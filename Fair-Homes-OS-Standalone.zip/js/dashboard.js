/* ==========================================================================
   Fair Homes OS — Main Dashboard (First Screen)
   Was a static placeholder ("—" everywhere, "Dashboard module built in a
   later phase") since Phase 1 — this actually wires it up to live data
   across every module, including the newer additions (Bookings,
   Brokerage-Only Flats, Social Media Tasks).
   ========================================================================== */

const DashboardController = (() => {
  function esc(str) { if (str === null || str === undefined) return ''; return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
  function fmtDate(iso) { if (!iso) return '—'; const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }); }
  function currentMonthStr() { return new Date().toISOString().slice(0, 7); }
  function todayIso() { return new Date().toISOString().slice(0, 10); }

  function render() {
    if (typeof PropertiesController === 'undefined') return; // not all controllers ready yet
    const thisMonth = currentMonthStr();
    const today = todayIso();

    // ---------------- Stat cards ----------------
    const properties = PropertiesController.getAll();
    document.getElementById('dashStatProperties').textContent = properties.length;

    let occupiedRooms = 0, totalRooms = 0;
    if (typeof RoomsController !== 'undefined') {
      const allRooms = RoomsController.getAllRooms();
      totalRooms = allRooms.length;
      occupiedRooms = allRooms.filter((r) => RoomsController.computeRoomStatus(r.id) === 'Occupied').length;
    }
    document.getElementById('dashStatOccupied').textContent = totalRooms ? `${occupiedRooms} / ${totalRooms}` : '0';

    const rentEntries = FinanceController.getAllRentEntries();
    const rentThisMonth = rentEntries.filter((r) => r.paymentDate && r.paymentDate.startsWith(thisMonth)).reduce((s, r) => s + r.amountPaid, 0);
    document.getElementById('dashStatRent').textContent = '₹' + rentThisMonth;

    let openTickets = 0;
    if (typeof MaintenanceController !== 'undefined') {
      openTickets = MaintenanceController.getAllTickets().filter((t) => ['Open', 'Assigned', 'In Progress'].includes(t.status)).length;
    }
    document.getElementById('dashStatTickets').textContent = openTickets;

    let activeBookings = 0;
    if (typeof BookingsController !== 'undefined') {
      activeBookings = BookingsController.getAll().filter((b) => b.status === 'Active').length;
    }
    document.getElementById('dashStatBookings').textContent = activeBookings;

    let brkFlatsCount = 0;
    if (typeof BrokerageFlatsController !== 'undefined') {
      brkFlatsCount = BrokerageFlatsController.getAll().length;
    }
    document.getElementById('dashStatBrkFlats').textContent = brkFlatsCount;

    let smtToday = 0;
    if (typeof SocialMediaController !== 'undefined') {
      smtToday = SocialMediaController.getAll().filter((t) => t.date === today).length;
    }
    document.getElementById('dashStatSmt').textContent = smtToday;

    // Net Profit — same formula as Finance > Fair Homes Income
    const mgmtFeesTotal = FinanceController.getAllManagementFees().filter((f) => f.status === 'Paid' && f.month === thisMonth).reduce((s, f) => s + f.amount, 0);
    const brokerageTotal = FinanceController.getAllBrokerage().filter((b) => b.status === 'Paid' && b.paymentDate && b.paymentDate.startsWith(thisMonth)).reduce((s, b) => s + b.amount, 0);
    const marginTotal = FinanceController.getAllMarginIncome().filter((m) => m.date.startsWith(thisMonth)).reduce((s, m) => s + m.amount, 0);
    const bizExpenseTotal = FinanceController.getAllBusinessExpenses().filter((b) => b.date.startsWith(thisMonth)).reduce((s, b) => s + b.amount, 0);
    const netProfit = mgmtFeesTotal + brokerageTotal + marginTotal - bizExpenseTotal;
    const profitEl = document.getElementById('dashStatProfit');
    profitEl.textContent = '₹' + netProfit;
    profitEl.className = 'value ' + (netProfit >= 0 ? 'success' : 'error');

    // ---------------- Today's Priorities ----------------
    const priorities = [];
    const overdueRent = rentEntries.filter((r) => r.paymentStatus === 'Overdue');
    if (overdueRent.length) priorities.push({ icon: '🔴', text: `${overdueRent.length} overdue rent payment${overdueRent.length > 1 ? 's' : ''}`, page: 'finance' });
    const pendingRent = rentEntries.filter((r) => r.paymentStatus === 'Pending');
    if (pendingRent.length) priorities.push({ icon: '⏳', text: `${pendingRent.length} rent payment${pendingRent.length > 1 ? 's' : ''} still pending`, page: 'finance' });
    if (openTickets > 0) priorities.push({ icon: '🔧', text: `${openTickets} open maintenance ticket${openTickets > 1 ? 's' : ''}`, page: 'maintenance' });
    if (typeof BookingsController !== 'undefined') {
      const staleBookings = BookingsController.getAll().filter((b) => b.status === 'Active' && (new Date() - new Date(b.createdAt)) / 86400000 >= 7);
      if (staleBookings.length) priorities.push({ icon: '🔖', text: `${staleBookings.length} booking${staleBookings.length > 1 ? 's' : ''} pending 7+ days — needs follow-up`, page: 'bookings' });
    }
    if (typeof AccessController !== 'undefined' && AccessController.getCurrentRole() === 'Super Admin' && typeof SettingsController !== 'undefined') {
      let credentialRequests = [];
      try { credentialRequests = JSON.parse(localStorage.getItem('fh_credential_requests')) || []; } catch (e) { credentialRequests = []; }
      const pendingApprovals = credentialRequests.filter((r) => r.status === 'Pending').length;
      if (pendingApprovals) priorities.push({ icon: '🔐', text: `${pendingApprovals} approval request${pendingApprovals > 1 ? 's' : ''} waiting on you`, page: 'settings' });
    }

    const prioBox = document.getElementById('dashPriorities');
    prioBox.innerHTML = priorities.length
      ? priorities.map((p) => `<div class="danger-row dash-priority-item" data-page="${p.page}" style="cursor:pointer;"><div class="dr-label">${p.icon} ${esc(p.text)}</div></div>`).join('')
      : '<div class="empty-state"><div class="ico">✅</div><div class="title">All caught up</div><div class="desc">Nothing urgent right now.</div></div>';
    prioBox.querySelectorAll('.dash-priority-item').forEach((el) => el.addEventListener('click', () => NavController.goToPage(el.dataset.page)));

    // ---------------- Recent Activity feed ----------------
    const activity = [];
    rentEntries.filter((r) => r.paymentDate).forEach((r) => activity.push({ date: r.paymentDate, icon: '💰', text: `Rent collected — ₹${r.amountPaid}` }));
    if (typeof MaintenanceController !== 'undefined') {
      MaintenanceController.getAllTickets().forEach((t) => activity.push({ date: (t.dateTime || '').slice(0, 10), icon: '🔧', text: `Ticket: ${t.category} — ${t.status}` }));
    }
    if (typeof BookingsController !== 'undefined') {
      BookingsController.getAll().forEach((b) => activity.push({ date: b.createdAt.slice(0, 10), icon: '🔖', text: `Booking — ${esc(b.clientName)} (${b.status})` }));
    }
    if (typeof TenantsController !== 'undefined') {
      TenantsController.getAll().forEach((t) => { if (t.createdAt) activity.push({ date: t.createdAt.slice(0, 10), icon: '🧑‍🤝‍🧑', text: `Tenant added — ${esc(t.fullName)}` }); });
    }

    const recent = activity.filter((a) => a.date).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 10);
    const box = document.getElementById('dashRecentActivity');
    box.innerHTML = recent.length
      ? recent.map((a) => `<div class="history-item"><div class="hi-title">${a.icon} ${a.text}</div><div class="hi-row">${fmtDate(a.date)}</div></div>`).join('')
      : '<div class="empty-state"><div class="ico">📈</div><div class="title">No activity yet</div><div class="desc">Recent rent payments, tickets, and bookings will appear here.</div></div>';
  }

  return { render };
})();
