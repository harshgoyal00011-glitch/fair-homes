/* ==========================================================================
   Fair Homes OS — Brokerage-Only Flats
   Flats NOT under Fair Homes management — no owner profile, no tenant
   records, no maintenance, no ongoing rent tracking. Just enough detail
   to advertise the flat and record whatever flexible brokerage amount
   gets earned once a tenant is found. Deliberately kept separate from
   the main Properties module, which is for fully-managed flats.
   ========================================================================== */

const BrokerageFlatsController = (() => {
  const STORAGE_KEY = 'fh_brokerage_flats';
  const BHK_OPTIONS = [
    '1 RK', '1 BHK', '2 BHK', '3 BHK', '4 BHK', '4 BHK+',
    '1 Seat in 1 RK',
    '1 Seat in 1 BHK',
    '1 Seat in 2 BHK', '1 Room in 2 BHK', '3 Seats in 2 BHK',
    '1 Seat in 3 BHK', '1 Room in 3 BHK', '3 Seats in 3 BHK', '2 Rooms in 3 BHK', '5 Seats in 3 BHK',
    '1 Seat in 4 BHK', '1 Room in 4 BHK', '3 Seats in 4 BHK', '2 Rooms in 4 BHK', '5 Seats in 4 BHK', '3 Rooms in 4 BHK', '7 Seats in 4 BHK',
    'Others',
  ].map((v) => ({ value: v, label: v }));
  const SEQ_KEY = 'fh_brokerage_flat_seq';
  let flats = [];
  let editingFlatId = null;
  let dealFlatId = null;
  let dealTenants = []; // [{id, name, mobile}] — built up while the Deal modal is open
  let editingDealId = null; // set when editing an existing deal, null when recording a new one

  function esc(str) { if (str === null || str === undefined) return ''; return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
  function generateId() { return (crypto.randomUUID ? crypto.randomUUID() : 'brk_' + Date.now() + '_' + Math.random().toString(16).slice(2)); }
  function todayIso() { return new Date().toISOString().slice(0, 10); }
  function fmtDate(iso) { if (!iso) return '—'; const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }); }
  function nextCode() {
    let n = Number(localStorage.getItem(SEQ_KEY)) || 0;
    n += 1;
    localStorage.setItem(SEQ_KEY, String(n));
    return 'BRK-' + String(n).padStart(4, '0');
  }
  function clearErrors(formId) { document.querySelectorAll('#' + formId + ' .form-error').forEach((el) => (el.textContent = '')); }
  function showErrors(errors) { Object.entries(errors).forEach(([id, msg]) => { const el = document.getElementById('err-' + id); if (el) el.textContent = msg; }); }
  function totalDealsEarned(flat) { return (flat.deals || []).reduce((s, d) => s + d.totalAmount, 0); }

  // ---------------- Storage ----------------
  function load() {
    try { flats = JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; } catch (e) { flats = []; }
    CloudSync.watch('brokerageFlats', (arr) => {
      flats = arr;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
      renderList();
    });
  }
  function persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(flats));
    CloudSync.sync('brokerageFlats', flats);
  }

  // ---------------- List ----------------
  function renderList() {
    const sourceFilter = document.getElementById('brkSourceFilter').value || 'all';
    const search = (document.getElementById('brkSearchInput').value || '').toLowerCase().trim();
    let list = [...flats].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    if (sourceFilter !== 'all') list = list.filter((f) => f.sourceType === sourceFilter);
    if (search) list = list.filter((f) => (f.society || '').toLowerCase().includes(search) || (f.flatNo || '').toLowerCase().includes(search));

    const box = document.getElementById('brokerageFlatsList');
    if (!list.length) { box.innerHTML = '<div class="empty-state"><div class="ico">🤝</div><div class="title">No brokerage-only flats</div><div class="desc">Add a flat that\'s only for finding a tenant, not full management.</div></div>'; return; }

    box.innerHTML = list.map((f) => {
      const earned = totalDealsEarned(f);
      const sourceInfo = f.sourceType === 'Direct Owner'
        ? (f.ownerName ? `Owner: ${esc(f.ownerName)}${f.ownerMobile ? ' · ' + phoneLinks(f.ownerMobile) : ''}` : '')
        : (f.brokerName ? `Broker: ${esc(f.brokerName)}${f.brokerMobile ? ' · ' + phoneLinks(f.brokerMobile) : ''}` : '');
      return `
        <div class="settings-card">
          <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:8px;">
            <div>
              <h3 style="margin-bottom:2px;">${esc(f.society)} — Flat ${esc(f.flatNo)} <span class="badge ${f.sourceType === 'Direct Owner' ? 'cat-system' : 'pay-pending'}" style="margin-left:6px;">${esc(f.sourceType)}</span></h3>
              <div class="sc-desc">${esc(f.bhk)} · ₹${f.rent} · ${esc(f.preference)}${sourceInfo ? ' · ' + sourceInfo : ''}</div>
            </div>
            <div style="display:flex; gap:6px;">
              <button class="btn small secondary brk-edit-btn" data-id="${f.id}">Edit</button>
              <button class="btn small secondary brk-del-btn" data-id="${f.id}" style="background:var(--error); color:#fff;">Delete</button>
            </div>
          </div>
          <div class="danger-row" style="border-top:1px solid var(--border); margin-top:10px; padding-top:10px;">
            <div class="dr-label">Total Brokerage Earned (All Deals)</div>
            <div style="font-weight:700; color:var(--success);">₹${earned}</div>
          </div>
          ${(f.deals || []).length ? `
            <div style="margin-top:8px;">
              <div class="sc-desc" style="margin-bottom:4px;">Deal History</div>
              ${f.deals.map((d) => `
                <div class="history-item" style="margin-bottom:6px;">
                  <div class="hi-title">${fmtDate(d.date)} — ₹${d.totalAmount} <button class="btn small secondary brk-deal-edit-btn" data-flat-id="${f.id}" data-deal-id="${d.id}" style="margin-left:8px; padding:2px 8px;">Edit</button></div>
                  <div class="hi-row">From Tenant: ₹${d.fromTenant} · From Owner: ₹${d.fromOwner}${d.notes ? ' · ' + esc(d.notes) : ''}</div>
                  ${(d.tenants || []).length ? `<div class="hi-row">${d.tenants.map((t) => `${esc(t.name)}${t.mobile ? ' (' + phoneLinks(t.mobile) + ')' : ''}`).join(', ')}</div>` : ''}
                </div>`).join('')}
            </div>` : ''}
          <button class="btn small brk-deal-btn" data-id="${f.id}" style="margin-top:10px;">+ Record New Brokerage Deal</button>
        </div>`;
    }).join('');

    box.querySelectorAll('.brk-edit-btn').forEach((b) => b.addEventListener('click', () => openEditFlatModal(b.dataset.id)));
    box.querySelectorAll('.brk-del-btn').forEach((b) => b.addEventListener('click', () => handleDeleteFlat(b.dataset.id)));
    box.querySelectorAll('.brk-deal-btn').forEach((b) => b.addEventListener('click', () => openDealModal(b.dataset.id)));
    box.querySelectorAll('.brk-deal-edit-btn').forEach((b) => b.addEventListener('click', () => openDealModal(b.dataset.flatId, b.dataset.dealId)));
  }

  // ---------------- Add/Edit Flat ----------------
  function toggleSourceFields() {
    const sourceType = document.getElementById('brkSourceType').value;
    document.getElementById('brkOwnerFields').classList.toggle('hidden', sourceType !== 'Direct Owner');
    document.getElementById('brkBrokerFields').classList.toggle('hidden', sourceType !== 'Through Broker');
  }

  function openAddFlatModal() {
    editingFlatId = null;
    document.getElementById('brkFlatModalTitle').textContent = 'Add Flat';
    document.getElementById('brkFlatForm').reset();
    document.getElementById('brkFlatId').value = '';
    document.getElementById('brkSourceType').value = 'Direct Owner';
    toggleSourceFields();
    clearErrors('brkFlatForm');
    document.getElementById('brkFlatModalOverlay').classList.add('open');
  }
  function openEditFlatModal(id) {
    const f = flats.find((x) => x.id === id);
    if (!f) return;
    editingFlatId = id;
    document.getElementById('brkFlatModalTitle').textContent = 'Edit Flat';
    document.getElementById('brkFlatId').value = f.id;
    document.getElementById('brkSociety').value = f.society;
    document.getElementById('brkFlatNo').value = f.flatNo;
    bhkSearchableSelect.setValue(f.bhk);
    document.getElementById('brkRent').value = f.rent;
    document.getElementById('brkPreference').value = f.preference;
    document.getElementById('brkSourceType').value = f.sourceType;
    document.getElementById('brkOwnerName').value = f.ownerName || '';
    document.getElementById('brkOwnerMobile').value = f.ownerMobile || '';
    document.getElementById('brkBrokerName').value = f.brokerName || '';
    document.getElementById('brkBrokerMobile').value = f.brokerMobile || '';
    document.getElementById('brkNotes').value = f.notes || '';
    toggleSourceFields();
    clearErrors('brkFlatForm');
    document.getElementById('brkFlatModalOverlay').classList.add('open');
  }
  function closeFlatModal() { document.getElementById('brkFlatModalOverlay').classList.remove('open'); editingFlatId = null; }

  function handleSaveFlat() {
    const society = document.getElementById('brkSociety').value.trim();
    const flatNo = document.getElementById('brkFlatNo').value.trim();
    const bhk = document.getElementById('brkBhk').value;
    const rent = document.getElementById('brkRent').value;
    const preference = document.getElementById('brkPreference').value;
    const sourceType = document.getElementById('brkSourceType').value;
    const ownerName = document.getElementById('brkOwnerName').value.trim();
    const ownerMobile = document.getElementById('brkOwnerMobile').value.trim();
    const brokerName = document.getElementById('brkBrokerName').value.trim();
    const brokerMobile = document.getElementById('brkBrokerMobile').value.trim();
    const notes = document.getElementById('brkNotes').value.trim();

    const errors = {};
    if (!society) errors.brkSociety = 'Society is required';
    if (!flatNo) errors.brkFlatNo = 'Flat number is required';
    else if (society) {
      const dup = flats.some((f) => f.id !== editingFlatId && f.society.trim().toLowerCase() === society.toLowerCase() && f.flatNo.trim().toLowerCase() === flatNo.toLowerCase());
      if (dup) errors.brkFlatNo = 'This flat number already exists in this society';
    }
    if (!bhk) errors.brkBhk = 'Select what\'s being rented out';
    if (!rent || Number(rent) <= 0) errors.brkRent = 'Enter a valid rent amount';
    clearErrors('brkFlatForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const now = new Date().toISOString();
    if (editingFlatId) {
      const idx = flats.findIndex((f) => f.id === editingFlatId);
      if (idx !== -1) flats[idx] = { ...flats[idx], society, flatNo, bhk, rent: Number(rent), preference, sourceType, ownerName, ownerMobile, brokerName, brokerMobile, notes, updatedAt: now };
    } else {
      flats.unshift({
        id: generateId(), code: nextCode(), society, flatNo, bhk, rent: Number(rent), preference, sourceType,
        ownerName, ownerMobile, brokerName, brokerMobile, notes, deals: [], createdAt: now, updatedAt: now,
      });
    }
    persist();
    closeFlatModal();
    renderList();
  }

  function handleDeleteFlat(id) {
    const f = flats.find((x) => x.id === id);
    if (!f) return;
    ConfirmModal.show(`Delete ${f.society} — Flat ${f.flatNo}? You can restore it later from Settings → Trash. This does not affect any brokerage income already recorded.`, () => {
      TrashController.moveToTrash('brokerageFlat', f, `${f.society} — Flat ${f.flatNo}`);
      flats = flats.filter((x) => x.id !== id);
      persist();
      renderList();
    });
  }

  // ---------------- Record Deal ----------------
  /** For a flat whose brokerage started via a converted Booking, computes
   *  how much of the agreed total has already been received (summing
   *  past deals tied to that same booking) vs what's still remaining —
   *  drives the smart Total/Received/Remaining display when recording
   *  the next payment toward it. */
  function getPendingBrokerageProgress(flat) {
    const pending = flat.pendingBrokerageInfo;
    if (!pending) return null;
    const alreadyReceived = (flat.deals || [])
      .filter((d) => d.linkedBookingId === pending.bookingId)
      .reduce((s, d) => s + (d.fromTenant || 0), 0);
    return { total: pending.total, alreadyReceived, remaining: pending.total - alreadyReceived, bookingId: pending.bookingId };
  }

  function openDealModal(flatId, dealId) {
    dealFlatId = flatId;
    editingDealId = dealId || null;
    document.getElementById('brkDealFlatId').value = flatId;
    clearErrors('brkDealForm');
    const flat = flats.find((f) => f.id === flatId);

    if (editingDealId) {
      const deal = flat ? (flat.deals || []).find((d) => d.id === editingDealId) : null;
      if (!deal) return;
      document.getElementById('brkDealModalTitle').textContent = 'Edit Brokerage Deal';
      document.getElementById('brkDealFromTenant').value = deal.fromTenant || '';
      document.getElementById('brkDealFromOwner').value = deal.fromOwner || '';
      document.getElementById('brkDealDate').value = deal.date;
      document.getElementById('brkDealNotes').value = deal.notes || '';
      dealTenants = (deal.tenants || []).map((t) => ({ id: generateId(), name: t.name, mobile: t.mobile }));
      document.getElementById('brkDealProgressBox').classList.add('hidden'); // editing a past entry — don't re-show the "at the time" progress snapshot
    } else {
      document.getElementById('brkDealModalTitle').textContent = 'Record Brokerage Deal';
      document.getElementById('brkDealFromTenant').value = '';
      document.getElementById('brkDealFromOwner').value = '';
      document.getElementById('brkDealDate').value = todayIso();
      document.getElementById('brkDealNotes').value = '';
      dealTenants = [];

      const progress = flat ? getPendingBrokerageProgress(flat) : null;
      const progressBox = document.getElementById('brkDealProgressBox');
      if (progress) {
        progressBox.classList.remove('hidden');
        document.getElementById('brkDealProgressTotal').textContent = '₹' + progress.total;
        document.getElementById('brkDealProgressReceived').textContent = '₹' + progress.alreadyReceived;
        document.getElementById('brkDealProgressRemaining').textContent = '₹' + progress.remaining;
      } else {
        progressBox.classList.add('hidden');
      }
    }
    renderDealTenantsList();
    updateDealCalc();
    document.getElementById('brkDealModalOverlay').classList.add('open');
  }
  function closeDealModal() { document.getElementById('brkDealModalOverlay').classList.remove('open'); dealFlatId = null; editingDealId = null; }

  /** Renders the current in-progress deal's tenant rows, each editable
   *  inline (name + mobile), with a remove button. Deliberately simple —
   *  this is just a reference record for a Brokerage-Only flat, not a
   *  full Tenant profile like the managed-properties module has. */
  function renderDealTenantsList() {
    const box = document.getElementById('brkDealTenantsList');
    if (!dealTenants.length) { box.innerHTML = '<div class="sc-desc" style="margin-bottom:8px;">Koi person add nahi kiya abhi.</div>'; return; }
    box.innerHTML = dealTenants.map((t) => `
      <div class="form-row-2" style="margin-bottom:6px; align-items:center;" data-tenant-row="${t.id}">
        <input type="text" class="deal-tenant-name" data-id="${t.id}" placeholder="Naam" value="${esc(t.name)}" />
        <div style="display:flex; gap:6px;">
          <input type="text" class="deal-tenant-mobile" data-id="${t.id}" placeholder="Mobile" maxlength="10" value="${esc(t.mobile)}" style="flex:1;" />
          <button type="button" class="btn small secondary deal-tenant-remove" data-id="${t.id}" style="background:var(--error); color:#fff; padding:6px 10px;">✕</button>
        </div>
      </div>`).join('');
    box.querySelectorAll('.deal-tenant-name').forEach((el) => el.addEventListener('input', (e) => {
      const t = dealTenants.find((x) => x.id === e.target.dataset.id); if (t) t.name = e.target.value;
    }));
    box.querySelectorAll('.deal-tenant-mobile').forEach((el) => el.addEventListener('input', (e) => {
      const t = dealTenants.find((x) => x.id === e.target.dataset.id); if (t) t.mobile = e.target.value;
    }));
    box.querySelectorAll('.deal-tenant-remove').forEach((el) => el.addEventListener('click', (e) => {
      dealTenants = dealTenants.filter((x) => x.id !== e.target.dataset.id);
      renderDealTenantsList();
    }));
  }

  function addDealTenantRow() {
    dealTenants.push({ id: generateId(), name: '', mobile: '' });
    renderDealTenantsList();
  }

  function updateDealCalc() {
    const fromTenant = Number(document.getElementById('brkDealFromTenant').value) || 0;
    const fromOwner = Number(document.getElementById('brkDealFromOwner').value) || 0;
    document.getElementById('brkDealCalcBox').innerHTML = `
      <div class="calc-row"><span>From Tenant</span><span>₹${fromTenant}</span></div>
      <div class="calc-row"><span>From Owner</span><span>₹${fromOwner}</span></div>
      <div class="calc-row total"><span>Total Brokerage</span><span>₹${fromTenant + fromOwner}</span></div>
    `;

    const note = document.getElementById('brkDealAdjustmentNote');
    const flat = flats.find((f) => f.id === dealFlatId);
    const progress = (!editingDealId && flat) ? getPendingBrokerageProgress(flat) : null;
    if (progress && fromTenant > 0) {
      const diff = fromTenant - progress.remaining;
      if (diff > 0) {
        note.classList.remove('hidden');
        note.innerHTML = `<div class="form-hint" style="color:var(--success);">Extra Received for Documentation / Extra Work: ₹${diff}</div>`;
      } else if (diff < 0) {
        note.classList.remove('hidden');
        note.innerHTML = `<div class="form-hint" style="color:var(--warning);">Discount Given: ₹${Math.abs(diff)}</div>`;
      } else {
        note.classList.add('hidden');
        note.innerHTML = '';
      }
    } else {
      note.classList.add('hidden');
      note.innerHTML = '';
    }
  }

  function handleSaveDeal() {
    const fromTenant = Number(document.getElementById('brkDealFromTenant').value) || 0;
    const fromOwner = Number(document.getElementById('brkDealFromOwner').value) || 0;
    const date = document.getElementById('brkDealDate').value;
    const notes = document.getElementById('brkDealNotes').value.trim();
    const totalAmount = fromTenant + fromOwner;

    clearErrors('brkDealForm');
    if (totalAmount <= 0) { showErrors({ brkDeal: 'Enter at least one amount (from Tenant or Owner).' }); return; }
    if (!date) { showErrors({ brkDeal: 'Select a date.' }); return; }

    const flat = flats.find((f) => f.id === dealFlatId);
    if (!flat) return;
    const idx = flats.findIndex((f) => f.id === dealFlatId);
    const tenants = dealTenants.filter((t) => t.name.trim()).map((t) => ({ name: t.name.trim(), mobile: t.mobile.trim() }));
    const label = `Brokerage-Only Deal — ${flat.society} Flat ${flat.flatNo} (${flat.code})`;

    if (editingDealId) {
      const dealIdx = (flats[idx].deals || []).findIndex((d) => d.id === editingDealId);
      if (dealIdx === -1) return;
      const existingDeal = flats[idx].deals[dealIdx];
      flats[idx].deals[dealIdx] = { ...existingDeal, fromTenant, fromOwner, totalAmount, date, notes, tenants };
      flats[idx].updatedAt = new Date().toISOString();
      persist();
      if (typeof FinanceController !== 'undefined' && existingDeal.marginIncomeId) {
        FinanceController.updateMarginIncome(existingDeal.marginIncomeId, { amount: totalAmount, date });
      }
    } else {
      const progress = getPendingBrokerageProgress(flat);
      let extraReceived = 0, discountGiven = 0, linkedBookingId = null;
      if (progress) {
        linkedBookingId = progress.bookingId;
        const diff = fromTenant - progress.remaining;
        if (diff > 0) extraReceived = diff;
        else if (diff < 0) discountGiven = Math.abs(diff);
      }
      const deal = {
        id: generateId(), fromTenant, fromOwner, totalAmount, date, notes, tenants, marginIncomeId: null,
        linkedBookingId, extraReceived, discountGiven,
        dealStage: progress ? 'Shifting Settlement' : 'Standalone',
      };
      if (typeof FinanceController !== 'undefined') {
        const result = FinanceController.recordMarginIncome({ source: 'brokerageOnlyDeal', propertyId: null, amount: totalAmount, label, date, flatId: flat.id });
        deal.marginIncomeId = result ? result.id : null;
      }
      flats[idx].deals = [...(flats[idx].deals || []), deal];
      // Once the full agreed brokerage has been received across all
      // deals tied to this booking, the pending target is settled —
      // clear it so a future, unrelated tenancy on this same flat
      // starts fresh instead of comparing against old numbers.
      if (progress) {
        const newTotalReceived = progress.alreadyReceived + fromTenant;
        if (newTotalReceived >= progress.total) flats[idx].pendingBrokerageInfo = null;
      }
      flats[idx].updatedAt = new Date().toISOString();
      persist();
    }

    closeDealModal();
    renderList();
  }

  // ---------------- Init ----------------
  function bindEvents() {
    document.getElementById('addBrokerageFlatBtn').addEventListener('click', openAddFlatModal);
    document.getElementById('brkFlatModalCloseBtn').addEventListener('click', closeFlatModal);
    document.getElementById('brkFlatCancelBtn').addEventListener('click', closeFlatModal);
    document.getElementById('brkFlatModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'brkFlatModalOverlay') closeFlatModal(); });
    document.getElementById('brkFlatSaveBtn').addEventListener('click', handleSaveFlat);
    document.getElementById('brkSourceType').addEventListener('change', toggleSourceFields);

    document.getElementById('brkDealModalCloseBtn').addEventListener('click', closeDealModal);
    document.getElementById('brkDealCancelBtn').addEventListener('click', closeDealModal);
    document.getElementById('brkDealModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'brkDealModalOverlay') closeDealModal(); });
    document.getElementById('brkDealSaveBtn').addEventListener('click', handleSaveDeal);
    ['brkDealFromTenant', 'brkDealFromOwner'].forEach((id) => document.getElementById(id).addEventListener('input', updateDealCalc));
    document.getElementById('brkDealAddTenantBtn').addEventListener('click', addDealTenantRow);

    document.getElementById('brkSourceFilter').addEventListener('change', renderList);
    document.getElementById('brkSearchInput').addEventListener('input', renderList);
  }

  function onPageShow() { renderList(); }
  let bhkSearchableSelect = null;
  function init() { load(); bindEvents(); bhkSearchableSelect = initSearchableSelect('brkBhkInput', 'brkBhk', BHK_OPTIONS); }
  function reload() { load(); renderList(); }

  /** Called from Bookings when a Brokerage-Only booking converts —
   *  records a Deal on this flat directly, with the client's name/
   *  mobile already filled in as the deal's person, and the collected
   *  token as the tenant-side brokerage amount. Defaults to 'Whole
   *  Flat' portion since the booking form doesn't ask for room/seat
   *  detail — editable afterward from the flat's own page if needed. */
  function recordDealFromBooking({ flatId, fromTenantAmount, clientName, clientMobile, date, bookingId, totalBrokerageTarget }) {
    const idx = flats.findIndex((f) => f.id === flatId);
    if (idx === -1) return;
    const deal = {
      id: generateId(), fromTenant: fromTenantAmount, fromOwner: 0, totalAmount: fromTenantAmount,
      date: date || todayIso(), notes: 'Converted from Booking.',
      tenants: clientName ? [{ name: clientName, mobile: clientMobile || '' }] : [],
      marginIncomeId: null, linkedBookingId: bookingId || null, extraReceived: 0, discountGiven: 0,
      dealStage: 'Booking Conversion',
    };
    if (typeof FinanceController !== 'undefined' && fromTenantAmount > 0) {
      const result = FinanceController.recordMarginIncome({
        source: 'brokerageOnlyDeal', propertyId: null, amount: fromTenantAmount,
        label: `Brokerage-Only Deal (from Booking) — ${flats[idx].society} Flat ${flats[idx].flatNo} (${flats[idx].code})`, date: date || todayIso(),
        flatId: flats[idx].id,
      });
      deal.marginIncomeId = result ? result.id : null;
    }
    flats[idx].deals = [...(flats[idx].deals || []), deal];
    // If there's more brokerage still to come (target bigger than what
    // was collected via the token), remember the target so the NEXT
    // deal recorded for this flat can show Total/Received/Remaining
    // automatically instead of the manager tracking it in their head.
    if (bookingId && totalBrokerageTarget > fromTenantAmount) {
      flats[idx].pendingBrokerageInfo = { bookingId, total: totalBrokerageTarget };
    }
    flats[idx].updatedAt = new Date().toISOString();
    persist();
    renderList();
  }

  return { init, onPageShow, reload, getAll: () => [...flats], recordDealFromBooking };
})();
