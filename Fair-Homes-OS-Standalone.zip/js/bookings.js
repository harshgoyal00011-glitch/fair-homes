/* ==========================================================================
   Fair Homes OS — Bookings (Token/Advance before move-in)
   Tracks the token/advance a prospective client pays to hold a flat
   before they actually shift in. Supports BOTH property types:
   - Management: converts into a full Tenant (Room/Bed allocation +
     auto Rent entry from the token).
   - Brokerage-Only: converts into a Brokerage Deal on that flat
     instead (no Tenant/Room/Rent tracking, since Fair Homes doesn't
     manage these — the token becomes the brokerage amount earned).
   Cancellation works the same for both: the token is non-refundable by
   default and becomes Fair Homes income; a partial refund can be
   entered, with the remainder still counted as income.
   ========================================================================== */

const BookingsController = (() => {
  const STORAGE_KEY = 'fh_bookings';
  const SEQ_KEY = 'fh_booking_seq';
  let bookings = [];
  let editingBookingId = null;
  let tokenPaymentBookingId = null;
  let cancelBookingId = null;

  function esc(str) { if (str === null || str === undefined) return ''; return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
  function generateId() { return (crypto.randomUUID ? crypto.randomUUID() : 'bk_' + Date.now() + '_' + Math.random().toString(16).slice(2)); }
  function todayIso() { return new Date().toISOString().slice(0, 10); }
  function fmtDate(iso) { if (!iso) return '—'; const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }); }
  function nextCode() {
    let n = Number(localStorage.getItem(SEQ_KEY)) || 0;
    n += 1;
    localStorage.setItem(SEQ_KEY, String(n));
    return 'BK-' + String(n).padStart(4, '0');
  }
  function clearErrors(formId) { document.querySelectorAll('#' + formId + ' .form-error').forEach((el) => (el.textContent = '')); }
  function showErrors(errors) { Object.entries(errors).forEach(([id, msg]) => { const el = document.getElementById('err-' + id); if (el) el.textContent = msg; }); }

  function totalTokenCollected(booking) { return (booking.tokenPayments || []).reduce((s, p) => s + p.amount, 0); }
  function totalPackage(booking) {
    const rentForPackage = booking.proratedFirstMonthRent !== undefined && booking.proratedFirstMonthRent !== null
      ? booking.proratedFirstMonthRent : (Number(booking.monthlyRent) || 0);
    return rentForPackage + (Number(booking.securityAmount) || 0) + (Number(booking.brokerageAmount) || 0);
  }

  /** Prorates the first month's rent from the move-in date to the end
   *  of that calendar month — so if rent is meant to run 1st-to-1st
   *  (a common Owner requirement when other rooms in the same flat are
   *  already on that cycle), a mid-month move-in doesn't get charged a
   *  full month. From the following month onward, the full monthly
   *  rent applies and the cycle naturally lines up to the 1st. */
  function calculateProratedRent(monthlyRent, moveInDateStr) {
    if (!moveInDateStr || !monthlyRent) return null;
    const moveIn = new Date(moveInDateStr);
    if (isNaN(moveIn)) return null;
    const year = moveIn.getFullYear(), month = moveIn.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const moveInDay = moveIn.getDate();
    const remainingDays = daysInMonth - moveInDay + 1; // inclusive of move-in day itself
    const proratedRent = Math.round((Number(monthlyRent) / daysInMonth) * remainingDays);
    const monthLabel = moveIn.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
    const nextCycleLabel = new Date(year, month + 1, 1).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
    return { daysInMonth, moveInDay, remainingDays, proratedRent, monthLabel, nextCycleLabel, isFullMonth: remainingDays === daysInMonth };
  }

  // ---------------- Storage ----------------
  function load() {
    try { bookings = JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; } catch (e) { bookings = []; }
    CloudSync.watch('bookings', (arr) => {
      bookings = arr;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
      renderBookingsList();
    });
  }
  function persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bookings));
    CloudSync.sync('bookings', bookings);
  }

  // ---------------- Filters ----------------
  function populateFilters() {
    const propSel = document.getElementById('bookingPropertyFilter');
    const current = propSel.value;
    const mgmtOptions = PropertiesController.getAll().map((p) => `<option value="mgmt:${p.id}">${esc(p.society || p.name)}</option>`).join('');
    const brkOptions = (typeof BrokerageFlatsController !== 'undefined' ? BrokerageFlatsController.getAll() : []).map((f) => `<option value="brk:${f.id}">${esc(f.society)} — Flat ${esc(f.flatNo)} (Brokerage-Only)</option>`).join('');
    propSel.innerHTML = '<option value="all">All Properties/Flats</option>' + mgmtOptions + brkOptions;
    propSel.value = current || 'all';
  }

  // ---------------- List rendering ----------------
  function renderBookingsList() {
    const statusFilter = document.getElementById('bookingStatusFilter').value || 'Active';
    const propFilter = document.getElementById('bookingPropertyFilter').value || 'all';
    const dateFilter = document.getElementById('bookingDateFilter').value || '';
    const search = (document.getElementById('bookingSearchInput').value || '').toLowerCase().trim();

    let list = [...bookings].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    if (statusFilter !== 'all') list = list.filter((b) => b.status === statusFilter);
    if (propFilter !== 'all') {
      const [kind, id] = propFilter.split(':');
      list = list.filter((b) => (kind === 'mgmt' ? b.propertyId === id : b.brokerageFlatId === id));
    }
    if (dateFilter) {
      list = list.filter((b) => b.createdAt.startsWith(dateFilter) || (b.tokenPayments || []).some((p) => p.date === dateFilter));
    }
    if (search) {
      list = list.filter((b) => {
        const property = b.bookingType === 'BrokerageOnly'
          ? (typeof BrokerageFlatsController !== 'undefined' ? BrokerageFlatsController.getAll().find((f) => f.id === b.brokerageFlatId) : null)
          : PropertiesController.getAll().find((p) => p.id === b.propertyId);
        const flatText = property ? (property.society || property.name || '') + ' ' + (property.flatNo || '') : '';
        return b.clientName.toLowerCase().includes(search) || (b.clientMobile || '').includes(search) || flatText.toLowerCase().includes(search);
      });
    }

    const box = document.getElementById('bookingsList');
    if (!list.length) { box.innerHTML = '<div class="empty-state"><div class="ico">🔖</div><div class="title">No bookings</div><div class="desc">Add one when a client pays a token to hold a flat.</div></div>'; return; }

    box.innerHTML = list.map((b) => {
      const isBrokerageOnly = b.bookingType === 'BrokerageOnly';
      const property = isBrokerageOnly
        ? (typeof BrokerageFlatsController !== 'undefined' ? BrokerageFlatsController.getAll().find((f) => f.id === b.brokerageFlatId) : null)
        : PropertiesController.getAll().find((p) => p.id === b.propertyId);
      const propertyLabel = property ? (property.society || property.name) + (isBrokerageOnly ? ` — Flat ${property.flatNo}` : '') : '—';
      const pkg = totalPackage(b);
      const collected = totalTokenCollected(b);
      const balance = pkg - collected;
      const statusBadgeClass = b.status === 'Active' ? 'pay-pending' : b.status === 'Converted' ? 'pay-paid' : 'pay-overdue';
      const convertLabel = isBrokerageOnly ? 'Convert to Deal' : 'Convert to Tenant';
      return `
        <div class="settings-card">
          <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:8px;">
            <div>
              <h3 style="margin-bottom:2px;">${esc(b.clientName)} <span class="badge ${statusBadgeClass}" style="margin-left:6px;">${b.status}</span> <span class="badge ${isBrokerageOnly ? 'pay-pending' : 'cat-system'}" style="margin-left:4px;">${isBrokerageOnly ? 'Brokerage-Only' : 'Management'}</span></h3>
              <div class="sc-desc">${esc(b.bookingCode)} · ${esc(propertyLabel)} · ${phoneLinks(b.clientMobile)} · Added ${fmtDate(b.createdAt.slice(0, 10))}${b.moveInDate ? ' · Move-in: ' + fmtDate(b.moveInDate) : ''}${b.ownerAdvanceAmount > 0 ? ' · Owner Advance: ₹' + b.ownerAdvanceAmount : ''}</div>
            </div>
          </div>
          <div class="danger-row" style="border-top:1px solid var(--border); margin-top:10px; padding-top:10px;">
            <div class="dr-label">Total Package (Rent + Security + Brokerage)</div>
            <div style="font-weight:700;">₹${pkg}</div>
          </div>
          ${b.proratedFirstMonthRent !== undefined && b.proratedFirstMonthRent !== null && b.proratedFirstMonthRent !== b.monthlyRent ? `<div class="sc-desc">First month rent prorated to ₹${b.proratedFirstMonthRent} (move-in ${fmtDate(b.moveInDate)}) — full ₹${b.monthlyRent} rent applies from next month, 1st-to-1st cycle.</div>` : ''}
          <div class="danger-row">
            <div class="dr-label">Token/Advance Collected So Far</div>
            <div style="font-weight:700; color:var(--success);">₹${collected}</div>
          </div>
          <div class="danger-row">
            <div class="dr-label">${b.status === 'Cancelled' ? 'Forfeited (Fair Homes Income)' : 'Balance Remaining'}</div>
            <div style="font-weight:700; color:${b.status === 'Cancelled' ? 'var(--success)' : 'var(--error)'};">₹${b.status === 'Cancelled' ? b.forfeitedAmount : balance}</div>
          </div>
          ${b.status === 'Active' ? `
            <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:10px;">
              <button class="btn small secondary bk-token-btn" data-id="${b.id}">+ Add Token Payment</button>
              <button class="btn small bk-convert-btn" data-id="${b.id}">${convertLabel}</button>
              <button class="btn small secondary bk-cancel-btn" data-id="${b.id}" style="background:var(--error); color:#fff;">Cancel Booking</button>
            </div>` : ''}
          ${b.status === 'Cancelled' ? `<div class="sc-desc" style="margin-top:8px;">${b.refundAmount > 0 ? `₹${b.refundAmount} refunded to client. ` : ''}${b.ownerAdvanceAmount > 0 ? `₹${b.ownerAdvanceAmount} was already advanced to Owner (non-recoverable).` : ''}</div>` : ''}
          <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:8px;">
            <button class="btn small secondary bk-edit-btn" data-id="${b.id}">Edit</button>
            <button class="btn small secondary bk-delete-btn" data-id="${b.id}" style="background:var(--error); color:#fff;">Delete</button>
          </div>
        </div>`;
    }).join('');

    box.querySelectorAll('.bk-token-btn').forEach((btn) => btn.addEventListener('click', () => openTokenPaymentModal(btn.dataset.id)));
    box.querySelectorAll('.bk-convert-btn').forEach((btn) => btn.addEventListener('click', () => handleConvert(btn.dataset.id)));
    box.querySelectorAll('.bk-cancel-btn').forEach((btn) => btn.addEventListener('click', () => openCancelBookingModal(btn.dataset.id)));
    box.querySelectorAll('.bk-edit-btn').forEach((btn) => btn.addEventListener('click', () => openEditBookingModal(btn.dataset.id)));
    box.querySelectorAll('.bk-delete-btn').forEach((btn) => btn.addEventListener('click', () => handleDeleteBooking(btn.dataset.id)));
  }

  // ---------------- Add Booking ----------------
  function toggleBookingTypeFields() {
    const isBrokerageOnly = document.getElementById('bookingType').value === 'BrokerageOnly';
    document.getElementById('bookingManagementFields').classList.toggle('hidden', isBrokerageOnly);
    document.getElementById('bookingBrokerageOnlyFields').classList.toggle('hidden', !isBrokerageOnly);
    document.getElementById('bookingBrokerageOnlyNote').classList.toggle('hidden', !isBrokerageOnly);
    document.getElementById('bookingOwnerAdvanceGroup').classList.toggle('hidden', !isBrokerageOnly);
    if (isBrokerageOnly) populateBrokerageFlatSelect();
  }

  /** When a Brokerage-Only Flat is picked, its rent is already on file
   *  — auto-fill it so the manager only has to type Security and
   *  Brokerage manually, not re-enter a number that's already stored. */
  function onBrokerageFlatSelected() {
    const flatId = document.getElementById('bookingBrokerageFlat').value;
    if (!flatId || typeof BrokerageFlatsController === 'undefined') return;
    const flat = BrokerageFlatsController.getAll().find((f) => f.id === flatId);
    if (flat) {
      document.getElementById('bookingRent').value = flat.rent;
      updateBookingPackageCalc();
    }
  }

  function populatePropertySelect(alwaysIncludePropertyId) {
    const sel = document.getElementById('bookingProperty');
    const allProperties = PropertiesController.getAll();
    const bookableProperties = typeof RoomsController !== 'undefined'
      ? allProperties.filter((p) => p.id === alwaysIncludePropertyId || (!p.underMaintenance && RoomsController.getAvailableRoomsByProperty(p.id).length > 0))
      : allProperties;
    sel.innerHTML = '<option value="">Select Property</option>' + bookableProperties.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
  }
  let brokerageFlatSearchableSelect = null;
  function populateBrokerageFlatSelect() {
    const flats = typeof BrokerageFlatsController !== 'undefined' ? BrokerageFlatsController.getAll() : [];
    const options = flats.map((f) => ({ value: f.id, label: `${f.society} — Flat ${f.flatNo} (${f.bhk})` }));
    brokerageFlatSearchableSelect = initSearchableSelect('bookingBrokerageFlatInput', 'bookingBrokerageFlat', options);
  }

  function openAddBookingModal() {
    editingBookingId = null;
    document.getElementById('bookingModalTitle').textContent = 'Add Booking';
    document.getElementById('bookingForm').reset();
    document.getElementById('bookingId').value = '';
    document.getElementById('bookingType').value = 'Management';
    document.getElementById('bookingType').disabled = false;
    document.getElementById('bookingProperty').disabled = false;
    document.getElementById('bookingBrokerageFlatInput').disabled = false;
    document.getElementById('bookingInitialTokenFields').classList.remove('hidden');
    document.getElementById('bookingEditTokenNote').classList.add('hidden');
    document.getElementById('bookingSaveBtn').textContent = 'Save Booking';
    populatePropertySelect();
    document.getElementById('bookingPortion').value = '1 Room';
    toggleBookingTypeFields();
    document.getElementById('bookingTokenDate').value = todayIso();
    updateBookingPackageCalc();
    clearErrors('bookingForm');
    document.getElementById('bookingModalOverlay').classList.add('open');
  }

  /** Edit only touches the booking's own details (client info,
   *  financial numbers, dates, notes) — NOT which property/flat it's
   *  for (that's locked in once created) or its token payment history
   *  (managed via the separate Add Token Payment flow). */
  /** "Edit This Booking" from inside Convert-to-Tenant — saves whatever
   *  has been typed so far into all tenant sections, then opens the
   *  normal Edit Booking form. After Save Changes there, the Convert
   *  modal reopens with that same data still in place. */
  function handleEditBookingFromConvert() {
    if (!convertingBooking) return;
    convertDraftToRestore = captureConvertDraft(convertingBooking.memberCount || 1);
    returnToConvertAfterEdit = true;
    document.getElementById('convertTenantModalOverlay').classList.remove('open');
    openEditBookingModal(convertingBooking.id);
  }

  function openEditBookingModal(id) {
    const b = bookings.find((x) => x.id === id);
    if (!b) return;
    editingBookingId = id;
    document.getElementById('bookingModalTitle').textContent = 'Edit Booking';
    document.getElementById('bookingId').value = b.id;
    document.getElementById('bookingType').value = b.bookingType;
    document.getElementById('bookingType').disabled = true;
    populatePropertySelect(b.propertyId);
    document.getElementById('bookingProperty').value = b.propertyId || '';
    document.getElementById('bookingProperty').disabled = true;
    document.getElementById('bookingPortion').value = b.portion || '1 Room';
    document.getElementById('bookingMemberCount').value = b.memberCount || '';
    toggleBookingTypeFields();
    if (b.bookingType === 'BrokerageOnly' && brokerageFlatSearchableSelect) {
      brokerageFlatSearchableSelect.setValue(b.brokerageFlatId || '');
    }
    document.getElementById('bookingBrokerageFlatInput').disabled = true;
    document.getElementById('bookingClientName').value = b.clientName;
    document.getElementById('bookingClientMobile').value = b.clientMobile;
    document.getElementById('bookingReferralSource').value = b.referralSource || '';
    document.getElementById('bookingRent').value = b.monthlyRent;
    document.getElementById('bookingSecurity').value = b.securityAmount;
    document.getElementById('bookingBrokerage').value = b.brokerageAmount;
    document.getElementById('bookingOwnerAdvance').value = b.ownerAdvanceAmount || '';
    document.getElementById('bookingMoveInDate').value = b.moveInDate || '';
    document.getElementById('bookingNotes').value = b.notes || '';
    document.getElementById('bookingInitialTokenFields').classList.add('hidden');
    document.getElementById('bookingEditTokenNote').classList.remove('hidden');
    document.getElementById('bookingSaveBtn').textContent = 'Save Changes';
    updateBookingPackageCalc();
    clearErrors('bookingForm');
    document.getElementById('bookingModalOverlay').classList.add('open');
  }

  function handleDeleteBooking(id) {
    const b = bookings.find((x) => x.id === id);
    if (!b) return;
    ConfirmModal.show(`Delete this booking for ${b.clientName}? You can restore it later from Settings → Trash.`, () => {
      if (typeof TrashController !== 'undefined') TrashController.moveToTrash('booking', b, `Booking — ${b.clientName} (${b.bookingCode})`);
      bookings = bookings.filter((x) => x.id !== id);
      persist();
      renderBookingsList();
    });
  }

  function closeBookingModal() {
    document.getElementById('bookingModalOverlay').classList.remove('open');
    editingBookingId = null;
    if (returnToConvertAfterEdit) {
      returnToConvertAfterEdit = false;
      const targetId = convertingBooking ? convertingBooking.id : null;
      const targetBooking = targetId ? bookings.find((b) => b.id === targetId) : null;
      if (targetBooking) setTimeout(() => openConvertToTenantModal(targetBooking), 50);
    }
  }

  function updateBookingPackageCalc() {
    const rent = Number(document.getElementById('bookingRent').value) || 0;
    const security = Number(document.getElementById('bookingSecurity').value) || 0;
    const brokerage = Number(document.getElementById('bookingBrokerage').value) || 0;
    const bookingType = document.getElementById('bookingType').value;
    const moveInDate = document.getElementById('bookingMoveInDate').value;

    let rentLine = `<div class="calc-row"><span>Rent</span><span>₹${rent}</span></div>`;
    let rentForTotal = rent;
    let cycleNote = '';

    if (bookingType === 'BrokerageOnly' && moveInDate && rent > 0) {
      const p = calculateProratedRent(rent, moveInDate);
      if (p && !p.isFullMonth) {
        rentForTotal = p.proratedRent;
        rentLine = `<div class="calc-row"><span>${esc(p.monthLabel)} Rent (Prorated, ${p.remainingDays}/${p.daysInMonth} days)</span><span>₹${p.proratedRent}</span></div>`;
        cycleNote = `<div class="form-hint" style="margin-top:6px;">1 October se poora monthly rent (₹${rent}) applicable hoga, aur rent cycle 1st-to-1st chalegi. Next full cycle starts: ${esc(p.nextCycleLabel)}.</div>`;
      } else if (p) {
        cycleNote = `<div class="form-hint" style="margin-top:6px;">Move-in month ke 1st se hi shuru ho raha hai — poora rent lagega, koi proration nahi.</div>`;
      }
    }

    document.getElementById('bookingPackageCalcBox').innerHTML = `
      ${rentLine}
      <div class="calc-row"><span>Security</span><span>₹${security}</span></div>
      <div class="calc-row"><span>Brokerage</span><span>₹${brokerage}</span></div>
      <div class="calc-row total"><span>Total Package</span><span>₹${rentForTotal + security + brokerage}</span></div>
      ${cycleNote}
    `;
  }

  function handleSaveBooking() {
    const bookingType = document.getElementById('bookingType').value;
    const propertyId = document.getElementById('bookingProperty').value;
    const portion = document.getElementById('bookingPortion').value;
    const memberCount = document.getElementById('bookingMemberCount').value;
    const brokerageFlatId = document.getElementById('bookingBrokerageFlat').value;
    const clientName = document.getElementById('bookingClientName').value.trim();
    const clientMobile = document.getElementById('bookingClientMobile').value.trim();
    const referralSource = document.getElementById('bookingReferralSource').value;
    const monthlyRent = document.getElementById('bookingRent').value;
    const securityAmount = document.getElementById('bookingSecurity').value;
    const brokerageAmount = document.getElementById('bookingBrokerage').value;
    const ownerAdvanceAmount = document.getElementById('bookingOwnerAdvance').value;
    const moveInDate = document.getElementById('bookingMoveInDate').value;
    const notes = document.getElementById('bookingNotes').value.trim();
    const proratedFirstMonthRent = (bookingType === 'BrokerageOnly' && moveInDate && monthlyRent)
      ? (calculateProratedRent(Number(monthlyRent), moveInDate)?.proratedRent ?? null) : null;

    const errors = {};
    if (bookingType === 'Management' && !propertyId) errors.bookingProperty = 'Select a property';
    if (bookingType === 'Management' && (!memberCount || Number(memberCount) < 1)) errors.bookingMemberCount = 'Enter how many members will stay';
    if (bookingType === 'BrokerageOnly' && !brokerageFlatId) errors.bookingBrokerageFlat = 'Select a flat';
    if (!clientName) errors.bookingClientName = 'Client name is required';
    if (!clientMobile || !/^\d{10}$/.test(clientMobile)) errors.bookingClientMobile = 'Enter a valid 10-digit mobile number';

    if (editingBookingId) {
      const existing = bookings.find((b) => b.id === editingBookingId);
      const collected = existing ? totalTokenCollected(existing) : 0;
      if (Number(ownerAdvanceAmount) > collected) errors.bookingOwnerAdvance = `Can't exceed the ₹${collected} token already collected`;
      clearErrors('bookingForm');
      if (Object.keys(errors).length) { showErrors(errors); return; }

      const idx = bookings.findIndex((b) => b.id === editingBookingId);
      if (idx !== -1) {
        bookings[idx] = {
          ...bookings[idx], clientName, clientMobile, referralSource,
          portion: bookings[idx].bookingType === 'Management' ? portion : null,
          memberCount: bookings[idx].bookingType === 'Management' ? Number(memberCount) || 1 : null,
          monthlyRent: Number(monthlyRent) || 0, securityAmount: Number(securityAmount) || 0, brokerageAmount: Number(brokerageAmount) || 0,
          ownerAdvanceAmount: Number(ownerAdvanceAmount) || 0, moveInDate: moveInDate || null, proratedFirstMonthRent, notes,
          updatedAt: new Date().toISOString(),
        };
      }
      persist();
      closeBookingModal();
      renderBookingsList();
      return;
    }

    const tokenAmount = document.getElementById('bookingTokenAmount').value;
    const tokenDate = document.getElementById('bookingTokenDate').value;
    if (!tokenAmount || Number(tokenAmount) <= 0) errors.bookingTokenAmount = 'Enter the token amount received';
    if (Number(ownerAdvanceAmount) > Number(tokenAmount)) errors.bookingTokenAmount = 'Owner advance can\'t be more than the token collected';
    clearErrors('bookingForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const now = new Date().toISOString();
    const record = {
      id: generateId(), bookingCode: nextCode(), bookingType,
      propertyId: bookingType === 'Management' ? propertyId : null,
      portion: bookingType === 'Management' ? portion : null, memberCount: bookingType === 'Management' ? Number(memberCount) || 1 : null,
      brokerageFlatId: bookingType === 'BrokerageOnly' ? brokerageFlatId : null,
      clientName, clientMobile, referralSource,
      monthlyRent: Number(monthlyRent) || 0, securityAmount: Number(securityAmount) || 0, brokerageAmount: Number(brokerageAmount) || 0,
      tokenPayments: [{ id: generateId(), amount: Number(tokenAmount), date: tokenDate || todayIso() }],
      ownerAdvanceAmount: Number(ownerAdvanceAmount) || 0, moveInDate: moveInDate || null, proratedFirstMonthRent,
      status: 'Active', notes,
      convertedTenantId: null, convertedAt: null,
      cancelledAt: null, refundAmount: 0, forfeitedAmount: 0, cancellationReason: '',
      createdAt: now, updatedAt: now,
    };
    bookings.unshift(record);
    persist();
    closeBookingModal();
    renderBookingsList();
  }

  // ---------------- Add Token Payment ----------------
  function openTokenPaymentModal(id) {
    tokenPaymentBookingId = id;
    document.getElementById('tokenPaymentBookingId').value = id;
    document.getElementById('tokenPaymentAmount').value = '';
    document.getElementById('tokenPaymentDate').value = todayIso();
    clearErrors('tokenPaymentForm');
    document.getElementById('tokenPaymentModalOverlay').classList.add('open');
  }
  function closeTokenPaymentModal() { document.getElementById('tokenPaymentModalOverlay').classList.remove('open'); tokenPaymentBookingId = null; }

  function handleSaveTokenPayment() {
    const amount = document.getElementById('tokenPaymentAmount').value;
    const date = document.getElementById('tokenPaymentDate').value;
    clearErrors('tokenPaymentForm');
    if (!amount || Number(amount) <= 0) { showErrors({ tokenPaymentAmount: 'Enter a valid amount' }); return; }
    const idx = bookings.findIndex((b) => b.id === tokenPaymentBookingId);
    if (idx === -1) return;
    bookings[idx].tokenPayments.push({ id: generateId(), amount: Number(amount), date: date || todayIso() });
    bookings[idx].updatedAt = new Date().toISOString();
    persist();
    closeTokenPaymentModal();
    renderBookingsList();
  }

  // ---------------- Convert (branches by booking type) ----------------
  function handleConvert(id) {
    const booking = bookings.find((b) => b.id === id);
    if (!booking) return;
    if (booking.bookingType === 'BrokerageOnly') handleConvertToDeal(booking);
    else handleConvertToTenant(booking);
  }

  function handleConvertToTenant(booking) {
    const collected = totalTokenCollected(booking);
    ConfirmModal.show(
      `Moving ${booking.clientName}'s booking to Tenants now — ${booking.memberCount || 1} member(s) to add. Rent/Security/Brokerage and the ₹${collected} token collected will carry over automatically.`,
      () => {
        NavController.goToPage('tenants');
        setTimeout(() => openConvertToTenantModal(booking), 50);
      },
      'Convert to Tenant'
    );
  }

  // ---------------- Convert to Tenant — Multi-Tenant Modal ----------------
  let convertingBooking = null;
  let convertDraftToRestore = null; // captured tenant-section values, restored after an Edit Booking detour
  let returnToConvertAfterEdit = false;

  function tenantFieldHTML(idx, fieldKey, label, type, extra) {
    const id = `convTenant_${idx}_${fieldKey}`;
    extra = extra || '';
    return `
      <div class="field-group">
        <label class="field-label" for="${id}">${label}</label>
        <input type="${type}" id="${id}" ${extra} />
        <div class="form-error" id="err-${id}"></div>
      </div>`;
  }

  function buildTenantSectionHTML(idx, availableRoomsOptions) {
    const isFirst = idx === 0;
    return `
      <div class="settings-card" style="margin-bottom:14px;" data-tenant-idx="${idx}">
        <h3 style="margin-bottom:10px;">Tenant ${idx + 1}${isFirst ? ' (Primary — Billing)' : ' (Co-Tenant)'}</h3>
        <div class="field-group">
          <label class="field-label" for="convTenant_${idx}_room">Room *</label>
          <select id="convTenant_${idx}_room">${availableRoomsOptions}</select>
          <div class="form-error" id="err-convTenant_${idx}_room"></div>
        </div>
        ${tenantFieldHTML(idx, 'fullName', 'Full Name *', 'text')}
        <div class="form-row-2">
          ${tenantFieldHTML(idx, 'mobile', 'Mobile Number *', 'text', 'maxlength="10"')}
          ${tenantFieldHTML(idx, 'altMobile', 'Alternate Mobile', 'text', 'maxlength="10"')}
        </div>
        ${tenantFieldHTML(idx, 'email', 'Email', 'email')}
        <div class="field-group">
          <label class="field-label" for="convTenant_${idx}_aadhaar">Aadhaar Number</label>
          <input type="text" id="convTenant_${idx}_aadhaar" placeholder="1234 5678 9012" maxlength="14" />
        </div>
        <div class="form-row-2">
          ${tenantFieldHTML(idx, 'fatherName', "Father's Name", 'text')}
          ${tenantFieldHTML(idx, 'emergencyContact', 'Emergency Contact', 'text', 'maxlength="10"')}
        </div>
        <div class="form-row-2">
          ${tenantFieldHTML(idx, 'dob', 'Date of Birth', 'date')}
          <div class="field-group">
            <label class="field-label" for="convTenant_${idx}_gender">Gender</label>
            <select id="convTenant_${idx}_gender"><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select>
          </div>
        </div>
        <div class="form-row-2">
          <div class="field-group">
            <label class="field-label" for="convTenant_${idx}_occupation">Occupation</label>
            <select id="convTenant_${idx}_occupation"><option value="">Select</option><option>Student</option><option>Employed</option><option>Business</option></select>
          </div>
          ${tenantFieldHTML(idx, 'companyOrCollege', 'Company / College (Optional)', 'text')}
        </div>
        ${tenantFieldHTML(idx, 'permanentAddress', 'Permanent Address', 'text')}
        ${tenantFieldHTML(idx, 'currentAddress', 'Current Address', 'text')}
        ${tenantFieldHTML(idx, 'notes', 'Notes', 'text')}
      </div>`;
  }

  const CONV_TENANT_FIELDS = ['room', 'fullName', 'mobile', 'altMobile', 'email', 'aadhaar', 'fatherName', 'emergencyContact', 'dob', 'gender', 'occupation', 'companyOrCollege', 'permanentAddress', 'currentAddress', 'notes'];

  /** Snapshots every field's current value across all tenant sections
   *  before leaving the Convert-to-Tenant modal for an Edit Booking
   *  detour — nothing typed so far gets lost. */
  function captureConvertDraft(memberCount) {
    const draft = [];
    for (let i = 0; i < memberCount; i++) {
      const entry = {};
      CONV_TENANT_FIELDS.forEach((key) => {
        const el = document.getElementById(`convTenant_${i}_${key}`);
        if (el) entry[key] = el.value;
      });
      draft.push(entry);
    }
    return draft;
  }

  /** Re-applies a previously captured draft onto the freshly-rebuilt
   *  tenant sections — called right after re-opening Convert-to-Tenant
   *  following an Edit Booking save. */
  function restoreConvertDraft(draft) {
    if (!draft) return;
    draft.forEach((entry, i) => {
      CONV_TENANT_FIELDS.forEach((key) => {
        const el = document.getElementById(`convTenant_${i}_${key}`);
        if (el && entry[key]) el.value = entry[key];
      });
    });
  }

  function openConvertToTenantModal(booking) {
    convertingBooking = booking;
    const property = PropertiesController.getAll().find((p) => p.id === booking.propertyId);
    document.getElementById('convBookedByInfo').innerHTML = `
      <div class="hi-title">Booked By This Person</div>
      <div class="hi-row">${esc(booking.clientName)} · ${phoneLinks(booking.clientMobile)}</div>
      <div class="sc-desc" style="margin-top:6px;">${property ? esc(property.name) : ''} · ${esc(booking.portion || '')} · This person may or may not be an actual tenant — fill in the real occupant(s) below.</div>
    `;

    const availableRooms = typeof RoomsController !== 'undefined' && property ? RoomsController.getAvailableRoomsByProperty(property.id) : [];
    const roomOptions = '<option value="">Select Room</option>' + availableRooms.map((r) => `<option value="${r.id}">Room ${esc(r.roomNumber)}</option>`).join('');
    const memberCount = booking.memberCount || 1;

    const container = document.getElementById('convTenantSectionsContainer');
    container.innerHTML = Array.from({ length: memberCount }, (_, i) => buildTenantSectionHTML(i, roomOptions)).join('');

    document.getElementById('convTenant_0_fullName').value = booking.clientName;
    document.getElementById('convTenant_0_mobile').value = booking.clientMobile;
    if (property) document.getElementById('convTenant_0_currentAddress').value = property.address || '';
    for (let i = 0; i < memberCount; i++) wireAadhaarFormatting(`convTenant_${i}_aadhaar`);

    if (convertDraftToRestore) {
      restoreConvertDraft(convertDraftToRestore);
      convertDraftToRestore = null;
    }

    document.getElementById('convPortionError').textContent = '';
    document.getElementById('convertTenantModalOverlay').classList.add('open');
  }

  function closeConvertToTenantModal() {
    document.getElementById('convertTenantModalOverlay').classList.remove('open');
    convertingBooking = null;
  }

  function handleSaveConvertToTenant() {
    const booking = convertingBooking;
    if (!booking) return;
    const memberCount = booking.memberCount || 1;
    const collected = totalTokenCollected(booking);
    const errors = {};
    const sections = [];

    for (let i = 0; i < memberCount; i++) {
      const roomId = document.getElementById(`convTenant_${i}_room`).value;
      const fullName = document.getElementById(`convTenant_${i}_fullName`).value.trim();
      const mobile = document.getElementById(`convTenant_${i}_mobile`).value.trim();
      if (!roomId) errors[`convTenant_${i}_room`] = 'Select a room';
      if (!fullName) errors[`convTenant_${i}_fullName`] = 'Full name is required';
      if (!mobile || !/^\d{10}$/.test(mobile)) errors[`convTenant_${i}_mobile`] = 'Enter a valid 10-digit mobile number';
      sections.push({
        roomId, fullName, mobile,
        altMobile: document.getElementById(`convTenant_${i}_altMobile`).value.trim(),
        email: document.getElementById(`convTenant_${i}_email`).value.trim(),
        aadhaar: document.getElementById(`convTenant_${i}_aadhaar`).value.replace(/\s/g, ''),
        fatherName: document.getElementById(`convTenant_${i}_fatherName`).value.trim(),
        emergencyContact: document.getElementById(`convTenant_${i}_emergencyContact`).value.trim(),
        dob: document.getElementById(`convTenant_${i}_dob`).value,
        gender: document.getElementById(`convTenant_${i}_gender`).value,
        occupation: document.getElementById(`convTenant_${i}_occupation`).value,
        companyOrCollege: document.getElementById(`convTenant_${i}_companyOrCollege`).value.trim(),
        permanentAddress: document.getElementById(`convTenant_${i}_permanentAddress`).value.trim(),
        currentAddress: document.getElementById(`convTenant_${i}_currentAddress`).value.trim(),
        notes: document.getElementById(`convTenant_${i}_notes`).value.trim(),
      });
    }

    document.querySelectorAll('#convTenantSectionsContainer .form-error').forEach((el) => (el.textContent = ''));
    document.getElementById('convPortionError').textContent = '';
    if (Object.keys(errors).length) {
      Object.entries(errors).forEach(([id, msg]) => { const el = document.getElementById('err-' + id); if (el) el.textContent = msg; });
      return;
    }

    // "What are you renting?" from the Booking should actually mean
    // something here — check the distinct rooms selected match it,
    // instead of the field just being decorative.
    const distinctRoomIds = new Set(sections.map((s) => s.roomId));
    const distinctCount = distinctRoomIds.size;
    const property = PropertiesController.getAll().find((p) => p.id === booking.propertyId);
    const totalRoomsInProperty = property && typeof RoomsController !== 'undefined' ? RoomsController.getRoomsByProperty(property.id).length : 0;
    let portionError = '';
    if (booking.portion === '1 Room' && distinctCount !== 1) {
      portionError = `Booking says "1 Room" but ${distinctCount} different rooms were selected. Pick the same room for everyone, or go back and edit the booking's portion.`;
    } else if (booking.portion === '2 Rooms' && distinctCount !== 2) {
      portionError = `Booking says "2 Rooms" but ${distinctCount} different room(s) were selected. Split the tenants across exactly 2 rooms, or edit the booking's portion.`;
    } else if (booking.portion === 'Complete Flat' && totalRoomsInProperty > 0 && distinctCount < totalRoomsInProperty) {
      portionError = `Booking says "Complete Flat" (${totalRoomsInProperty} rooms) but only ${distinctCount} distinct room(s) were selected. Assign tenants across all rooms, or edit the booking's portion.`;
    }
    if (portionError) {
      document.getElementById('convPortionError').textContent = portionError;
      return;
    }

    const moveInDate = booking.moveInDate || todayIso();
    const createdIds = [];
    sections.forEach((s, i) => {
      const currentAllocation = {
        propertyId: booking.propertyId, roomId: s.roomId, moveInDate,
        rent: i === 0 ? (Number(booking.monthlyRent) || 0) : 0,
        deposit: i === 0 ? (Number(booking.securityAmount) || 0) : 0,
        maintCharge: 0, brokerage: i === 0 ? (Number(booking.brokerageAmount) || 0) : 0,
        agreementStart: null, agreementEnd: null, paymentDueDate: null, lockInPeriod: null,
      };
      const newId = TenantsController.createTenantDirect({
        ...s, currentAllocation, referralSource: i === 0 ? booking.referralSource : '',
        tenantSource: 'Booked Through Fair Homes',
      });
      createdIds.push(newId);
      if (typeof RoomsController !== 'undefined') RoomsController.syncRoomVacancyTracking(s.roomId);
    });

    if (typeof FinanceController !== 'undefined' && FinanceController.createInitialRentFromBooking) {
      FinanceController.createInitialRentFromBooking({
        tenantId: createdIds[0], monthlyRent: booking.monthlyRent, tokenCollected: collected, moveInDate,
      });
    }

    // Only NOW — after tenants are actually created — mark the booking
    // Converted. If the manager had cancelled the modal instead, the
    // booking correctly stays Active with nothing lost.
    const idx = bookings.findIndex((b) => b.id === booking.id);
    if (idx !== -1) { bookings[idx].status = 'Converted'; bookings[idx].convertedAt = new Date().toISOString(); }
    persist();
    renderBookingsList();

    closeConvertToTenantModal();
    if (typeof TenantsController !== 'undefined') TenantsController.reload();
    alert(`${sections.length} tenant(s) added successfully.`);
  }

  /** For a Brokerage-Only booking: instead of creating a Tenant, this
   *  directly records a Brokerage Deal on that flat — the collected
   *  token becomes the "From Tenant" amount, and the client's own name/
   *  mobile carries over as that deal's person, so nothing needs
   *  re-typing. */
  function handleConvertToDeal(booking) {
    const collected = totalTokenCollected(booking);
    const ownerAdvance = Number(booking.ownerAdvanceAmount) || 0;
    const fairHomesRetained = collected - ownerAdvance;
    ConfirmModal.show(
      `Recording a Brokerage Deal for ${booking.clientName} on this flat — ₹${fairHomesRetained} (token minus what already went to the Owner) becomes the starting brokerage amount from the tenant side. You can add more if the rest of the brokerage is collected later. This booking will be marked Converted.`,
      () => {
        const idx = bookings.findIndex((b) => b.id === booking.id);
        if (idx !== -1) { bookings[idx].status = 'Converted'; bookings[idx].convertedAt = new Date().toISOString(); }
        persist();
        renderBookingsList();

        if (typeof BrokerageFlatsController !== 'undefined' && BrokerageFlatsController.recordDealFromBooking) {
          BrokerageFlatsController.recordDealFromBooking({
            flatId: booking.brokerageFlatId, fromTenantAmount: fairHomesRetained,
            clientName: booking.clientName, clientMobile: booking.clientMobile, date: todayIso(),
            bookingId: booking.id, totalBrokerageTarget: booking.brokerageAmount,
          });
        }
        NavController.goToPage('brokerageFlats');
      },
      'Convert to Deal'
    );
  }

  // ---------------- Cancel Booking ----------------
  function openCancelBookingModal(id) {
    cancelBookingId = id;
    const booking = bookings.find((b) => b.id === id);
    if (!booking) return;
    document.getElementById('cancelBookingId').value = id;
    document.getElementById('cancelRefundAmount').value = '';
    document.getElementById('cancelBookingReason').value = '';
    updateCancelBookingCalc();
    clearErrors('cancelBookingForm');
    document.getElementById('cancelBookingModalOverlay').classList.add('open');
  }
  function closeCancelBookingModal() { document.getElementById('cancelBookingModalOverlay').classList.remove('open'); cancelBookingId = null; }

  function updateCancelBookingCalc() {
    const booking = bookings.find((b) => b.id === cancelBookingId);
    if (!booking) return;
    const collected = totalTokenCollected(booking);
    const ownerAdvance = Number(booking.ownerAdvanceAmount) || 0;
    const fairHomesRetained = collected - ownerAdvance;
    const refund = Number(document.getElementById('cancelRefundAmount').value) || 0;
    const forfeited = Math.max(fairHomesRetained - refund, 0);
    document.getElementById('cancelBookingCalcBox').innerHTML = `
      <div class="calc-row"><span>Token Collected</span><span>₹${collected}</span></div>
      ${ownerAdvance > 0 ? `<div class="calc-row"><span>− Already Advanced to Owner (non-recoverable)</span><span>₹${ownerAdvance}</span></div>` : ''}
      <div class="calc-row"><span>Fair Homes Retained</span><span>₹${fairHomesRetained}</span></div>
      <div class="calc-row"><span>Refund to Client</span><span>₹${refund}</span></div>
      <div class="calc-row total"><span>Fair Homes Income (Forfeited)</span><span>₹${forfeited}</span></div>
    `;
  }

  function handleCancelBooking() {
    const booking = bookings.find((b) => b.id === cancelBookingId);
    if (!booking) return;
    const collected = totalTokenCollected(booking);
    const ownerAdvance = Number(booking.ownerAdvanceAmount) || 0;
    const fairHomesRetained = collected - ownerAdvance;
    const refundAmount = Number(document.getElementById('cancelRefundAmount').value) || 0;
    const reason = document.getElementById('cancelBookingReason').value.trim();
    clearErrors('cancelBookingForm');
    if (refundAmount > fairHomesRetained) { showErrors({ cancelRefundAmount: `Fair Homes only holds ₹${fairHomesRetained} (₹${ownerAdvance} already went to the Owner) — can't refund more than that.` }); return; }

    const forfeited = fairHomesRetained - refundAmount;
    const idx = bookings.findIndex((b) => b.id === cancelBookingId);
    if (idx !== -1) {
      bookings[idx].status = 'Cancelled';
      bookings[idx].cancelledAt = new Date().toISOString();
      bookings[idx].refundAmount = refundAmount;
      bookings[idx].forfeitedAmount = forfeited;
      bookings[idx].cancellationReason = reason;
    }
    persist();

    if (forfeited > 0 && typeof FinanceController !== 'undefined') {
      FinanceController.recordMarginIncome({
        source: 'bookingForfeiture', propertyId: booking.propertyId || null, amount: forfeited,
        label: `Booking Cancelled — ${booking.clientName} (${booking.bookingCode})`, date: todayIso(),
      });
    }
    closeCancelBookingModal();
    renderBookingsList();
  }

  // ---------------- Init ----------------
  function bindEvents() {
    document.getElementById('addBookingBtn').addEventListener('click', openAddBookingModal);
    document.getElementById('bookingModalCloseBtn').addEventListener('click', closeBookingModal);
    document.getElementById('bookingCancelBtn').addEventListener('click', closeBookingModal);
    document.getElementById('bookingModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'bookingModalOverlay') closeBookingModal(); });
    document.getElementById('bookingSaveBtn').addEventListener('click', handleSaveBooking);
    document.getElementById('bookingType').addEventListener('change', () => { toggleBookingTypeFields(); updateBookingPackageCalc(); });
    document.getElementById('bookingBrokerageFlat').addEventListener('change', onBrokerageFlatSelected);
    ['bookingRent', 'bookingSecurity', 'bookingBrokerage', 'bookingMoveInDate'].forEach((id) => {
      document.getElementById(id).addEventListener('input', updateBookingPackageCalc);
    });

    document.getElementById('tokenPaymentModalCloseBtn').addEventListener('click', closeTokenPaymentModal);
    document.getElementById('tokenPaymentCancelBtn').addEventListener('click', closeTokenPaymentModal);
    document.getElementById('tokenPaymentModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'tokenPaymentModalOverlay') closeTokenPaymentModal(); });
    document.getElementById('tokenPaymentSaveBtn').addEventListener('click', handleSaveTokenPayment);

    document.getElementById('cancelBookingModalCloseBtn').addEventListener('click', closeCancelBookingModal);
    document.getElementById('cancelBookingCancelBtn').addEventListener('click', closeCancelBookingModal);
    document.getElementById('cancelBookingModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'cancelBookingModalOverlay') closeCancelBookingModal(); });
    document.getElementById('cancelBookingSaveBtn').addEventListener('click', handleCancelBooking);
    document.getElementById('cancelRefundAmount').addEventListener('input', updateCancelBookingCalc);

    document.getElementById('convertTenantModalCloseBtn').addEventListener('click', closeConvertToTenantModal);
    document.getElementById('convertTenantCancelBtn').addEventListener('click', closeConvertToTenantModal);
    document.getElementById('convertTenantEditBookingBtn').addEventListener('click', handleEditBookingFromConvert);
    document.getElementById('convertTenantModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'convertTenantModalOverlay') closeConvertToTenantModal(); });
    document.getElementById('convertTenantSaveBtn').addEventListener('click', handleSaveConvertToTenant);

    document.getElementById('bookingStatusFilter').addEventListener('change', renderBookingsList);
    document.getElementById('bookingPropertyFilter').addEventListener('change', renderBookingsList);
    document.getElementById('bookingDateFilter').addEventListener('change', renderBookingsList);
    document.getElementById('bookingSearchInput').addEventListener('input', renderBookingsList);
  }

  function onPageShow() { populateFilters(); renderBookingsList(); }

  function init() {
    load();
    bindEvents();
  }

  function reload() { load(); renderBookingsList(); }

  return { init, onPageShow, reload, getAll: () => [...bookings] };
})();
