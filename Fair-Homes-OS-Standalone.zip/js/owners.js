/* ==========================================================================
   Fair Homes OS — Owners Module (Phase 2)
   Full CRUD + validation + search + localStorage persistence.
   Data model:
   { id, fullName, mobile, altMobile, email, aadhaar, address,
     bank: { accountNumber, ifsc, bankName }, notes, createdAt, updatedAt }
   ========================================================================== */

const OwnersController = (() => {
  const STORAGE_KEY = 'fh_owners';
  let owners = [];
  let editingId = null;
  let viewingId = null;

  // ---------------- Storage ----------------
  // Local array stays the source of truth for rendering — CloudSync just
  // keeps it in sync with Firebase in the background (both directions:
  // local writes flow up, and other devices' writes flow down here via
  // the real-time listener). localStorage is kept as an instant-read
  // fallback cache so the very first paint isn't blocked on the network.
  function load() {
    try {
      owners = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    } catch (e) {
      owners = [];
    }
    CloudSync.watch('owners', (cloudOwners) => {
      owners = cloudOwners;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(owners));
      renderList();
      if (viewingId) renderDetail(viewingId);
    });
  }

  function persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(owners));
    CloudSync.sync('owners', owners);
  }

  function generateId() {
    return (crypto.randomUUID ? crypto.randomUUID() : 'own_' + Date.now() + '_' + Math.random().toString(16).slice(2));
  }

  // ---------------- Validation ----------------
  function validate(form) {
    const errors = {};

    if (!form.fullName.trim()) errors.ownerFullName = 'Full name is required';
    else if (form.fullName.trim().length < 2) errors.ownerFullName = 'Enter a valid name';

    if (!form.mobile.trim()) errors.ownerMobile = 'Mobile number is required';
    else if (!/^[6-9]\d{9}$/.test(form.mobile.trim())) errors.ownerMobile = 'Enter a valid 10-digit mobile number';
    else {
      const dup = owners.some((o) => o.mobile === form.mobile.trim() && o.id !== editingId);
      if (dup) errors.ownerMobile = 'An owner with this mobile number already exists';
    }

    if (form.altMobile.trim() && !/^[6-9]\d{9}$/.test(form.altMobile.trim())) {
      errors.ownerAltMobile = 'Enter a valid 10-digit number';
    }

    if (form.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
      errors.ownerEmail = 'Enter a valid email address';
    }

    if (form.aadhaar.trim() && !/^\d{12}$/.test(form.aadhaar.replace(/\s/g, ''))) {
      errors.ownerAadhaar = 'Aadhaar must be exactly 12 digits';
    }


    if (form.bankIfsc.trim() && !/^[A-Z]{4}0[A-Z0-9]{6}$/.test(form.bankIfsc.trim().toUpperCase())) {
      errors.ownerBankIfsc = 'Enter a valid IFSC code';
    }

    return errors;
  }

  function clearErrors() {
    document.querySelectorAll('#ownerForm .form-error').forEach((el) => (el.textContent = ''));
  }

  function showErrors(errors) {
    Object.entries(errors).forEach(([fieldId, message]) => {
      const el = document.getElementById('err-' + fieldId);
      if (el) el.textContent = message;
    });
  }

  // ---------------- Modal ----------------
  let pendingQrImage = null; // base64 data URL while modal is open

  function openAddModal() {
    editingId = null;
    pendingQrImage = null;
    document.getElementById('ownerModalTitle').textContent = 'Add Owner';
    document.getElementById('ownerForm').reset();
    document.getElementById('ownerId').value = '';
    document.getElementById('ownerQrPreviewWrap').classList.add('hidden');
    clearErrors();
    document.getElementById('ownerModalOverlay').classList.add('open');
  }

  function openEditModal(id) {
    const owner = owners.find((o) => o.id === id);
    if (!owner) return;
    editingId = id;
    pendingQrImage = owner.qrCodeImage || null;
    document.getElementById('ownerModalTitle').textContent = 'Edit Owner';
    document.getElementById('ownerId').value = owner.id;
    document.getElementById('ownerFullName').value = owner.fullName || '';
    document.getElementById('ownerMobile').value = owner.mobile || '';
    document.getElementById('ownerAltMobile').value = owner.altMobile || '';
    document.getElementById('ownerEmail').value = owner.email || '';
    document.getElementById('ownerAadhaar').value = formatAadhaar(owner.aadhaar || '');
    document.getElementById('ownerElectricityAccount').value = owner.electricityAccount || '';
    document.getElementById('ownerAddress').value = owner.address || '';
    document.getElementById('ownerBankAccount').value = owner.bank?.accountNumber || '';
    document.getElementById('ownerBankIfsc').value = owner.bank?.ifsc || '';
    document.getElementById('ownerBankName').value = owner.bank?.bankName || '';
    document.getElementById('ownerNotes').value = owner.notes || '';
    if (pendingQrImage) {
      document.getElementById('ownerQrPreview').src = pendingQrImage;
      document.getElementById('ownerQrPreviewWrap').classList.remove('hidden');
    } else {
      document.getElementById('ownerQrPreviewWrap').classList.add('hidden');
    }
    clearErrors();
    document.getElementById('ownerModalOverlay').classList.add('open');
  }

  function closeModal() {
    document.getElementById('ownerModalOverlay').classList.remove('open');
    editingId = null;
  }

  function handleSave() {
    const form = {
      fullName: document.getElementById('ownerFullName').value,
      mobile: document.getElementById('ownerMobile').value,
      altMobile: document.getElementById('ownerAltMobile').value,
      email: document.getElementById('ownerEmail').value,
      aadhaar: document.getElementById('ownerAadhaar').value.replace(/\s/g, ''),
      electricityAccount: document.getElementById('ownerElectricityAccount').value.trim(),
      address: document.getElementById('ownerAddress').value,
      bankAccount: document.getElementById('ownerBankAccount').value,
      bankIfsc: document.getElementById('ownerBankIfsc').value,
      bankName: document.getElementById('ownerBankName').value,
      notes: document.getElementById('ownerNotes').value,
    };

    clearErrors();
    const errors = validate(form);
    if (Object.keys(errors).length > 0) {
      showErrors(errors);
      return;
    }

    const now = new Date().toISOString();
    const ownerData = {
      fullName: form.fullName.trim(),
      mobile: form.mobile.trim(),
      altMobile: form.altMobile.trim(),
      email: form.email.trim(),
      aadhaar: form.aadhaar.trim(),
      electricityAccount: form.electricityAccount.trim(),
      address: form.address.trim(),
      bank: {
        accountNumber: form.bankAccount.trim(),
        ifsc: form.bankIfsc.trim().toUpperCase(),
        bankName: form.bankName.trim(),
      },
      notes: form.notes.trim(),
      qrCodeImage: pendingQrImage || null,
      updatedAt: now,
    };

    if (editingId) {
      const idx = owners.findIndex((o) => o.id === editingId);
      if (idx !== -1) owners[idx] = { ...owners[idx], ...ownerData };
    } else {
      owners.unshift({ id: generateId(), createdAt: now, ...ownerData });
    }

    persist();
    closeModal();
    renderList();
    if (viewingId && (editingId === viewingId || !editingId)) {
      // If we just edited the owner currently being viewed, refresh detail view.
    }
    if (viewingId) renderDetail(viewingId);
  }

  function handleDelete(id) {
    const owner = owners.find((o) => o.id === id);
    if (!owner) return;
    ConfirmModal.show(`Delete "${owner.fullName}"?`, () => {
      TrashController.moveToTrash('owner', owner, owner.fullName);
      owners = owners.filter((o) => o.id !== id);
      persist();
      renderList();
      if (viewingId === id) backToList();
    }, 'Delete Owner');
  }

  // ---------------- List Rendering ----------------
  function initials(name) {
    const parts = name.trim().split(/\s+/);
    return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase() || '?';
  }

  function renderList() {
    const query = (document.getElementById('ownerSearchInput')?.value || '').toLowerCase().trim();
    const filtered = owners.filter((o) =>
      o.fullName.toLowerCase().includes(query) ||
      (o.mobile || '').includes(query) ||
      (o.email || '').toLowerCase().includes(query)
    );

    document.getElementById('ownerCountChip').textContent = owners.length + (owners.length === 1 ? ' owner' : ' owners');

    const grid = document.getElementById('ownersGrid');
    if (!filtered.length) {
      grid.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="ico">👤</div>
          <div class="title">${owners.length === 0 ? 'No owners yet' : 'No matching owners'}</div>
          <div class="desc">${owners.length === 0 ? 'Add your first property owner to get started.' : 'Try a different search term.'}</div>
        </div>`;
      return;
    }

    grid.innerHTML = filtered.map((o) => {
      const ownerProperties = (typeof PropertiesController !== 'undefined') ? PropertiesController.getAll().filter((p) => p.ownerId === o.id) : [];
      const propertyLines = ownerProperties.map((p) => {
        const parts = [p.flatNo ? 'Flat ' + p.flatNo : '', p.society || p.name, p.bhk].filter(Boolean);
        return `<div class="oc-row">🏢 ${esc(parts.join(', '))}</div>`;
      }).join('');
      return `
      <div class="owner-card" data-id="${o.id}">
        <div class="oc-top">
          <div class="oc-avatar">${initials(o.fullName)}</div>
          <div>
            <div class="oc-name">${esc(o.fullName)}</div>
            <div class="oc-sub">Added ${formatDate(o.createdAt)}</div>
          </div>
        </div>
        <div class="oc-row">📱 ${esc(o.mobile)}</div>
        ${propertyLines}
        ${o.email ? `<div class="oc-row">✉️ ${esc(o.email)}</div>` : ''}
        <div class="oc-actions">
          <button class="btn small secondary oc-edit-btn" data-id="${o.id}">Edit</button>
          <button class="btn small oc-delete-btn" data-id="${o.id}" style="background:var(--error);">Delete</button>
        </div>
      </div>
    `;
    }).join('');

    // Card click (excluding action buttons) opens detail view
    grid.querySelectorAll('.owner-card').forEach((card) => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('.oc-edit-btn') || e.target.closest('.oc-delete-btn')) return;
        renderDetail(card.dataset.id);
      });
    });
    grid.querySelectorAll('.oc-edit-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => { e.stopPropagation(); openEditModal(btn.dataset.id); });
    });
    grid.querySelectorAll('.oc-delete-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => { e.stopPropagation(); handleDelete(btn.dataset.id); });
    });
  }

  // ---------------- Detail View ----------------
  function renderDetail(id) {
    const owner = owners.find((o) => o.id === id);
    if (!owner) return;
    viewingId = id;

    document.getElementById('odAvatar').textContent = initials(owner.fullName);
    document.getElementById('odName').textContent = owner.fullName;
    document.getElementById('odCreated').textContent = 'Added ' + formatDate(owner.createdAt);
    setDetailValue('odMobile', owner.mobile);
    if (owner.mobile) document.getElementById('odMobile').innerHTML = phoneLinks(owner.mobile);
    setDetailValue('odAltMobile', owner.altMobile);
    setDetailValue('odEmail', owner.email);
    setDetailValue('odAadhaar', owner.aadhaar ? formatAadhaar(owner.aadhaar) : '');
    setDetailValue('odElectricityAccount', owner.electricityAccount);
    setDetailValue('odAddress', owner.address);
    setDetailValue('odBankAccount', owner.bank?.accountNumber);
    setDetailValue('odBankIfsc', owner.bank?.ifsc);
    setDetailValue('odBankName', owner.bank?.bankName);
    setDetailValue('odNotes', owner.notes);

    if (owner.qrCodeImage) {
      document.getElementById('odQrImage').src = owner.qrCodeImage;
      document.getElementById('odQrImage').style.display = 'block';
      document.getElementById('odQrEmpty').classList.add('hidden');
    } else {
      document.getElementById('odQrImage').style.display = 'none';
      document.getElementById('odQrEmpty').classList.remove('hidden');
    }

    renderOwnerProperties(owner.id);
    renderInteractionLog(owner);

    document.getElementById('odEditBtn').onclick = () => openEditModal(owner.id);
    document.getElementById('odDeleteBtn').onclick = () => handleDelete(owner.id);

    document.getElementById('ownersListView').classList.add('hidden');
    document.getElementById('ownerDetailView').classList.remove('hidden');
  }

  /**
   * Shows every property this owner has, with Flat No / Society / BHK and
   * a live occupancy summary computed from Rooms & Beds — Fully Occupied /
   * Vacant / Partially Occupied with room-wise vacancy count. Never a
   * stored/stale value — always computed fresh from current bed statuses.
   */
  function renderOwnerProperties(ownerId) {
    const box = document.getElementById('odPropertiesBox');
    if (typeof PropertiesController === 'undefined') { box.innerHTML = ''; return; }
    const ownerProperties = PropertiesController.getAll().filter((p) => p.ownerId === ownerId);

    if (!ownerProperties.length) {
      box.innerHTML = '<div class="empty-state"><div class="desc">No properties linked to this owner yet.</div></div>';
      return;
    }

    box.innerHTML = ownerProperties.map((p) => {
      let occupancyText = 'Not tracked (no rooms added yet)';
      if (typeof RoomsController !== 'undefined') {
        const rooms = RoomsController.getRoomsByProperty(p.id);
        if (rooms.length) {
          const vacantRooms = rooms.filter((r) => RoomsController.computeRoomStatus(r.id) === 'Available');
          if (vacantRooms.length === 0) occupancyText = 'Fully Occupied';
          else if (vacantRooms.length === rooms.length) occupancyText = 'Fully Vacant';
          else occupancyText = `Partially Occupied — ${vacantRooms.length} of ${rooms.length} room(s) vacant`;
        }
      }
      return `
        <div class="info-card" style="margin-bottom:8px;">
          <div class="title">${esc(p.name)}</div>
          <div class="sub">
            ${p.flatNo ? 'Flat ' + esc(p.flatNo) + ' · ' : ''}${p.society ? esc(p.society) + ' · ' : ''}${p.bhk ? esc(p.bhk) : ''}
          </div>
          <div class="sub" style="margin-top:4px;">${esc(occupancyText)}</div>
        </div>`;
    }).join('');
  }

  /** Renders the dated Interaction Log — calls/meetings/notes, most
   *  recent first. Stored as owner.interactionLog: [{id, text, date}]. */
  function renderInteractionLog(owner) {
    const box = document.getElementById('odInteractionLog');
    const log = owner.interactionLog || [];
    if (!log.length) { box.innerHTML = '<div class="empty-state"><div class="desc">No entries yet.</div></div>'; return; }
    const sorted = [...log].sort((a, b) => b.date.localeCompare(a.date));
    box.innerHTML = sorted.map((entry) => `
      <div class="history-item">
        <div class="hi-title">${esc(entry.text)}</div>
        <div class="hi-row">${formatDate(entry.date)}</div>
      </div>`).join('');
  }

  function handleAddOwnerLogEntry() {
    const input = document.getElementById('odNewLogEntry');
    const text = input.value.trim();
    if (!text || !viewingId) return;
    const owner = owners.find((o) => o.id === viewingId);
    if (!owner) return;
    if (!owner.interactionLog) owner.interactionLog = [];
    owner.interactionLog.push({ id: generateId(), text, date: new Date().toISOString().slice(0, 10) });
    owner.updatedAt = new Date().toISOString();
    persist();
    input.value = '';
    renderInteractionLog(owner);
  }

  function setDetailValue(elId, value) {
    const el = document.getElementById(elId);
    if (value && value.trim()) { el.textContent = value; el.classList.remove('empty'); }
    else { el.textContent = 'Not provided'; el.classList.add('empty'); }
  }

  function backToList() {
    viewingId = null;
    document.getElementById('ownerDetailView').classList.add('hidden');
    document.getElementById('ownersListView').classList.remove('hidden');
    renderList();
  }

  // ---------------- Helpers ----------------
  function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function formatDate(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  // ---------------- Init / Bindings ----------------
  function bindEvents() {
    document.getElementById('addOwnerBtn').addEventListener('click', openAddModal);
    document.getElementById('odAddLogBtn').addEventListener('click', handleAddOwnerLogEntry);
    document.getElementById('ownerModalCloseBtn').addEventListener('click', closeModal);
    document.getElementById('ownerCancelBtn').addEventListener('click', closeModal);
    document.getElementById('ownerSaveBtn').addEventListener('click', handleSave);
    document.getElementById('ownerModalOverlay').addEventListener('click', (e) => {
      if (e.target.id === 'ownerModalOverlay') closeModal();
    });
    document.getElementById('ownerSearchInput').addEventListener('input', renderList);
    document.getElementById('ownerBackBtn').addEventListener('click', backToList);

    // IFSC auto-uppercase as user types
    document.getElementById('ownerBankIfsc').addEventListener('input', (e) => { e.target.value = e.target.value.toUpperCase(); });

    // QR code upload — base64, since there's no backend/file server here.
    document.getElementById('ownerQrFile').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      if (file.size > 1024 * 1024) { alert('Please choose an image smaller than 1MB.'); e.target.value = ''; return; }
      const reader = new FileReader();
      reader.onload = (ev) => {
        pendingQrImage = ev.target.result;
        document.getElementById('ownerQrPreview').src = pendingQrImage;
        document.getElementById('ownerQrPreviewWrap').classList.remove('hidden');
      };
      reader.readAsDataURL(file);
    });
    document.getElementById('ownerQrRemoveBtn').addEventListener('click', () => {
      pendingQrImage = null;
      document.getElementById('ownerQrFile').value = '';
      document.getElementById('ownerQrPreviewWrap').classList.add('hidden');
    });
    // Mobile numeric-only input
    ['ownerMobile', 'ownerAltMobile'].forEach((id) => {
      document.getElementById(id).addEventListener('input', (e) => {
        e.target.value = e.target.value.replace(/\D/g, '');
      });
    });
    wireAadhaarFormatting('ownerAadhaar');
    document.getElementById('ownerElectricityAccount').addEventListener('input', (e) => {
      e.target.value = e.target.value.replace(/\D/g, '').slice(0, 11);
    });
  }

  function getAll() {
    return [...owners].sort((a, b) => a.fullName.localeCompare(b.fullName));
  }

  function init() {
    load();
    bindEvents();
    renderList();
  }

  /** Re-reads localStorage and re-renders — used after Settings restores a backup. */
  function reload() { load(); renderList(); }

  /** Bulk-adds pre-shaped owner records — used by Settings' CSV/Excel import. */
  function bulkImport(records) {
    const now = new Date().toISOString();
    records.forEach((r) => {
      owners.unshift({
        id: (crypto.randomUUID ? crypto.randomUUID() : 'own_' + Date.now() + '_' + Math.random().toString(16).slice(2)),
        fullName: r.fullName || '', phone: r.phone || r.mobile || '', email: r.email || '',
        altMobile: '', aadhaar: '', address: '', bank: { accountNumber: '', ifsc: '', bankName: '' },
        notes: '', createdAt: now, updatedAt: now,
      });
    });
    persist();
    renderList();
  }

  return { init, renderList, getAll, reload, bulkImport, openDetail: renderDetail };
})();
