/* ==========================================================================
   Fair Homes OS — App Bootstrap
   Flow: Splash -> Real Firebase Login/Sign Up -> App Shell (Dashboard)
   Every module's data now syncs through CloudSync (Firebase) instead of
   being purely local — this is what enables real-time, offline-capable,
   multi-device sync.
   ========================================================================== */

let authMode = 'signin'; // 'signin' | 'signup'
let appHasEntered = false; // guards against enterApp() running twice

// PWA install support — only actually works when served over http/https
// (e.g. Netlify). Opening the merged single-file version directly (no
// server) simply skips this; nothing breaks either way.
if ('serviceWorker' in navigator && (location.protocol === 'http:' || location.protocol === 'https:')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').then((reg) => {
      // A new deployment means sw.js itself changed, so the browser
      // downloads it in the background and parks it as "waiting" until
      // the user confirms — this is what lets us show "Update Now"
      // instead of silently swapping code out from under an open session.
      reg.addEventListener('updatefound', () => {
        const newWorker = reg.installing;
        newWorker.addEventListener('statechange', () => {
          if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
            document.getElementById('updateAvailableBar').classList.remove('hidden');
          }
        });
      });
      // Also actively re-check for a newer deployment every time the
      // app is opened (not just relying on the browser's own timing).
      reg.update();
    }).catch((err) => console.warn('Service worker registration failed:', err.message));

    document.getElementById('updateNowBtn').addEventListener('click', () => {
      navigator.serviceWorker.getRegistration().then((reg) => {
        if (reg && reg.waiting) reg.waiting.postMessage({ type: 'SKIP_WAITING' });
      });
    });
    // Once the new service worker actually takes control, reload once
    // to run the freshly updated app code.
    let refreshing = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (refreshing) return;
      refreshing = true;
      location.reload();
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  CloudSync.init();
  ThemeController.init();
  ConfirmModal.init();
  NavController.bindNavClicks();

  const splash = document.getElementById('splashScreen');
  const authWrap = document.getElementById('authWrap');

  // Firebase resolves whether a session already exists (persisted from a
  // previous visit) almost instantly — we wait for that before deciding
  // whether to show the login screen or go straight into the app, so a
  // returning user on the same device doesn't have to sign in every time.
  let authResolved = false;
  let splashMinTimeElapsed = false;

  function maybeProceedPastSplash() {
    if (!authResolved || !splashMinTimeElapsed) return;
    splash.classList.add('fade-out');
    setTimeout(() => { splash.classList.add('hidden'); }, 400);
  }

  setTimeout(() => { splashMinTimeElapsed = true; maybeProceedPastSplash(); }, 1400);

  CloudSync.onAuthChange((user) => {
    authResolved = true;
    if (user && !appHasEntered) {
      authWrap.classList.add('hidden');
      enterApp();
    } else if (!user) {
      CloudSync.stopAllWatchers();
      appHasEntered = false;
      authWrap.classList.remove('hidden');
      document.getElementById('appShell').style.display = 'none';
    }
    maybeProceedPastSplash();
  });

  // ---------------- Auth form ----------------
  function setAuthError(msg) { document.getElementById('authError').textContent = msg || ''; }
  function friendlyAuthError(err) {
    const map = {
      'auth/invalid-email': 'Email address is not valid.',
      'auth/user-not-found': 'No account found with this email. Try "Create an account" below.',
      'auth/wrong-password': 'Wrong password. Try again or reset it.',
      'auth/invalid-credential': 'Email or password is incorrect.',
      'auth/email-already-in-use': 'An account already exists with this email — try signing in instead.',
      'auth/weak-password': 'Password must be at least 6 characters.',
      'auth/network-request-failed': 'No internet connection. Check your network and try again.',
      'auth/too-many-requests': 'Too many attempts. Please wait a bit and try again.',
    };
    return map[err.code] || err.message || 'Something went wrong. Please try again.';
  }

  document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    handleAuthSubmit();
  });
  document.getElementById('loginBtn').addEventListener('click', (e) => {
    e.preventDefault();
    handleAuthSubmit();
  });

  function handleAuthSubmit() {
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    setAuthError('');

    if (!email || !password) { setAuthError('Enter both email and password.'); return; }
    if (password.length < 6) { setAuthError('Password must be at least 6 characters.'); return; }

    const btn = document.getElementById('loginBtn');
    btn.disabled = true;
    btn.textContent = authMode === 'signin' ? 'Signing In...' : 'Creating Account...';

    const action = authMode === 'signin' ? CloudSync.signIn(email, password) : CloudSync.signUp(email, password);
    action
      .catch((err) => setAuthError(friendlyAuthError(err)))
      .finally(() => {
        btn.disabled = false;
        btn.textContent = authMode === 'signin' ? 'Sign In' : 'Create Account';
      });
  }

  document.getElementById('toggleAuthModeLink').addEventListener('click', (e) => {
    e.preventDefault();
    authMode = authMode === 'signin' ? 'signup' : 'signin';
    setAuthError('');
    if (authMode === 'signup') {
      document.getElementById('authTitle').textContent = 'Create Account';
      document.getElementById('authSubtitle').textContent = 'Set up Fair Homes OS for your business';
      document.getElementById('loginBtn').textContent = 'Create Account';
      document.getElementById('toggleAuthModeLink').textContent = 'Already have an account? Sign In';
    } else {
      document.getElementById('authTitle').textContent = 'Welcome Back';
      document.getElementById('authSubtitle').textContent = 'Sign in to manage your properties';
      document.getElementById('loginBtn').textContent = 'Sign In';
      document.getElementById('toggleAuthModeLink').textContent = 'New here? Create an account';
    }
  });

  document.getElementById('forgotPasswordLink').addEventListener('click', (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim();
    if (!email) { setAuthError('Enter your email above first, then tap "Forgot password?"'); return; }
    CloudSync.sendPasswordReset(email)
      .then(() => setAuthError('Password reset email sent — check your inbox.'))
      .catch((err) => setAuthError(friendlyAuthError(err)));
  });

  document.getElementById('themeToggleBtn').addEventListener('click', () => ThemeController.toggle());
  wireShowPasswordToggle('showLoginPasswordChk', ['loginPassword']);

  document.getElementById('avatarBadgeBtn').addEventListener('click', (e) => {
    e.stopPropagation();
    const dropdown = document.getElementById('avatarDropdown');
    const user = CloudSync.getCurrentUser();
    document.getElementById('avatarEmail').textContent = user ? user.email : '—';
    document.getElementById('avatarRole').textContent = (typeof AccessController !== 'undefined' && AccessController.getCurrentRole()) ? AccessController.getCurrentRole() : '';
    dropdown.classList.toggle('hidden');
  });
  document.addEventListener('click', (e) => {
    const dropdown = document.getElementById('avatarDropdown');
    if (!dropdown.classList.contains('hidden') && !e.target.closest('#avatarDropdown') && e.target.id !== 'avatarBadgeBtn') {
      dropdown.classList.add('hidden');
    }
  });
  document.getElementById('signOutBtn').addEventListener('click', () => {
    document.getElementById('avatarDropdown').classList.add('hidden');
    CloudSync.signOutUser();
  });

  async function enterApp() {
    appHasEntered = true;
    document.getElementById('appShell').style.display = 'block';
    OwnersController.init();
    PropertiesController.init();
    RoomsController.init();
    BookingsController.init();
    BrokerageFlatsController.init();
    SocialMediaController.init();
    TenantsController.init();
    FinanceController.init();
    MaintenanceController.init();
    ReportsController.init();
    NotificationsController.init();
    SettingsController.init();
    TrashController.init();
    SearchController.init();
    recordLoginEvent();

    await AccessController.resolveCurrentUser();
    if (AccessController.isAccessDenied()) {
      document.getElementById('appShell').style.display = 'none';
      return; // sign-out from resolveCurrentUser() will flip the auth screen back on
    }
    AccessController.applyRestrictions();
    AccessController.watchOwnAccessLive();
    NavController.goToPage(AccessController.getFirstAccessiblePage());
  }

  // Real login tracking — now backed by an actual authenticated session,
  // not just an app-open event.
  function recordLoginEvent() {
    const now = new Date().toISOString();
    localStorage.setItem('fh_last_login', now);
    let history = [];
    try { history = JSON.parse(localStorage.getItem('fh_login_history')) || []; } catch (e) { history = []; }
    history.unshift({ timestamp: now, email: CloudSync.getCurrentUser()?.email || '' });
    localStorage.setItem('fh_login_history', JSON.stringify(history.slice(0, 50)));
  }
});
