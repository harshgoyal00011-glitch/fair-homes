/* ==========================================================================
   Fair Homes OS — Shared UI Helpers
   ConfirmModal replaces the browser's native confirm() everywhere in the
   app. Native confirm() is unreliable inside embedded webviews/in-app
   browsers (some silently block or auto-reject it), which is why Delete
   buttons could appear to "do nothing" — this custom modal always works
   because it's just our own HTML/CSS/JS, not a browser API.
   ========================================================================== */

const ConfirmModal = (() => {
  let pendingYes = null;

  function show(message, onYes, title) {
    document.getElementById('globalConfirmTitle').textContent = title || 'Confirm Delete';
    document.getElementById('globalConfirmMessage').textContent = message;
    pendingYes = onYes;
    document.getElementById('globalConfirmOverlay').classList.add('open');
  }

  function hide() {
    document.getElementById('globalConfirmOverlay').classList.remove('open');
    pendingYes = null;
  }

  function bindEvents() {
    document.getElementById('globalConfirmYesBtn').addEventListener('click', () => {
      const cb = pendingYes;
      hide();
      if (cb) cb();
    });
    document.getElementById('globalConfirmNoBtn').addEventListener('click', hide);
    document.getElementById('globalConfirmOverlay').addEventListener('click', (e) => {
      if (e.target.id === 'globalConfirmOverlay') hide();
    });
  }

  function init() { bindEvents(); }

  return { init, show };
})();

/**
 * Wires a 'Show Password' checkbox to reveal/hide one or more password
 * fields at once (toggles type between 'password' and 'text'). Safe to
 * call multiple times on the same checkboxId — re-attaching just resets
 * the listener rather than stacking duplicates, so dynamically re-rendered
 * sections (e.g. an approval-completion form) can call it freely.
 */
function wireShowPasswordToggle(checkboxId, inputIds) {
  const checkbox = document.getElementById(checkboxId);
  if (!checkbox) return;
  const handler = () => {
    inputIds.forEach((id) => {
      const input = document.getElementById(id);
      if (input) input.type = checkbox.checked ? 'text' : 'password';
    });
  };
  if (checkbox._showPasswordHandler) checkbox.removeEventListener('change', checkbox._showPasswordHandler);
  checkbox._showPasswordHandler = handler;
  checkbox.addEventListener('change', handler);
}

/**
 * Renders a phone number with tap-to-call and tap-to-WhatsApp icons —
 * used anywhere a mobile number is displayed, so reaching an owner/
 * tenant/client doesn't require manually copying the number into
 * another app first. Assumes Indian 10-digit numbers (prefixes with 91
 * for the WhatsApp link, which needs the country code).
 */
function phoneLinks(mobile, label) {
  if (!mobile) return label ? esc(label) : '';
  const clean = String(mobile).replace(/\D/g, '');
  const waNumber = clean.length === 10 ? '91' + clean : clean;
  const displayText = label || mobile;
  return `${esc(displayText)} <a href="tel:${clean}" style="text-decoration:none; margin-left:4px;" title="Call">📞</a><a href="https://wa.me/${waNumber}" target="_blank" rel="noopener" style="text-decoration:none; margin-left:2px;" title="WhatsApp">💬</a>`;
}
function esc(str) { if (str === null || str === undefined) return ''; return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

/** Opens WhatsApp with a pre-filled text message to the given mobile
 *  number — used for sharing rent receipts and similar quick notices.
 *  Only sends TEXT (WhatsApp's click-to-chat doesn't support attaching
 *  a file via URL — for that, the Web Share API would be needed, which
 *  isn't available on all devices/browsers). */
function shareViaWhatsApp(mobile, text) {
  const clean = String(mobile || '').replace(/\D/g, '');
  const waNumber = clean.length === 10 ? '91' + clean : clean;
  window.open(`https://wa.me/${waNumber}?text=${encodeURIComponent(text)}`, '_blank');
}

/**
 * Turns a text input + hidden input pair into a searchable dropdown
 * ("combobox") — type to filter the option list, click or Arrow+Enter
 * to select, click elsewhere to close. Built for option lists too long
 * to comfortably scroll through as a plain <select> (like Brokerage-
 * Only Flat's BHK/portion list).
 *
 * @param textInputId  id of the visible text <input> the user types/sees into
 * @param hiddenInputId id of a hidden <input> that stores the actual selected VALUE
 * @param options      array of {value, label} — label is what's shown/searched, value is stored
 * @returns {setValue(value)} — call to pre-fill programmatically (e.g. when editing)
 */
function initSearchableSelect(textInputId, hiddenInputId, options) {
  const textInput = document.getElementById(textInputId);
  const hiddenInput = document.getElementById(hiddenInputId);
  if (!textInput || !hiddenInput) return { setValue: () => {} };

  // Already wired up for this input — just refresh the option list
  // (e.g. a newly-added Brokerage-Only Flat) without re-attaching
  // listeners, which would otherwise stack up on every modal re-open.
  if (textInput._ssRefresh) {
    textInput._ssRefresh(options);
    return { setValue: textInput._ssSetValue };
  }

  let dropdown = document.getElementById(textInputId + '_dropdown');
  if (!dropdown) {
    dropdown = document.createElement('div');
    dropdown.id = textInputId + '_dropdown';
    dropdown.className = 'searchable-select-dropdown hidden';
    textInput.insertAdjacentElement('afterend', dropdown);
  }
  let liveOptions = options;
  let highlightedIdx = -1;
  let filtered = liveOptions;

  function renderDropdown() {
    if (!filtered.length) { dropdown.innerHTML = '<div class="ss-empty">No match</div>'; return; }
    dropdown.innerHTML = filtered.map((o, i) => `<div class="ss-option${i === highlightedIdx ? ' highlighted' : ''}" data-idx="${i}">${esc(o.label)}</div>`).join('');
    dropdown.querySelectorAll('.ss-option').forEach((el) => {
      el.addEventListener('mousedown', (e) => { e.preventDefault(); selectOption(filtered[Number(el.dataset.idx)]); });
    });
  }
  function selectOption(opt) {
    if (!opt) return;
    textInput.value = opt.label;
    hiddenInput.value = opt.value;
    closeDropdown();
    hiddenInput.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function openDropdown(query) {
    const q = (query || '').toLowerCase();
    filtered = q ? liveOptions.filter((o) => o.label.toLowerCase().includes(q)) : liveOptions;
    highlightedIdx = -1;
    renderDropdown();
    dropdown.classList.remove('hidden');
  }
  function closeDropdown() { dropdown.classList.add('hidden'); }
  function matchingLabel(value) { const m = liveOptions.find((o) => o.value === value); return m ? m.label : ''; }
  function setValue(value) { textInput.value = matchingLabel(value); hiddenInput.value = value; }

  textInput.addEventListener('focus', () => openDropdown(textInput.value === matchingLabel(hiddenInput.value) ? '' : textInput.value));
  textInput.addEventListener('input', () => openDropdown(textInput.value));
  textInput.addEventListener('keydown', (e) => {
    if (dropdown.classList.contains('hidden') && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) { openDropdown(''); return; }
    if (e.key === 'ArrowDown') { e.preventDefault(); highlightedIdx = Math.min(highlightedIdx + 1, filtered.length - 1); renderDropdown(); scrollHighlightedIntoView(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); highlightedIdx = Math.max(highlightedIdx - 1, 0); renderDropdown(); scrollHighlightedIntoView(); }
    else if (e.key === 'Enter' && !dropdown.classList.contains('hidden') && ((highlightedIdx >= 0 && filtered[highlightedIdx]) || filtered.length === 1)) {
      // Only intercept Enter when it actually picks a suggestion — pick
      // it, then let the keypress keep bubbling so the app-wide
      // Enter-moves-to-next-field navigation still advances the form.
      if (highlightedIdx >= 0 && filtered[highlightedIdx]) selectOption(filtered[highlightedIdx]);
      else selectOption(filtered[0]);
    }
    else if (e.key === 'Escape' && !dropdown.classList.contains('hidden')) { closeDropdown(); e.stopPropagation(); }
  });
  document.addEventListener('click', (e) => { if (e.target !== textInput && !dropdown.contains(e.target)) closeDropdown(); });
  function scrollHighlightedIntoView() { dropdown.querySelector('.ss-option.highlighted')?.scrollIntoView({ block: 'nearest' }); }

  textInput._ssRefresh = (newOptions) => { liveOptions = newOptions; };
  textInput._ssSetValue = setValue;

  return { setValue };
}

/** Formats a raw Aadhaar number (with or without existing spaces) into
 *  the 4-4-4 grouped display used on the physical card — "1234 5678
 *  9012". Storage always keeps the raw 12 digits; this is display/
 *  input-only formatting. */
function formatAadhaar(raw) {
  const digits = String(raw || '').replace(/\D/g, '').slice(0, 12);
  return digits.match(/.{1,4}/g)?.join(' ') || '';
}

/** Wires an Aadhaar <input> to auto-format into 4-4-4 groups as the
 *  person types, keeping the cursor in the right spot even as spaces
 *  get inserted/removed around it. Call once per input (e.g. in
 *  bindEvents); safe to call again (idempotent, mirrors
 *  initSearchableSelect's pattern). */
function wireAadhaarFormatting(inputId) {
  const input = document.getElementById(inputId);
  if (!input || input._aadhaarWired) return;
  input._aadhaarWired = true;
  input.maxLength = 14; // 12 digits + 2 spaces
  input.addEventListener('input', (e) => {
    const cursorPos = e.target.selectionStart;
    const rawDigitsBeforeCursor = e.target.value.slice(0, cursorPos).replace(/\D/g, '').length;
    const formatted = formatAadhaar(e.target.value);
    e.target.value = formatted;
    let newPos = 0, digitsSeen = 0;
    while (digitsSeen < rawDigitsBeforeCursor && newPos < formatted.length) {
      if (/\d/.test(formatted[newPos])) digitsSeen++;
      newPos++;
    }
    e.target.setSelectionRange(newPos, newPos);
  });
}

/* ==========================================================================
   APP-WIDE KEYBOARD NAVIGATION
   Works generically across every form/modal/page without per-form wiring:
   - Enter moves to the next input/select/textarea in the same modal or
     form (like Tab). Textareas keep their normal newline behavior.
   - Backspace, when the focused field is already empty, moves back to
     the previous field instead of doing nothing — never fires while
     there's still text to delete, so normal editing is unaffected.
   - Escape closes the topmost open modal (clicking its own .modal-close
     button, so each modal's own cleanup logic still runs normally); with
     no modal open, it clicks a visible page-level "back" button if one
     exists, so repeated Escape presses step back through the app.
   ========================================================================== */
function getKeyboardNavFields(container) {
  return Array.from(container.querySelectorAll('input:not([type="hidden"]):not([disabled]), select:not([disabled]), textarea:not([disabled])'))
    .filter((el) => el.offsetParent !== null); // visible only
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    const openModals = Array.from(document.querySelectorAll('.modal-overlay.open'));
    if (openModals.length) {
      const topModal = openModals[openModals.length - 1];
      const closeBtn = topModal.querySelector('.modal-close');
      if (closeBtn) { closeBtn.click(); e.preventDefault(); }
      return;
    }
    const backBtns = Array.from(document.querySelectorAll('.back-btn')).filter((el) => el.offsetParent !== null);
    if (backBtns.length) { backBtns[backBtns.length - 1].click(); e.preventDefault(); }
    return;
  }

  if (e.key !== 'Enter' && e.key !== 'Backspace') return;
  const target = e.target;
  if (!['INPUT', 'SELECT', 'TEXTAREA'].includes(target.tagName)) return;

  const container = target.closest('.modal-box') || target.closest('form') || target.closest('.page-section') || document.body;
  const fields = getKeyboardNavFields(container);
  const idx = fields.indexOf(target);
  if (idx === -1) return;

  if (e.key === 'Enter') {
    if (target.tagName === 'TEXTAREA') return; // keep normal newline behavior
    e.preventDefault();
    if (idx < fields.length - 1) fields[idx + 1].focus();
    else target.blur();
  } else if (e.key === 'Backspace') {
    if (target.tagName === 'SELECT' || target.type === 'checkbox' || target.type === 'radio') return;
    if (target.value === '' && idx > 0) {
      e.preventDefault();
      fields[idx - 1].focus();
    }
  }
});

