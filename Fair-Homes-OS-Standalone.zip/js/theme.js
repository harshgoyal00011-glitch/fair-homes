/* ==========================================================================
   Fair Homes OS — Theme Controller (Light/Dark Mode)
   ========================================================================== */

const ThemeController = (() => {
  const STORAGE_KEY = 'fh_theme';

  function getStored() {
    return localStorage.getItem(STORAGE_KEY);
  }

  function apply(mode) {
    document.documentElement.setAttribute('data-theme', mode);
    localStorage.setItem(STORAGE_KEY, mode);
    updateToggleIcon(mode);
  }

  function updateToggleIcon(mode) {
    const btn = document.getElementById('themeToggleBtn');
    if (btn) btn.textContent = mode === 'dark' ? '☀️' : '🌙';
  }

  function toggle() {
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    apply(current === 'dark' ? 'light' : 'dark');
  }

  function init() {
    const stored = getStored();
    if (stored) {
      apply(stored);
    } else {
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      apply(prefersDark ? 'dark' : 'light');
    }
  }

  return { init, toggle, apply };
})();
