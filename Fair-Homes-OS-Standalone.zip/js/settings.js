/* ==========================================================================
   Fair Homes OS — System Settings, User Management, Backup & Business
   Configuration (Phase 10). Final core module — integrates with every
   other module via already-exposed getters, plus small additive reload()/
   bulkImport() functions added to Owners/Properties/Tenants/Finance and
   clearAll()/archiveOld() added to Notifications. No existing module was
   restructured.
   ========================================================================== */

const SettingsController = (() => {
  const KEYS = {
    company: 'fh_company_profile', users: 'fh_users', perms: 'fh_role_permissions',
    business: 'fh_business_settings', app: 'fh_app_settings', lastBackup: 'fh_last_backup',
  };
  const ROLES = ['Super Admin', 'Admin', 'Manager', 'Staff', 'Accountant', 'Social Media', 'Read Only'];
  const MODULES = ['Dashboard', 'Owners', 'Properties', 'Rooms', 'Bookings', 'BrokerageFlats', 'Tenants', 'Finance', 'Maintenance', 'SocialMediaTasks', 'Reports', 'Notifications', 'Settings'];
  const PERM_TYPES = ['View', 'Create', 'Edit', 'Delete', 'Export'];
  const THEME_COLORS = ['#2563EB', '#0D9488', '#9333EA', '#DC2626', '#D97706', '#16A34A'];

  let users = [], permissions = {}, editingUserId = null, activeRole = 'Super Admin';
  let credentialRequests = [];

  // ---------------- Storage ----------------
  function loadJson(key, fallback) { try { const v = JSON.parse(localStorage.getItem(key)); return v ?? fallback; } catch (e) { return fallback; } }
  function saveJson(key, val) {
    localStorage.setItem(key, JSON.stringify(val));
    CloudSync.syncDoc(key, val);
  }
  function generateId() { return (crypto.randomUUID ? crypto.randomUUID() : 'id_' + Date.now() + '_' + Math.random().toString(16).slice(2)); }

  function loadAll() {
    users = loadJson(KEYS.users, []);
    permissions = loadJson(KEYS.perms, null) || seedDefaultPermissions();
    permissions = backfillPermissions(permissions);
    try { credentialRequests = JSON.parse(localStorage.getItem('fh_credential_requests')) || []; } catch (e) { credentialRequests = []; }

    // Users list re-renders live on cloud updates (e.g. a teammate added
    // from another device). The single-object settings (company profile,
    // business settings, app settings, permissions) only update the local
    // cache silently — actively overwriting an open form while someone is
    // mid-edit would be disruptive; the freshest value is picked up the
    // next time that settings tab is opened.
    CloudSync.watch('users', (arr) => { users = arr; localStorage.setItem(KEYS.users, JSON.stringify(arr)); renderUsers(); });
    CloudSync.watch('credentialRequests', (arr) => {
      credentialRequests = arr;
      localStorage.setItem('fh_credential_requests', JSON.stringify(arr));
      if (document.getElementById('ssub-setAccountSecurity')?.classList.contains('active')) renderAccountSecurity();
    });
    CloudSync.watchDoc(KEYS.company, (data) => { if (data) localStorage.setItem(KEYS.company, JSON.stringify(data)); });
    CloudSync.watchDoc(KEYS.perms, (data) => { if (data) { permissions = data; localStorage.setItem(KEYS.perms, JSON.stringify(data)); } });
    CloudSync.watchDoc(KEYS.business, (data) => { if (data) localStorage.setItem(KEYS.business, JSON.stringify(data)); });
    CloudSync.watchDoc(KEYS.app, (data) => { if (data) localStorage.setItem(KEYS.app, JSON.stringify(data)); });
  }

  function seedDefaultPermissions() {
    // Sensible default permission templates (configuration, not business
    // data) — Super Admin gets everything, Read Only gets View only,
    // others start with reasonable operational defaults. Fully editable.
    const perms = {};
    ROLES.forEach((role) => {
      perms[role] = {};
      MODULES.forEach((mod) => {
        if (role === 'Super Admin') perms[role][mod] = { View: true, Create: true, Edit: true, Delete: true, Export: true };
        else if (role === 'Read Only') perms[role][mod] = { View: true, Create: false, Edit: false, Delete: false, Export: false };
        else if (role === 'Social Media') {
          const isTheirModule = mod === 'SocialMediaTasks';
          perms[role][mod] = { View: isTheirModule, Create: isTheirModule, Edit: isTheirModule, Delete: isTheirModule, Export: false };
        }
        else perms[role][mod] = { View: true, Create: true, Edit: true, Delete: false, Export: role === 'Accountant' && mod === 'Finance' };
      });
    });
    saveJson(KEYS.perms, perms);
    return perms;
  }

  /** Adds any role or module missing from an existing permissions object
   *  (e.g. this business set up permissions before 'Social Media' role
   *  or 'SocialMediaTasks' module existed) — fills in sensible defaults
   *  for just what's missing, without touching anything already
   *  configured. Saves back to cloud only if something was actually added. */
  function backfillPermissions(perms) {
    let changed = false;
    const fresh = seedDefaultPermissionsInMemory();
    ROLES.forEach((role) => {
      if (!perms[role]) { perms[role] = fresh[role]; changed = true; return; }
      MODULES.forEach((mod) => {
        if (!perms[role][mod]) { perms[role][mod] = fresh[role][mod]; changed = true; }
      });
    });
    if (changed) saveJson(KEYS.perms, perms);
    return perms;
  }
  /** Same defaults as seedDefaultPermissions() but returns the object
   *  without persisting — used by backfillPermissions() as a reference
   *  for filling in just the missing pieces. */
  function seedDefaultPermissionsInMemory() {
    const perms = {};
    ROLES.forEach((role) => {
      perms[role] = {};
      MODULES.forEach((mod) => {
        if (role === 'Super Admin') perms[role][mod] = { View: true, Create: true, Edit: true, Delete: true, Export: true };
        else if (role === 'Read Only') perms[role][mod] = { View: true, Create: false, Edit: false, Delete: false, Export: false };
        else if (role === 'Social Media') {
          const isTheirModule = mod === 'SocialMediaTasks';
          perms[role][mod] = { View: isTheirModule, Create: isTheirModule, Edit: isTheirModule, Delete: isTheirModule, Export: false };
        }
        else perms[role][mod] = { View: true, Create: true, Edit: true, Delete: false, Export: role === 'Accountant' && mod === 'Finance' };
      });
    });
    return perms;
  }

  function esc(str) { if (str === null || str === undefined) return ''; return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
  function fmtDateTime(iso) { if (!iso) return 'Never'; const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }
  function clearErrors(formId) { document.querySelectorAll('#' + formId + ' .form-error').forEach((el) => (el.textContent = '')); }
  function showErrors(errors) { Object.entries(errors).forEach(([id, msg]) => { const el = document.getElementById('err-' + id); if (el) el.textContent = msg; }); }

  // ======================================================================
  // 1. COMPANY PROFILE
  // ======================================================================
  function loadCompanyForm() {
    const c = loadJson(KEYS.company, {});
    document.getElementById('cpName').value = c.name || '';
    document.getElementById('cpTagline').value = c.tagline || '';
    document.getElementById('cpGst').value = c.gst || '';
    document.getElementById('cpPan').value = c.pan || '';
    document.getElementById('cpAddress').value = c.address || '';
    document.getElementById('cpMobile').value = c.mobile || '';
    document.getElementById('cpEmail').value = c.email || '';
    document.getElementById('cpWebsite').value = c.website || '';
    document.getElementById('cpHours').value = c.hours || '';
    document.getElementById('cpBankAccount').value = c.bankAccount || '';
    document.getElementById('cpBankIfsc').value = c.bankIfsc || '';
    document.getElementById('cpBankName').value = c.bankName || '';
    document.getElementById('cpUpi').value = c.upi || '';
  }
  function saveCompanyProfile() {
    saveJson(KEYS.company, {
      name: document.getElementById('cpName').value.trim(), tagline: document.getElementById('cpTagline').value.trim(),
      gst: document.getElementById('cpGst').value.trim(), pan: document.getElementById('cpPan').value.trim().toUpperCase(),
      address: document.getElementById('cpAddress').value.trim(), mobile: document.getElementById('cpMobile').value.trim(),
      email: document.getElementById('cpEmail').value.trim(), website: document.getElementById('cpWebsite').value.trim(),
      hours: document.getElementById('cpHours').value.trim(), bankAccount: document.getElementById('cpBankAccount').value.trim(),
      bankIfsc: document.getElementById('cpBankIfsc').value.trim().toUpperCase(), bankName: document.getElementById('cpBankName').value.trim(),
      upi: document.getElementById('cpUpi').value.trim(), updatedAt: new Date().toISOString(),
    });
    alert('Company profile saved.');
  }

  // ======================================================================
  // 2. USER MANAGEMENT
  // ======================================================================
  function renderUsers() {
    const box = document.getElementById('usersList');
    if (!users.length) { box.innerHTML = '<div class="empty-state"><div class="ico">👥</div><div class="title">No users yet</div><div class="desc">Add your team members above.</div></div>'; return; }
    box.innerHTML = users.map((u) => {
      const isSuperAdmin = u.role === 'Super Admin';
      return `
      <div class="user-row">
        <div>
          <div style="font-weight:700;">${esc(u.name)} <span class="badge ${u.status === 'Active' ? 'pay-paid' : 'pay-pending'}" style="margin-left:6px;">${u.status}</span></div>
          <div class="sub">${esc(u.email)} · ${esc(u.role)}${u.mobile ? ' · ' + esc(u.mobile) : ''}</div>
        </div>
        <div class="row-actions">
          <button class="btn small secondary us-edit-btn" data-id="${u.id}">Edit</button>
          <button class="btn small secondary us-resetpw-btn" data-id="${u.id}">Reset Password</button>
          ${isSuperAdmin ? '' : `<button class="btn small secondary us-toggle-btn" data-id="${u.id}">${u.status === 'Active' ? 'Deactivate' : 'Activate'}</button>`}
          ${isSuperAdmin ? '' : `<button class="btn small secondary us-forcesignout-btn" data-id="${u.id}">Force Sign Out</button>`}
          ${isSuperAdmin ? '<span class="na-note">Super Admin can\'t be removed</span>' : `<button class="btn small danger us-del-btn" data-id="${u.id}" style="background:var(--error); color:#fff;">Delete</button>`}
        </div>
      </div>`;
    }).join('');
    box.querySelectorAll('.us-edit-btn').forEach((b) => b.addEventListener('click', () => openEditUserModal(b.dataset.id)));
    box.querySelectorAll('.us-resetpw-btn').forEach((b) => b.addEventListener('click', () => handleSendPasswordReset(b.dataset.id)));
    box.querySelectorAll('.us-toggle-btn').forEach((b) => b.addEventListener('click', () => toggleUserStatus(b.dataset.id)));
    box.querySelectorAll('.us-forcesignout-btn').forEach((b) => b.addEventListener('click', () => forceSignOutUser(b.dataset.id)));
    box.querySelectorAll('.us-del-btn').forEach((b) => b.addEventListener('click', () => deleteUser(b.dataset.id)));
  }

  function openAddUserModal() {
    editingUserId = null;
    document.getElementById('userModalTitle').textContent = 'Add User';
    document.getElementById('userForm').reset();
    document.getElementById('userId').value = '';
    document.getElementById('userPasswordGroup').style.display = 'block';
    clearErrors('userForm');
    document.getElementById('userModalOverlay').classList.add('open');
  }
  function openEditUserModal(id) {
    const u = users.find((x) => x.id === id);
    if (!u) return;
    editingUserId = id;
    document.getElementById('userModalTitle').textContent = 'Edit User';
    document.getElementById('userId').value = u.id;
    document.getElementById('userName').value = u.name;
    document.getElementById('userEmail').value = u.email;
    document.getElementById('userMobile').value = u.mobile || '';
    document.getElementById('userRole').value = u.role;
    // Can't change someone's login email/password from here — editing
    // only updates their name/mobile/role (the organizational record).
    document.getElementById('userPasswordGroup').style.display = 'none';
    clearErrors('userForm');
    document.getElementById('userModalOverlay').classList.add('open');
  }
  function closeUserModal() { document.getElementById('userModalOverlay').classList.remove('open'); editingUserId = null; }

  async function handleSaveUser() {
    const name = document.getElementById('userName').value.trim();
    const email = document.getElementById('userEmail').value.trim();
    const mobile = document.getElementById('userMobile').value.trim();
    const password = document.getElementById('userPassword').value;
    const role = document.getElementById('userRole').value;

    const errors = {};
    if (!name) errors.userName = 'Name is required';
    if (!email) errors.userEmail = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.userEmail = 'Enter a valid email';
    else {
      const dup = users.some((u) => u.email.toLowerCase() === email.toLowerCase() && u.id !== editingUserId);
      if (dup) errors.userEmail = 'A user with this email already exists';
    }
    if (!editingUserId && (!password || password.length < 6)) errors.userPassword = 'Enter a password, 6+ characters';
    clearErrors('userForm');
    if (Object.keys(errors).length) { showErrors(errors); return; }

    const now = new Date().toISOString();
    const saveBtn = document.getElementById('userSaveBtn');

    if (editingUserId) {
      const idx = users.findIndex((u) => u.id === editingUserId);
      if (idx !== -1) users[idx] = { ...users[idx], name, email, mobile, role, updatedAt: now };
      localStorage.setItem(KEYS.users, JSON.stringify(users));
      CloudSync.sync('users', users);
      closeUserModal();
      renderUsers();
      return;
    }

    saveBtn.disabled = true;
    saveBtn.textContent = 'Creating login...';
    try {
      const result = await CloudSync.createTeamMember(email, password);
      users.unshift({ id: generateId(), uid: result.uid, name, email, mobile, role, status: 'Active', createdAt: now, updatedAt: now });
      localStorage.setItem(KEYS.users, JSON.stringify(users));
      CloudSync.sync('users', users);
      closeUserModal();
      renderUsers();
      if (result.wasExisting) {
        alert(`${name} already had a login for this email — it's now linked to this business's shared data instead of its own separate space. They can sign in with their EXISTING password (not the one you just typed here).`);
      } else {
        alert(`${name}'s login is ready. Share their email and the password you set — they can now sign in with their own account.`);
      }
    } catch (err) {
      const msg = err.message || 'Could not create the login. Try again.';
      showErrors({ userPassword: msg });
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = 'Save User';
    }
  }

  function toggleUserStatus(id) { const u = users.find((x) => x.id === id); if (u) { u.status = u.status === 'Active' ? 'Inactive' : 'Active'; localStorage.setItem(KEYS.users, JSON.stringify(users));
    CloudSync.sync('users', users); renderUsers(); } }
  function deleteUser(id) {
    const u = users.find((x) => x.id === id);
    if (!u) return;
    ConfirmModal.show('Delete this user? You can restore it later from Settings → Trash.', () => {
      TrashController.moveToTrash('user', u, u.name);
      users = users.filter((x) => x.id !== id);
      localStorage.setItem(KEYS.users, JSON.stringify(users));
    CloudSync.sync('users', users);
      renderUsers();
    });
  }
  async function handleSendPasswordReset(id) {
    const u = users.find((x) => x.id === id);
    if (!u) return;
    try {
      await CloudSync.sendPasswordReset(u.email);
      alert(`Password reset email sent to ${u.email}. Ask them to check their inbox (and spam folder) and follow the link to set a new password.`);
    } catch (err) {
      alert('Could not send reset email: ' + (err.message || 'Try again.'));
    }
  }

  async function forceSignOutUser(id) {
    const u = users.find((x) => x.id === id);
    if (!u) return;
    const pin = prompt(`Enter your Security PIN to force sign out ${u.name}:`);
    if (pin === null) return;
    const result = await AccessController.verifySecurityPin(pin);
    if (!result.ok) {
      alert(result.reason === 'not_set' ? 'You haven\'t set a Security PIN yet — set one in Account & Security first.' : 'Wrong PIN.');
      return;
    }
    const idx = users.findIndex((x) => x.id === id);
    if (idx !== -1) users[idx] = { ...users[idx], forceSignOutAt: new Date().toISOString() };
    localStorage.setItem(KEYS.users, JSON.stringify(users));
    CloudSync.sync('users', users);
    alert(`${u.name} will be signed out of their current session. They can sign back in immediately if needed.`);
  }

  // ======================================================================
  // ACCOUNT & SECURITY
  // ======================================================================
  function renderAccountSecurity() {
    const authUser = CloudSync.getCurrentUser();
    const isSuperAdmin = AccessController.getCurrentRole() === 'Super Admin';
    document.getElementById('myAccountEmail').textContent = authUser ? `Signed in as ${authUser.email} (${AccessController.getCurrentRole()})` : '—';

    document.getElementById('myAccountSuperAdminForm').classList.toggle('hidden', !isSuperAdmin);
    document.getElementById('myAccountRequestForm').classList.toggle('hidden', isSuperAdmin);
    document.getElementById('securityPinCard').classList.toggle('hidden', !isSuperAdmin);
    document.getElementById('approvalRequestsCard').classList.toggle('hidden', !isSuperAdmin);

    if (isSuperAdmin) {
      renderApprovalRequests();
    } else if (authUser) {
      const myRequests = credentialRequests.filter((r) => r.requesterEmail.toLowerCase() === authUser.email.toLowerCase());
      const pending = myRequests.find((r) => r.status === 'Pending');
      const approved = myRequests.find((r) => r.status === 'Approved');
      const pendingNote = document.getElementById('myPendingRequestNote');
      const approvedBox = document.getElementById('myApprovedRequestBox');
      pendingNote.classList.toggle('hidden', !pending);
      if (pending) pendingNote.textContent = `⏳ Your ${pending.requestType} change request is waiting for Super Admin approval.`;
      approvedBox.classList.toggle('hidden', !approved);
      if (approved) {
        approvedBox.innerHTML = approved.requestType === 'password'
          ? `<div style="font-weight:700; margin-bottom:8px;">✅ Approved — set your new password now</div>
             <div class="field-group"><label class="field-label" for="completeCurrentPassword">Current Password</label><input type="password" id="completeCurrentPassword" /></div>
             <div class="field-group"><label class="field-label" for="completeNewPassword">New Password</label><input type="password" id="completeNewPassword" placeholder="6+ characters" /></div>
             <div class="show-password-row"><input type="checkbox" id="showCompletePasswordChk" /><label for="showCompletePasswordChk">Show passwords</label></div>
             <div class="form-error" id="err-completeChange"></div>
             <button class="btn small" id="completeChangeBtn" data-request-id="${approved.id}">Set New Password</button>`
          : `<div style="font-weight:700; margin-bottom:8px;">✅ Approved — confirm to change your email to ${esc(approved.newEmail)}</div>
             <div class="field-group"><label class="field-label" for="completeCurrentPassword">Current Password</label><input type="password" id="completeCurrentPassword" /></div>
             <div class="show-password-row"><input type="checkbox" id="showCompletePasswordChk" /><label for="showCompletePasswordChk">Show password</label></div>
             <div class="form-error" id="err-completeChange"></div>
             <button class="btn small" id="completeChangeBtn" data-request-id="${approved.id}">Confirm Email Change</button>`;
        document.getElementById('completeChangeBtn').addEventListener('click', () => handleCompleteApprovedChange(approved));
        wireShowPasswordToggle('showCompletePasswordChk', ['completeCurrentPassword', 'completeNewPassword']);
      }
    }
  }

  async function handleMyAccountSave() {
    const currentPassword = document.getElementById('myCurrentPassword').value;
    const newPassword = document.getElementById('myNewPassword').value;
    const newEmail = document.getElementById('myNewEmail').value.trim();
    clearErrors('myAccountSuperAdminForm');
    if (!currentPassword) { showErrors({ myAccount: 'Enter your current password to confirm changes.' }); return; }
    if (!newPassword && !newEmail) { showErrors({ myAccount: 'Enter a new password or new email to change.' }); return; }
    if (newPassword && newPassword.length < 6) { showErrors({ myAccount: 'New password must be 6+ characters.' }); return; }

    const btn = document.getElementById('myAccountSaveBtn');
    btn.disabled = true; btn.textContent = 'Updating...';
    try {
      if (newPassword) await CloudSync.changeOwnPassword(currentPassword, newPassword);
      if (newEmail) await CloudSync.changeOwnEmail(currentPassword, newEmail);
      alert('Account updated.');
      document.getElementById('myCurrentPassword').value = '';
      document.getElementById('myNewPassword').value = '';
      document.getElementById('myNewEmail').value = '';
      renderAccountSecurity();
    } catch (err) {
      showErrors({ myAccount: err.code === 'auth/wrong-password' ? 'Current password is incorrect.' : (err.message || 'Update failed.') });
    } finally {
      btn.disabled = false; btn.textContent = 'Update My Account';
    }
  }

  function requestCredentialChange(requestType, newEmail) {
    const authUser = CloudSync.getCurrentUser();
    if (!authUser) return;
    const already = credentialRequests.find((r) => r.requesterEmail.toLowerCase() === authUser.email.toLowerCase() && r.status === 'Pending');
    if (already) { alert('You already have a pending request awaiting approval.'); return; }
    const rec = {
      id: (crypto.randomUUID ? crypto.randomUUID() : 'req_' + Date.now()),
      requesterEmail: authUser.email, requestType, newEmail: newEmail || null,
      status: 'Pending', requestedAt: new Date().toISOString(),
    };
    credentialRequests.unshift(rec);
    localStorage.setItem('fh_credential_requests', JSON.stringify(credentialRequests));
    CloudSync.sync('credentialRequests', credentialRequests);
    alert('Request sent to your Super Admin for approval.');
    renderAccountSecurity();
  }

  async function handleCompleteApprovedChange(request) {
    const currentPassword = document.getElementById('completeCurrentPassword').value;
    clearErrors('myApprovedRequestBox');
    if (!currentPassword) { showErrors({ completeChange: 'Enter your current password.' }); return; }
    const btn = document.getElementById('completeChangeBtn');
    btn.disabled = true; btn.textContent = 'Saving...';
    try {
      if (request.requestType === 'password') {
        const newPassword = document.getElementById('completeNewPassword').value;
        if (!newPassword || newPassword.length < 6) { showErrors({ completeChange: 'New password must be 6+ characters.' }); btn.disabled = false; btn.textContent = 'Set New Password'; return; }
        await CloudSync.changeOwnPassword(currentPassword, newPassword);
      } else {
        await CloudSync.changeOwnEmail(currentPassword, request.newEmail);
        // Keep the Users directory record in sync with their new sign-in email.
        const idx = users.findIndex((u) => u.email.toLowerCase() === request.requesterEmail.toLowerCase());
        if (idx !== -1) { users[idx] = { ...users[idx], email: request.newEmail }; localStorage.setItem(KEYS.users, JSON.stringify(users)); CloudSync.sync('users', users); }
      }
      credentialRequests = credentialRequests.map((r) => r.id === request.id ? { ...r, status: 'Completed', completedAt: new Date().toISOString() } : r);
      localStorage.setItem('fh_credential_requests', JSON.stringify(credentialRequests));
      CloudSync.sync('credentialRequests', credentialRequests);
      alert('Done — your change has been applied.');
      renderAccountSecurity();
    } catch (err) {
      showErrors({ completeChange: err.code === 'auth/wrong-password' ? 'Current password is incorrect.' : (err.message || 'Failed.') });
      btn.disabled = false; btn.textContent = request.requestType === 'password' ? 'Set New Password' : 'Confirm Email Change';
    }
  }

  function renderApprovalRequests() {
    const box = document.getElementById('approvalRequestsList');
    const pending = credentialRequests.filter((r) => r.status === 'Pending');
    if (!pending.length) { box.innerHTML = '<div class="empty-state"><div class="desc">No pending requests.</div></div>'; return; }
    box.innerHTML = pending.map((r) => `
      <div class="danger-row">
        <div>
          <div class="dr-label">${esc(r.requesterEmail)} — ${r.requestType === 'password' ? 'Password Change' : 'Email Change to ' + esc(r.newEmail)}</div>
          <div class="dr-desc">Requested ${fmtDateTime(r.requestedAt)}</div>
        </div>
        <div style="display:flex; gap:6px;">
          <button class="btn small approve-req-btn" data-id="${r.id}">Approve</button>
          <button class="btn small secondary reject-req-btn" data-id="${r.id}">Reject</button>
        </div>
      </div>`).join('');
    box.querySelectorAll('.approve-req-btn').forEach((b) => b.addEventListener('click', () => decideCredentialRequest(b.dataset.id, 'Approved')));
    box.querySelectorAll('.reject-req-btn').forEach((b) => b.addEventListener('click', () => decideCredentialRequest(b.dataset.id, 'Rejected')));
  }

  async function decideCredentialRequest(id, decision) {
    const pin = prompt(`Enter your Security PIN to ${decision.toLowerCase()} this request:`);
    if (pin === null) return;
    const result = await AccessController.verifySecurityPin(pin);
    if (!result.ok) {
      alert(result.reason === 'not_set' ? 'Set your Security PIN first (above), then try again.' : 'Wrong PIN.');
      return;
    }
    credentialRequests = credentialRequests.map((r) => r.id === id ? { ...r, status: decision, decidedAt: new Date().toISOString() } : r);
    localStorage.setItem('fh_credential_requests', JSON.stringify(credentialRequests));
    CloudSync.sync('credentialRequests', credentialRequests);
    renderApprovalRequests();
  }

  async function handleSavePin() {
    const current = document.getElementById('securityPinCurrent').value;
    const newPin = document.getElementById('securityPinNew').value;
    clearErrors('securityPinCard');
    if (!newPin || newPin.length < 4 || newPin.length > 8 || !/^\d+$/.test(newPin)) { showErrors({ securityPin: 'PIN must be 4-8 digits.' }); return; }
    const hasPin = await AccessController.hasSecurityPinSet();
    if (hasPin) {
      const result = await AccessController.verifySecurityPin(current);
      if (!result.ok) { showErrors({ securityPin: 'Current PIN is incorrect.' }); return; }
    }
    await AccessController.setSecurityPin(newPin);
    document.getElementById('securityPinCurrent').value = '';
    document.getElementById('securityPinNew').value = '';
    alert('Security PIN saved.');
  }

  // ======================================================================
  // 3. ROLE PERMISSIONS
  // ======================================================================
  function renderRoleChips() {
    document.getElementById('roleChips').innerHTML = ROLES.map((r) => `<div class="role-chip ${r === activeRole ? 'active' : ''}" data-role="${r}">${r}</div>`).join('');
    document.querySelectorAll('.role-chip').forEach((chip) => chip.addEventListener('click', () => { activeRole = chip.dataset.role; renderRoleChips(); renderPermMatrix(); }));
  }
  function renderPermMatrix() {
    const table = document.getElementById('permMatrix');
    const head = '<tr><th>Module</th>' + PERM_TYPES.map((p) => `<th>${p}</th>`).join('') + '</tr>';
    const body = MODULES.map((mod) => {
      const cells = PERM_TYPES.map((p) => {
        const checked = permissions[activeRole]?.[mod]?.[p] ? 'checked' : '';
        return `<td><input type="checkbox" data-mod="${mod}" data-perm="${p}" ${checked} /></td>`;
      }).join('');
      return `<tr><td>${mod}</td>${cells}</tr>`;
    }).join('');
    table.innerHTML = head + body;
    table.querySelectorAll('input[type="checkbox"]').forEach((cb) => cb.addEventListener('change', () => {
      permissions[activeRole][cb.dataset.mod][cb.dataset.perm] = cb.checked;
      saveJson(KEYS.perms, permissions);
    }));
  }

  // ======================================================================
  // 4. BUSINESS SETTINGS
  // ======================================================================
  function loadBusinessForm() {
    const b = loadJson(KEYS.business, {});
    document.getElementById('bsCurrency').value = b.currency || 'INR';
    document.getElementById('bsDateFormat').value = b.dateFormat || 'DD/MM/YYYY';
    document.getElementById('bsTimeFormat').value = b.timeFormat || '12h';
    document.getElementById('bsFinYear').value = b.finYear || 'April';
    document.getElementById('bsTax').value = b.taxPct ?? '';
    document.getElementById('bsLateFee').value = b.lateFeeRate ?? 20;
    document.getElementById('bsDepositRule').value = b.depositRule || '';
    document.getElementById('bsBrokerageRule').value = b.brokerageRule || '';
    document.getElementById('bsMgmtRule').value = b.mgmtRule || '';
  }
  function saveBusinessSettings() {
    saveJson(KEYS.business, {
      currency: document.getElementById('bsCurrency').value, dateFormat: document.getElementById('bsDateFormat').value,
      timeFormat: document.getElementById('bsTimeFormat').value, finYear: document.getElementById('bsFinYear').value,
      taxPct: document.getElementById('bsTax').value, lateFeeRate: document.getElementById('bsLateFee').value,
      depositRule: document.getElementById('bsDepositRule').value.trim(), brokerageRule: document.getElementById('bsBrokerageRule').value.trim(),
      mgmtRule: document.getElementById('bsMgmtRule').value.trim(), updatedAt: new Date().toISOString(),
    });
    alert('Business settings saved. Late Fee Rate now applies to new Rent Collection entries in Finance.');
  }

  // ======================================================================
  // 5. IMPORT DATA
  // ======================================================================
  function parseFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      const isCsv = file.name.toLowerCase().endsWith('.csv');
      reader.onload = (e) => {
        try {
          if (isCsv) {
            const lines = e.target.result.split(/\r?\n/).filter((l) => l.trim());
            const headers = lines[0].split(',').map((h) => h.trim());
            const rows = lines.slice(1).map((line) => {
              const cells = line.split(',').map((c) => c.trim());
              const obj = {};
              headers.forEach((h, i) => (obj[h] = cells[i] || ''));
              return obj;
            });
            resolve(rows);
          } else {
            if (typeof XLSX === 'undefined') { reject(new Error('Excel library not loaded — check internet connection.')); return; }
            const wb = XLSX.read(e.target.result, { type: 'binary' });
            const sheet = wb.Sheets[wb.SheetNames[0]];
            resolve(XLSX.utils.sheet_to_json(sheet));
          }
        } catch (err) { reject(err); }
      };
      reader.onerror = reject;
      if (isCsv) reader.readAsText(file); else reader.readAsBinaryString(file);
    });
  }

  async function runImport() {
    const fileInput = document.getElementById('importFile');
    const module = document.getElementById('importModule').value;
    const statusEl = document.getElementById('importStatus');
    if (!fileInput.files.length) { statusEl.style.color = 'var(--error)'; statusEl.textContent = 'Select a file first.'; return; }

    try {
      const rows = await parseFile(fileInput.files[0]);
      if (!rows.length) { statusEl.style.color = 'var(--error)'; statusEl.textContent = 'No rows found in file.'; return; }

      if (module === 'owners') OwnersController.bulkImport(rows);
      else if (module === 'properties') PropertiesController.bulkImport(rows);
      else if (module === 'tenants') TenantsController.bulkImport(rows);
      else if (module === 'rent') FinanceController.bulkImportRent(rows);

      statusEl.style.color = 'var(--success)';
      statusEl.textContent = `Imported ${rows.length} row(s) into ${module}. Visit that module to see them.`;
      fileInput.value = '';
    } catch (err) {
      statusEl.style.color = 'var(--error)';
      statusEl.textContent = 'Import failed: ' + err.message;
    }
  }

  // ======================================================================
  // 6. EXPORT DATA
  // ======================================================================
  function getModuleData(module) {
    const map = {
      owners: () => OwnersController.getAll().map((o) => ({ Name: o.fullName, Mobile: o.phone, Email: o.email })),
      properties: () => PropertiesController.getAll().map((p) => ({ Name: p.name, Type: p.type, City: p.city, Rent: p.rent, Status: p.status })),
      tenants: () => TenantsController.getAll().map((t) => ({ Name: t.fullName, Mobile: t.mobile, Status: t.status })),
      rent: () => FinanceController.getAllRentEntries().map((r) => ({ Month: r.rentMonth, Amount: r.amountPaid, Status: r.paymentStatus })),
    };
    return map[module] ? map[module]() : [];
  }

  function exportModuleAs(format) {
    const module = document.getElementById('exportModule').value;
    if (module === 'all') { exportFullBackup(); return; }
    const rows = getModuleData(module);
    if (!rows.length) { alert('No data to export.'); return; }
    const headers = Object.keys(rows[0]);
    const dataRows = rows.map((r) => headers.map((h) => r[h]));

    if (format === 'csv') {
      const lines = [headers.join(','), ...dataRows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(','))];
      downloadBlob(lines.join('\n'), module + '.csv', 'text/csv');
    } else if (format === 'excel') {
      if (typeof XLSX === 'undefined') { alert('Excel library not loaded.'); return; }
      const ws = XLSX.utils.aoa_to_sheet([headers, ...dataRows]);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, module.slice(0, 30));
      XLSX.writeFile(wb, module + '.xlsx');
    } else if (format === 'json') {
      downloadBlob(JSON.stringify(rows, null, 2), module + '.json', 'application/json');
    }
  }

  function downloadBlob(content, filename, mime) {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  }

  // ======================================================================
  // 7. BACKUP & RESTORE
  // ======================================================================
  const ALL_DATA_KEYS = [
    'fh_owners', 'fh_properties', 'fh_property_id_seq', 'fh_rooms',
    'fh_tenants', 'fh_tenant_id_seq', 'fh_bookings', 'fh_booking_seq', 'fh_brokerage_flats', 'fh_brokerage_flat_seq', 'fh_social_media_tasks', 'fh_smt_seq', 'fh_rent_entries', 'fh_rent_seq', 'fh_deposits', 'fh_deposit_seq',
    'fh_brokerage', 'fh_brokerage_seq', 'fh_management_fees', 'fh_fee_seq', 'fh_expenses', 'fh_expense_seq',
    'fh_tickets', 'fh_ticket_seq', 'fh_vendor_categories', 'fh_work_types', 'fh_vendor_bills', 'fh_vendor_bill_seq',
    'fh_maids', 'fh_maid_seq', 'fh_maid_assignments', 'fh_maid_attendance', 'fh_maid_payments', 'fh_electricity_bills', 'fh_electricity_bill_seq',
    'fh_notifications', 'fh_task_reminders', 'fh_automation_logs',
    'fh_message_templates', 'fh_company_profile', 'fh_users', 'fh_role_permissions', 'fh_business_settings', 'fh_app_settings',
    'fh_credential_requests', 'fh_security_pin', 'fh_owner_payouts', 'fh_payout_seq',
  ];

  function exportFullBackup() {
    const snapshot = {};
    ALL_DATA_KEYS.forEach((k) => { const v = localStorage.getItem(k); if (v !== null) snapshot[k] = v; });
    const payload = { fairHomesBackup: true, exportedAt: new Date().toISOString(), data: snapshot };
    downloadBlob(JSON.stringify(payload, null, 2), 'fair-homes-backup-' + new Date().toISOString().slice(0, 10) + '.json', 'application/json');
    localStorage.setItem(KEYS.lastBackup, new Date().toISOString());
    renderLastBackupNote();
  }

  function renderLastBackupNote() {
    const last = localStorage.getItem(KEYS.lastBackup);
    document.getElementById('lastBackupNote').textContent = 'Last backup: ' + fmtDateTime(last);
  }

  const KEY_TO_COLLECTION = {
    fh_owners: 'owners', fh_properties: 'properties', fh_rooms: 'rooms', fh_tenants: 'tenants',
    fh_rent_entries: 'rentEntries', fh_deposits: 'deposits', fh_brokerage: 'brokerageEntries',
    fh_management_fees: 'managementFees', fh_expenses: 'expenses', fh_margin_income: 'marginIncome',
    fh_owner_advances: 'ownerAdvances', fh_business_expenses: 'businessExpenses', fh_owner_payouts: 'ownerPayouts', fh_setup_expenses: 'setupExpenses',
    fh_tickets: 'tickets', fh_routine_tasks: 'routineTasks',
    fh_notifications: 'notifications', fh_task_reminders: 'taskReminders',
    fh_automation_logs: 'automationLogs', fh_message_templates: 'messageTemplates', fh_users: 'users',
  };
  const KEY_TO_SETTINGS_DOC = { fh_company_profile: true, fh_role_permissions: true, fh_business_settings: true, fh_app_settings: true };

  function restoreFromBackup() {
    const fileInput = document.getElementById('restoreFile');
    if (!fileInput.files.length) { alert('Select a backup JSON file first.'); return; }
    ConfirmModal.show('This will OVERWRITE all current data — on this device AND in your cloud account. Continue?', () => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const payload = JSON.parse(e.target.result);
          if (!payload.fairHomesBackup || !payload.data) { alert('This does not look like a valid Fair Homes OS backup file.'); return; }
          Object.entries(payload.data).forEach(([k, v]) => {
            localStorage.setItem(k, v);
            // Push to the cloud too — otherwise the real-time listeners
            // would just sync the OLD cloud data back down and silently
            // undo this restore the moment the page reloads.
            try {
              const parsed = JSON.parse(v);
              if (KEY_TO_COLLECTION[k] && Array.isArray(parsed)) CloudSync.sync(KEY_TO_COLLECTION[k], parsed);
              else if (KEY_TO_SETTINGS_DOC[k] && parsed && typeof parsed === 'object') CloudSync.syncDoc(k, parsed);
            } catch (parseErr) { /* not JSON — skip cloud sync for this key */ }
          });
          alert('Restore complete — synced to your cloud account too. The app will now reload.');
          location.reload();
        } catch (err) {
          alert('Restore failed: ' + err.message);
        }
      };
      reader.readAsText(fileInput.files[0]);
    }, 'Restore Backup');
  }

  // ======================================================================
  // 8. DATA MANAGEMENT
  // ======================================================================
  function checkDemoData() { alert('No demo/sample data was ever seeded in this app — every record you see was entered by you or imported by you.'); }
  function deleteAllNotifications() {
    ConfirmModal.show('Delete ALL notifications and reminder history? This cannot be undone.', () => {
      NotificationsController.clearAllNotifications();
      alert('All notifications deleted.');
    }, 'Delete All Notifications');
  }
  function archiveOldNotifications() { const count = NotificationsController.archiveOldNotifications(90); alert(count + ' notification(s) older than 90 days archived.'); }
  function resetDatabase() {
    const typed = prompt('This permanently deletes ALL data — on this device AND in your cloud account (all devices). Type RESET to confirm:');
    if (typed !== 'RESET') { alert('Reset cancelled.'); return; }
    ALL_DATA_KEYS.forEach((k) => localStorage.removeItem(k));
    localStorage.removeItem('fh_last_login');
    localStorage.removeItem('fh_login_history');
    alert('Clearing cloud data — this may take a moment...');
    CloudSync.deleteAllCloudData()
      .then(() => { alert('All data has been reset everywhere. The app will now reload.'); location.reload(); })
      .catch((err) => { alert('Local data was cleared, but clearing the cloud failed: ' + err.message + '. Please check your connection and try again.'); location.reload(); });
  }

  // ======================================================================
  // 9. APP SETTINGS
  // ======================================================================
  function loadAppSettingsForm() {
    const a = loadJson(KEYS.app, {});
    document.getElementById('compactSidebar').checked = !!a.compactSidebar;
    document.getElementById('showKpiCards').checked = a.showKpiCards !== false;
    renderColorSwatches(a.themeColor || THEME_COLORS[0]);
    updateThemeModeChips();
  }
  function renderColorSwatches(active) {
    document.getElementById('colorSwatches').innerHTML = THEME_COLORS.map((c) => `<div class="color-swatch ${c === active ? 'active' : ''}" style="background:${c}" data-color="${c}"></div>`).join('');
    document.querySelectorAll('.color-swatch').forEach((sw) => sw.addEventListener('click', () => {
      document.documentElement.style.setProperty('--brand-primary', sw.dataset.color);
      document.querySelectorAll('.color-swatch').forEach((s) => s.classList.remove('active'));
      sw.classList.add('active');
    }));
  }
  function updateThemeModeChips() {
    const mode = document.documentElement.getAttribute('data-theme') || 'light';
    document.getElementById('lightModeBtn').classList.toggle('active', mode === 'light');
    document.getElementById('darkModeBtn').classList.toggle('active', mode === 'dark');
  }
  function saveAppSettings() {
    const themeColor = document.querySelector('.color-swatch.active')?.dataset.color || THEME_COLORS[0];
    saveJson(KEYS.app, {
      compactSidebar: document.getElementById('compactSidebar').checked,
      showKpiCards: document.getElementById('showKpiCards').checked,
      themeColor, updatedAt: new Date().toISOString(),
    });
    document.querySelector('.sidebar').style.width = document.getElementById('compactSidebar').checked ? '72px' : '';
    alert('App settings saved.');
  }

  // ======================================================================
  // 10+11. SYSTEM & SECURITY
  // ======================================================================
  function renderSystemInfo() {
    let bytes = 0;
    for (const k in localStorage) { if (localStorage.hasOwnProperty(k)) bytes += (localStorage[k].length + k.length) * 2; }
    const kb = (bytes / 1024).toFixed(1);
    const lastBackup = localStorage.getItem(KEYS.lastBackup);
    const lastLogin = localStorage.getItem('fh_last_login');

    document.getElementById('sysInfoGrid').innerHTML = `
      <div class="sysinfo-item"><div class="si-label">App Version</div><div class="si-value">v1.0.0 — Phase 10</div></div>
      <div class="sysinfo-item"><div class="si-label">Data Schema Version</div><div class="si-value">LocalStorage Schema v1</div></div>
      <div class="sysinfo-item"><div class="si-label">Storage Usage</div><div class="si-value">${kb} KB</div></div>
      <div class="sysinfo-item"><div class="si-label">Last Backup</div><div class="si-value" style="font-size:13px;">${fmtDateTime(lastBackup)}</div></div>
      <div class="sysinfo-item"><div class="si-label">Last Login</div><div class="si-value" style="font-size:13px;">${fmtDateTime(lastLogin)}</div></div>
    `;
  }

  function loadSecurityForm() {
    const a = loadJson(KEYS.app, {});
    document.getElementById('secSessionTimeout').value = a.sessionTimeout ?? 30;
    document.getElementById('secAutoLogout').checked = !!a.autoLogout;
  }
  function saveSecuritySettings() {
    const a = loadJson(KEYS.app, {});
    a.sessionTimeout = document.getElementById('secSessionTimeout').value;
    a.autoLogout = document.getElementById('secAutoLogout').checked;
    saveJson(KEYS.app, a);
    alert('Security preferences saved. (Note: no live session/auth system exists yet to actively enforce timeout — this is a stored preference for when that is built.)');
  }

  function renderLoginHistory() {
    const history = loadJson('fh_login_history', []);
    const box = document.getElementById('loginHistoryList');
    box.innerHTML = history.length
      ? history.slice(0, 15).map((h) => `<div class="history-item"><div class="hi-row">${fmtDateTime(h.timestamp)}</div></div>`).join('')
      : '<div class="empty-state"><div class="desc">No login history yet.</div></div>';
  }

  function renderActivityLog() {
    // Reuses Notifications' Automation Log (real, working) — manual
    // per-field edit tracking across every module isn't implemented,
    // since that would require touching every module's save function.
    const box = document.getElementById('activityLogList');
    const logs = loadJson('fh_automation_logs', []);
    box.innerHTML = logs.length
      ? logs.slice(0, 15).map((l) => `<div class="auto-log-item"><span class="al-arrow">⚙️</span><div><strong>${esc(l.ruleName)}</strong><div class="hi-row">${fmtDateTime(l.triggeredAt)}</div></div></div>`).join('')
      : '<div class="empty-state"><div class="desc">No activity logged yet.</div></div>';
  }

  // ======================================================================
  // 12. HELP & SUPPORT
  // ======================================================================
  const FAQ = [
    { q: 'Is my data safe if I close the browser?', a: 'Yes — your data is synced to your private Firebase (Google Cloud) account, and a local copy is also kept on this device. It stays safe even if you close the app or lose internet.' },
    { q: 'Can I use this on another device?', a: 'Yes — sign in with the same email and password on any phone, tablet, or laptop, and all your data appears automatically. No manual backup/restore needed.' },
    { q: 'Does this app send my data anywhere?', a: 'Yes, to your own private Firebase account (Google Cloud) — this is what powers multi-device sync. Only you can access it; it is never shared with anyone else.' },
    { q: 'Does the app work without internet?', a: 'Yes — you can keep working offline. Anything you add or change syncs automatically to your other devices the moment internet is available again.' },
    { q: 'What happens if I clear my browser data?', a: 'Nothing is lost — your data lives in your Firebase account, not just this browser. Simply sign in again to see everything.' },
  ];
  function renderFaq() {
    document.getElementById('faqList').innerHTML = FAQ.map((f, i) => `
      <div class="faq-item" data-i="${i}"><div class="faq-q">${esc(f.q)}</div><div class="faq-a">${esc(f.a)}</div></div>
    `).join('');
    document.querySelectorAll('.faq-item').forEach((item) => item.querySelector('.faq-q').addEventListener('click', () => item.classList.toggle('open')));
  }

  // ======================================================================
  // Sub-nav + Init
  // ======================================================================
  function switchSubTab(subId) {
    document.querySelectorAll('#settingsSubnav .st-tab').forEach((t) => t.classList.toggle('active', t.dataset.ssub === subId));
    document.querySelectorAll('#page-settings .settings-subview').forEach((v) => v.classList.toggle('active', v.id === 'ssub-' + subId));
    if (subId === 'setCompany') loadCompanyForm();
    if (subId === 'setUsers') { renderUsers(); renderRoleChips(); renderPermMatrix(); }
    if (subId === 'setAccountSecurity') renderAccountSecurity();
    if (subId === 'setBusiness') loadBusinessForm();
    if (subId === 'setBackup') renderLastBackupNote();
    if (subId === 'setTrash' && typeof TrashController !== 'undefined') TrashController.onPageShow();
    if (subId === 'setApp') loadAppSettingsForm();
    if (subId === 'setSystem') { renderSystemInfo(); loadSecurityForm(); renderLoginHistory(); renderActivityLog(); }
    if (subId === 'setHelp') renderFaq();
  }

  function bindEvents() {
    document.querySelectorAll('#settingsSubnav .st-tab').forEach((tab) => tab.addEventListener('click', () => switchSubTab(tab.dataset.ssub)));

    document.getElementById('saveCompanyBtn').addEventListener('click', saveCompanyProfile);

    document.getElementById('addUserBtn').addEventListener('click', openAddUserModal);
    document.getElementById('myAccountSaveBtn').addEventListener('click', handleMyAccountSave);
    document.getElementById('requestPasswordChangeBtn').addEventListener('click', () => requestCredentialChange('password'));
    document.getElementById('requestEmailChangeBtn').addEventListener('click', () => {
      const newEmail = prompt('Enter the new email you want to switch to:');
      if (newEmail && newEmail.trim()) requestCredentialChange('email', newEmail.trim());
    });
    document.getElementById('savePinBtn').addEventListener('click', handleSavePin);
    wireShowPasswordToggle('showMyAccountPasswordChk', ['myCurrentPassword', 'myNewPassword']);
    wireShowPasswordToggle('showPinChk', ['securityPinCurrent', 'securityPinNew']);
    wireShowPasswordToggle('showUserPasswordChk', ['userPassword']);
    document.getElementById('userModalCloseBtn').addEventListener('click', closeUserModal);
    document.getElementById('userCancelBtn').addEventListener('click', closeUserModal);
    document.getElementById('userSaveBtn').addEventListener('click', handleSaveUser);
    document.getElementById('userModalOverlay').addEventListener('click', (e) => { if (e.target.id === 'userModalOverlay') closeUserModal(); });

    document.getElementById('saveBusinessBtn').addEventListener('click', saveBusinessSettings);

    document.getElementById('runImportBtn').addEventListener('click', runImport);
    document.getElementById('exportCsvSettingsBtn').addEventListener('click', () => exportModuleAs('csv'));
    document.getElementById('exportExcelSettingsBtn').addEventListener('click', () => exportModuleAs('excel'));
    document.getElementById('exportJsonSettingsBtn').addEventListener('click', () => exportModuleAs('json'));

    document.getElementById('downloadBackupBtn').addEventListener('click', exportFullBackup);
    document.getElementById('restoreBackupBtn').addEventListener('click', restoreFromBackup);

    document.getElementById('clearDemoBtn').addEventListener('click', checkDemoData);
    document.getElementById('deleteNotifsBtn').addEventListener('click', deleteAllNotifications);
    document.getElementById('archiveOldBtn').addEventListener('click', archiveOldNotifications);
    document.getElementById('resetDbBtn').addEventListener('click', resetDatabase);

    document.getElementById('lightModeBtn').addEventListener('click', () => { ThemeController.apply('light'); updateThemeModeChips(); });
    document.getElementById('darkModeBtn').addEventListener('click', () => { ThemeController.apply('dark'); updateThemeModeChips(); });
    document.getElementById('saveAppSettingsBtn').addEventListener('click', saveAppSettings);

    document.getElementById('saveSecurityBtn').addEventListener('click', saveSecuritySettings);
  }

  function onPageShow() {
    const activeTab = document.querySelector('#settingsSubnav .st-tab.active');
    switchSubTab(activeTab ? activeTab.dataset.ssub : 'setCompany');
  }

  /**
   * Re-applies persisted appearance preferences on every app load — fixes
   * the gap where Compact Sidebar / Theme Color only took effect while
   * actively viewing Settings, not on a fresh reload/session.
   */
  function applyPersistedAppearance() {
    const a = loadJson(KEYS.app, {});
    if (a.compactSidebar) {
      const sidebar = document.querySelector('.sidebar');
      if (sidebar) sidebar.style.width = '72px';
    }
    if (a.themeColor) {
      document.documentElement.style.setProperty('--brand-primary', a.themeColor);
    }
  }

  function init() {
    loadAll();
    bindEvents();
    applyPersistedAppearance();
  }

  /** Standalone version of the backfill, safe to call from anywhere
   *  (e.g. AccessController) without depending on SettingsController's
   *  own init() having already run — does its own fresh cloud fetch,
   *  fills in any roles/modules missing from what's stored, saves if
   *  anything changed, and returns the complete, up-to-date map. This
   *  is what guarantees a newly-added role's permissions are actually
   *  in place before that person's own first login tries to read them. */
  async function ensurePermissionsBackfilled() {
    let perms = null;
    try { perms = await CloudSync.getDocOnce('fh_role_permissions'); } catch (e) { perms = null; }
    if (!perms) { try { perms = JSON.parse(localStorage.getItem(KEYS.perms)); } catch (e) { perms = null; } }
    if (!perms) { return seedDefaultPermissions(); }
    return backfillPermissions(perms);
  }

  return { init, onPageShow, reload: () => { loadAll(); renderUsers(); }, ensurePermissionsBackfilled };
})();
