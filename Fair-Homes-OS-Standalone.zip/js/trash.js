/* ==========================================================================
   Fair Homes OS — Trash / Restore System
   Every "Delete" in the app moves the record here first instead of wiping
   it immediately. From Settings → Trash, anything can be restored back to
   its original module, or permanently removed. One shared system used by
   every module (Owners, Properties, Rooms, Beds, Tenants, Finance entries,
   Maintenance Tickets, Task Reminders, Users) — not a separate trash per
   module.
   ========================================================================== */

const TrashController = (() => {
  const KEY = 'fh_trash';
  let trash = [];

  // Maps a store type to (a) the localStorage key holding its live array
  // and (b) which controller to refresh after a restore.
  const STORE_CONFIG = {
    owner: { key: 'fh_owners', collection: 'owners', label: 'Owner', reload: () => window.OwnersController?.reload?.() },
    property: { key: 'fh_properties', collection: 'properties', label: 'Property', reload: () => window.PropertiesController?.reload?.() },
    room: { key: 'fh_rooms', collection: 'rooms', label: 'Room', reload: () => window.RoomsController?.reload?.() },
    tenant: { key: 'fh_tenants', collection: 'tenants', label: 'Tenant', reload: () => window.TenantsController?.reload?.() },
    rentEntry: { key: 'fh_rent_entries', collection: 'rentEntries', label: 'Rent Entry', reload: () => window.FinanceController?.reload?.() },
    deposit: { key: 'fh_deposits', collection: 'deposits', label: 'Deposit', reload: () => window.FinanceController?.reload?.() },
    brokerage: { key: 'fh_brokerage', collection: 'brokerageEntries', label: 'Brokerage Entry', reload: () => window.FinanceController?.reload?.() },
    managementFee: { key: 'fh_management_fees', collection: 'managementFees', label: 'Management Fee', reload: () => window.FinanceController?.reload?.() },
    expense: { key: 'fh_expenses', collection: 'expenses', label: 'Expense', reload: () => window.FinanceController?.reload?.() },
    ticket: { key: 'fh_tickets', collection: 'tickets', label: 'Maintenance Ticket', reload: () => window.MaintenanceController?.reload?.() },
    task: { key: 'fh_task_reminders', collection: 'taskReminders', label: 'Task Reminder', reload: () => window.NotificationsController?.reload?.() },
    user: { key: 'fh_users', collection: 'users', label: 'User', reload: () => window.SettingsController?.reload?.() },
    brokerageFlat: { key: 'fh_brokerage_flats', collection: 'brokerageFlats', label: 'Brokerage-Only Flat', reload: () => window.BrokerageFlatsController?.reload?.() },
    socialMediaTask: { key: 'fh_social_media_tasks', collection: 'socialMediaTasks', label: 'Social Media Task', reload: () => window.SocialMediaController?.reload?.() },
    booking: { key: 'fh_bookings', collection: 'bookings', label: 'Booking', reload: () => window.BookingsController?.reload?.() },
  };

  function load() {
    try { trash = JSON.parse(localStorage.getItem(KEY)) || []; } catch (e) { trash = []; }
    CloudSync.watch('trash', (arr) => {
      trash = arr;
      localStorage.setItem(KEY, JSON.stringify(trash));
      renderTrashList();
    });
  }
  function persist() {
    localStorage.setItem(KEY, JSON.stringify(trash));
    CloudSync.sync('trash', trash);
  }
  function generateId() { return (crypto.randomUUID ? crypto.randomUUID() : 'trash_' + Date.now() + '_' + Math.random().toString(16).slice(2)); }
  function esc(str) { if (str === null || str === undefined) return ''; return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
  function fmtDateTime(iso) { const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }

  /**
   * Call this instead of directly splicing an array before persisting a
   * delete. `storeType` must be one of the STORE_CONFIG keys above.
   * `record` is the full object being deleted. `label` is a short
   * human-readable name shown in the Trash list (e.g. a tenant's name).
   */
  function moveToTrash(storeType, record, label) {
    trash.unshift({
      id: generateId(), storeType, record, label: label || STORE_CONFIG[storeType]?.label || 'Item',
      deletedAt: new Date().toISOString(),
    });
    persist();
  }

  function restore(trashId) {
    const item = trash.find((t) => t.id === trashId);
    if (!item) return false;
    const cfg = STORE_CONFIG[item.storeType];
    if (!cfg) return false;
    let arr = [];
    try { arr = JSON.parse(localStorage.getItem(cfg.key)) || []; } catch (e) { arr = []; }
    arr.unshift(item.record);
    localStorage.setItem(cfg.key, JSON.stringify(arr));
    CloudSync.sync(cfg.collection, arr);
    trash = trash.filter((t) => t.id !== trashId);
    persist();
    cfg.reload();
    return true;
  }

  function permanentlyDelete(trashId) {
    trash = trash.filter((t) => t.id !== trashId);
    persist();
  }

  function emptyTrash() {
    trash = [];
    persist();
  }

  function getAll() { return [...trash]; }

  // ---------------- UI (rendered inside Settings → Trash tab) ----------------
  function renderTrashList() {
    const box = document.getElementById('trashList');
    if (!box) return;
    if (!trash.length) {
      box.innerHTML = '<div class="empty-state"><div class="ico">🗑️</div><div class="title">Trash is empty</div><div class="desc">Deleted items from any module will appear here and can be restored.</div></div>';
      return;
    }
    box.innerHTML = trash.map((t) => `
      <div class="user-row">
        <div>
          <div style="font-weight:700;">${esc(t.label)} <span class="badge status-open" style="margin-left:6px;">${esc(STORE_CONFIG[t.storeType]?.label || t.storeType)}</span></div>
          <div class="sub">Deleted ${fmtDateTime(t.deletedAt)}</div>
        </div>
        <div class="row-actions">
          <button class="btn small secondary tr-restore-btn" data-id="${t.id}">Restore</button>
          <button class="btn small danger tr-perm-btn" data-id="${t.id}" style="background:var(--error); color:#fff;">Delete Forever</button>
        </div>
      </div>`).join('');

    box.querySelectorAll('.tr-restore-btn').forEach((b) => b.addEventListener('click', () => {
      restore(b.dataset.id);
      renderTrashList();
    }));
    box.querySelectorAll('.tr-perm-btn').forEach((b) => b.addEventListener('click', () => {
      ConfirmModal.show('Permanently delete this item? This cannot be undone.', () => {
        permanentlyDelete(b.dataset.id);
        renderTrashList();
      }, 'Delete Forever');
    }));
  }

  function bindEvents() {
    document.getElementById('emptyTrashBtn')?.addEventListener('click', () => {
      if (!trash.length) return;
      ConfirmModal.show(`Permanently delete all ${trash.length} item(s) in Trash? This cannot be undone.`, () => {
        emptyTrash();
        renderTrashList();
      }, 'Empty Trash');
    });
  }

  function onPageShow() { renderTrashList(); }

  function init() {
    load();
    bindEvents();
  }

  return { init, onPageShow, moveToTrash, restore, permanentlyDelete, getAll };
})();
