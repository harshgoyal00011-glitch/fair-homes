/* ==========================================================================
   Fair Homes OS — Cloud Layer (Firebase)
   Initializes Firebase, provides real email/password Authentication (this
   replaces the old UI-only fake login), and a generic CloudSync helper
   that every module's load()/persist() plugs into for real-time,
   offline-capable, multi-device sync — without needing to rewrite each
   module's business logic. Local in-memory arrays stay the source of
   truth for rendering; this layer just keeps them synced with the cloud.
   ========================================================================== */

const firebaseConfig = {
  apiKey: "AIzaSyA1oUMKF-CxzDa1Cu4LcBzBP9PjG9cwbmE",
  authDomain: "fair-homes.firebaseapp.com",
  projectId: "fair-homes",
  storageBucket: "fair-homes.firebasestorage.app",
  messagingSenderId: "383588252380",
  appId: "1:383588252380:web:a925a22eb0969e58eb1219",
  measurementId: "G-0TV74P7FBD"
};

const CloudSync = (() => {
  let app = null, auth = null, db = null;
  let currentUid = null;
  // businessId: the shared data namespace this signed-in account belongs
  // to. NOT the same as currentUid — multiple team members (each their
  // own Firebase Auth account/UID) must all resolve to the SAME
  // businessId so they see the SAME Owners/Properties/Tenants/etc, not
  // each their own empty space keyed by their individual UID.
  let businessId = null;
  const lastKnownState = {}; // collectionName -> Map(docId -> JSON string) — used to diff writes
  const unsubscribers = {}; // collectionName -> unsubscribe function, so re-watching on re-login doesn't double-listen

  function init() {
    app = firebase.initializeApp(firebaseConfig);
    auth = firebase.auth();
    db = firebase.firestore();
    // Offline persistence: Firestore caches data in IndexedDB so the app
    // works fully offline, and automatically re-syncs the moment internet
    // returns — this is what gives "works offline, auto-syncs when online".
    db.enablePersistence({ synchronizeTabs: true }).catch((err) => {
      console.warn('Firestore offline persistence unavailable:', err.code);
    });
  }

  /**
   * Resolves which shared business namespace this signed-in account
   * belongs to, via a ROOT-level lookup (businessMembers/{email}) that
   * is NOT scoped under anyone's UID — any signed-in account can read
   * its own entry there. If no entry exists yet, this account is
   * treated as owning its own business (businessId = their own UID) —
   * this is what correctly preserves an EXISTING Super Admin's data
   * (already living under their own UID from before this concept
   * existed), and is also the correct behavior for a genuinely new
   * business's first-ever sign-up. The lookup entry is created/updated
   * so future logins resolve instantly without guessing.
   */
  async function resolveBusinessId(email) {
    const emailKey = (email || '').toLowerCase().trim();
    if (!emailKey) { businessId = currentUid; return businessId; }
    try {
      const snap = await db.collection('businessMembers').doc(emailKey).get();
      if (snap.exists && snap.data().businessId) {
        businessId = snap.data().businessId;
        return businessId;
      }
    } catch (e) {
      console.warn('resolveBusinessId lookup failed, defaulting to own UID:', e.message);
    }
    // No mapping found — this account owns its own business namespace.
    businessId = currentUid;
    try {
      await db.collection('businessMembers').doc(emailKey).set({ businessId, linkedAt: new Date().toISOString() }, { merge: true });
    } catch (e) { /* non-fatal — resolution still succeeded for this session */ }
    return businessId;
  }

  /** Links another email to THIS account's business namespace — used
   *  when adding a team member, so when THEY sign in, they resolve to
   *  the same shared data instead of getting their own empty space. */
  async function linkEmailToCurrentBusiness(email) {
    const emailKey = (email || '').toLowerCase().trim();
    if (!emailKey || !businessId) return;
    await db.collection('businessMembers').doc(emailKey).set({ businessId, linkedAt: new Date().toISOString() }, { merge: true });
  }

  // ---------------- Authentication ----------------
  function signUp(email, password) { return auth.createUserWithEmailAndPassword(email, password); }
  function signIn(email, password) { return auth.signInWithEmailAndPassword(email, password); }
  function signOutUser() { return auth.signOut(); }
  function onAuthChange(callback) {
    auth.onAuthStateChanged(async (user) => {
      currentUid = user ? user.uid : null;
      if (user) {
        await resolveBusinessId(user.email);
      } else {
        businessId = null;
      }
      callback(user);
    });
  }
  function getCurrentUser() { return auth.currentUser; }
  function sendPasswordReset(email) { return auth.sendPasswordResetEmail(email); }

  // ---------------- Generic collection sync ----------------
  /**
   * Sets up a real-time listener on users/{uid}/{collectionName}. Whenever
   * the cloud data changes — from THIS device's own writes, or from ANY
   * other device signed into the same account — onChange(array) fires
   * with the full up-to-date array, so the module can update its local
   * in-memory state and re-render. This is what makes cross-device sync
   * "on the spot": every device watches the same cloud collection.
   */
  function watch(collectionName, onChange, tag) {
    if (!db || !businessId) return;
    const key = collectionName + '::' + (tag || 'default');
    if (unsubscribers[key]) { unsubscribers[key](); }
    const colRef = db.collection('users').doc(businessId).collection(collectionName);
    unsubscribers[key] = colRef.onSnapshot((snapshot) => {
      const arr = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }));
      const map = new Map(arr.map((item) => [item.id, JSON.stringify(item)]));
      lastKnownState[collectionName] = map; // shared write-diff base is fine even with multiple watchers
      onChange(arr);
    }, (err) => {
      console.warn('CloudSync watch error on', collectionName, err.message);
    });
  }

  /**
   * Diffs `newArray` against the last-known cloud state for this
   * collection and writes/deletes ONLY what actually changed — never the
   * whole array — so a single edit doesn't burn through the daily write
   * quota. Called right after a module's local array is mutated (i.e.
   * from inside its existing persist() function — no other code needs
   * to change).
   */
  function sync(collectionName, newArray) {
    if (!db || !businessId) return;
    const colRef = db.collection('users').doc(businessId).collection(collectionName);
    const prevMap = lastKnownState[collectionName] || new Map();
    const newMap = new Map();

    newArray.forEach((item) => {
      if (!item.id) return;
      const json = JSON.stringify(item);
      newMap.set(item.id, json);
      if (prevMap.get(item.id) !== json) {
        colRef.doc(item.id).set(item).catch((err) => console.warn('CloudSync write failed:', collectionName, err.message));
      }
    });
    prevMap.forEach((_, id) => {
      if (!newMap.has(id)) {
        colRef.doc(id).delete().catch((err) => console.warn('CloudSync delete failed:', collectionName, err.message));
      }
    });
    lastKnownState[collectionName] = newMap;
  }

  /** Stops all active listeners — called on sign-out so a subsequent
   *  different account's data never leaks into a stale listener. */
  function stopAllWatchers() {
    Object.values(unsubscribers).forEach((unsub) => unsub());
    Object.keys(unsubscribers).forEach((k) => delete unsubscribers[k]);
    Object.keys(lastKnownState).forEach((k) => delete lastKnownState[k]);
  }

  // ---------------- Single-document sync (for settings, not lists) ----------------
  const docUnsubscribers = {};
  /** Watches one document (e.g. users/{uid}/settings/company) — used for
   *  single-object settings rather than arrays of records. */
  function watchDoc(docName, onChange) {
    if (!db || !businessId) return;
    if (docUnsubscribers[docName]) docUnsubscribers[docName]();
    const ref = db.collection('users').doc(businessId).collection('settings').doc(docName);
    docUnsubscribers[docName] = ref.onSnapshot((snap) => {
      onChange(snap.exists ? snap.data() : null);
    }, (err) => console.warn('CloudSync watchDoc error on', docName, err.message));
  }
  function syncDoc(docName, data) {
    if (!db || !businessId || !data) return;
    db.collection('users').doc(businessId).collection('settings').doc(docName).set(data)
      .catch((err) => console.warn('CloudSync syncDoc failed:', docName, err.message));
  }

  const ALL_COLLECTIONS = [
    'owners', 'properties', 'rooms', 'tenants', 'bookings', 'brokerageFlats', 'socialMediaTasks',
    'rentEntries', 'deposits', 'brokerageEntries', 'managementFees', 'expenses',
    'marginIncome', 'ownerAdvances', 'businessExpenses', 'ownerPayouts', 'setupExpenses',
    'tickets', 'routineTasks', 'vendorCategories', 'workTypes', 'vendorBills',
    'maids', 'maidAssignments', 'maidAttendance', 'maidPayments', 'electricityBills',
    'notifications', 'taskReminders', 'automationLogs', 'messageTemplates',
    'users', 'trash', 'credentialRequests',
  ];
  const ALL_SETTINGS_DOCS = ['fh_company_profile', 'fh_role_permissions', 'fh_business_settings', 'fh_app_settings', 'fh_security_pin', 'fh_visiting_charge_rule'];

  /** Deletes every document across every collection AND every settings
   *  doc for the signed-in user — used by Settings > Reset Database, so
   *  a reset actually clears the cloud too, not just this device (a
   *  device-only reset would otherwise just get overwritten again the
   *  next time the real-time listeners sync back down from the cloud). */
  async function deleteAllCloudData() {
    if (!db || !businessId) return;
    const userRef = db.collection('users').doc(businessId);
    for (const col of ALL_COLLECTIONS) {
      const snap = await userRef.collection(col).get();
      const batch = db.batch();
      snap.docs.forEach((d) => batch.delete(d.ref));
      if (snap.docs.length) await batch.commit();
    }
    for (const docName of ALL_SETTINGS_DOCS) {
      await userRef.collection('settings').doc(docName).delete().catch(() => {});
    }
    lastKnownState && Object.keys(lastKnownState).forEach((k) => delete lastKnownState[k]);
  }

  /**
   * Creates a real, separate login for a teammate (Manager/Staff/
   * Accountant/etc.) — WITHOUT signing the current admin out. Normally,
   * calling createUserWithEmailAndPassword() on the main app instance
   * immediately switches the active session to the new user, which
   * would kick the admin out mid-setup. Spinning up a short-lived
   * SECONDARY Firebase app instance avoids that entirely, and there's
   * no backend server involved — this all happens client-side.
   */
  async function createTeamMember(email, password) {
    const secondaryApp = firebase.initializeApp(firebaseConfig, 'secondary-' + Date.now());
    try {
      const cred = await secondaryApp.auth().createUserWithEmailAndPassword(email, password);
      const uid = cred.user.uid;
      await secondaryApp.auth().signOut();
      await linkEmailToCurrentBusiness(email);
      return { uid, wasExisting: false };
    } catch (err) {
      if (err.code === 'auth/email-already-in-use') {
        // This email already has a Firebase login (e.g. it was
        // mistakenly bootstrapped into its own separate business
        // namespace by an earlier bug) — don't fail; just repair their
        // business link so they resolve to THIS shared data going
        // forward. No new Auth account needed since one already exists.
        await linkEmailToCurrentBusiness(email);
        return { uid: null, wasExisting: true };
      }
      throw err;
    } finally {
      await secondaryApp.delete();
    }
  }

  /** One-time fetch (not a live listener) — used where code needs the
   *  current cloud state immediately and can't wait for the next
   *  real-time snapshot (e.g. resolving a user's role right at login,
   *  before the regular watchers have necessarily populated anything
   *  yet on a fresh device). */
  async function getOnce(collectionName) {
    if (!db || !businessId) return [];
    const snap = await db.collection('users').doc(businessId).collection(collectionName).get();
    return snap.docs.map((d) => ({ ...d.data(), id: d.id }));
  }

  /** One-time fetch of a single settings document (e.g. role permissions) */
  async function getDocOnce(docName) {
    if (!db || !businessId) return null;
    const snap = await db.collection('users').doc(businessId).collection('settings').doc(docName).get();
    return snap.exists ? snap.data() : null;
  }

  // ---------------- Security PIN (hashed, never stored in plain text) ----------------
  async function hashPin(pin) {
    const data = new TextEncoder().encode('fh-pin-salt-v1:' + pin);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hashBuffer)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  // ---------------- Self-service credential changes (current user only) ----------------
  /** Firebase requires a recent sign-in before allowing sensitive changes
   *  like updatePassword/updateEmail — this re-confirms identity with
   *  their current password first. */
  async function reauthenticate(currentPassword) {
    const user = auth.currentUser;
    if (!user) throw new Error('Not signed in.');
    const cred = firebase.auth.EmailAuthProvider.credential(user.email, currentPassword);
    await user.reauthenticateWithCredential(cred);
  }
  async function changeOwnPassword(currentPassword, newPassword) {
    await reauthenticate(currentPassword);
    await auth.currentUser.updatePassword(newPassword);
  }
  async function changeOwnEmail(currentPassword, newEmail) {
    await reauthenticate(currentPassword);
    await auth.currentUser.updateEmail(newEmail);
  }

  /** Writes ONE document into a collection directly, without touching
   *  any other document in it. Unlike sync() (which diffs a full array
   *  and can DELETE anything missing from that array), this is purely
   *  additive/updating — safe to use for one-off writes like bootstrap,
   *  where accidentally wiping other existing records would be
   *  catastrophic. */
  async function addOneToCollection(collectionName, item) {
    if (!db || !businessId || !item || !item.id) return;
    await db.collection('users').doc(businessId).collection(collectionName).doc(item.id).set(item);
  }

  return {
    init, signUp, signIn, signOutUser, onAuthChange, getCurrentUser, sendPasswordReset,
    watch, sync, stopAllWatchers, watchDoc, syncDoc, deleteAllCloudData, createTeamMember, getOnce, getDocOnce,
    hashPin, reauthenticate, changeOwnPassword, changeOwnEmail, addOneToCollection,
    resolveBusinessId, linkEmailToCurrentBusiness, getBusinessId: () => businessId,
  };
})();
