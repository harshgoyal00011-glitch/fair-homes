# Fair Homes OS — Standalone Copy

This is the project exported from Claude.

## What this project is
- Static Progressive Web App (HTML/CSS/JavaScript)
- Firebase Authentication
- Firebase Firestore for cloud data/sync
- Chart.js, SheetJS (XLSX), and jsPDF loaded from CDNs

## Run on macOS
Do not open `index.html` with `file://` for the full app. Start a local web server.

If Python 3 is installed:
    python3 -m http.server 8080

Then open:
    http://localhost:8080

## Important
Claude is NOT required to run the exported code.

The current app DOES depend on the Firebase project configured in `js/cloud.js`.
That is separate from Claude. If you control that Firebase project, the app can continue using it independently.
If you do not control it, migrate the Firestore data and authentication to a Firebase project you own (or another backend).

## Backup
Keep this entire folder and the original ZIP unchanged as a master backup.
